package pages;

import java.text.MessageFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class PatientConsultationRequestPage {
	private static Logger log = Logger.getLogger(PatientConsultationRequestPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	CommonUtilsPage cmnUtilsPage = new CommonUtilsPage(); 
	final String PatientStateNotListedText = "Not listed";
	
	
	/**
	 * This method is used to fill consultation form for video/phone consultation.
	 * @param visitReason
	 * @param medicines
	 * @param allergies
	 * @param driver
	 * @param hasMeds
	 * @throws Exception
	 */
	public void fillConsultationFormForNewUser(boolean video, String visitReason, String medicines, String allergies, WebDriver driver) throws Exception {
		if(video){
			genLibWeb.clickOnElementByID("patientConsultTypeVideoRdInp.id", driver);
		} else {
			genLibWeb.clickOnElementByID("patientConsultTypePhoneRdInp.id", driver);
			genLibWeb.isElementFoundByXPath("patientPhoneDrpBx.ngModel.xpath", null, driver); //make sure phone drop down list box found
		}
		genLibWeb.enterTextValueByName("patientChiefComplaintInp.name", visitReason, driver);
		//medications
		//enter medications
		if (StringUtils.isNotBlank(medicines)){
			cmnUtilsPage.enterMedications(medicines, "patientMedicationInp.ngModel.xpath", null, "patientMedicationAddBtn.xpath", null, driver);
		}
		//allergies
		//enter allergies
		if (StringUtils.isNotBlank(allergies)){
			cmnUtilsPage.enterAllergies(allergies, "patientAllergyInp.ngModel.xpath", null, "patientAllergyAddBtn.xpath", null, driver);
		}
		//select State if not selected
		if(StringUtils.isBlank(genLibWeb.getSelectOptionTextBySelectElementName("patientStatesDrpBx.name", driver))){
			genLibWeb.selectByVisibleTextFromSelectElementName("patientStatesDrpBx.name", "California", driver); //California
		}
		genLibWeb.clickOnElementByXPath("patientVisitInfoNextBtn.ngClick.xpath", null, driver);
	}
	
	/**
	 * This method is used to fill consultation form for video/phone consultation.
	 * @param visitReason
	 * @param medicines
	 * @param allergies
	 * @param driver
	 * @param hasMeds
	 * @throws Exception
	 */
	public void fillConsultationForm(Boolean video, String visitReason, String medicines, String allergies, WebDriver driver) throws Exception {
		if(video != null) {//can be null for fac pat, as its default video and needs no selection
			if(video){
				genLibWeb.clickOnElementByID("patientConsultTypeVideoRdInp.id", driver);
			} else {
				genLibWeb.clickOnElementByID("patientConsultTypePhoneRdInp.id", driver);
				genLibWeb.isElementFoundByXPath("patientPhoneDrpBx.ngModel.xpath", null, driver); //make sure phone drop down list box found
			}
		}
		genLibWeb.enterTextValueByName("patientChiefComplaintInp.name", visitReason, driver);
//		genLibWeb.clickOnElementByXPath("dependentLogoImg.xpath", null, driver);//the auto drop down remains as it is and so click on logo
		genLibWeb.clickOnElementByID("patAvatarImg.id", driver);
		//medications
		//enter medications
		if (StringUtils.isNotBlank(medicines)){
			//remove all medications
			cmnUtilsPage.removeOldMedications("patientMedicationOldListP.xpath", null, "patientMedicationOldRemoveSpan.xpath", driver);
			cmnUtilsPage.enterMedications(medicines, "patientMedicationInp.ngModel.xpath", null, "patientMedicationAddBtn.xpath", null, driver);
		}
		//allergies
		//enter allergies
		if (StringUtils.isNotBlank(allergies)){
			//remove all allergies
			cmnUtilsPage.removeOldAllergies("patientAllergyOldListP.xpath", null, "patientAllergyOldRemoveSpan.xpath", driver);
			cmnUtilsPage.enterAllergies(allergies, "patientAllergyInp.ngModel.xpath", null, "patientAllergyAddBtn.xpath", null, driver);
		}
		//select State if not selected
		if(StringUtils.isBlank(genLibWeb.getSelectOptionTextBySelectElementName("patientStatesDrpBx.name", driver))){
			genLibWeb.selectByVisibleTextFromSelectElementName("patientStatesDrpBx.name", "California", driver); //California
		}
		genLibWeb.clickOnElementByXPath("patientVisitInfoNextBtn.ngClick.xpath", null, driver);
	}
	
	public void fillConsultationFormWithValidations(boolean video, String visitReason, String medicines, String allergies, WebDriver driver) throws Exception {
		//validate consultation type - video or phone not selected - required field 
		validateRequiredFieldOnConsultForm("Consultation Type", driver);
		if(video){
			genLibWeb.clickOnElementByID("patientConsultTypeVideoRdInp.id", driver);
		} else {
			genLibWeb.clickOnElementByID("patientConsultTypePhoneRdInp.id", driver);
			genLibWeb.isElementFoundByXPath("patientPhoneDrpBx.ngModel.xpath", null, driver); //make sure phone drop down list box found
		}
		//validate reason for visit - required field 
		validateRequiredFieldOnConsultForm("Reason for Visit", driver);
		genLibWeb.enterTextValueByName("patientChiefComplaintInp.name", visitReason, driver);
		//medications with validation
		//enter medications
		if (StringUtils.isNotBlank(medicines)){
			//remove all medications
			cmnUtilsPage.removeOldMedications("patientMedicationOldListP.xpath", null, "patientMedicationOldRemoveSpan.xpath", driver);
			if(!cmnUtilsPage.enterMedications(medicines, "patientMedicationInp.ngModel.xpath", null, "patientMedicationAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Medications were NOT added");				
				Assert.fail("One of the Medications were NOT added");		
			}
			log.info("All Medications were added");
		}
		//allergies with validation		
		//enter allergies
		if (StringUtils.isNotBlank(allergies)){
			//remove all allergies
			cmnUtilsPage.removeOldAllergies("patientAllergyOldListP.xpath", null, "patientAllergyOldRemoveSpan.xpath", driver);
			if(!cmnUtilsPage.enterAllergies(allergies, "patientAllergyInp.ngModel.xpath", null, "patientAllergyAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Allergies were NOT added");				
				Assert.fail("One of the Allergies were NOT added");		
			}
			log.info("All  Allergies were added");
		}
		//validate location - required field
		if(StringUtils.isBlank(genLibWeb.getSelectOptionTextBySelectElementName("patientStatesDrpBx.name", driver))){
			validateRequiredFieldOnConsultForm("Location State", driver);// required			
			genLibWeb.selectByVisibleTextFromSelectElementName("patientStatesDrpBx.name", "California", driver); //California
		} 
		//validate location - service not available
		validateStateServiceNotAvailable(driver);
		Thread.sleep(1000);
		genLibWeb.selectByVisibleTextFromSelectElementName("patientStatesDrpBx.name", "California", driver); //California
		genLibWeb.clickOnElementByXPath("patientVisitInfoNextBtn.ngClick.xpath", null, driver);		
	}

	/**
	 * This method is used to add child/dependent
	 * @param driver
	 * @throws Exception 
	 */
	public void clickAddChild(WebDriver driver) throws Exception {
		if(!genLibWeb.explicitWaitUntilElementWithIDIsVisible("patientAddDependentI.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Add child option NOT found");				
			Assert.fail("Add child option NOT found");			
		}
		log.info("Add child option Found");
		genLibWeb.clickOnElementByID("patientAddDependentI.id", driver);
	}
	
	/**
	 * This method is used to select an existing dependent
	 * @param driver
	 * @param dependentFName
	 * @param dependentLName
	 * @throws Exception 
	 */
	public void selectExistingDependent(String dependentFName, String dependentLName, WebDriver driver) throws Exception {
		int numOfDependents = genLibWeb.getNumberOfElementsByXPath("dependentListDiv.xpath", null, driver);//UI shows the patient in dependent section as hidden, when not selected
		String foundDepenCount = null;
		if(!(numOfDependents > 0) ){
			TestCaseInit.testCaseStatus = false;
			log.error("NO dependents found for the patient");	
			Assert.fail("NO dependents found for the patient");
		}
		boolean found = false;
		while(!found){
			for(int i=0; i<numOfDependents; i++){
				String depenCount = Integer.toString(i);				
				String dependNameTxt = genLibWeb.getTextByID(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("dependentNameP.id"), depenCount), driver);				
				if(StringUtils.isNotBlank(dependNameTxt) 
						&& (StringUtils.containsIgnoreCase(dependNameTxt, dependentFName) && StringUtils.containsIgnoreCase(dependNameTxt, dependentLName))){
					foundDepenCount = depenCount;
					found = true;
					break;
				}
			}
			if(!found || StringUtils.isBlank(foundDepenCount)) {
				TestCaseInit.testCaseStatus = false;
				log.error("NO dependents matched the specified name, first name: "+dependentFName+" and last name: "+dependentLName+" for the patient");	
				Assert.fail("NO dependents matched the specified name, first name: "+dependentFName+" and last name: "+dependentLName+" for the patient");	
			} else{
				genLibWeb.clickOnElementByID(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("dependentAvatarImg.id"), foundDepenCount), driver);
			}
		}
	}

	//Helpers
	private void validateStateServiceNotAvailable(WebDriver driver) throws Exception {
		//select last element, which is 'Not Listed'
		genLibWeb.selectByVisibleTextFromSelectElementName("patientStatesDrpBx.name", PatientStateNotListedText, driver);
		if(!genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patientStatesNotlistedPopUpP.xpath", null, driver)) {
			TestCaseInit.testCaseStatus = false;
			log.error("State not-listed popup message NOT displayed");				
			Assert.fail("State not-listed popup message NOT displayed");	
		}
		log.info("State not-listed popup message displayed");
		genLibWeb.clickOnElementByXPath("patientStatesNotlistedPopUpOkBtn.ngClick.xpath", null, driver);
	}

	private void validateRequiredFieldOnConsultForm(String field, WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByXPath("patientVisitInfoNextBtn.ngClick.xpath", null, driver);
		if(!genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patientLandingPageH1.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Missing required field: "+ field);				
			Assert.fail("Missing required field: "+ field);				
		}
	}
}
