package pages;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class AdminOtherElemsPreviousConsultsPage {
	static Logger log = Logger.getLogger(AdminOtherElemsPreviousConsultsPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	
	/**
	 * This method is used to verify if on Admin Other Elements: Previous Consults Page
	 */	
	public boolean verifyOnAdminOtherElemsPrevConsultsPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminOthrElemsPrevConsultsTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin Other Elements: Previous Consults Page
	 */
	public void verifyNValidateOnAdminOtherElemsPrevConsultsPage(WebDriver driver)throws Exception {
		if(!verifyOnAdminOtherElemsPrevConsultsPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Admin Other Elements: Previous Consults Page");
			Assert.fail("NOT on Admin Other Elements: Previous Consults Page");
		}		
		log.info("On Admin Other Elements: Previous Consults Page");
	}
	
	public void verifyRefundSuccessOnPrevConsults(String patEmail, String docName, WebDriver driver) throws Exception{
		searchByPatEmail(patEmail, driver);
		lookUpPrevConsultWithRefundStatus(VMedixUtils.REFUND_STATUS_SUCCESS, docName, driver);
		log.info("Previous Consult found");
	}
	
	public void verifyRefundRejectedOnPrevConsults(String patEmail, String docName, WebDriver driver) throws Exception{
		searchByPatEmail(patEmail, driver);
		lookUpPrevConsultWithRefundStatus(VMedixUtils.REFUND_STATUS_REJECTED, docName, driver);
		log.info("Previous Consult found");
	}

	public void searchByPatEmail(String patEmail, WebDriver driver) throws Exception{
		genLibWeb.enterTextValueByID("docAdminOthrElemsPrevConsultsSearchInp.id", patEmail, driver);
		genLibWeb.clickOnElementByID("docAdminOthrElemsPrevConsultsSearchBtn.id", driver);
		Thread.sleep(3000);
	}
	
	public void viewPrevConsult(String docName, WebDriver driver) throws Exception{
		int countPrevConsults = genLibWeb.getNumberOfElementsByXPath("docAdminOthrElemsPrevConsultsRowsFetchedTrs.xpath", null, driver)-1;
		if(!(countPrevConsults > 0) ){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Previous Consults found");	
			Assert.fail("NO Previous Consults found");
		}
		boolean found = false;
		DateFormat dateFormtr = new SimpleDateFormat("MMMM dd, yyyy hh:mm a");
		while(!found){
			for(int i=0; i<countPrevConsults; i++){
				String rowCount = Integer.toString(i);
				String dateXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminOthrElemsPrevConsultsDateTd.xpath"), rowCount);
				String docNameXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminOthrElemsPrevConsultsDocNameTd.xpath"), rowCount);
				String viewConsultXpathVal =  MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminOthrElemsPrevConsultsViewConsultLinkAnc.xpath"), rowCount);
				String datetxtRetrivedWthBr = genLibWeb.getTextByXPath(null, dateXpathVal, driver);
				String[] dateSplitArr = datetxtRetrivedWthBr.split("\\n"); 
				Date dateRetrieved = dateFormtr.parse(dateSplitArr[0] + " " +dateSplitArr[1]);
				if(dateRetrieved.compareTo(dateFormtr.parse(PatientConsultationRequestPaymentPage.beforeConsultPaymentDateTime)) >= 0
						&& docName.equalsIgnoreCase(genLibWeb.getTextByXPath(null, docNameXpathVal, driver))){
					genLibWeb.clickOnElementByXPath(null, viewConsultXpathVal, driver);
					found = true;
					break;
				}
			}
			if(!found){
				//search on next page
				if(!genLibWeb.isElementEnabledByXPath("nextBtnOnPages.ngClick.xpath", null, driver)){
					TestCaseInit.testCaseStatus = false;
					log.error("NO Previous Consult found");	
					Assert.fail("NO Previous Consult found");					
				} else {
					genLibWeb.clickOnElementByXPath("nextBtnOnPages.ngClick.xpath", null, driver);
					Thread.sleep(5000);
					countPrevConsults = genLibWeb.getNumberOfElementsByXPath("docAdminOthrElemsPrevConsultsRowsFetchedTrs.xpath", null, driver)-1;
				}
			}		
		}
	}
	
	private void lookUpPrevConsultWithRefundStatus(String refundStatus, String docName, WebDriver driver) throws Exception{
		int countPrevConsults = genLibWeb.getNumberOfElementsByXPath("docAdminOthrElemsPrevConsultsRowsFetchedTrs.xpath", null, driver)-1;
		if(!(countPrevConsults > 0) ){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Previous Consults found");	
			Assert.fail("NO Previous Consults found");
		}
		boolean found = false;
		DateFormat dateFormtr = new SimpleDateFormat("MMMM dd, yyyy hh:mm a");
		while(!found){
			for(int i=0; i<countPrevConsults; i++){
				String rowCount = Integer.toString(i);
				String dateXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminOthrElemsPrevConsultsDateTd.xpath"), rowCount);
				String docNameXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminOthrElemsPrevConsultsDocNameTd.xpath"), rowCount);
				String refundStatusXpathVal =  MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminOthrElemsPrevConsultsRefundStatusTd.xpath"), rowCount);
				String datetxtRetrivedWthBr = genLibWeb.getTextByXPath(null, dateXpathVal, driver);
				String[] dateSplitArr = datetxtRetrivedWthBr.split("\\n"); 
				Date dateRetrieved = dateFormtr.parse(dateSplitArr[0] + " " +dateSplitArr[1]);				
				if(dateRetrieved.compareTo(dateFormtr.parse(PatientConsultationRequestPaymentPage.beforeConsultPaymentDateTime)) >= 0
						&& docName.equalsIgnoreCase(genLibWeb.getTextByXPath(null, docNameXpathVal, driver))
						&& refundStatus.equalsIgnoreCase(genLibWeb.getTextByXPath(null, refundStatusXpathVal, driver))){						
					found = true;
					break;
				}
			}
			if(!found){
				//search on next page
				if(!genLibWeb.isElementEnabledByXPath("nextBtnOnPages.ngClick.xpath", null, driver)){
					TestCaseInit.testCaseStatus = false;
					log.error("NO Previous Consult found");	
					Assert.fail("NO Previous Consult found");					
				} else {
					genLibWeb.clickOnElementByXPath("nextBtnOnPages.ngClick.xpath", null, driver);
					Thread.sleep(5000);
					countPrevConsults = genLibWeb.getNumberOfElementsByXPath("docAdminOthrElemsPrevConsultsRowsFetchedTrs.xpath", null, driver)-1;
				}
			}		
		}
	}
}
