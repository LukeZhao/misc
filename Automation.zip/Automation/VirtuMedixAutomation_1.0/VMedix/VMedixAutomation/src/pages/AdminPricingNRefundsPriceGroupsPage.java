package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class AdminPricingNRefundsPriceGroupsPage {
	static Logger log = Logger.getLogger(AdminPricingNRefundsPriceGroupsPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	public AdminPricNRefPriceGrpsNewPage adminNewPriceGrp = new AdminPricNRefPriceGrpsNewPage();
	/**
	 * This method is used to verify if on Admin Pricing N Refunds: Price Groups Page
	 */	
	public boolean verifyOnAdminPricingNRefundsPriceGroupsPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminPricingNRefundPriceGroupsTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin Pricing N Refunds: Price Groups Page
	 */
	public void verifyNValidateOnAdminPricingNRefundsPriceGroupsPage(WebDriver driver)throws Exception {
		if(!verifyOnAdminPricingNRefundsPriceGroupsPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Admin Pricing N Refunds: Price Groups Page");
			Assert.fail("NOT on Admin Pricing N Refunds: Price Groups Page");
		}		
		log.info("On Admin Pricing N Refunds: Price Groups Page");
	}
	
	public void addNewPriceGroup(String priceGrpName, String priceGrpId, String price, String memberId, WebDriver driver) throws Exception {
		//Click add new
		if(genLibWeb.explicitWaitUntilElementWithIDIsVisible("docAdminPricingNRefundPriceGroupsAddNewLinkAnc.id", driver)){
			genLibWeb.clickOnElementByID("docAdminPricingNRefundPriceGroupsAddNewLinkAnc.id", driver);
		}
		adminNewPriceGrp.verifyNValidateOnAdminNewPriceGrpsPage(driver);
		adminNewPriceGrp.submitNewPriceGroup(priceGrpName, priceGrpId, price, memberId, driver);
	}
	
	public void verifyInPriceGroupList(String priceGrpName, String priceGrpId, String price, WebDriver driver) throws Exception {
		//search by name
		genLibWeb.enterTextValueByID("docAdminPricingNRefundPriceGroupsSearchInp.id", priceGrpName, driver);
		genLibWeb.clickOnElementByID("docAdminPricingNRefundPriceGroupsSearchBtn.id", driver);
		Thread.sleep(1000);
		if(!genLibWeb.getTextByXPath("docAdminPrcNRefFirstGrpIdTdAnc.xpath", null, driver).equalsIgnoreCase(priceGrpId)
				|| !genLibWeb.getTextByXPath("docAdminPrcNRefFirstGrpNameTdAnc.xpath", null, driver).equalsIgnoreCase(priceGrpName)
				|| !genLibWeb.getTextByXPath("docAdminPrcNRefFirstGrpPriceTd.xpath", null, driver).equalsIgnoreCase(price)){
			TestCaseInit.testCaseStatus = false;
			log.error("Price Group NOT in the List: " + priceGrpName);
			Assert.fail("Price Group NOT in the List: " + priceGrpName);			
		}
		log.info("Price Group in the List: " + priceGrpName);
	}
}
