package pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.BussinessLib;
import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class PatientConsultationRequestPaymentPage {	
	private static Logger log = Logger.getLogger(PatientConsultationRequestPaymentPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	BussinessLib bussLib = new BussinessLib();	
	public static String beforeConsultPaymentDateTime = null;
	
	/**
	 * This method is used to verify if on HealthInfo page
	 */	
	public boolean verifyPatientOnPaymentPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultPaymentPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on HealthInfo page
	 */
	public void verifyNValidatePatientOnPaymentPage(WebDriver driver) throws Exception {
		if(!verifyPatientOnPaymentPage(driver)){
			TestCaseInit.testCaseStatus = false;
			log.info("Patient is NOT on the Payment page");
			Assert.fail("Patient is NOT on the Payment page");
		}
		log.info("Patient is on the Payment page");
	}	
	
	/**
	 * This function is used to make payment for consultation.
	 * @param debitCardNo
	 * @param expirationMonthValid
	 * @param expirationYear
	 * @param cardSecurity
	 * @param driver
	 * @throws Exception
	 */
	public void enterInfoOnPaymentPage(String cCardNo, String expMon, String expYear, String cVC, WebDriver driver) throws Exception {
		try {
			verifyNValidatePatientOnPaymentPage(driver);
			enterPaymentInfo(cCardNo, expMon, expYear, cVC, driver);
			checkAgreements(driver);
			clickConsultPaymentNextBtn(driver);
		} catch (Exception e) {	
			log.info(e);
			log.error("Failed to check Payment page with all details");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to fill and submit Payment page due to : "+e);
		}
	}
	
	/**
	 * This function is used to make payment for consultation with values auto generated.
	 * @param debitCardNo
	 * @param expirationMonthValid
	 * @param expirationYear
	 * @param cardSecurity
	 * @param driver
	 * @throws Exception
	 */
	public void enterAutoInfoOnPaymentPage(WebDriver driver) throws Exception {
		try {
			verifyNValidatePatientOnPaymentPage(driver);
			//auto generate card exp month(same month) and year(1 year ahead) from current date
			enterAutoPaymentInfo(driver);
			checkAgreements(driver);
			clickConsultPaymentNextBtn(driver);
		} catch (Exception e) {	
			log.info(e);
			log.error("Failed to check Payment page with all details");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to fill and submit Payment page due to : "+e);
		}
	}
	
	/**
	 * This function is used to make payment for consultation with values auto generated with coupon.
	 * @param coupon
	 * @param price
	 * @param driver
	 * @throws Exception
	 */
	public void enterAutoInfoOnPaymentWithCoupon(String coupon, String price, WebDriver driver) {
		try {
			verifyNValidatePatientOnPaymentPage(driver);
			applyCoupon(coupon, driver);
			if(!StringUtils.containsIgnoreCase(getConsultationFee(driver), price)){
				TestCaseInit.testCaseStatus = false;
				log.error("Consultation Fee same as Coupon price NOT displayed, "+ price);
				Assert.fail("Consultation Fee same as Coupon price NOT displayed, "+ price);	
			}
			log.info("Consultation Fee same as Coupon price is displayed, "+ price);
			//auto generate card exp month(same month) and year(1 year ahead) from current date
			enterAutoPaymentInfo(driver);
			checkAgreements(driver);
			clickConsultPaymentNextBtn(driver);
		} catch (Exception e) {	
			log.info(e);
			log.error("Failed to check Payment page with all details");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to fill and submit Payment page due to : "+e);
		}
	}	
	
	public void enterAutoInfoOnPaymentWithInvalidPriceGroupNEdited(String priceGroupId, String memberId, String priceGrpAmount, WebDriver driver) throws Exception {
		try{
			verifyNValidatePatientOnPaymentPage(driver);
			String badGrpId = priceGroupId+VMedixUtils.generateDynamicString();
			applyPriceGroup(badGrpId, memberId, driver);//bad grp id
			//verify invalid price group
			Thread.sleep(1000);
			String invalidGrpDisplayTxt = genLibWeb.getTextByXPath("patConsultPaymentPriceGrpInvalidB.xpath", null, driver);
			if(!(StringUtils.containsIgnoreCase(invalidGrpDisplayTxt, "invalid") && StringUtils.containsIgnoreCase(invalidGrpDisplayTxt, badGrpId))){
				TestCaseInit.testCaseStatus = false;
				log.error("Invalid Price Group NOT displayed, "+ badGrpId);
				Assert.fail("Invalid Price Group NOT displayed, "+ badGrpId);	
			} 
			log.info("Invalid Price Group Displayed, "+ badGrpId);
			//edit and apply correct price group
			if(!genLibWeb.isElementFoundByXPath("patConsultPaymentPriceGrpInvalidEditLincAnc.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("Edit option NOT provided for invalid Price Group");
				Assert.fail("Edit option NOT provided for invalid Price Group");	
			} 
			log.info("Edit option Provided for invalid Price Group");			
			editPriceGroup(priceGroupId, memberId, driver);
			//verify price group amount
			Thread.sleep(1500);
			if(!StringUtils.containsIgnoreCase(getConsultationFee(driver), priceGrpAmount)){
				TestCaseInit.testCaseStatus = false;
				log.error("Consultation Fee same as Price Group amount NOT displayed, "+ priceGrpAmount);
				Assert.fail("Consultation Fee same as Price Group amount NOT displayed, "+ priceGrpAmount);	
			}
			log.info("Consultation Fee same as Price Group amount is displayed, "+ priceGrpAmount);
			//auto generate card exp month(same month) and year(1 year ahead) from current date
			enterAutoPaymentInfo(driver);
			checkAgreements(driver);
			clickConsultPaymentNextBtn(driver);
		} catch (Exception e) {	
			log.info(e);
			log.error("Failed to check Payment page with all details");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to fill and submit Payment page due to : "+e);
		}
	}
	
	public void enterAutoInfoOnPaymentWithValidPriceGroup(String priceGroupId, String memberId, String priceGrpAmount, WebDriver driver) throws Exception {
		try{
			verifyNValidatePatientOnPaymentPage(driver);
			applyPriceGroup(priceGroupId, memberId, driver);
			Thread.sleep(1000);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastTitleMsg.xpath", null, driver);
			String toastMsg = genLibWeb.getTextByXPath("toastTitleMsg.xpath", null, driver);		
			if(!TestCaseInit.messagesVMedixProp.getProperty("priceGroupApplied.success").equals(toastMsg)) { 
				TestCaseInit.testCaseStatus = false;
				log.error("Price Group NOT applied, price group: "+ priceGroupId + "; member id: " + memberId);
				Assert.fail("Price Group NOT applied, price group: "+ priceGroupId + "; member id: " + memberId);
			}
			log.info("Price Group Applied, price group: "+ priceGroupId + "; member id: " + memberId);	
			//verify price group amount
			if(!StringUtils.containsIgnoreCase(getConsultationFee(driver), priceGrpAmount)){
				TestCaseInit.testCaseStatus = false;
				log.error("Consultation Fee same as Price Group amount NOT displayed, "+ priceGrpAmount);
				Assert.fail("Consultation Fee same as Price Group amount NOT displayed, "+ priceGrpAmount);	
			}
			log.info("Consultation Fee same as Price Group amount is displayed, "+ priceGrpAmount);
			//auto generate card exp month(same month) and year(1 year ahead) from current date
			enterAutoPaymentInfo(driver);
			checkAgreements(driver);
			clickConsultPaymentNextBtn(driver);
		} catch (Exception e) {	
			log.info(e);
			log.error("Failed to check Payment page with all details");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to fill and submit Payment page due to : "+e);
		}
	}

	public void clickConsultPaymentNextBtn(WebDriver driver) throws Exception {
		DateFormat dateFormtr = new SimpleDateFormat("MMMM dd, yyyy hh:mm a");
		beforeConsultPaymentDateTime = dateFormtr.format(new Date());
		genLibWeb.clickOnElementByName("patConsultPaymentNextBtn.name", driver);
		Thread.sleep(4000); //wait to process payment		
	}

	/**
	 * This method is used to verify if on apply Coupon PopUp Page
	 */	
	public boolean verifyPatientOnCouponPopUp(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultPaymentCouponPopUpH2.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on apply Coupon PopUp Page
	 */
	public void verifyNValidatePatientOnCouponPopUp(WebDriver driver) throws Exception {
		if(!verifyPatientOnCouponPopUp(driver)){
			TestCaseInit.testCaseStatus = false;
			log.info("Patient is NOT on apply Coupon PopUp Page");
			Assert.fail("Patient is NOT on apply Coupon PopUp Page");
		}
		log.info("Patient is on apply Coupon PopUp Page");
	}
	
	private void applyCoupon(String coupon, WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("patConsultPaymentCouponsNOthersBtn.id", driver);
		genLibWeb.clickOnElementByID("patConsultPaymentAddCouponLinkAnc.id", driver);
		verifyNValidatePatientOnCouponPopUp(driver);
		genLibWeb.enterTextValueByXPath("patConsultPaymentCouponPopUpCodeInp.ngModel.xpath", null, coupon, driver);
		genLibWeb.clickOnElementByXPath("patConsultPaymentCouponPopUpApplyBtn.ngClick.xpath", null, driver);		
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);		
		if(!TestCaseInit.messagesVMedixProp.getProperty("couponApplied.success").equals(toastMsg)) { 
			TestCaseInit.testCaseStatus = false;
			log.error("Coupon NOT applied, "+ coupon);
			Assert.fail("Coupon NOT applied, "+ coupon);
		}
		log.info("Coupon Applied, "+ coupon);
	}	
	
	/**
	 * This method is used to verify if on apply Price Group PopUp Page
	 */	
	public boolean verifyPatientOnPriceGroupPopUp(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultPaymentPriceGrpPopUpH2.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on apply Price Group PopUp Page
	 */
	public void verifyNValidatePatientOnPriceGroupPopUp(WebDriver driver) throws Exception {
		if(!verifyPatientOnPriceGroupPopUp(driver)){
			TestCaseInit.testCaseStatus = false;
			log.info("Patient is NOT on apply Price Group PopUp Page");
			Assert.fail("Patient is NOT on apply Price Group PopUp Page");
		}
		log.info("Patient is on apply Price Group PopUp Page");
	}
	
	private void applyPriceGroup(String priceGroupId, String memberId, WebDriver driver) throws Exception {
		applyPriceGroup(false, priceGroupId, memberId, driver);
	}
	
	private void editPriceGroup(String priceGroupId, String memberId, WebDriver driver) throws Exception {
		applyPriceGroup(true, priceGroupId, memberId, driver);
	}
	
	private void applyPriceGroup(Boolean forEdit, String priceGroupId, String memberId, WebDriver driver) throws Exception {
		//verify if coupon and payment options already displayed
		if(!forEdit){
			if(genLibWeb.isElementFoundByXPath("patConsultPaymentCouponsNOthersPlusSpan.xpath", null, driver)){
				genLibWeb.clickOnElementByID("patConsultPaymentCouponsNOthersBtn.id", driver);			
			}
			if(genLibWeb.isElementFoundByXPath("patConsultPaymentPriceGrpInvalidEditLincAnc.xpath", null, driver)){//previously invalid
				genLibWeb.clickOnElementByXPath("patConsultPaymentPriceGrpInvalidEditLincAnc.xpath", null, driver);
			}else if(genLibWeb.isElementFoundByXPath("patConsultPaymentPriceGrpValidEditTd.xpath", null, driver)){ //previously valid
				genLibWeb.clickOnElementByID("patConsultPaymentPriceGrpValidEditLincAnc.id", driver);
			}else{
				genLibWeb.clickOnElementByID("patConsultPaymentAddPriceGrpLinkAnc.id", driver);
			}
		} else{
			genLibWeb.clickOnElementByXPath("patConsultPaymentPriceGrpInvalidEditLincAnc.xpath", null, driver);
		}
		verifyNValidatePatientOnPriceGroupPopUp(driver);
		genLibWeb.enterTextValueByXPath("patConsultPaymentPriceGrpPopUpGrpIdInp.ngModel.xpath", null, priceGroupId, driver);
		genLibWeb.enterTextValueByXPath("patConsultPaymentPriceGrpPopUpMemIdInp.ngModel.xpath", null, memberId, driver);
		genLibWeb.clickOnElementByXPath("patConsultPaymentPriceGrpPopUpApplyBtn.ngClick.xpath", null, driver);		
	}

	private void enterPaymentInfo(String cCardNo, String expMon, String expYear, String cVC, WebDriver driver) throws Exception {
		//enter payment info if consultation cost is not 0
		if(!VMedixUtils.ZERO_CONSULTATION_PAY.equalsIgnoreCase(getConsultationFee(driver))){
			genLibWeb.enterTextValueByID("patConsultPaymentCreditCardInp.id", cCardNo, driver);			
			genLibWeb.enterTextValueByName("patConsultPaymentCcExpMonInp.name", expMon, driver);
			genLibWeb.enterTextValueByName("patConsultPaymentCcExpYearInp.name", expYear, driver);
			genLibWeb.enterTextValueByName("patConsultPaymentCcCVCInp.name", cVC, driver);
		}
	}
	
	private void enterAutoPaymentInfo(WebDriver driver) throws Exception {		
		String format = "yyyy-MM-dd";
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		String currDate = dateFormat.format(new Date());
		Calendar cal = Calendar.getInstance();    
		cal.setTime(dateFormat.parse(currDate));
		cal.add(Calendar.YEAR, 1);		
		enterPaymentInfo(VMedixUtils.CREDIT_CARD_NUMBER, Integer.toString(cal.get(Calendar.MONTH)+1), Integer.toString(cal.get(Calendar.YEAR)), VMedixUtils.CREDIT_CARD_CVC_3DIGIT, driver);
	}
	
	/**
	 * This function is used to get Consultation fee from payment page
	 * @param driver
	 * @return String; price
	 * @throws Exception
	 */
	public String getConsultationFee(WebDriver driver) throws Exception {
		String consultFee = genLibWeb.getTextByCssSelector("patConsultCostP.css", driver);
		String[] splitConsultFee = consultFee.split("\\$");			
		String pricePartWithPrefixStr = splitConsultFee[1];
		String[] splitPricePartWithPrefixStr = pricePartWithPrefixStr.split("\\s+"); //split on space/empty string
		return splitPricePartWithPrefixStr[0];	
	}
	
	/**
	 * This function is used to verify if the agreements are checked
	 * @param label
	 * @param passedInDriver
	 * @throws Exception
	 */
	public void checkAgreements(WebDriver driver) throws Exception {
		if(!genLibWeb.clickOnElementByXPath("patConsultAgreeTosI.xpath", null, driver) 
				|| !genLibWeb.clickOnElementByXPath("patConsultAgreePrivacyI.xpath", null, driver)
				|| !genLibWeb.clickOnElementByXPath("patConsultAgreeMedConsentI.xpath", null, driver)){				
			TestCaseInit.testCaseStatus = false;
			log.error("Agreement NOT checked");
			Assert.fail("Agreement NOT checked");
		}
		log.info("All agreements checked");
	}
}
