package pages;

import java.text.MessageFormat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.BussinessLib;
import library.GenericLibWeb;
import tests.TestCaseInit;

public class DoctorProfilePage {
	private static Logger log = Logger.getLogger(DoctorProfilePage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	BussinessLib busslib = new BussinessLib();


	public void clickNVerifyMyProfile(WebDriver driver) throws Exception {
		if(genLibWeb.clickOnElementByID("doctorMyProfileLinkAnc.id", driver)){
			log.info("My Profile is selected by Doctor");
			if (genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorMyProfilePageTitleH4.xpath", null, driver)) {
				log.info("Doctor is on My Profile");
			} else {
				TestCaseInit.testCaseStatus = false;
				log.error("Doctor is NOT on My Profile");
				Assert.fail("Doctor is NOT on My Profile");
			}			
		} else{
			TestCaseInit.testCaseStatus = false;
			log.error("My Profile is NOT selected by Doctor");
			Assert.fail("My Profile is NOT selected by Doctor");
		}
	}
	
	public void assertMyProfileFields(String fName, String lName, String docEmail, String gender, String notification, String city, String state, 
			String country, String phone, String npi, String dea, WebDriver driver) throws Exception {		
		try{
			Assert.assertEquals(genLibWeb.getValueByID("doctorMyProfileFirstnameInp.id", driver), fName);
			Assert.assertEquals(genLibWeb.getValueByID("doctorMyProfileLastnameInp.id", driver), lName);
			Assert.assertEquals(genLibWeb.getValueByID("doctorMyProfileEmailInp.id", driver), docEmail.toLowerCase());
			Assert.assertEquals(genLibWeb.getValueOfCheckedRadioButtonByName("doctorMyProfileGenderRdBtn.name", driver), gender.toLowerCase());
			Assert.assertEquals(genLibWeb.getSelectOptionTextBySelectElementID("doctorMyProfileNotificationPrefDrpBx.id", driver), notification);		
			Assert.assertEquals(genLibWeb.getValueByName("doctorMyProfileCityInp.name", driver), city);
			Assert.assertEquals(genLibWeb.getSelectOptionTextBySelectElementName("doctorMyProfileStateDrpBx.name", driver), state);
			Assert.assertEquals(genLibWeb.getValueByName("doctorMyProfileCountryInp.name", driver), country);
			Assert.assertEquals(genLibWeb.getValueByXPath("doctorMyProfilePhoneInp.xpath", null, driver), phone);
			Assert.assertEquals(genLibWeb.getValueByID("doctorMyProfileNpiInp.id", driver), npi);	
			Assert.assertEquals(genLibWeb.getValueByID("doctorMyProfileDeaInp.id", driver), dea);
			log.info("All the My Profile fields asserted true!");							
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
	}
	
	public void verifyChangePasswordScreen(WebDriver driver, String docName) throws Exception {
		genLibWeb.clickOnElementByID("doctorMyProfileChangePwdLinkAnc.id", driver);
		Thread.sleep(1000);
		//verify if the doctor is on change password page and the name is displayed
		if(genLibWeb.explicitWaitUntilElementWithXPathIsVisible(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("doctorMyProfileChangePwdPageTitleH1.xpath"), docName), driver)){
			log.info("Doctor is on Change Password Page");
			//cancel out of the page
			genLibWeb.clickOnElementByXPath("doctorMyProfileChangePwdCancelBtn.ngClick.xpath", null, driver);
		} else {
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT on Change Password Page");
			Assert.fail("Doctor is NOT on Change Password Page");
		}				
	}
}
