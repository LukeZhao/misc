package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class FacilitatorNewPatientPage {
	private static Logger log = Logger.getLogger(FacilitatorNewPatientPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if on Facilitator New Patient Page
	 */	
	public boolean verifyOnFacilitatorNewPatientPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("facNewPatPageTitleH2.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Facilitator New Patient Page
	 */
	public void verifyNValidateOnFacilitatorNewPatientPage(WebDriver driver)throws Exception {
		if(!verifyOnFacilitatorNewPatientPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Facilitator New Patient Page");
			Assert.fail("NOT on Facilitator New Patient Page");
		}		
		log.info("On Facilitator New Patient Page");
	}

	public void addNewFacPat(String facPatFName, String facPatLName, String dobMon, String dobDay, String dobYear, String gender, String primPhone, WebDriver driver)throws Exception {
		genLibWeb.enterTextValueByID("facNewPatFNameInp.id", facPatFName, driver);
		genLibWeb.enterTextValueByID("facNewPatLNameInp.id", facPatLName, driver);
		genLibWeb.selectByValueFromSelectElementID("facNewPatDobMonthDrpBx.id", dobMon, driver);
		genLibWeb.selectByValueFromSelectElementID("facNewPatDobDayDrpBx.id", dobDay, driver);
		genLibWeb.selectByValueFromSelectElementID("facNewPatDobYearDrpBx.id", dobYear, driver);
		if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("M")) {
			genLibWeb.clickOnElementByID("facNewPatGenderMaleRdLabel.id", driver);
		} else if(gender.equalsIgnoreCase("Female") || gender.equalsIgnoreCase("F")) {
			genLibWeb.clickOnElementByID("facNewPatGenderFemaleRdLabel.id", driver);
		} else {
			log.error("Please pass correct gender from the test data");
		}
		//Verify phone is not empty, as facility phone is default
		if(StringUtils.isBlank(genLibWeb.getValueByXPath("facNewPatPhoneInp.ngModel.xpath", null, driver))){
			TestCaseInit.testCaseStatus = false;
			log.error("Phone number field is empty, Facility Phone number might NOT displayed as default");
			Assert.fail("Phone number field is empty, Facility Phone number might NOT displayed as default");
		}
		log.info("Facility Phone number might be displayed as default");
		genLibWeb.enterTextValueByXPath("facNewPatPhoneInp.ngModel.xpath", null, primPhone, driver);
		genLibWeb.clickOnElementByID("facNewPatAddPatNCheckInBtn.id", driver);	
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastTitleMsg.xpath", null, driver);
		String toastMsg = genLibWeb.getTextByXPath("toastTitleMsg.xpath", null, driver);		
		if(!TestCaseInit.messagesVMedixProp.getProperty("facNewPatAdded.success").equals(toastMsg)) { 
			TestCaseInit.testCaseStatus = false;
			log.error("Facilitated patient NOT added: " + facPatFName + " " + facPatLName);
			Assert.fail("Facilitated patient NOT added: " + facPatFName + " " + facPatLName);
		}
		log.info("Facilitated patient Added: " + facPatFName + " " + facPatLName);	
	}
}
