package pages;

import java.text.MessageFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class FacilitatorPage {
	private static Logger log = Logger.getLogger(FacilitatorPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	public static String facPatConsultState = null;
	public FacilitatedPatientPage facPat = new FacilitatedPatientPage();
	PatientConsultationVideoOrPhonePage patientConsultation = new PatientConsultationVideoOrPhonePage();

	/**
	 * This method is used to verify if on Facilitator Page
	 */	
	public boolean verifyOnFacilitatorPage(String facName, WebDriver driver) throws Exception {
		if(genLibWeb.explicitWaitUntilElementWithXPathIsVisible("facilitatorLandingPageCheckInH2.xpath", null, driver) 
				&& genLibWeb.isElementFoundByXPath("facilitatorLandingPagePatDashBrdH2.xpath", null, driver) 
				&& genLibWeb.isElementFoundByXPath("facilitatorLandingPageFacConsultSpan.xpath", null, driver) 
				&& (facName.equalsIgnoreCase(genLibWeb.getTextByID("facilitatorLandingPageFacNameSpan.id", driver).trim())) 
				){
			return true;			
		} 
		return false;		
	}
	
	/**
	 * This method is used to validate if on Facilitator Page
	 */
	public void verifyNValidateOnFacilitatorPage(String facName, WebDriver driver)throws Exception {
		if(!verifyOnFacilitatorPage(facName, driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Facilitator Page");
			Assert.fail("NOT on Facilitator Page");
		}		
		log.info("On Facilitator Page");
	}
	
	public void searchOrSelectOnDashBoard(String facPatFName, String facPatLName, WebDriver driver)throws Exception {
		//search
		genLibWeb.enterTextValueByID("facPatSearchInp.id", facPatLName, driver);
		genLibWeb.clickOnElementByID("facPatSearchBtnSpan.id", driver);
		Thread.sleep(1000);
		if(!genLibWeb.isElementFoundByID("facPatFirstAncLink.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Facilitated Patient found");
			Assert.fail("NO Facilitated Patient found");
		}
		log.info("Facilitated Patient found");
		genLibWeb.clickOnElementByID("facPatFirstAncLink.id", driver);
		//verify on fac pat home page
		if(!facPat.verifyOnFacilitatedPatPage(facPatFName+" "+facPatLName, driver)){
			log.info("Facilitated Patient is not on Home page");
			//look for fac pat on dash board
			lookUpNSelectOnPatDashboard(facPatFName, facPatLName, driver);
		}else{
			log.info("Facilitated Patient is on on Home page");
		}
	}
	
	public void searchRandomNClickOnAddPat(WebDriver driver)throws Exception {
		//search
		genLibWeb.enterTextValueByID("facPatSearchInp.id", VMedixUtils.generateDynamicString(), driver);
		genLibWeb.clickOnElementByID("facPatSearchBtnSpan.id", driver);
		Thread.sleep(500);
		genLibWeb.clickOnElementByID("facPatAddNewI.id", driver);
	}

	private void lookUpNSelectOnPatDashboard(String facPatFName, String facPatLName, WebDriver driver) throws Exception {
		int countConsultsOnPatDashBrd = genLibWeb.getNumberOfElementsByXPath("facPatDashBrdConsultRowsAncLink.xpath", null, driver);
		if(!(countConsultsOnPatDashBrd > 0) ){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Consults found on dashboard");	
			Assert.fail("NO Consults found on dashboard");
		}
		boolean found = false;
		while(!found){
			for(int i=0; i<countConsultsOnPatDashBrd; i++){
				String rowCount = Integer.toString(i);
				String facPatNameIdVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("facPatDashBrdConsultPatName.id"), rowCount);				
				String facPatNameTxtRetrvd =  genLibWeb.getTextByID(null, facPatNameIdVal, driver);
				if(StringUtils.containsIgnoreCase(facPatNameTxtRetrvd, facPatFName) 
						&& StringUtils.containsIgnoreCase(facPatNameTxtRetrvd, facPatLName)){
					String facPatConsultStateTxtRetrvd = genLibWeb.getTextByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("facPatDashBrdConsultStateDiv.xpath"), rowCount), driver);
					if(StringUtils.containsIgnoreCase(facPatConsultStateTxtRetrvd, VMedixUtils.FAC_PAT_PRE_CHECK_IN)){
						facPatConsultState = VMedixUtils.FAC_PAT_PRE_CHECK_IN;
					} else if(StringUtils.containsIgnoreCase(facPatConsultStateTxtRetrvd, VMedixUtils.FAC_PAT_IN_QUEUE)){
						facPatConsultState = VMedixUtils.FAC_PAT_IN_QUEUE;
					} else if(StringUtils.containsIgnoreCase(facPatConsultStateTxtRetrvd, VMedixUtils.FAC_PAT_WAITING)){
						facPatConsultState = VMedixUtils.FAC_PAT_WAITING;
					} else {
						facPatConsultState = VMedixUtils.FAC_PAT_IN_CONSULT;
					}
					genLibWeb.clickOnElementByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("facPatDashBrdConsultAncLink.xpath"), rowCount), driver);
					found = true;					
					break;
				}
			}
		}
		if(!found){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Consults found on dashboard with name:" + facPatFName+" "+facPatLName);	
			Assert.fail("NO Consults found on dashboard with name:" + facPatFName+" "+facPatLName);					
		}		
	}	

	public void bringFacPatientToStartConsultState(String facName, String facPatFName, String facPatLName, WebDriver driver)throws Exception {
		boolean foundRightPage = false;
		if(genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultNotifyDoctorNoThanksBtn.ngClick.xpath", null, driver)){  
			foundRightPage = true;
			//handle alert for notification - text, call, no thanks, continue
			genLibWeb.clickOnElementByXPath("patConsultNotifyDoctorNoThanksBtn.ngClick.xpath", null, driver);
			patientConsultation.cancelVideoOrPhoneConsultation(driver);
		} else if(patientConsultation.verifyPatientOnWaitingForDocInQPage(driver)){
			foundRightPage = true;
			patientConsultation.cancelVideoOrPhoneConsultation(driver);
		} else {
			log.error("Facilitated patient is on a Wrong Screen");
		}
		Thread.sleep(1000);
		if (!foundRightPage || !verifyOnFacilitatorPage(facName, driver)) {
			TestCaseInit.testCaseStatus = false;
			log.error("Failed to bring facilitated patient to Home Screen");
			Assert.fail("Failed to bring facilitated patient to Home Screen");					
		} 
		log.info("Facilitated patient is now on Home Screen");
	}
}
