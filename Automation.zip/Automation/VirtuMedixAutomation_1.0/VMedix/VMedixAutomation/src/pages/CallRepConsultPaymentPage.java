package pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class CallRepConsultPaymentPage {
	static Logger log = Logger.getLogger(CallRepConsultPaymentPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if on Call Rep Consultation Payment Page
	 */	
	public boolean verifyOnCallRepConsultationPaymentPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("callRepNewConsultPaymentPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Call Rep Consultation Payment Page
	 */
	public void verifyNValidateOnCallRepConsultationPaymentPage(WebDriver driver)throws Exception {
		if(!verifyOnCallRepConsultationPaymentPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Call Rep Consultation Payment Page");
			Assert.fail("NOT on Call Rep Consultation Payment Page");
		}		
		log.info("On Call Rep Consultation Payment Page");
	}

	public void enterAutoInfoOnCallRepPayment(WebDriver driver) throws Exception {
		try{
			verifyNValidateOnCallRepConsultationPaymentPage(driver);			
			//auto generate card exp month(same month) and year(1 year ahead) from current date
			enterAutoPaymentInfo(driver);
			checkAgreements(driver);
			genLibWeb.clickOnElementByID("callRepConsultPaymentSubmitPaymentNContinueBtn.id", driver);
			Thread.sleep(3000); //wait to process payment
		} catch (Exception e) {	
			log.info(e);
			log.error("Failed to fill  and submit Payment page with all details");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to fill and submit Payment page due to : "+e);
		}		
	}
	
	/**
	 * This function is used to verify if the agreements are checked
	 * @param label
	 * @param passedInDriver
	 * @throws Exception
	 */
	public void checkAgreements(WebDriver driver) throws Exception {
		if(!genLibWeb.clickOnElementByXPath("callRepConsultPaymentAgreeTosI.xpath", null, driver) 
				|| !genLibWeb.clickOnElementByXPath("callRepConsultPaymentAgreePrivacyI.xpath", null, driver)
				|| !genLibWeb.clickOnElementByXPath("callRepConsultPaymentAgreeMedConsentI.xpath", null, driver)){				
			TestCaseInit.testCaseStatus = false;
			log.error("Agreement NOT checked");
			Assert.fail("Agreement NOT checked");
		}
		log.info("All agreements checked");		
	}
	
	/**
	 * This function is used to get Consultation fee from payment page
	 * @param driver
	 * @return String; price
	 * @throws Exception
	 */
	public String getConsultationFee(WebDriver driver) throws Exception {
		String consultFee = genLibWeb.getTextByXPath("callRepConsultPaymentCostSpan.xpath", null, driver);
		String[] splitConsultFee = consultFee.split("\\$");			
		String pricePartWithPrefixStr = splitConsultFee[1];
		String[] splitPricePartWithPrefixStr = pricePartWithPrefixStr.split("\\s+"); //split on space/empty string
		return splitPricePartWithPrefixStr[0];	
	}
	
	private void enterAutoPaymentInfo(WebDriver driver) throws Exception {
		String format = "yyyy-MM-dd";
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		String currDate = dateFormat.format(new Date());
		Calendar cal = Calendar.getInstance();    
		cal.setTime(dateFormat.parse(currDate));
		cal.add(Calendar.YEAR, 1);		
		enterPaymentInfo(VMedixUtils.CREDIT_CARD_NUMBER, Integer.toString(cal.get(Calendar.MONTH)+1), Integer.toString(cal.get(Calendar.YEAR)), VMedixUtils.CREDIT_CARD_CVC_3DIGIT, driver);
	}
	
	private void enterPaymentInfo(String cCardNo, String expMon, String expYear, String cVC, WebDriver driver) throws Exception {
		//enter payment info if consultation cost is not 0
		if(!VMedixUtils.ZERO_CONSULTATION_PAY.equalsIgnoreCase(getConsultationFee(driver))){
			genLibWeb.enterTextValueByID("callRepConsultPaymentCreditCardInp.id", cCardNo, driver);			
			genLibWeb.enterTextValueByID("callRepConsultPaymentCcExpMonInp.id", expMon, driver);
			genLibWeb.enterTextValueByID("callRepConsultPaymentCcExpYearInp.id", expYear, driver);
			genLibWeb.enterTextValueByID("callRepConsultPaymentCcCVCInp.id", cVC, driver);
		}
	}
}
