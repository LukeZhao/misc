package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class CallRepAdminPage {
	static Logger log = Logger.getLogger(CallRepAdminPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if on CallRep Admin Page
	 */	
	public boolean verifyOnCallRepAdminPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("callRepAdminLandingPageH3.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on CallRep Admin Page
	 */
	public void verifyNValidateOnCallRepAdminPage(WebDriver driver)throws Exception {
		if(!verifyOnCallRepAdminPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on CallRep Admin Page");
			Assert.fail("NOT on CallRep Admin Page");
		}		
		log.info("On CallRep Admin Page");
	}
	
	/**
	 * This method is used to click on Call Center Agents User profiles
	 */	
	public void clickCallCenterAgentsUserProfiles(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByID("callRepAdminCallCenterAgentsProfileLinkAnc.id", driver);
	}
}
