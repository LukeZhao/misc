package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class FacilitatedPatAfterSurveyPage {
	static Logger log = Logger.getLogger(FacilitatedPatAfterSurveyPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();	

	/**
	 * This method is used to verify if facilitated patient is on After Survey Page
	 * @throws Exception 
	 */	
	public boolean verifyFacPatOnAfterSurveyPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("facPatAfterSurveyPageH2.xpath", null, driver) 
				&& genLibWeb.isElementDisplayedByXPath("facPatAfterSurveyPageP.xpath", null, driver);		
	}
	
	/**
	 * This method is used to validate if facilitated patient is on After Survey Page
	 * @throws Exception 
	 */
	public void verifyNValidateFacPatOnOnAfterSurveyPage(WebDriver driver)throws Exception {
		if(!verifyFacPatOnAfterSurveyPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Facilitated patient is NOT on After Survey Page");
			Assert.fail("Facilitated patient is NOT on After Survey Page");
		}		
		log.info("Facilitated patient is on After Survey Page");
	}

	public void clickOnNextLogOutBtn(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByXPath("facPatAfterSurveyNextBtn.ngClick.xpath", null, driver);
	}
}
