package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class AdminPricNRefPriceGrpsNewPage {
	static Logger log = Logger.getLogger(AdminPricNRefPriceGrpsNewPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	public final String autoItExeLocationForChrome_UploadPriceGroupPat15 = TestCaseInit.Current_Directory+"\\Test_Data\\ChromeAutoIt_PriceGroupPat15.exe";
	public final String autoItExeLocationForFirefox_UploadPriceGroupPat15 = TestCaseInit.Current_Directory+"\\Test_Data\\FirefoxAutoIt_PriceGroupPat15.exe";	
	/**
	 * This method is used to verify if on on Admin New Price Groups Page
	 */	
	public boolean verifyOnAdminNewPriceGrpsPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminPrcNRefNewPriceGroupTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin New Price Groups Page
	 */
	public void verifyNValidateOnAdminNewPriceGrpsPage(WebDriver driver)throws Exception {
		if(!verifyOnAdminNewPriceGrpsPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on New Price Groups Page");
			Assert.fail("NOT on New Price Groups Page");
		}		
		log.info("On New Price Groups Page");
	}
	
	public void submitNewPriceGroup(String priceGrpName, String priceGrpId, String price, String memberId, WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByID("docAdminPrcNRefNewPrcGrpNameInp.id", priceGrpName, driver);
		genLibWeb.enterTextValueByID("docAdminPrcNRefNewPrcGrpIdInp.id", priceGrpId, driver);
		genLibWeb.enterTextValueByID("docAdminPrcNRefNewPrcGrpPriceInp.id", price, driver);
		if(StringUtils.isNotBlank(memberId)){
			genLibWeb.clickOnElementByXPath("docAdminPrcNRefNewPrcGrpMemberIdChkBxI.xpath", null, driver);
		}			
		//upload file
		genLibWeb.clickOnElementByID("docAdminPrcNRefNewPrcGrpUploadFileInp.id", driver);
		if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_CHROME)){
			Runtime.getRuntime().exec(autoItExeLocationForChrome_UploadPriceGroupPat15);
		}else if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_FIREFOX)){
			Runtime.getRuntime().exec(autoItExeLocationForFirefox_UploadPriceGroupPat15);
		}	
		Thread.sleep(5000);
		//submit
		genLibWeb.clickOnElementByID("docAdminPrcNRefNewPrcGrpSubmitBtn.id", driver);
		
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);		
		if(!TestCaseInit.messagesVMedixProp.getProperty("priceGroupUpload.success").equals(toastMsg)) {
			TestCaseInit.testCaseStatus = false;
			log.error("Price Group NOT created: " + priceGrpName);
			Assert.fail("Price Group NOT created: " + priceGrpName);			
		}
		log.info("Price Group created: " + priceGrpName);
	}
}
