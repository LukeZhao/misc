package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class AdminAppChoicesHnPTemplatePage {
	static Logger log = Logger.getLogger(AdminAppChoicesHnPTemplatePage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();

	/**
	 * This method is used to verify if on Admin Application Choices: HnP Template Page
	 */	
	public boolean verifyOnAdminAppChoicesHnPTemplatePage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminAppChoicesHnPTemplatesTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin Application Choices: HnP Template
	 */
	public void verifyNValidateOnAdminAppChoicesHnPTemplatePage(WebDriver driver)throws Exception {
		if(!verifyOnAdminAppChoicesHnPTemplatePage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Admin Application Choices: HnP Template Page");
			Assert.fail("NOT on Admin Application Choices: HnP Template Page");
		}		
		log.info("On Admin Application Choices: HnP Template Page");
	}

	public void selectHnPTemplate(String hnpTemplateToselect, WebDriver driver)throws Exception{
		Thread.sleep(1000);
		genLibWeb.selectByVisibleTextFromSelectElementID("docAdminAppChoicesHnPChooseTemplateDrpBx.id", hnpTemplateToselect, driver);
	}
	
	public void editPatInfoHeaderInTemplateRawText(String oldTemplateHeader, String newTemplateHeader, WebDriver driver)throws Exception{
		Thread.sleep(1000);
		String hnpTemplateRawText = genLibWeb.getValueByID("docAdminAppChoicesHnPTemplateRawTxtArea.id", driver);
		hnpTemplateRawText = hnpTemplateRawText.replace(oldTemplateHeader, newTemplateHeader);
		genLibWeb.enterTextValueByID("docAdminAppChoicesHnPTemplateRawTxtArea.id", hnpTemplateRawText, driver);
	}
	
	public void clickSave(WebDriver driver)throws Exception{
		genLibWeb.clickOnElementByXPath("docAdminAppChoicesHnPSaveBtn.ngClick.xpath", null, driver);		
		if(genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("hnpTemplateSaved.success"), "toastMsg.xpath", null, driver)){
			log.info("H&P template Saved");
		}else{
			TestCaseInit.testCaseStatus = false;
			log.error("H&P template NOT saved");
			Assert.fail("H&P template NOT saved");
		}
	}
}
