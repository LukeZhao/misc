package pages;

import java.text.MessageFormat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class AdminAppChoicesMedicationsPage {
	static Logger log = Logger.getLogger(AdminAppChoicesMedicationsPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	public static String idValueForDelete = null;

	/**
	 * This method is used to verify if on Admin Application Choices: Medications Page
	 */	
	public boolean verifyOnAdminAppChoicesMedicationsPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminAppChoicesMedicationsTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin Application Choices: Medications Page
	 */
	public void verifyNValidateOnAdminAppChoicesMedicationsPage(WebDriver driver)throws Exception {
		if(!verifyOnAdminAppChoicesMedicationsPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Admin Application Choices: Medications Page");
			Assert.fail("NOT on Admin Application Choices: Medications Page");
		}		
		log.info("On Admin Application Choices: Medications Page");
	}
	
	public void addNewMedication(String newMedToAdd, WebDriver driver)throws Exception {
		genLibWeb.enterTextValueByID("docAdminAppChoicesMedsAddInp.Id", newMedToAdd, driver);
		genLibWeb.clickOnElementByID("docAdminAppChoicesMedsAddBtn.Id", driver);
		Thread.sleep(2000);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);		
		if(TestCaseInit.messagesVMedixProp.getProperty("medicationAdded.success").equals(toastMsg)) { 
			driver.navigate().refresh();
			log.info("Medication Added: "+ newMedToAdd);
		}else if(TestCaseInit.messagesVMedixProp.getProperty("medicationIgnored.info").equals(toastMsg)){
			log.info("Medication Ignored, as it already exists. Continuing test with med: "+ newMedToAdd);
		}else{
			TestCaseInit.testCaseStatus = false;
			log.error("Medication NOT added: " + newMedToAdd);
			Assert.fail("Medication NOT added: " + newMedToAdd);
		}
	}
	
	public void deleteMedication(String medToDelete, WebDriver driver)throws Exception {
		if(!lookupMedication(medToDelete, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Medication to delete is NOT found: "+ medToDelete);
			Assert.fail("Medication to delete is NOT found: "+ medToDelete);
		} else{
			log.info("Medication to delete is found: "+ medToDelete);
			//delete the Med
			genLibWeb.clickOnElementByID(null, idValueForDelete, driver);	//select the check box
			genLibWeb.clickOnElementByXPath("docAdminAppChoicesMedicationDeleteSpan.ngClick.xpath", null, driver);	//click delete icon	
			Thread.sleep(2000);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
			String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);		
			if(TestCaseInit.messagesVMedixProp.getProperty("medicationDeleted.success").equals(toastMsg)) { 
				log.info("Medication Deleted, "+ medToDelete);
			}else{
				TestCaseInit.testCaseStatus = false;
				log.error("Medication NOT deleted, "+ medToDelete);
				Assert.fail("Medication NOT deleted, "+ medToDelete);
			}
		}
	}
	
	public boolean lookupMedication(String medToFind, WebDriver driver) throws Exception {
		int countOfMeds = genLibWeb.getElementsByXPath("docAdminAppChoicesMedsDeleteInp.xpath", null, driver).size();//getting the count by delete checkbox inputs
		if(!(countOfMeds > 0) ){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Medications found");	
			Assert.fail("NO Medications found");
		}		
		boolean found = false;
		for(int i=0; i<countOfMeds; i++){
			if(genLibWeb.getElementByID(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminAppChoicesMedsTr.id"), Integer.toString(i)), driver) != null) {
				String medicationTdXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminAppChoicesMedicationTd.xpath"), Integer.toString(i));			
				if(medToFind.equalsIgnoreCase(genLibWeb.getTextByXPath(null, medicationTdXpathVal, driver))){						
					idValueForDelete = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminAppChoicesMedicationTdCheckBxInp.id"), Integer.toString(i));
					found = true;
					break;
				}
			} 
		}
		return found;
	}
}
