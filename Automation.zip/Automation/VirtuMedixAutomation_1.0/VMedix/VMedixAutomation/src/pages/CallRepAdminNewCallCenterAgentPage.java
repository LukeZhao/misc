package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class CallRepAdminNewCallCenterAgentPage {
	static Logger log = Logger.getLogger(CallRepAdminNewCallCenterAgentPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if on New Call Center Agent Page
	 */	
	public boolean verifyOnNewCallCenterAgentPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("newCallCenterAgentPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on New Call Center Agent Page
	 */
	public void verifyNValidateOnNewCallCenterAgentPage(WebDriver driver)throws Exception {
		if(!verifyOnNewCallCenterAgentPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on New Call Center Agent Page");
			Assert.fail("NOT on New Call Center Agent Page");
		}		
		log.info("On New Call Center Agent Page");
	}

	public void saveNewCallRep(String firstName, String lastName, String phone, String emailForRegister, WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByID("newCallCenterAgentFirstNameInp.id", firstName, driver);
		genLibWeb.enterTextValueByName("newCallCenterAgentLastNameInp.name", lastName, driver);
		genLibWeb.enterTextValueByName("newCallCenterAgentEmailInp.name", emailForRegister, driver);
		genLibWeb.enterTextValueByXPath("newCallCenterAgentPhoneNumberInp.ngModel.xpath", null, phone, driver);
		genLibWeb.clickOnElementByID("newCallCenterAgentSaveBtn.id", driver);
		if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("createdUserByAdmin.success"), "toastMsg.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("New call center agent NOT created with email: "+ emailForRegister);
			Assert.fail("New call center agent NOT created with email: "+ emailForRegister);
		}
		log.info("New call center agent created with email: "+ emailForRegister);	
	}
}
