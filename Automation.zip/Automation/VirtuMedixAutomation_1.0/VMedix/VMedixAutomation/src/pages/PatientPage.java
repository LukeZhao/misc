package pages;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class PatientPage {
	static Logger log = Logger.getLogger(PatientPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	CommonUtilsPage cmnUtilsPage = new CommonUtilsPage(); 
	DoctorConsultationPage docConsult = new DoctorConsultationPage();
	PatientConsultWaitingRoomHealthPreQueInfoPage patConsultWaitRoomHealthInfoPreQ = new PatientConsultWaitingRoomHealthPreQueInfoPage();
	PatientConsultationVideoOrPhonePage patientConsultation = new PatientConsultationVideoOrPhonePage();
	
	public boolean verifyPatientOnLandingPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patientLandingPageH1.xpath", null, driver);
	}
	
	public void verifyNValidatePatientOnLandingPage(WebDriver driver) throws Exception{
		if(!verifyPatientOnLandingPage(driver)){
			TestCaseInit.testCaseStatus = false;
			log.info("Patient is NOT on the Landing/Check-in page");
			Assert.fail("Patient is NOT on the Landing/Check-in page");
		}
		log.info("Patient is NOT on the Landing/Check-in page");
	}
	
	public void verifyAndBringPatientToLandingPage(WebDriver driver) throws Exception {
		try {
			if (!verifyPatientOnLandingPage(driver)) {
				bringPatientToHomeScreen(driver);
			} else {
				log.info("Patient is on Landing page");	
			}
		} catch (Exception e) {
			log.error("Unable to bring Patient back to Landing page", e);
			throw e;
		}
	}

	/**
	 * This method is used to verify medication added by Admin is present and auto displayed on Patient
	 * @param driver
	 * @throws Exception 
	 */
	public void verifyMedicationAddedByAdmin(String med1Add, WebDriver driver) throws Exception {
		if(!cmnUtilsPage.verifyPresentInDropBoxAfterAutoDisplay(med1Add, "patientMedicationInp.ngModel.xpath", null, "patientMedicationDrpBxWithVal.ngClick.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Medication added NOT found on Patient: " +med1Add);
			Assert.fail("Medication added NOT found on Patient: " +med1Add);
		}
		log.info("Medication added was Found on Patient: " +med1Add);		
	}	
	
	public int getNumberOfPatientStateOptions(WebDriver driver) throws Exception{
		int stateOptionSize = 0;
		if(!genLibWeb.explicitWaitUntilElementWithNameIsVisible("patientStatesDrpBx.name", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("State options NOT found on Patient homepage");
			Assert.fail("State options NOT found on Patient homepage");	
		}
		log.info("State options found on Patient homepage");
		//State is pre-entered based on geo loaction, which doesnot work at times. 
		//In which case the State is not selected and the drop box has extra blank element to be removed
		boolean geolocationWorked = false;
		if(!StringUtils.isBlank(genLibWeb.getSelectOptionTextBySelectElementName("patientStatesDrpBx.name", driver))){
			geolocationWorked = true;
		}
		List<WebElement> StateOptionFromUI= genLibWeb.getDropDownSelectOptionsByName("patientStatesDrpBx.name", driver);
		if(StateOptionFromUI != null) {
			if(!geolocationWorked){
				StateOptionFromUI.remove(0);// Remove the first blank display in options
			}
			if(StateOptionFromUI.size() > 0){
				StateOptionFromUI.remove(StateOptionFromUI.size() - 1);// Remove the last option - not listed
				stateOptionSize = StateOptionFromUI.size();
			}			
		}
		return stateOptionSize;		
	}
	
	public void clickOnConsultHistoryOption(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByID("patConsultHistoryBtn.id", driver);
	}
	
	public void clickOnPatientInfoOption(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByName("patPatientInfoBtn.name", driver);
	}
	
	public void clickOnSeeDoctorOption(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByName("patSeeADoctorBtn.name", driver);
	}
	
	public void clickOnLogout(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByID("patAvatarImg.id", driver);
		genLibWeb.clickOnElementByID("patAvatarImg.id", driver);
		Thread.sleep(1000);//wait for drop down to show		
		genLibWeb.clickOnElementByXPath("patLogOutAnc.ngHRef.xpath", null, driver);
	}
	
	//Helpers
	private void bringPatientToHomeScreen(WebDriver driver) throws Exception {
		boolean foundRightPage = false;
		try {
			if(patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driver)){ 
				//on health info page after payment
				foundRightPage = true;
				bringPatHomeFromHealthInfoPage(driver);
			} else if(patientConsultation.verifyPatientOnWaitingForDocInQPage(driver) 
					&& !genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultNotifyDoctorNoThanksBtn.ngClick.xpath", null, driver)){  
				//patient waiting for Doctor - less than 10 mins or doctor took up the consultation and patient has to not begun consultation 
				//cancel Consultation - before consultation begin
				foundRightPage = true;
				bringPatHomeByCancelConsultation(driver);
			} else if(genLibWeb.isElementFoundByID("patConsultEndConsutationBtn.id", driver)){ //video consult
				foundRightPage = true;
				//end the Video or Phone consultation
				bringPatHomeByEndVideoOrPhoneConsultation(driver);
			} else {
				log.error("Patient is on a Wrong Screen");
			}
			Thread.sleep(1000);
			if (!foundRightPage || !verifyPatientOnLandingPage(driver)) {
				TestCaseInit.testCaseStatus = false;
				log.error("Failed to bring patient to Home Screen");
				Assert.fail("Failed to bring patient to Home Screen");					
			} 
			log.info("Patient is now on Home Screen");

		} catch (Exception e) {
			throw e;
		}
	}
	
	private void bringPatHomeFromHealthInfoPage(WebDriver driver) throws Exception{
		genLibWeb.scrollToViewElementWithXPath("patConsultHealthInfoNextBtn.ngClick.xpath", null, driver);
		genLibWeb.clickOnElementByXPath("patConsultHealthInfoNextBtn.ngClick.xpath",null,driver);
		genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoPageH1.xpath", null, driver);				
		genLibWeb.scrollToViewElementWithXPath("patConsultReviewHealthInfoSubmitBtn.ngClick.xpath", null, driver);
		genLibWeb.clickOnElementByXPath("patConsultReviewHealthInfoSubmitBtn.ngClick.xpath", null, driver);
		//handle alert for notification - text, call, no thanks, continue
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultNotifyDoctorNoThanksBtn.ngClick.xpath", null, driver);
		genLibWeb.clickOnElementByXPath("patConsultNotifyDoctorNoThanksBtn.ngClick.xpath", null, driver);
		//cancel Consultation - before consultation begin
		bringPatHomeByCancelConsultation(driver);
	}
	
	private void bringPatHomeByCancelConsultation(WebDriver driver) throws Exception{
		patientConsultation.cancelVideoOrPhoneConsultation(driver);
	}
	
	private void bringPatHomeByEndVideoOrPhoneConsultation(WebDriver driver) throws Exception{
		patientConsultation.endVideoOrPhoneConsultation(driver);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultSurveyPageH1.xpath", null, driver);
		genLibWeb.clickOnElementByID("patConsultSurveySkipLinkAnc.id", driver);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patAfterConsultPageH1.xpath", null, driver);
		genLibWeb.clickOnElementByID("patAfterConsultHomeBtn.id", driver);	
	}
}
