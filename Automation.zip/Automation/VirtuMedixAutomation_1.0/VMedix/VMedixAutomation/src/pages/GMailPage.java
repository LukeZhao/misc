package pages;

import java.text.MessageFormat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.EnvironmentConfigSettings;
import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class GMailPage {
	
	static Logger log = Logger.getLogger(GMailPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();	
	LoginPage login = new LoginPage();
	public NewPatientEmailVerifiedPage newPatEmailVerPage = new NewPatientEmailVerifiedPage();
	public PatientPage patientPage = new PatientPage();
	
	public static final String COMPOSE_TEXT = "COMPOSE";	
	public static final String EMAIL_VERIFICATION_AND_PWD_RESET_SUBJECT_TITLE_VIRTUMEDIX = "VirtuMedix: Email verification and setting password";
	public static final String EMAIL_VERIFICATION_FOR_NEW_PATIENT_SUBJECT_TITLE_VIRTUMEDIX = "VirtuMedix: Email verification";
	public static final String PASSWORD_RESET_SUBJECT_TITLE_VIRTUMEDIX = "VirtuMedix: Password reset";
	public static final String DEFAULT_SENDER_EMAIL_VIRTUMEDIX = "no-reply@virtumedix.com";
	public static final String ADMIN_REPORT_SUBJECT_TITLE_VIRTUMEDIX = "VirtuMedix: New admin report";
	public static final String PATIENT_NEW_CONSULT_REPORT_SUBJECT_TITLE_VIRTUMEDIX = "VirtuMedix: New consultation report";
	public static final String PATIENT_NEW_CONSULT_REPORT_BODY_TITLE_VIRTUMEDIX = "Consultation report (PDF) is available in \"My Health Record\" section.";
	
	public static String parentHandle = null;
	
	/**
	 * This method is used to login to GMail
	 * @param email
	 * @param password
	 * @param driver
	 * @throws Exception
	 */	
	public void loginGmail(String email, String password, WebDriver driver) throws Exception {
		if(email.contains("+")){//Vitumedix email test data contains '+', that points to a single gmail account which is considered discarding substrings with and after '+'   
			email = getCorrectGmail(email);
		}
		driver.get(EnvironmentConfigSettings.getGmailUrlEnvConfig());
		genLibWeb.enterTextValueByID("gmailEmailInp.id", email,	driver);
		genLibWeb.clickOnElementByID("gmailEmailNextBtn.id", driver);
		if(genLibWeb.explicitWaitUntilElementWithIDIsVisible("gmailpasswordInp.id",driver)){
			genLibWeb.enterTextValueByID("gmailpasswordInp.id", password, driver);
		}
		genLibWeb.clickOnElementByID("gmailSignIn.id", driver);
		if(genLibWeb.explicitWaitUntilElementWithXPathIsVisible("gmailComposeBtn.xpath", null, driver)){
			log.info("Successfully logged into GMAIL Account: " + email);
		}else{
			TestCaseInit.testCaseStatus = false;
			log.error("FAILED to login into GMAIL Account: " + email);
			Assert.fail("FAILED to login into GMAIL Account: " + email);
		}
	}

	/**
	 * This method is used to login out of GMail
	 * @param email
	 * @param password
	 * @param driver
	 * @throws Exception
	 */	
	public void logoutGmail(String userEmail, WebDriver driver) throws Exception {
		if(userEmail.contains("+")){//Vitumedix email test data contains '+', that points to a single gmail account which is considered discarding substrings with and after '+'   
			userEmail = getCorrectGmail(userEmail);
		}
		String gmailAccounttAncHrefTitleXPathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("gmailAccounttAncHrefTitle.xpath"), "\'Google Account:\'", "\'"+userEmail.toLowerCase()+"\'");
		genLibWeb.clickOnElementByXPath(null, gmailAccounttAncHrefTitleXPathVal , driver);
		if (genLibWeb.clickOnElementByXPath("gmailSignOutAncText.xpath", null, driver)) {
			log.info("Logged Out from the Gmail Account: "+ userEmail);
		} else {
			log.info("Gmail LogOut Button is Not Visible on UI");
		}		
	}	
	
	/**
	 * This method is used to login to GMail and validate password reset
	 * @param email
	 * @param password
	 * @param searchTitle
	 * @param driver
	 * @throws Exception
	 */	
	public void validateResetPasswordEmailRecieved(String email, String password, WebDriver driver) throws Exception {		
		loginGmail(email, password, driver);
		if(!validateEmailRecieved(email, PASSWORD_RESET_SUBJECT_TITLE_VIRTUMEDIX, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Email NOT received for Reset Password");
			Assert.fail("Email NOT received for Reset Password");
		} else {
			//verify sender
			verifySenderEmail(DEFAULT_SENDER_EMAIL_VIRTUMEDIX, driver);
		}
		logoutGmail(email, driver);
	}
		
	/**
	 * This method is used to login to Admin GMail to verify the emails for generated reports
	 * @param email
	 * @param password
	 * @param emailToSearch
	 * @param driver
	 * @throws Exception
	 */
	public void loginGmailAsAdminToVerifyReports(String email, String password,	String reportType, WebDriver driver) throws Exception {
		try{
			Thread.sleep(10000);//wait for the email to be sent, as report generation could take time based on length of records
			loginGmail(email, password, driver);
			if(!validateEmailRecieved(email, ADMIN_REPORT_SUBJECT_TITLE_VIRTUMEDIX, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("Email NOT received for Admin report: "+ reportType);
				Assert.fail("Email NOT received for Admin report: "+ reportType);				
			} else {
				//verify text in email body with report type
				Thread.sleep(1000);
				if(!genLibWeb.getTextOfLastElementByXPath("gmailBodyStyl.xpath", null, driver).contains(reportType)){
					TestCaseInit.testCaseStatus = false;
					log.error("Email body did NOT match for report type: "+ reportType);
					Assert.fail("Email body did NOT match for report type: "+ reportType);
				} else{
					log.info("Email body Matched for report type: "+ reportType);
					//verify sender
					verifySenderEmail(DEFAULT_SENDER_EMAIL_VIRTUMEDIX, driver);
				}
			}			
			logoutGmail(email, driver);
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * This method is used to login into gmail and validate email verification and the reset password functionality 
	 * For NEW users created by Admin 
	 * @param gmailUsr
	 * @param gmailPwd
	 * @param vMedNewEmail
	 * @param newPassword
	 * @param driver
	 * @throws Exception
	 */
	public void loginToGmailNValidateEmailVerificationAndPasswordReset(String email, String gmailPwd, String newPassword, String userType, WebDriver driver) throws Exception {
		parentHandle = null;
		loginGmail(email, gmailPwd, driver);
		try{			
			parentHandle = validateEmailVerificationNPwdResetOnGmail(email, newPassword, userType, driver);			
		} finally{			
			if(parentHandle != null){
				driver.close(); //close newly opened window when done with it
				driver.switchTo().window(parentHandle); //switch back to the original window	
			}
			logoutGmail(email, driver);			
		}															
	}

	/**
	 * This method is used to login into gmail and validate email verification for the new patients
	 * @param gmailUsr
	 * @param gmailPwd
	 * @param vMedNewEmail
	 * @param newPassword
	 * @param driver
	 * @throws Exception
	 */
	public void loginToGmailNValidateEmailVerificationForNewPatient(String email, String pwd, WebDriver driver) throws Exception {
		parentHandle = null;	
		loginGmail(email, pwd, driver);
		try{			
			parentHandle = validateEmailVerificationForNewPatOnGmail(email, pwd, driver);			
		} finally{			
			if(parentHandle != null){
				driver.close(); //close newly opened window when done with it
				driver.switchTo().window(parentHandle); //switch back to the original window	
			}
			logoutGmail(email, driver);			
		}															
	}
	
	/**
	 * This method is used to verify email and reset password functionality for new users
	 * @param email
	 * @param pwd
	 * @param driver
	 * @throws Exception
	 */
	public String validateEmailVerificationForNewPatOnGmail(String email, String pwd, WebDriver driver) throws Exception {
		if(!validateEmailRecieved(email, EMAIL_VERIFICATION_FOR_NEW_PATIENT_SUBJECT_TITLE_VIRTUMEDIX, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Email NOT received for Email verification of New Patient");;
			Assert.fail("Email NOT received for Email verification of New Patient");
		} else {
			//verify sender
			verifySenderEmail(DEFAULT_SENDER_EMAIL_VIRTUMEDIX, driver);
			
			//verify url 
			//ui specifies the api url as http and not https; So, considering the latter part of api url prefix to verify and click the link
			String apiUrlPrefix = TestCaseInit.apiUrl;
			String splitApiUrlAtHttp[] = apiUrlPrefix.split(":");
			String verifyEmailChangePwdLinkHrefVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("verifyEmailChangePwdLinkHref.xpath"), "\'"+splitApiUrlAtHttp[1]);
	
			//email verification and password reset
			parentHandle = driver.getWindowHandle();
			//verify text in last email
			Thread.sleep(500);//wait to load
			if(!genLibWeb.getTextOfLastElementByXPath("gmailBodyStyl.xpath", null, driver).contains(email.toLowerCase())) {
				TestCaseInit.testCaseStatus = false;
				log.error("Password reset Email is NOT for: " + email);
				Assert.fail("Password reset Email is NOT for: " + email);	
			}
			//click element in last email - latest email
			if(genLibWeb.clickOnLastElementByXPath(null, verifyEmailChangePwdLinkHrefVal, driver)){
				for (String winHandle : driver.getWindowHandles()) {
					if(!winHandle.equalsIgnoreCase(parentHandle)){
						driver.switchTo().window(winHandle); // switch focus of reset password window
						break;
					}
				}
				Thread.sleep(1000);
				//verify new patient login using patient Verified email page
				newPatEmailVerPage.verifyNValidateNewPatientOnVerifiedEmailPage(driver);
				newPatEmailVerPage.verifyNValidateLogin(email, pwd, driver);
				Thread.sleep(1000);
				patientPage.clickOnLogout(driver);
			} else{
				parentHandle = null;
			}		
		}
		return parentHandle;
	}
	
	
	/**
	 * This method is used to verify email and reset password functionality for new users
	 * @param vMedNewEmail
	 * @param verifyEmailPwdLink
	 * @param newPassword
	 * @param driver
	 * @throws Exception
	 */
	public String validateEmailVerificationNPwdResetOnGmail(String vMedNewEmail, String newPassword, String userType, WebDriver driver) throws Exception {
		if(!validateEmailRecieved(vMedNewEmail, EMAIL_VERIFICATION_AND_PWD_RESET_SUBJECT_TITLE_VIRTUMEDIX, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Email NOT received for Email verification and Password reset");;
			Assert.fail("Email NOT received for Email verification and Password reset");
		} else {
			//verify sender
			verifySenderEmail(DEFAULT_SENDER_EMAIL_VIRTUMEDIX, driver);
			
			//verify url 
			//ui specifies the api url as http and not https; So, considering the latter part of api url prefix to verify and click the link
			String apiUrlPrefix = TestCaseInit.apiUrl;
			String splitApiUrlAtHttp[] = apiUrlPrefix.split(":");
			String verifyEmailChangePwdLinkHrefVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("verifyEmailChangePwdLinkHref.xpath"), "\'"+splitApiUrlAtHttp[1]);
	
			//email verification and password reset
			parentHandle = driver.getWindowHandle();
			//verify text in last email
			Thread.sleep(500);//wait to load
			if(!genLibWeb.getTextOfLastElementByXPath("gmailBodyStyl.xpath", null, driver).contains(vMedNewEmail.toLowerCase())) {
				TestCaseInit.testCaseStatus = false;
				log.error("Password reset Email is NOT for: " + vMedNewEmail);
				Assert.fail("Password reset Email is NOT for: " + vMedNewEmail);	
			}
			//click element in last email - latest email
			if(genLibWeb.clickOnLastElementByXPath(null, verifyEmailChangePwdLinkHrefVal, driver)){
				for (String winHandle : driver.getWindowHandles()) {
					if(!winHandle.equalsIgnoreCase(parentHandle)){
						driver.switchTo().window(winHandle); // switch focus of reset password window
						break;
					}
				}
				Thread.sleep(1000);
				genLibWeb.explicitWaitUntilElementWithXPathIsVisible("setPasswordH1.xpath", null, driver);
				genLibWeb.enterTextValueByXPath("newPasswordInp.ngModel.xpath", null, newPassword, driver);
				genLibWeb.enterTextValueByXPath("newPasswordInp.ngModel.xpath", null, newPassword, driver);
				genLibWeb.enterTextValueByXPath("confirmNewPasswordInp.ngModel.xpath", null, newPassword, driver);
				Thread.sleep(250);
				genLibWeb.clickOnElementByName("setPasswordSubmitBtn.name", driver);				
				if (genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driver)) {
					log.info("Password reset was Successful for: " + vMedNewEmail);
				} else {
					TestCaseInit.testCaseStatus = false;
					log.error("Password reset Failed for: " + vMedNewEmail);
					Assert.fail("Password reset Failed for: " + vMedNewEmail);					
				}
				
				//verify login with new credentials
				verifyLoginWthNewCredentials(vMedNewEmail, newPassword, userType, driver);
			} else{
				parentHandle = null;
			}		
		}
		return parentHandle;
	}

	
	/**
	 * This method is used to upload Bulk Doctor Gmail Verification..
	 * @param email
	 * @param password
	 * @param passwordResetLink
	 * @param newPassword
	 * @param driver
	 * @throws Exception
	 */
	public void bulkUploadGmailVerification(String email, String password, String newPassword, String userType, WebDriver driver) throws Exception{
		parentHandle = null;
		loginGmail(email, password, driver);
		try{			
			parentHandle = validateEmailVerificationNPwdResetOnGmail(email, newPassword, userType, driver);	
		} finally{			
			if(parentHandle != null){
				driver.close(); //close newly opened window when done with it
				driver.switchTo().window(parentHandle); //switch back to the original window	
			}
			logoutGmail(email, driver);					
		}
	}
	
	public void verifyNewConsultReportEmailForPatient(String email, String pwd, WebDriver driver) throws Exception{
		loginGmail(email, pwd, driver);
		Thread.sleep(5000);//wait for the email
		if(!validateEmailRecieved(email, PATIENT_NEW_CONSULT_REPORT_SUBJECT_TITLE_VIRTUMEDIX, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Email NOT received for New Consultation Report");
			Assert.fail("Email NOT received for New Consultation Report");
		}
		log.info("Email Received for New Consultation Report");	
		//verify body content
		String textBody = genLibWeb.getTextOfLastElementByXPath("gmailBodyStylConsultRepText.xpath", null, driver);
		if(!textBody.equals(PATIENT_NEW_CONSULT_REPORT_BODY_TITLE_VIRTUMEDIX)){
			log.error("Email body did NOT match to: "+ PATIENT_NEW_CONSULT_REPORT_BODY_TITLE_VIRTUMEDIX);
		} else {
			log.info("Email body Matched to: "+ PATIENT_NEW_CONSULT_REPORT_BODY_TITLE_VIRTUMEDIX);
		}
		//verify sender
		verifySenderEmail(DEFAULT_SENDER_EMAIL_VIRTUMEDIX, driver);
	}
	
//Helper
	private String getCorrectGmail(String email) {
		//Strip the substring after'+'(including +) in a given email; Example: For vmedixAuto1+D1@gmail.com, the actual Gmail account is vmedixAuto1@gmail.com
		//split at +
		String[] splitPlusEmail = email.split("\\+");
		int splitPlusEmailLen = splitPlusEmail.length;
		//split at @
		String[] splitAtEmail = splitPlusEmail[splitPlusEmailLen-1].split("\\@");	
		
		return splitPlusEmail[0] +"@"+ splitAtEmail[1];
	}
	
	private boolean verifySenderEmail(String senderEmail, WebDriver driver) throws Exception{
		boolean senderEmailVerified = false;
		String gmailSenderEmailXPathVal =  MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("gmailSenderEmail.xpath"), "\'"+senderEmail+"\'");
		if(genLibWeb.isElementFoundByXPath(null, gmailSenderEmailXPathVal , driver)){
			log.info("Sender Email Matched with: "+ senderEmail);
			senderEmailVerified = true;		
		}else {
			log.error("Sender Email does NOT match with: "+ senderEmail);	
		}
		return senderEmailVerified;
	}
	
	private boolean validateEmailRecieved(String email, String subjectTitle, WebDriver driver) throws Exception {
		boolean emailRecieved = false;
		try{
			//search for unread email title - reset password
			genLibWeb.clickOnElementByID("gmailSearchBoxInp.id", driver);
			genLibWeb.enterTextValueByID("gmailSearchBoxInp.id","is:unread label:inbox "+ subjectTitle, driver);
			genLibWeb.clickOnElementByID("gmailSearchBtn.id", driver);			
			//validate subject of the first unread email
			if(genLibWeb.clickOnElementByXPath("gmailFirstSearchEmailTr.xpath", null, driver)){
				//no new emails or no email with the reset password subject
				log.info("Email Received with subject title: "+ subjectTitle);				
				emailRecieved = true;
			} else {
				log.error("Email NOT received with subject title: "+ subjectTitle);	
			}
		} catch (Exception exp){
			throw exp;	
		}		
		return emailRecieved;
	}	
	
	private void verifyLoginWthNewCredentials(String email, String pwd, String userType, WebDriver driver) throws Exception{
		boolean loginSucc = false;
		if(VMedixUtils.USERTYPE_DOCTOR.equalsIgnoreCase(userType)){
			if(login.validateLoginAsExistingUser(email, pwd, driver) && (genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorLandingPageH1.xpath", null, driver))){
				loginSucc = true;
			}				
		} else if(VMedixUtils.USERTYPE_PATIENT.equalsIgnoreCase(userType)){
			if(login.validateLoginAsExistingUser(email, pwd, driver) && (genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patientLandingPageH1.xpath", null, driver))){
				loginSucc = true;
			}
		} else if(VMedixUtils.USERTYPE_CALLREP.equalsIgnoreCase(userType)){
			if(login.validateLoginAsExistingUser(email, pwd, driver) && (genLibWeb.explicitWaitUntilElementWithXPathIsVisible("callRepLandingPageH1.xpath", null, driver))){
				loginSucc = true;
			}
		} else if(VMedixUtils.USERTYPE_DOCTORADMIN.equalsIgnoreCase(userType)){
			if(login.validateLoginAsExistingUser(email, pwd, driver) && (genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminLandingPageH3.xpath", null, driver))){
				loginSucc = true;
			}
		}
		//if successful
		if(loginSucc) {
			log.info("Login was Successful with new credentials for: "+ email);
		} else{
			log.info("Login Failed with new credentials for: "+ email);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Login Failed with new credentials for: "+ email);
		}
	}
}
