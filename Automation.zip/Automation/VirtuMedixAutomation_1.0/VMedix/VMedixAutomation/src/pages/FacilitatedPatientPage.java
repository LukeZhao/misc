package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class FacilitatedPatientPage {
	private static Logger log = Logger.getLogger(FacilitatedPatientPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if on Facilitated Patient Page
	 */	
	public boolean verifyOnFacilitatedPatPage(String facPatName, WebDriver driver) throws Exception{
		boolean onPage = false;
		if(genLibWeb.explicitWaitUntilElementWithXPathIsVisible("facPatientLandingPageH1.xpath", null, driver)) {
			Thread.sleep(1000);
			if(StringUtils.containsIgnoreCase(genLibWeb.getTextByXPath("facPatientLandingPageH1.xpath", null, driver), facPatName)){
				onPage = true;
			}			
		}
		return onPage;		
	}
	
	/**
	 * This method is used to validate if on Facilitated Patient Page
	 */
	public void verifyNValidateOnFacilitatedPatPage(String facPatName, WebDriver driver)throws Exception {
		if(!verifyOnFacilitatedPatPage(facPatName, driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Facilitated Patient Page");
			Assert.fail("NOT on Facilitated Patient Page");
		}		
		log.info("On Facilitated Patient Page");
	}	
	
	public void verifyVideoTestLink(WebDriver driver)throws Exception {
		if(genLibWeb.isElementFoundByID("facPatVidTestAncLink.id", driver)){
			log.info("Video test link Found on facilitated patient page");
			genLibWeb.clickOnElementByID("facPatVidTestAncLink.id", driver);
			verifyVideoTestPopUp(driver);
			clickOnVideoTestPopUpOk(driver);
		}
		log.error("Video test link NOT found on facilitated patient page");		
	}
	
	public boolean verifyVideoTestPopUp(WebDriver driver)throws Exception {
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("facPatVidTestPopUpTitleH2.xpath", null, driver);
	}
	
	public void clickOnVideoTestPopUpOk(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByID("facPatVidTestPopUpOkBtn.id", driver);
	}
}
