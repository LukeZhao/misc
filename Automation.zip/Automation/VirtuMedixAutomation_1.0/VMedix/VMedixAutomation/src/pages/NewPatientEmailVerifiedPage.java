package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class NewPatientEmailVerifiedPage {
	static Logger log = Logger.getLogger(NewPatientEmailVerifiedPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	public PatientPage patientPage = new PatientPage();
	
	/**
	 * This method is used to verify if new patient is on Verified Email Page
	 */	
	public boolean verifyNewPatientOnVerifiedEmailPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("newPatEmailVerifiedPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if new patient is on Verified Email Page
	 */
	public void verifyNValidateNewPatientOnVerifiedEmailPage(WebDriver driver)throws Exception {
		if(!verifyNewPatientOnVerifiedEmailPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("New patient NOT on Verified Email Page");
			Assert.fail("New patient NOT on Verified Email Page");
		}		
		log.info("New patient is on Verified Email Page");
	}
	
	public boolean verifyLogin(String newPatEmail, String newPatPwd, WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByXPath("newPatEmailVerifiedEmailInp.ngModel.xpath", null, newPatEmail, driver);
		genLibWeb.enterTextValueByXPath("newPatEmailVerifiedPasswordInp.ngModel.xpath", null, newPatPwd, driver);
		genLibWeb.clickOnElementByXPath("newPatEmailVerifiedPasswordBtn.ngClick.xpath", null, driver);
		return patientPage.verifyPatientOnLandingPage(driver);
	}
	
	public void verifyNValidateLogin(String newPatEmail, String newPatPwd, WebDriver driver) throws Exception {
		if(!verifyLogin(newPatEmail, newPatPwd, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Email verification for new Patient was NOT successful, "+newPatEmail);
			Assert.fail("Email verification for new Patient was NOT successful, "+newPatEmail);	
		}
		log.info("Email verification for new Patient was Successful, "+newPatEmail);
	}	
}
