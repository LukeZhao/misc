package pages;

import java.text.MessageFormat;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class TrackingBoardScreenPage {
	static Logger log = Logger.getLogger(TrackingBoardScreenPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();

	/**
	 * This method checks for the Patient availability on Tracking Board for video consult
	 * @param patientName 
	 * @param driver
	 * @throws Exception
	 */
	public void checkPatientAvailableNStartConsultation(boolean videoConsult, String patientName, WebDriver driver) throws Exception {
		//find specific patient for consultation
		boolean found = false;
		String trackBrdPatientXPathVal = null;
		//video or phone consult
		if(videoConsult){
			trackBrdPatientXPathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docTrackingboardPatientVideoAncI.xpath"), patientName);
		} else {
			trackBrdPatientXPathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docTrackingboardPatientPhoneAncI.xpath"), patientName);
		}	
		while(!found) {
			if(genLibWeb.isElementFoundByXPath(null, trackBrdPatientXPathVal, driver)){
				found = true;
				log.info("Specified patient: "+patientName+" Found on Tracking board");
				genLibWeb.clickOnElementByXPath(null, trackBrdPatientXPathVal, driver);
			}
			if(!found){
				//search on next page
				if(!genLibWeb.isElementEnabledByXPath("nextBtnOnPages.ngClick.xpath", null, driver)){
					TestCaseInit.testCaseStatus = false;
					log.error("Specified patient: "+patientName+" NOT found on Tracking board");	
					Assert.fail("Specified patient: "+patientName+" NOT found on Tracking board");		
				} else{
					genLibWeb.clickOnElementByXPath("nextBtnOnPages.ngClick.xpath", null, driver);
					Thread.sleep(5000);
				}				
			}
		}
	}
	
	/**
	 * This method is used to verify if on Notify Doc Of Facilitated Pat Popup
	 */	
	public boolean verifyOnNotifyDocOfFacilitatedPatPopup(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorNotifyFacPatPopUpTitleH2.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Notify Doc Of Facilitated Pat Popup
	 */
	public void verifyNValidateOnNotifyDocOfFacilitatedPatPopup(WebDriver driver)throws Exception {
		if(!verifyOnNotifyDocOfFacilitatedPatPopup(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Patient is NOT on Notify Doc Of Facilitated Pat Popup");
			Assert.fail("Patient is NOT on Notify Doc Of Facilitated Pat Popup");
		}
		log.info("Patient is on Notify Doc Of Facilitated Pat Popup");
	}

	public void acceptFacPatOnNotifyDocPopup(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("doctorNotifyFacPatAcceptConsultBtn.id", driver);
	}
	
	public void cancelFacPatOnNotifyDocPopup(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("doctorNotifyFacPatCancelConsultBtn.id", driver);
	}	
}
