package pages;

import java.text.MessageFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import library.VMedixUtils.NotifyDoctorMethod;
import tests.TestCaseInit;

public class PatientConsultWaitingRoomHealthPreQueInfoPage {
	private static Logger log = Logger.getLogger(PatientConsultWaitingRoomHealthPreQueInfoPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	CommonUtilsPage cmnUtilsPage = new CommonUtilsPage(); 
	final String noHeightFeet = "0\'";
	final String noHeightInches = "0\"";
	final String noWeight = "0 lbs";
	final String dashHealthInfo = "--";
	final String smokePacksLessThan1 = "Less than 1";
	public final String autoItExeLocationForChrome_PatientAllowCamera = TestCaseInit.Current_Directory+"\\Test_Data\\ChromeAutoIt_AllowCamera.exe";
	
	/**
	 * This method is used to verify if on HealthInfo page
	 */	
	public boolean verifyPatientOnHealthInfoPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultHealthInfoPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on HealthInfo page
	 */
	public void verifyNValidatePatientOnHealthInfoPage(WebDriver driver)throws Exception {
		if(!verifyPatientOnHealthInfoPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Patient is NOT on Health Info page");
			Assert.fail("Patient is NOT on Health Info page");
		}
		log.info("Patient is on Health Info page");
	}
	
	/**
	 * This method is used to fill health info form. Specify null for the fields where there is no need of edit.	
	 * @param heighFeet
	 * @param heighInches
	 * @param weightLbs
	 * @param medCondition
	 * @param surgeries
	 * @param smoke
	 * @param smokePacksNum
	 * @param alcohol
	 * @param jobProf
	 * @param famMedProb
	 * @param driver
	 * @throws Exception 
	 */
	public void fillNReviewHealthInfo(String heighFeet, String heighInches, String weightLbs, String medCondition, String surgeries, String smoke, String smokePacksNum, String alcohol, String jobProf, 
			String famMedProb, String primDocName, String primDocPhone, String primDocFax, String primDocEmail, String primDocAddr1, String primDocAddr2, String primDocCity, String primDocState, String primDocZipCode, 
			String prefPharmName, String prefPharmPhone, String prefPharmFax, String prefPharmEmail, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, String prefPharmState, String prefPharmZipCode, WebDriver driver) throws Exception {
		//specify fields null, when need to do nothing. To clear the fields specify blank/empty string. For smoke yes or no is specified
		enterMedicalHistoryDetails(heighFeet, heighInches, weightLbs, medCondition, surgeries, smoke, smokePacksNum, VMedixUtils.ALCOHOL_NEVER, jobProf, famMedProb, primDocName, 
				primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail,	prefPharmAddr1, 
				prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driver);
		clickNextOnHealthInfoPage(driver);
		
		//review
		verifyMedicalHistoryDetails(heighFeet, heighInches, weightLbs, medCondition, surgeries, smoke, smokePacksNum, VMedixUtils.ALCOHOL_NEVER, jobProf, famMedProb, primDocName, 
				primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail,	prefPharmAddr1, 
				prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driver);
		clickSubmitOnReviewHealthInfoPage(driver);
	}
	
	public void enterMedicalHistoryDetails(String heighFeet, String heighInches, String weightLbs, String medCondition, String surgeries, String smoke, String smokePacksNum, String alcohol, String jobProf, 
			String famMedProb, String primDocName, String primDocPhone, String primDocFax, String primDocEmail, String primDocAddr1, String primDocAddr2, String primDocCity, String primDocState, String primDocZipCode, 
			String prefPharmName, String prefPharmPhone, String prefPharmFax, String prefPharmEmail, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, String prefPharmState, String prefPharmZipCode, WebDriver driver)throws Exception {
		enterHealthInfo(heighFeet, heighInches, weightLbs, medCondition, surgeries, smoke, smokePacksNum, alcohol, jobProf, famMedProb, driver);
		enterPrimaryDoctorInfo(primDocName, primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, driver);
		enterPreferredPharmacyInfo(prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driver);
	}
	
	public void verifyMedicalHistoryDetails(String heighFeet, String heighInches, String weightLbs, String medCondition, String surgeries, String smoke, String smokePacksNum, String alcohol, String jobProf, 
			String famMedProb, String primDocName, String primDocPhone, String primDocFax, String primDocEmail, String primDocAddr1, String primDocAddr2, String primDocCity, String primDocState, String primDocZipCode, 
			String prefPharmName, String prefPharmPhone, String prefPharmFax, String prefPharmEmail, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, String prefPharmState, String prefPharmZipCode, WebDriver driver)throws Exception {
		reviewHealthInfo(heighFeet, heighInches, weightLbs, medCondition, surgeries, smoke, smokePacksNum, alcohol, jobProf, famMedProb, driver);
		reviewPrimaryDoctorInfo(primDocName, primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, driver);
		reviewPreferredPharmacyInfo(prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driver);
	}
	
	public void enterHealthInfo(String heighFeet, String heighInches, String weightLbs, String medConditions, String surgeries, String smoke, String smokePacksNum, 
			String alcohol, String jobProf,	String famMedProbs, WebDriver driver) throws Exception {
		
		verifyNValidatePatientOnHealthInfoPage(driver);
		
		if(StringUtils.isNotBlank(heighFeet)){
			genLibWeb.selectByVisibleTextFromSelectElementName("patConsultHealthInfoHeightFeetDrpBx.name", heighFeet, driver);
		}
		if(heighInches != null){
			if(heighInches.isEmpty()){
				genLibWeb.selectByVisibleTextFromSelectElementName("patConsultHealthInfoHeightInchesDrpBx.name", "0", driver);
			}else{
				genLibWeb.selectByVisibleTextFromSelectElementName("patConsultHealthInfoHeightInchesDrpBx.name", heighInches, driver);
			}
		}
		if(weightLbs != null){
			genLibWeb.enterTextValueByName("patConsultHealthInfoHeightWeightInp.name", weightLbs, driver);
		}
		//med conditions
		if(StringUtils.isNotBlank(medConditions)){
			//remove old medical conditions
			cmnUtilsPage.removeOldMedicalConditions("patConsultHealthInfoMedCondOldListP.xpath", null, "patConsultHealthInfoMedCondOldRemoveSpan.xpath", driver);
			//add medical conditions with validation
			if(!cmnUtilsPage.enterMedicalConditions(medConditions,"patConsultHealthInfoMedCondInp.ngModel.xpath", null, "patConsultHealthInfoMedCondAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Medical Conditions were NOT added");				
				Assert.fail("One of the Medical Conditions were NOT added");		
			}
			log.info("All Medical Conditions were added");
		}
		//surgeries
		if(StringUtils.isNotBlank(surgeries)){
			//remove old surgeries
			cmnUtilsPage.removeOldSurgeries("patConsultHealthInfoSurgeriesOldListP.xpath", null, "patConsultHealthInfoSurgeriesOldRemoveSpan.xpath", driver);
			//add surgeries with validation
			if(!cmnUtilsPage.enterSurgeries(surgeries,"patConsultHealthInfoSurgeriesInp.ngModel.xpath", null, "patConsultHealthInfoSurgeriesAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Surgeries were NOT added");				
				Assert.fail("One of the Surgeries were NOT added");		
			}
			log.info("All Surgeries were added");
		}
		//family med probs		
		if(StringUtils.isNotBlank(famMedProbs)){
			//remove old family med probs
			cmnUtilsPage.removeOldFamilyMedicalProblems("patConsultHealthInfoFamMedProbOldListP.xpath", null, "patConsultHealthInfoFamMedProbOldRemoveSpan.xpath", driver);
			//add family med probs
			if(!cmnUtilsPage.enterFamilyMedicalProblems(famMedProbs, "patConsultHealthInfoFamMedProbInp.ngModel.xpath", null, "patConsultHealthInfoFamMedProbAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Family Medical Problems were NOT added");				
				Assert.fail("One of the Family Medical Problems were NOT added");		
			}
			log.info("All Family Medical Problems were added");			
		}
		//smoke
		if(StringUtils.isNotBlank(smoke)) {	
			if(smoke.equalsIgnoreCase(VMedixUtils.YES)){
				genLibWeb.clickRadioButtonByValueWithElementXPath("patConsultHealthInfoSmokeRdBtn.ngModel.xpath", null, VMedixUtils.YES.toLowerCase(), driver);
				if(StringUtils.isNotBlank(smokePacksNum)) { //default set to 0					
					genLibWeb.selectByVisibleTextFromSelectElementXPath("patConsultHealthInfoSmokePacksDrpBx.ngModel.xpath", null, smokePacksNum, driver);
				} 
			} else {
				genLibWeb.clickRadioButtonByValueWithElementXPath("patConsultHealthInfoSmokeRdBtn.ngModel.xpath", null, VMedixUtils.NO.toLowerCase(), driver);
			}
		} 
		if(alcohol != null) { //default is --
			genLibWeb.selectByVisibleTextFromSelectElementXPath("patConsultHealthInfoAlcoholDrpBx.ngModel.xpath", null, alcohol, driver);
		}
		if(jobProf != null) { //default is --
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoJobProfInp.ngModel.xpath", null, jobProf, driver);		
		}				
	}
	
	//TODO: VM-3984; when empty string for Zipcode
	public void enterPrimaryDoctorInfo(String primDocName, String phoneNum, String faxNum, String email, String addr1, String addr2, String city, String state, String zipCode, WebDriver driver) throws Exception {
		verifyNValidatePatientOnHealthInfoPage(driver);
		
		//verify if the primary doctor section add icon button found
		if(genLibWeb.isElementFoundByXPath("patConsultHealthInfoPrimDocAddIconBtn.ngClick.xpath", null, driver)){
			genLibWeb.clickOnElementByXPath("patConsultHealthInfoPrimDocAddIconBtn.ngClick.xpath", null, driver);
		}else if(!genLibWeb.isElementFoundByXPath("patConsultHealthInfoPrimDocMinusIconSpan.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Add icon NOT found for primary doctor info");
			Assert.fail("Add icon NOT found for primary doctor info");		
		}
		
		if(primDocName != null) {
			genLibWeb.enterTextValueByName("patConsultHealthInfoPrimDocNameInp.name", primDocName, driver);
		}
		if(phoneNum != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrimDocPhoneInp.ngModel.xpath", null, phoneNum, driver);
		}
		if(faxNum != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrimDocFaxInp.ngModel.xpath", null, faxNum, driver);
		}
		if(email != null) {
			genLibWeb.enterTextValueByName("patConsultHealthInfoPrimDocEmailInp.name", email, driver);
		}
		if(addr1 != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrimDocAddr1Inp.xpath", null, addr1, driver);
		}
		if(addr2 != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrimDocAddr2Inp.xpath", null, addr2, driver);
		}
		if(city != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrimDocCityInp.xpath", null, city, driver);
		}
		if(state != null) {
			genLibWeb.selectByValueFromSelectElementXPath("patConsultHealthInfoPrimDocStateDrpBx.xpath", null, "string:"+state, driver);
		}
		if(zipCode != null) { //VM-3984
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrimDocZipCodeInp.xpath", null, zipCode, driver);
		}
		
		//country is readonly and is auto generated based on location
		if(!(genLibWeb.isElementReadOnlyByXPath("patConsultHealthInfoPrimDocCountryInp.xpath", null, driver) 
				&&(!genLibWeb.getValueByXPath("patConsultHealthInfoPrimDocCountryInp.xpath", null, driver).isEmpty()))){
			log.error("Country NOT auto generated for Primary Doctor Info");			
		}		
	}
	
	//TODO: VM-3984; when empty string for Zipcode
	public void enterPreferredPharmacyInfo(String prefPharmacyName, String phoneNum, String faxNum, String email, String addr1, String addr2, String city, String state, String zipCode, WebDriver driver) throws Exception {
		verifyNValidatePatientOnHealthInfoPage(driver);
		
		//verify if the preferred pharmacy section add icon button is found 
		if(genLibWeb.isElementFoundByXPath("patConsultHealthInfoPrefPharmAddIconBtn.ngClick.xpath", null, driver)){
			genLibWeb.clickOnElementByXPath("patConsultHealthInfoPrefPharmAddIconBtn.ngClick.xpath", null, driver);
		}else if(!genLibWeb.isElementFoundByXPath("patConsultHealthInfoPrefPharmMinusIconSpan.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Add icon NOT found for preferred pharmacy");
			Assert.fail("Add icon NOT found for preferred pharmacy");
		}
		
		if(prefPharmacyName != null) {
			genLibWeb.enterTextValueByName("patConsultHealthInfoPrefPharmNameInp.name", prefPharmacyName, driver);
		}
		if(phoneNum != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrefPharmPhoneInp.ngModel.xpath", null, phoneNum, driver);
		}
		if(faxNum != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrefPharmFaxInp.ngModel.xpath", null, faxNum, driver);
		}
		if(email != null) {
			genLibWeb.enterTextValueByName("patConsultHealthInfoPrefPharmEmailInp.name", email, driver);
		}
		if(addr1 != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrefPharmAddr1Inp.xpath", null, addr1, driver);
		}
		if(addr2 != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrefPharmAddr2Inp.xpath", null, addr2, driver);
		}
		if(city != null) {
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrefPharmCityInp.xpath", null, city, driver);
		}
		if(state != null) {
			genLibWeb.selectByValueFromSelectElementXPath("patConsultHealthInfoPrefPharmStateDrpBx.xpath", null, "string:"+state, driver);
		}
		if(zipCode != null) { //VM-3984
			genLibWeb.enterTextValueByXPath("patConsultHealthInfoPrefPharmZipCodeInp.xpath", null, zipCode, driver);
		}
		//country is readonly and is auto generated based on location
		if(!(genLibWeb.isElementReadOnlyByXPath("patConsultHealthInfoPrefPharmCountryInp.xpath", null, driver) 
				&&(!genLibWeb.getValueByXPath("patConsultHealthInfoPrefPharmCountryInp.xpath", null, driver).isEmpty()))){
			log.error("Country NOT auto generated for Preferred Pharmacy Info");			
		}
	}	
	
	
	public void clickNextOnHealthInfoPage(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByXPath("patConsultHealthInfoNextBtn.ngClick.xpath", null, driver);
	}

	
	/**
	 * This method is used to verify if on HealthInfo page
	 */	
	public boolean verifyPatientOnReviewHealthInfoPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultReviewHealthInfoPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on HealthInfo page
	 */
	public void verifyNValidatePatientOnReviewHealthInfoPage(WebDriver driver) throws Exception {
		if(!verifyPatientOnReviewHealthInfoPage(driver)){
			TestCaseInit.testCaseStatus = false;
			log.info("Patient is NOT on Review Health Info page");
			Assert.fail("Patient is NOT on Review Health Info page");
		}
		log.info("Patient is on Review Health Info page");
	}
	
	public void reviewHealthInfo(String heighFeet, String heighInches, String weightLbs, String medCondition, String surgeries, String smoke, String smokePacksNum, 
			String alcohol,	String jobProf, String famMedProb,	WebDriver driver) throws Exception {
		verifyNValidatePatientOnReviewHealthInfoPage(driver);
 		String errMessage = "Health info NOT correct on Review Page for: ";
		try{
			String heightTxt = genLibWeb.getTextByID("patConsultReviewHealthInfoHeightTxtSpan.id", driver);
			if(StringUtils.isNotBlank(heighFeet)){
				//equals
				Assert.assertTrue(StringUtils.containsIgnoreCase(heightTxt, heighFeet.trim()+"'"), errMessage+"Height Feet, ");
			}

			if(heighInches != null) {
				if(heighInches.isEmpty()){ //default 0
					//equals
					Assert.assertTrue(StringUtils.containsIgnoreCase(heightTxt, "0") , errMessage+"Height Inches, ");					
				}else{
					Assert.assertTrue(StringUtils.containsIgnoreCase(heightTxt, heighInches.trim()+"\""), errMessage+"Height Inches, ");
				}
			}
			String weightTxt = genLibWeb.getTextByID("patConsultReviewHealthInfoWeightTxtSpan.id", driver);
			if(weightLbs != null){
				if(weightLbs.isEmpty()){ //default 0
					//equals
					Assert.assertTrue(StringUtils.containsIgnoreCase(weightTxt, "0"), errMessage+"Weight Lbs, ");					
				}else{
					Assert.assertTrue(StringUtils.containsIgnoreCase(weightTxt, weightLbs.trim()),	errMessage+"Weight Lbs, ");
				}	
			}
			
			//verify BMI 
			if((StringUtils.equalsIgnoreCase(weightTxt, noWeight))
				|| (StringUtils.containsIgnoreCase(heightTxt, noHeightFeet) 
						&& StringUtils.containsIgnoreCase(heightTxt, noHeightInches))) {				
				boolean assertVal = (genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoBMIHiddenSpan.xpath", null, driver) 
										&& (genLibWeb.getTextByXPath("patConsultReviewHealthInfoNoBMISpan.xpath", null, driver).equalsIgnoreCase(dashHealthInfo)));
				log.info("Expecting BMI calculation: -- ");
				Assert.assertTrue(assertVal, errMessage+"BMI, ");
			} else {
				String bmiCalculated = genLibWeb.getTextByXPath("patConsultReviewHealthInfoBMISpan.xpath", null, driver);
				Assert.assertTrue((!bmiCalculated.isEmpty() && !bmiCalculated.equalsIgnoreCase(dashHealthInfo)), errMessage+"BMI, ");
			}
			
			if(StringUtils.isBlank(medCondition)){ //default None
				if(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoMedCondSpan.xpath", null, driver)){
					log.info("Expecting Medical condition: None");
					Assert.assertTrue(genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoMedCondNoneSpan.xpath", null, driver), errMessage+"Medical conditions, ");
				}
			}else {
				//contains
				Assert.assertTrue(genLibWeb.isElementFoundByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultReviewHealthInfoMedCondTxtSpan.xpath"), medCondition.trim()), driver),
					errMessage+"Medical conditions, ");
			}
			
			if(StringUtils.isBlank(surgeries)){ //default None
				if(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoSurgeriesSpan.xpath", null, driver)){
					log.info("Expecting Surgeries: None");
					Assert.assertTrue(genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoSurgeriesNoneSpan.xpath", null, driver), errMessage+"Surgeries, ");
				}
			}else {
				//contains
				Assert.assertTrue(genLibWeb.isElementFoundByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultReviewHealthInfoSurgeriesTxtSpan.xpath"), surgeries.trim()), driver),
					errMessage+"Surgeries, ");
			}
			
			if(StringUtils.isBlank(famMedProb)){ //default None
				if(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoFamHistSpan.xpath", null, driver)){
					log.info("Expecting Family Medical History: None");
					Assert.assertTrue(genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoFamHistNoneSpan.xpath", null, driver), errMessage+"Family Medical History, ");
				}
			}else {
				//contains
				Assert.assertTrue(genLibWeb.isElementFoundByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultReviewHealthInfoFamHistTxtSpan.xpath"), famMedProb.trim()), driver),
					errMessage+"Family Medical History, ");
			}			

			if(StringUtils.isNotBlank(smoke)){ // default is empty
				if(smoke.equalsIgnoreCase(VMedixUtils.YES)){
					//equals				
					if(StringUtils.isBlank(smokePacksNum) || (!smokePacksNum.equalsIgnoreCase(smokePacksLessThan1) && Integer.parseInt(smokePacksNum) > 5)){
						smokePacksNum = "0";
					}
					Assert.assertTrue(genLibWeb.isElementFoundByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultReviewHealthInfoSmokeYesPacksSpan.xpath"), smokePacksNum.trim()), driver),
							errMessage+"Smoke Pack(s)/day, ");
				}else{
					log.info("Expecting Smoke: No");
					Assert.assertTrue(genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoSmokeNoSpan.xpath", null, driver), errMessage+"Smoke, ");
				}
			}
			
			if(alcohol != null){
				if(alcohol.isEmpty()|| !(alcohol.equalsIgnoreCase(VMedixUtils.ALCOHOL_NEVER) || alcohol.equalsIgnoreCase(VMedixUtils.ALCOHOL_OCCASIONALLY) || alcohol.equalsIgnoreCase(VMedixUtils.ALCOHOL_DAILY))) {// default --	
					if(genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoNoAlcoholSpan.xpath", null, driver)){
						log.info("Expecting Alcohol: -- ");
						Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoNoAlcoholSpan.xpath", null, driver).equalsIgnoreCase(dashHealthInfo), errMessage+"Alcohol, ");					
					}			
				} else{
					//equals
					Assert.assertTrue(genLibWeb.isElementFoundByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultReviewHealthInfoAlcoholSpan.xpath"), alcohol.trim()), driver),
							errMessage+"Alcohol, ");
				}
			}
			
			if(jobProf != null) {
				if(jobProf.isEmpty()) {// default --	
					if(genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoNoJobProfSpan.xpath", null, driver)){
						log.info("Expecting Job/Profession: -- ");
						Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoNoJobProfSpan.xpath", null, driver).equalsIgnoreCase(dashHealthInfo), errMessage+"Job/Profession, ");					
					}			
				} else{
					//equals
					Assert.assertTrue(genLibWeb.isElementFoundByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultReviewHealthInfoJobProfSpan.xpath"), jobProf.trim()), driver),
							errMessage+"Job/Profession, ");
				}
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}				
	}	
	
	public void reviewPrimaryDoctorInfo(String primDocName, String phoneNum, String faxNum, String email, String addr1, String addr2, String city, String state, String zipCode, WebDriver driver) throws Exception {
		verifyNValidatePatientOnReviewHealthInfoPage(driver);
		String errMessage = "Primary Doctor info NOT correct on Review Page for: ";
		try{
			if(primDocName != null){
				if(primDocName.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocNameSpan.xpath", null, driver).isEmpty(), errMessage+"Primary doctor Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocNameSpan.xpath", null, driver).equalsIgnoreCase(primDocName.trim()), errMessage+"Primary doctor Name, ");
				}
			}
			if(phoneNum != null){
				if(phoneNum.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocPhNumSpan.xpath", null, driver).isEmpty(), errMessage+"Primary doctor Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocPhNumSpan.xpath", null, driver).equalsIgnoreCase(phoneNum.trim()), errMessage+"Primary doctor Phone Number, ");
				}
			}		
			if(faxNum != null){
				if(faxNum.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocFaxNumSpan.xpath", null, driver).isEmpty(), errMessage+"Primary doctor Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocFaxNumSpan.xpath", null, driver).equalsIgnoreCase(faxNum.trim()), errMessage+"Primary doctor Fax Number, ");
				}
			}		
			if(email != null){
				if(email.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocEmailSpan.xpath", null, driver).isEmpty(), errMessage+"Primary doctor Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocEmailSpan.xpath", null, driver).equalsIgnoreCase(email.trim()), errMessage+"Primary doctor Email, ");
				}
			}			
			String fullAddressFromUI = genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocFullAddrSpan.xpath", null, driver);
			if((addr1 != null && addr1.trim().isEmpty()) && (addr2 != null && addr2.trim().isEmpty()) && 
					(city != null && city.trim().isEmpty()) && (state != null && state.trim().isEmpty()) && 
					(zipCode != null && zipCode.trim().isEmpty())) {
				Assert.assertTrue(fullAddressFromUI.isEmpty(), errMessage+"Primary doctor Full Address, ");			
			} else {
				if(addr1 != null){
					if(addr1.trim().isEmpty()){//empty string or with spaces
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoPrimDocAddr1Span.xpath", null, driver), errMessage+"Primary doctor Address 1, ");
					}else {//not null and not empty
						Assert.assertTrue(fullAddressFromUI.contains(addr1.trim()), errMessage+"Primary doctor Address 1, ");
					}
				}				
				if(addr2 != null){
					if(addr2.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoPrimDocAddr2Span.xpath", null, driver), errMessage+"Primary doctor Address 2, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(addr2.trim()), errMessage+"Primary doctor Address 2, ");
					}
				}
				if(city != null){
					if(city.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoPrimDocCitySpan.xpath", null, driver), errMessage+"Primary doctor City, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(city.trim()), errMessage+"Primary doctor City, ");
					}
				}
				if(state != null){
					if(state.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoPrimDocStateSpan.xpath", null, driver), errMessage+"Primary doctor State, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(state.trim()), errMessage+"Primary doctor State, ");
					}
				}				
				if(zipCode != null){
					if(zipCode.trim().isEmpty()){						
						Assert.assertTrue(StringUtils.isBlank(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrimDocZipCodeSpan.xpath", null, driver)), errMessage+"Primary doctor Zip code, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(zipCode.trim()), errMessage+"Primary doctor Zip code, ");
					}
				}
				//For now the below
				if(StringUtils.isNotBlank(zipCode)){
					Assert.assertTrue(fullAddressFromUI.contains(zipCode.trim()), errMessage+"Primary doctor Zip code, ");
				}	
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
	}
	
	public void reviewPreferredPharmacyInfo(String prefPharmacyName, String phoneNum, String faxNum, String email, String addr1, String addr2, String city, String state, String zipCode, WebDriver driver) throws Exception {
		verifyNValidatePatientOnReviewHealthInfoPage(driver);
		String errMessage = "Preferred Pharmacy info NOT correct on Review Page for: ";
		try{
			if(prefPharmacyName != null){
				if(prefPharmacyName.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmNameSpan.xpath", null, driver).isEmpty(), errMessage+"Preferred Pharmacy Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmNameSpan.xpath", null, driver).equalsIgnoreCase(prefPharmacyName.trim()), errMessage+"Preferred Pharmacy Name, ");
				}
			}
			if(phoneNum != null){
				if(phoneNum.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmPhNumSpan.xpath", null, driver).isEmpty(), errMessage+"Preferred Pharmacy Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmPhNumSpan.xpath", null, driver).equalsIgnoreCase(phoneNum.trim()), errMessage+"Preferred Pharmacy Phone Number, ");
				}
			}		
			if(faxNum != null){
				if(faxNum.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmFaxNumSpan.xpath", null, driver).isEmpty(), errMessage+"Preferred Pharmacy Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmFaxNumSpan.xpath", null, driver).equalsIgnoreCase(faxNum.trim()), errMessage+"Preferred Pharmacy Fax Number, ");
				}
			}		
			if(email != null){
				if(email.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmEmailSpan.xpath", null, driver).isEmpty(), errMessage+"Preferred Pharmacy Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmEmailSpan.xpath", null, driver).equalsIgnoreCase(email.trim()), errMessage+"Preferred Pharmacy Email, ");
				}
			}			
			String fullAddressFromUI = genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmFullAddrSpan.xpath", null, driver);
			if((addr1 != null && addr1.trim().isEmpty()) && (addr2 != null && addr2.trim().isEmpty()) && 
					(city != null && city.trim().isEmpty()) && (state != null && state.trim().isEmpty()) && 
					(zipCode != null && zipCode.trim().isEmpty())) {
				Assert.assertTrue(fullAddressFromUI.equalsIgnoreCase("US"), errMessage+"Primary doctor Full Address, ");//Country is auto generated			
			} else {
				if(addr1 != null){
					if(addr1.trim().isEmpty()){//empty string or with spaces
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoPrefPharmAddr1Span.xpath", null, driver), errMessage+"Preferred Pharmacy Address 1, ");
					}else {//not null and not empty
						Assert.assertTrue(fullAddressFromUI.contains(addr1.trim()), errMessage+"Preferred Pharmacy Address 1, ");
					}
				}				
				if(addr2 != null){
					if(addr2.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoPrefPharmAddr2Span.xpath", null, driver), errMessage+"Preferred Pharmacy Address 2, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(addr2.trim()), errMessage+"Preferred Pharmacy Address 2, ");
					}
				}
				if(city != null){
					if(city.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoPrefPharmCitySpan.xpath", null, driver), errMessage+"Preferred Pharmacy City, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(city.trim()), errMessage+"Preferred Pharmacy City, ");
					}
				}
				if(state != null){
					if(state.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patConsultReviewHealthInfoPrefPharmStateSpan.xpath", null, driver), errMessage+"Preferred Pharmacy State, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(state.trim()), errMessage+"Preferred Pharmacy State, ");
					}
				}				
				if(zipCode != null){
					if(zipCode.trim().isEmpty()){						
						Assert.assertTrue(StringUtils.isBlank(genLibWeb.getTextByXPath("patConsultReviewHealthInfoPrefPharmZipCodeSpan.xpath", null, driver)), errMessage+"Preferred Pharmacy Zip code, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(zipCode.trim()), errMessage+"Preferred Pharmacy Zip code, ");
					}
				}
				//For now the below
				if(StringUtils.isNotBlank(zipCode)){
					Assert.assertTrue(fullAddressFromUI.contains(zipCode.trim()), errMessage+"Preferred Pharmacy Zip code, ");
				}	
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}
	
	/**
	 * This method is used to click submit button on Review Health info page 
	 */
	public void clickSubmitOnReviewHealthInfoPage(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByXPath("patConsultReviewHealthInfoSubmitBtn.ngClick.xpath", null, driver);
	}
	
	/**
	 * This method is used to verify if on Notify Doctor popup
	 */	
	public boolean verifyPatientOnNotifyDoctorPopUp(WebDriver driver) throws Exception{
		return genLibWeb.isElementFoundByXPath("patConsultNotifyDoctorPopUpH4.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Notify Doctor popup 
	 */
	public void verifyNValidatePatientOnNotifyDoctorPopUp(WebDriver driver) throws Exception {
		if(!verifyPatientOnNotifyDoctorPopUp(driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Patient is NOT on Notify Doctor Popup");
			Assert.fail("Patient is NOT on Notify Doctor Popup");
		}
		log.info("Patient is on Notify Doctor Popup");
	}
	
	/**
	 * This function is used to handle notify doctor method pop up.
	 * @param notifyDocMeth
	 * @param driver
	 * @throws Exception
	 */
	public void notifyMethodForDoctor(NotifyDoctorMethod notifyDocMeth, String notifyPhoneNum,  WebDriver driver) throws Exception {
		//verify notification pop up
		verifyNValidatePatientOnNotifyDoctorPopUp(driver);
		boolean checkPhNum = false;
		switch(notifyDocMeth) {
			case TEXT_ME:
				genLibWeb.clickOnElementByID("patConsultNotifyDoctorTextMeRdBtn.id", driver);
				checkPhNum = true;
				break;
			case CALL_ME:
				genLibWeb.clickOnElementByID("patConsultNotifyDoctorCallMeRdBtn.id", driver);
				checkPhNum = true;
				break;
			case NO_THANKS:
				genLibWeb.clickOnElementByXPath("patConsultNotifyDoctorNoThanksBtn.ngClick.xpath", null, driver);
				break;
			case CONTINUE:
				genLibWeb.clickOnElementByXPath("patConsultNotifyDoctorContinueBtn.ngClick.xpath", null, driver);
				break;
		}
		if(checkPhNum) {
			Thread.sleep(2000);
			if(!genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultNotifyDoctorNumberInp.ngModel.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("Default Notify doctor Phone Number option NOT displayed");
				Assert.fail("Default Notify doctor Phone Number option NOT displayed");
			}
			log.error("Default Notify doctor Phone Number option Displayed");
			if(genLibWeb.getValueByXPath("patConsultNotifyDoctorNumberInp.ngModel.xpath", null, driver).trim().isEmpty()){
				TestCaseInit.testCaseStatus = false;
				log.error("Default Notify doctor Phone Number NOT present");
				Assert.fail("Default Notify doctor Phone Number NOT present");
			} else {
				log.info("Default Notify doctor Phone Number present");	
				Thread.sleep(1000);
				if(StringUtils.isNotBlank(notifyPhoneNum)){
					genLibWeb.enterTextValueByXPath("patConsultNotifyDoctorNumberInp.ngModel.xpath", null, notifyPhoneNum, driver);
					Thread.sleep(500);
				}
				genLibWeb.clickOnElementByXPath("patConsultNotifyDoctorContinueBtn.ngClick.xpath", null, driver);
			}
		}
	}
	
	/**
	 * This method is used to verify if on Notify Doctor popup
	 */	
	public boolean verifyBeginConsultationPoUpDueToDoc(String docName, WebDriver driver) throws Exception{
		boolean onPopUp = false;
		if(StringUtils.containsIgnoreCase(genLibWeb.getTextByXPath("patConsultBeginConsultationPopUpH3.xpath", null, driver), docName)){
			onPopUp = true;
		}
		return onPopUp;
	}	
	
	/**
	 * This method is used to validate if on Notify Doctor popup 
	 */
	public void verifyNValidateBeginConsultationPoUp(String docName, WebDriver driver) throws Exception {
		if(!verifyBeginConsultationPoUpDueToDoc(docName, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Patient is NOT on Begin Consultation Popup");
			Assert.fail("Patient is NOT on Begin Consultation Popup");
		}
		log.info("Patient is on Begin Consultation Popup");
	}
	
	/**
	 * This function is used to click on Begin Button.	
	 * @param driver
	 * @throws Exception
	 */
	public void beginConsultationStartedByDoctor(String docName , WebDriver driver) throws Exception {
		Thread.sleep(3000);
		verifyNValidateBeginConsultationPoUp(docName, driver);		
		if(genLibWeb.explicitWaitUntilElementWithNameIsVisible("patConsultBeginBtn.name", driver)){
			genLibWeb.clickOnElementByName("patConsultBeginBtn.name", driver);
		}else{
			TestCaseInit.testCaseStatus = false;
			log.error("Begin Consultation button NOT present on patient");
			Assert.fail("Begin Consultation button NOT present on patient");
		}
	}	
}
