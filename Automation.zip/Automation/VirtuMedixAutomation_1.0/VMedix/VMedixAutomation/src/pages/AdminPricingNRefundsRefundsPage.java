package pages;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class AdminPricingNRefundsRefundsPage {
	static Logger log = Logger.getLogger(AdminPricingNRefundsRefundsPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	public static String idValueForApprove = null;
	public static String xpathValueForReject = null;
	
	/**
	 * This method is used to verify if on Admin Pricing N Refunds: Refunds Page
	 */	
	public boolean verifyOnAdminPricingNRefundsRefundsPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminPricingNRefundRefundsTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin Pricing N Refunds: Refunds Page
	 */
	public void verifyNValidateOnAdminPricingNRefundsRefundsPage(WebDriver driver)throws Exception {
		if(!verifyOnAdminPricingNRefundsRefundsPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Admin Pricing N Refunds: Refunds Page");
			Assert.fail("NOT on Admin Pricing N Refunds: Refunds Page");
		}		
		log.info("On Admin Pricing N Refunds: Refunds Page");
	}
	
	public void searchByPatEmail(String patEmail, WebDriver driver) throws Exception{
		genLibWeb.enterTextValueByID("docAdminPrcNRefRefundsSearchInp.id", patEmail, driver);
		genLibWeb.clickOnElementByID("docAdminPrcNRefRefundsSearchBtn.id", driver);
		Thread.sleep(3000);
	}

	public void approveRefund(String patEmail, String docName, WebDriver driver) throws Exception {
		searchByPatEmail(patEmail, driver);		
		lookupRefundRecord(docName, driver);
		genLibWeb.clickOnElementByID(null, idValueForApprove, driver);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);		
		if(!TestCaseInit.messagesVMedixProp.getProperty("refundApproved.success").equals(toastMsg)) {
			TestCaseInit.testCaseStatus = false;
			log.error("Refund NOT approved for patient, "+ patEmail);
			Assert.fail("Refund NOT approved for patient, "+ patEmail);
		}
		log.info("Refund approved for patient, "+ patEmail);
	}
	
	public void rejectRefund(String patEmail, String docName, WebDriver driver) throws Exception {
		searchByPatEmail(patEmail, driver);		
		lookupRefundRecord(docName, driver);		
		genLibWeb.clickOnElementByXPath(null, xpathValueForReject, driver);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);		
		if(!TestCaseInit.messagesVMedixProp.getProperty("refundRejected.success").equals(toastMsg)) { 
			TestCaseInit.testCaseStatus = false;
			log.error("Refund NOT rejected for patient, "+ patEmail);
			Assert.fail("Refund NOT rejected for patient, "+ patEmail);
		}			
		log.info("Refund rejected for patient, "+ patEmail);
	}

	private void lookupRefundRecord(String docName, WebDriver driver) throws Exception {
		//get the count of refund records fetched, ignore header
		int countOfRefRec = genLibWeb.getElementsByXPath("docAdminPrcNRefRefundsRowsFetchedTrs.xpath", null, driver).size()-1;
		if(!(countOfRefRec > 0) ){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Refund records found");	
			Assert.fail("NO Refund records found");
		}	
		boolean found = false;
		DateFormat dateFormat1 = new SimpleDateFormat("M/d/yy");
		String currentDate = dateFormat1.format(new Date());
		for(int i=0; i<countOfRefRec; i++){
			String rowCount = Integer.toString(i);
			String subDateXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminPrcNRefRefundsSubmissionDateTd.xpath"), rowCount);
			String docNameXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminPrcNRefRefundsDocNameTd.xpath"), rowCount);
			String refundStatusXpathVal =  MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminPrcNRefRefundsRefundStatusTd.xpath"), rowCount);
			if(currentDate.equals(genLibWeb.getTextByXPath(null, subDateXpathVal, driver))
					&& docName.equalsIgnoreCase(genLibWeb.getTextByXPath(null, docNameXpathVal, driver))
					&& VMedixUtils.REFUND_STATUS_PENDING.equalsIgnoreCase(genLibWeb.getTextByXPath(null, refundStatusXpathVal, driver))){	
				idValueForApprove = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminPrcNRefRefundsApproveTdBtn.id"), rowCount);
				xpathValueForReject = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminPrcNRefRefundsRejectTdBtn.xpath"), rowCount);
				found = true;
				break;				
			}
		}
		if(!found){
			TestCaseInit.testCaseStatus = false;
			log.error("Refund record NOT found");
			Assert.fail("Refund record NOT found");
		}
		log.info("Refund record Found");
	}
}
