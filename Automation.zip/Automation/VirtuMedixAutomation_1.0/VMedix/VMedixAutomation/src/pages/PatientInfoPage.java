package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class PatientInfoPage {
	private static Logger log = Logger.getLogger(CommonUtilsPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();	
	
	final String noHeightFeet = "0\'";
	final String noHeightInches = "0\"";
	final String noWeightBlank = " ";
	final String noWeight0 = "0 lbs";
	final String dashInfo = "--";
	final String smokePacksLessThan1 = "Less than 1";
	
	public boolean verifyPatientOnPatientInfoPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patInfoPageSpan.xpath", null, driver);
	}
	
	public void verifyNValidatePatientOnPatientInfoPage(WebDriver driver) throws Exception{
		if(!verifyPatientOnPatientInfoPage(driver)){
			TestCaseInit.testCaseStatus = false;
			log.info("Patient is NOT on the Patient Info page");
			Assert.fail("Patient is NOT on the Patient Info page");
		}
		log.info("Patient is on the Patient Info page");
	}
	
	public void verifyPatientInfo(String heighFeet, String heighInches, String weightLbs, String medications, String allergies, String medCondition, String surgeries, String smoke, String smokePacksNum, String alcohol, String jobProf, 
			String famMedProb, String primDocName, String primDocPhone, String primDocFax, String primDocEmail, String primDocAddr1, String primDocAddr2, String primDocCity, String primDocState, 
			String primDocZipCode, String prefPharmName, String prefPharmPhone, String prefPharmFax, String prefPharmEmail, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, 
			String prefPharmState, String prefPharmZipCode, WebDriver driver) throws Exception{
		verifyHealthInfo(heighFeet, heighInches, weightLbs, medications, allergies, medCondition, surgeries, smoke, smokePacksNum, alcohol, jobProf, famMedProb, driver);
		verifyPrimaryDoctorInfo(primDocName, primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, driver);
		verifyPreferredPharmacyInfo(prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driver);
	}

	public void verifyHealthInfo(String heighFeet, String heighInches, String weightLbs, String medications, String allergies, String medCondition, String surgeries, String smoke, String smokePacksNum, 
			String alcohol, String jobProf, String famMedProb, WebDriver driver) throws Exception {
 		String errMessage = "Health info NOT correct on Patient Info page for: ";
		try{
			String heightFrmUi = genLibWeb.getTextByID("patInfoHeightSpan.id", driver);			
			if(StringUtils.isNotBlank(heighFeet)){
				//equals
				Assert.assertTrue(heightFrmUi.contains(heighFeet.trim()+"\'"), errMessage+"Height Feet, ");
			}
			if(heighInches != null) {
				if(heighInches.isEmpty()){ //default 0
					//equals
					Assert.assertTrue(heightFrmUi.contains(noHeightInches),	errMessage+"Height Inches, ");					
				}else{
					Assert.assertTrue(heightFrmUi.contains(heighInches.trim()+"\""),
						errMessage+"Height Inches, ");
				}
			}
			String weightFrmUi = genLibWeb.getTextByID("patInfoWeightSpan.id", driver);	
			if(weightLbs != null){
				if(weightLbs.isEmpty()){ //default 0
					//equals
					Assert.assertTrue(weightFrmUi.equalsIgnoreCase(noWeight0) || weightFrmUi.equalsIgnoreCase(noWeightBlank)|| weightFrmUi.equalsIgnoreCase(dashInfo),errMessage+"Weight Lbs, ");					
				}else{
					Assert.assertTrue(weightFrmUi.contains(weightLbs.trim()+" lbs"), errMessage+"Weight Lbs, ");
				}	
			}			
			//verify BMI 
			if((genLibWeb.getTextByID("patInfoWeightSpan.id", driver).equalsIgnoreCase(noWeight0) 
					|| genLibWeb.getTextByID("patInfoWeightSpan.id", driver).equalsIgnoreCase(noWeightBlank) 
					||genLibWeb.getTextByID("patInfoWeightSpan.id", driver).equalsIgnoreCase(dashInfo))
				|| (heightFrmUi.contains(noHeightFeet) 
						&& heightFrmUi.contains(noHeightInches))) {				
				boolean assertVal = (genLibWeb.isElementFoundByXPath("patInfoBMIHiddenSpan.xpath", null, driver) 
										&& (genLibWeb.getTextByXPath("patInfoNoBMISpan.xpath", null, driver).equalsIgnoreCase(dashInfo)));
				log.info("Expecting BMI calculation: -- ");
				Assert.assertTrue(assertVal, errMessage+"BMI, ");
			} else {
				String bmiCalculated = genLibWeb.getTextByXPath("patInfoBMISpan.xpath", null, driver);
				Assert.assertTrue((!bmiCalculated.isEmpty() && !bmiCalculated.equalsIgnoreCase(dashInfo)), errMessage+"BMI, ");
			}	
			
			if(medications != null){
				if(StringUtils.isBlank(medications)){ //default None
					if(!genLibWeb.isElementFoundByID("patInfoMedicationsSpan.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("patInfoMedicationsSpan.id", driver))){
						log.info("Expecting Medications: None");
						Assert.assertTrue(genLibWeb.getTextByID("patInfoMedicationsNoneSpan.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMessage+"Medications, ");
					}
				}else {
					//contains
					Assert.assertEquals(genLibWeb.getTextByID("patInfoMedicationsSpan.id", driver), medications, errMessage+"Medications, ");
				}
			}
	
			if(allergies != null){
				if(StringUtils.isBlank(allergies)){ //default None
					if(!genLibWeb.isElementFoundByID("patInfoAllergiesSpan.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("patInfoAllergiesSpan.id", driver))){
						log.info("Expecting Allergies: None");
						Assert.assertTrue(genLibWeb.getTextByID("patInfoAllergiesNoneSpan.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMessage+"Allergies, ");
					}
				}else {
					//contains
					Assert.assertEquals(genLibWeb.getTextByID("patInfoAllergiesSpan.id", driver), allergies, errMessage+"Allergies, ");
				}
			}

			if(medCondition != null){
				if(StringUtils.isBlank(medCondition)){ //default None
					if(!genLibWeb.isElementFoundByID("patInfoMedCondSpan.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("patInfoMedCondSpan.id", driver))){
						log.info("Expecting Medical Conditions: None");
						Assert.assertTrue(genLibWeb.getTextByID("patInfoMedCondNoneSpan.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMessage+"Medical conditions, ");
					}
				}else {
					//contains
					Assert.assertEquals(genLibWeb.getTextByID("patInfoMedCondSpan.id", driver), medCondition, errMessage+"Medical conditions, ");
				}
			}
			
			if(surgeries != null){
				if(StringUtils.isBlank(surgeries)){ //default None
					if(!genLibWeb.isElementFoundByID("patInfoSurgeriesSpan.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("patInfoSurgeriesSpan.id", driver))){
						log.info("Expecting Surgeries: None");
						Assert.assertTrue(genLibWeb.getTextByID("patInfoSurgeriesNoneSpan.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMessage+"Surgeries, ");
					}
				}else {
					//contains
					Assert.assertEquals(genLibWeb.getTextByID("patInfoSurgeriesSpan.id", driver), surgeries, errMessage+"Surgeries, ");
				}
			}
		
			if(famMedProb != null){
				if(StringUtils.isBlank(famMedProb)){ //default None
					if(!genLibWeb.isElementFoundByID("patInfoFamHistSpan.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("patInfoFamHistSpan.id", driver))){
						log.info("Expecting Family Medical History: None");
						Assert.assertTrue(genLibWeb.getTextByID("patInfoFamHistNoneSpan.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMessage+"Family Medical History, ");
					}
				}else {
					//contains
					Assert.assertEquals(genLibWeb.getTextByID("patInfoFamHistSpan.id", driver), famMedProb, errMessage+"Family Medical History, ");
				}
			}
			
			if(smoke != null){
				if(StringUtils.isNotBlank(smoke)){ // default is empty
					if(smoke.equalsIgnoreCase(VMedixUtils.YES)){
						//equals				
						if(StringUtils.isBlank(smokePacksNum) || (!smokePacksNum.equalsIgnoreCase(smokePacksLessThan1) && Integer.parseInt(smokePacksNum) > 5)){
							smokePacksNum = "0";
						}
						Assert.assertTrue(StringUtils.containsIgnoreCase(genLibWeb.getTextByID("patInfoSmokeYesPacksSpan.id", driver), smokePacksNum), errMessage+"Smoke Pack(s)/day, " );
					}else{
						log.info("Expecting Smoke: No");
						Assert.assertTrue(genLibWeb.getTextByID("patInfoSmokeNoSpan.id", driver).equalsIgnoreCase(VMedixUtils.NO), errMessage+"Smoke, ");
					}
				}			
			}

			if(alcohol != null){// default --
				if(alcohol.isEmpty()|| !(alcohol.equalsIgnoreCase(VMedixUtils.ALCOHOL_NEVER) || alcohol.equalsIgnoreCase(VMedixUtils.ALCOHOL_OCCASIONALLY) || alcohol.equalsIgnoreCase(VMedixUtils.ALCOHOL_DAILY))) {// default --	
					if(genLibWeb.isElementFoundByID("patInfoNoAlcoholSpan.id", driver)){
						log.info("Expecting Alcohol: -- ");
						Assert.assertTrue(genLibWeb.getTextByID("patInfoNoAlcoholSpan.id", null, driver).equalsIgnoreCase(dashInfo), errMessage+"Alcohol, ");					
					}			
				} else{
					//equals
					Assert.assertTrue(genLibWeb.getTextByID("patInfoAlcoholSpan.id", driver).equalsIgnoreCase(alcohol.trim()), errMessage+"Alcohol, ");
				}
			}
			
			if(jobProf != null) {
				if(jobProf.isEmpty()) {// default --	
					if(genLibWeb.isElementFoundByID("patInfoNoJobProfSpan.id", driver)){
						log.info("Expecting Job/Profession: -- ");
						Assert.assertTrue(genLibWeb.getTextByID("patInfoNoJobProfSpan.id", driver).equalsIgnoreCase(dashInfo), errMessage+"Job/Profession, ");					
					}			
				} else{
					//equals
					Assert.assertTrue(genLibWeb.getTextByID("patInfoJobProfSpan.id", driver).equalsIgnoreCase(jobProf.trim()), errMessage+"Job/Profession, ");
				}
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}			
	}
	
	public void verifyPrimaryDoctorInfo(String primDocName, String phoneNum, String faxNum, String email, String addr1, String addr2, String city, String state, String zipCode, WebDriver driver) throws Exception {
		String errMessage = "Primary Doctor info NOT correct on Patient Info page for: ";
		try{
			if(primDocName != null){
				if(primDocName.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrimDocNameSpan.id", driver).isEmpty(), errMessage+"Primary doctor Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrimDocNameSpan.id", driver).equalsIgnoreCase(primDocName.trim()), errMessage+"Primary doctor Name, ");
				}
			}
			if(phoneNum != null){
				if(phoneNum.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrimDocPhNumSpan.id",driver).isEmpty(), errMessage+"Primary doctor Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrimDocPhNumSpan.id", driver).equalsIgnoreCase(phoneNum.trim()), errMessage+"Primary doctor Phone Number, ");
				}
			}		
			if(faxNum != null){
				if(faxNum.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrimDocFaxNumSpan.id", driver).isEmpty(), errMessage+"Primary doctor Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrimDocFaxNumSpan.id", driver).equalsIgnoreCase(faxNum.trim()), errMessage+"Primary doctor Fax Number, ");
				}
			}		
			if(email != null){
				if(email.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrimDocEmailSpan.id", driver).isEmpty(), errMessage+"Primary doctor Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrimDocEmailSpan.id", driver).equalsIgnoreCase(email.trim()), errMessage+"Primary doctor Email, ");
				}
			}			
			String fullAddressFromUI = genLibWeb.getTextByXPath("patInfoPrimDocFullAddrSpan.xpath", null, driver);
			if((addr1 != null && addr1.trim().isEmpty()) && (addr2 != null && addr2.trim().isEmpty()) && 
					(city != null && city.trim().isEmpty()) && (state != null && state.trim().isEmpty()) && 
					(zipCode != null && zipCode.trim().isEmpty())) {
				Assert.assertTrue(fullAddressFromUI.isEmpty(), errMessage+"Primary doctor Full Address, ");			
			} else {
				if(addr1 != null){
					if(addr1.trim().isEmpty()){//empty string or with spaces
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patInfoPrimDocAddr1Span.xpath", null, driver), errMessage+"Primary doctor Address 1, ");
					}else {//not null and not empty
						Assert.assertTrue(fullAddressFromUI.contains(addr1.trim()), errMessage+"Primary doctor Address 1, ");
					}
				}				
				if(addr2 != null){
					if(addr2.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patInfoPrimDocAddr2Span.xpath", null, driver), errMessage+"Primary doctor Address 2, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(addr2.trim()), errMessage+"Primary doctor Address 2, ");
					}
				}
				if(city != null){
					if(city.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patInfoPrimDocCitySpan.xpath", null, driver), errMessage+"Primary doctor City, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(city.trim()), errMessage+"Primary doctor City, ");
					}
				}
				if(state != null){
					if(state.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patInfoPrimDocStateSpan.xpath", null, driver), errMessage+"Primary doctor State, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(state.trim()), errMessage+"Primary doctor State, ");
					}
				}				
				if(zipCode != null){
					if(zipCode.trim().isEmpty()){						
						Assert.assertTrue(StringUtils.isBlank(genLibWeb.getTextByXPath("patInfoPrimDocZipCodeSpan.xpath", null, driver)), errMessage+"Primary doctor Zip code, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(zipCode.trim()), errMessage+"Primary doctor Zip code, ");
					}
				}
				//For now the below
				if(StringUtils.isNotBlank(zipCode)){
					Assert.assertTrue(fullAddressFromUI.contains(zipCode.trim()), errMessage+"Primary doctor Zip code, ");
				}	
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
	}

	public void verifyPreferredPharmacyInfo(String prefPharmacyName, String phoneNum, String faxNum, String email, String addr1, String addr2, String city, String state, String zipCode, WebDriver driver) throws Exception {
		String errMessage = "Preferred Pharmacy info NOT correct on Patient Info page for: ";
		try{
			if(prefPharmacyName != null){
				if(prefPharmacyName.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrefPharmNameSpan.id", driver).isEmpty(), errMessage+"Preferred Pharmacy Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrefPharmNameSpan.id", driver).equalsIgnoreCase(prefPharmacyName.trim()), errMessage+"Preferred Pharmacy Name, ");
				}
			}
			if(phoneNum != null){
				if(phoneNum.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrefPharmPhNumSpan.id", driver).isEmpty(), errMessage+"Preferred Pharmacy Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrefPharmPhNumSpan.id", driver).equalsIgnoreCase(phoneNum.trim()), errMessage+"Preferred Pharmacy Phone Number, ");
				}
			}		
			if(faxNum != null){
				if(faxNum.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrefPharmFaxNumSpan.id", driver).isEmpty(), errMessage+"Preferred Pharmacy Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrefPharmFaxNumSpan.id", driver).equalsIgnoreCase(faxNum.trim()), errMessage+"Preferred Pharmacy Fax Number, ");
				}
			}		
			if(email != null){
				if(email.trim().isEmpty()){
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrefPharmEmailSpan.id", driver).isEmpty(), errMessage+"Preferred Pharmacy Name, ");
				} else{
					Assert.assertTrue(genLibWeb.getTextByID("patInfoPrefPharmEmailSpan.id", driver).equalsIgnoreCase(email.trim()), errMessage+"Preferred Pharmacy Email, ");
				}
			}			
			String fullAddressFromUI = genLibWeb.getTextByXPath("patInfoPrefPharmFullAddrSpan.xpath", null, driver);
			if((addr1 != null && addr1.trim().isEmpty()) && (addr2 != null && addr2.trim().isEmpty()) && 
					(city != null && city.trim().isEmpty()) && (state != null && state.trim().isEmpty()) && 
					(zipCode != null && zipCode.trim().isEmpty())) {
				Assert.assertTrue(fullAddressFromUI.equalsIgnoreCase("US"), errMessage+"Primary doctor Full Address, ");//Country is auto generated			
			} else {
				if(addr1 != null){
					if(addr1.trim().isEmpty()){//empty string or with spaces
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patInfoPrefPharmAddr1Span.xpath", null, driver), errMessage+"Preferred Pharmacy Address 1, ");
					}else {//not null and not empty
						Assert.assertTrue(fullAddressFromUI.contains(addr1.trim()), errMessage+"Preferred Pharmacy Address 1, ");
					}
				}				
				if(addr2 != null){
					if(addr2.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patInfoPrefPharmAddr2Span.xpath", null, driver), errMessage+"Preferred Pharmacy Address 2, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(addr2.trim()), errMessage+"Preferred Pharmacy Address 2, ");
					}
				}
				if(city != null){
					if(city.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patInfoPrefPharmCitySpan.xpath", null, driver), errMessage+"Preferred Pharmacy City, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(city.trim()), errMessage+"Preferred Pharmacy City, ");
					}
				}
				if(state != null){
					if(state.trim().isEmpty()){
						Assert.assertTrue(!genLibWeb.isElementFoundByXPath("patInfoPrefPharmStateSpan.xpath", null, driver), errMessage+"Preferred Pharmacy State, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(state.trim()), errMessage+"Preferred Pharmacy State, ");
					}
				}				
				if(zipCode != null){
					if(zipCode.trim().isEmpty()){						
						Assert.assertTrue(StringUtils.isBlank(genLibWeb.getTextByXPath("patInfoPrefPharmZipCodeSpan.xpath", null, driver)), errMessage+"Preferred Pharmacy Zip code, ");
					}else {
						Assert.assertTrue(fullAddressFromUI.contains(zipCode.trim()), errMessage+"Preferred Pharmacy Zip code, ");
					}
				}
				//For now the below
				if(StringUtils.isNotBlank(zipCode)){
					Assert.assertTrue(fullAddressFromUI.contains(zipCode.trim()), errMessage+"Preferred Pharmacy Zip code, ");
				}	
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}				
	}
}
