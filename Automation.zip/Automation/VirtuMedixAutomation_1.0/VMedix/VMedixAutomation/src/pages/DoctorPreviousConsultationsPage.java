package pages;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class DoctorPreviousConsultationsPage {

	private static Logger log = Logger.getLogger(DoctorPreviousConsultationsPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	public static String xpathValueForPrevConsultOfAnotherDoctor = null;	
	CommonUtilsPage cmnUtilsPage = new CommonUtilsPage(); 

	/**
	 * This method is used to verify if Doctor on previous consults page
	 */	
	public boolean verifyDoctorOnPreviousConsultsPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorPrevConsultsPageTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if Doctor on previous consults page
	 */
	public void verifyNValidateDoctorOnPreviousConsultsPage(WebDriver driver)throws Exception {
		if(!verifyDoctorOnPreviousConsultsPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT on Previous consults page");
			Assert.fail("Doctor is NOT on Previous consults page");
		}		
		log.info("Doctor is on Previous consults page");
	}
	
	public void clickOnPreviousConsults(WebDriver driver) throws Exception {
		Thread.sleep(1000);
		genLibWeb.clickOnElementByID("doctorPrevConsultsLinkAnc.id",driver);
		verifyNValidateDoctorOnPreviousConsultsPage(driver);
	}	
	
	public void clickOnViewConsults(WebDriver driver) throws Exception {
		if(genLibWeb.getElementsByName("doctorPrevConsultsViewConsultLinkAncHref.name",driver).size() > 0 
				&& genLibWeb.clickOnElementByName("doctorPrevConsultsViewConsultLinkAncHref.name", driver)) {
			log.info("Previous Consultations Found");			
			if(!genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorPreviousConsultationPageTitleH4.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("Previous Consultations panel did NOT open");	
				Assert.fail("Previous Consultations panel did NOT open");
			}
			log.info("Previous Consultations panel opened");
		}else{
			TestCaseInit.testCaseStatus = false;
			log.error("NO Previous Consultations found");	
			Assert.fail("NO Previous Consultations found");
		}
	}
	
	public void assertRequiredDataOnPrevConsult(WebDriver driver) throws Exception{
		Thread.sleep(3000); //Required Sleep
		String errMsg = " field is Empty.";
		try {
			//assert the required fields for the first previous consultation
			Assert.assertTrue(genLibWeb.getTextByID("doctorPrevConsultPatientNameP.id", driver).length() > 0, "Patient Name"+ errMsg);
			Assert.assertTrue(genLibWeb.getTextByID("doctorPrevConsultReasonForVisitP.id", driver).length() > 0, "Reason for visit" + errMsg);
			Assert.assertTrue(genLibWeb.getTextByID("doctorPrevConsultEmailP.id", driver).length() > 0, "Email" + errMsg);
			Assert.assertTrue(genLibWeb.getTextByID("doctorPrevConsultBirthDateP.id", driver).length() > 0, "DOB" + errMsg);
			Assert.assertTrue(genLibWeb.getTextByID("doctorPrevConsultPhoneNumberP.id", driver).length() > 0, "Phone Number" + errMsg);
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
	}
	
	public int getTotalCountOfPreviousConsults(WebDriver driver) throws Exception{
		int countPrevConsults = genLibWeb.getNumberOfElementsByXPath("doctorPrevConsultListTr.xpath", null, driver);		
		while(genLibWeb.isElementEnabledByXPath("nextBtnOnPages.ngClick.xpath", null, driver)){
			genLibWeb.clickOnElementByXPath("nextBtnOnPages.ngClick.xpath", null, driver);
			Thread.sleep(5000);	//wait for the consults to upload
			verifyDoctorOnPreviousConsultsPage(driver);
			countPrevConsults = countPrevConsults + genLibWeb.getNumberOfElementsByXPath("doctorPrevConsultListTr.xpath", null, driver);
		}
		return countPrevConsults;
	}
	
	public void selectPrevConsultOfAnotherDoctor(String qaDocName, WebDriver driver) throws Exception{
		Thread.sleep(3000);		
		genLibWeb.clickOnElementByID("doctorQAAllConsultationsLinkAnc.id", driver);
		Thread.sleep(5000);
		int countOfPrevElements = genLibWeb.getElementsByName("doctorPrevConsultsViewConsultLinkAncHref.name",driver).size();
		if(!(countOfPrevElements > 0) ){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Previous Consultations found");	
			Assert.fail("NO Previous Consultations found");
		}
		log.info("Previous Consultations found");
		boolean found = false;
		while(!found){
			for(int i=0; i<countOfPrevElements; i++){
				if(genLibWeb.getElementByID(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("doctorQAPrevConsultTr.id"), Integer.toString(i)), driver) != null) {
					String doctorTdXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("doctorQAPrevConsultDoctorTd.xpath"), Integer.toString(i+1));
					String viewConsultLinkAncXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("doctorQAPrevConsultViewConsultTdLinkAnc.xpath"), Integer.toString(i+1));
					String docNameRetrvd = genLibWeb.getTextByXPath(null, doctorTdXpathVal, driver);
					if(StringUtils.isNotBlank(docNameRetrvd) 
							&& !qaDocName.equalsIgnoreCase(docNameRetrvd)
							&& genLibWeb.isElementFoundByXPath(null, viewConsultLinkAncXpathVal, driver)){						
						genLibWeb.clickOnElementByXPath(null, viewConsultLinkAncXpathVal, driver);
						xpathValueForPrevConsultOfAnotherDoctor = viewConsultLinkAncXpathVal;
						found = true;
						break;
					}
				} 
			}
			if(!found){
				//search on next page
				if(!genLibWeb.isElementEnabledByXPath("nextBtnOnPages.ngClick.xpath", null, driver)){
					TestCaseInit.testCaseStatus = false;
					log.error("NO Previous Consultations found for Another doctor");	
					Assert.fail("NO Previous Consultations found Another doctor");					
				} else {
					genLibWeb.clickOnElementByXPath("nextBtnOnPages.ngClick.xpath", null, driver);
					Thread.sleep(5000);
					countOfPrevElements = genLibWeb.getElementsByName("doctorPrevConsultsViewConsultLinkAncHref.name",driver).size();
				}
			}
		}
	}
	
	public void findPrevConsultOfDoctor(String docName, String patName, WebDriver driver) throws Exception{
		int countPrevConsults = genLibWeb.getNumberOfElementsByXPath("doctorPrevConsultListTr.xpath", null, driver);
		if(!(countPrevConsults > 0) ){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Previous Consults found for doctor");	
			Assert.fail("NO Previous Consults found for doctor");
		}
		boolean found = false;
		DateFormat dateFormtr = new SimpleDateFormat("MMMM dd, yyyy hh:mm a");
		while(!found){
			for(int i=0; i<countPrevConsults; i++){
				String rowCount = Integer.toString(i);
				if(genLibWeb.getElementByID(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("doctorPrevConsultTr.id"), rowCount), driver) != null) {
					String patientTdXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("doctorPrevConsultPatientTd.xpath"), rowCount);
					String dateTdXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("doctorPrevConsultDateTd.xpath"), rowCount);
					String viewConsultLinkAncXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("doctorPrevConsultTdViewConsultLinkAnc.xpath"), rowCount);					
					String datetxtRetrivedWthBr = genLibWeb.getTextByXPath(null, dateTdXpathVal, driver);
					String[] dateSplitArr = datetxtRetrivedWthBr.split("\\n"); 
					Date dateRetrieved = dateFormtr.parse(dateSplitArr[0] + " " +dateSplitArr[1]);
					if(dateRetrieved.compareTo(dateFormtr.parse(PatientConsultationRequestPaymentPage.beforeConsultPaymentDateTime)) >= 0
							&& patName.equalsIgnoreCase(genLibWeb.getTextByXPath(null, patientTdXpathVal, driver))){	
						log.info("Previous Consult Found for the doctor");
						genLibWeb.clickOnElementByXPath(null, viewConsultLinkAncXpathVal, driver);
						found = true;
						break;
					}
				} 
			}
			if(!found){
				//search on next page
				if(!genLibWeb.isElementEnabledByXPath("nextBtnOnPages.ngClick.xpath", null, driver)){
					TestCaseInit.testCaseStatus = false;
					log.error("NO Previous Consult found for the doctor");	
					Assert.fail("NO Previous Consult found for the doctor");					
				} else {
					genLibWeb.clickOnElementByXPath("nextBtnOnPages.ngClick.xpath", null, driver);
					Thread.sleep(5000);
					countPrevConsults = genLibWeb.getNumberOfElementsByXPath("doctorPrevConsultListTr.xpath", null, driver);
				}
			}		
		}
	}
	
	public void verifyNValidatePreviousConsultationsPanelOnViewConsult(WebDriver driver) throws Exception {
		if(!genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorPreviousConsultationPageTitleH4.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Previous Consultations panel did NOT open");	
			Assert.fail("Previous Consultations panel did NOT open");
		}
		log.info("Previous Consultations panel opened");
	}

	public void verifyCancelNSubmitBtnsOnReasonPopUp(WebDriver driver) throws Exception {
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorQAPrevConsultReasonPopUpPageTitleH4.xpath", null, driver);
		if(!genLibWeb.isElementFoundByXPath("doctorQAPrevConsultReasonCancelBtn.ngClick.xpath", null, driver) 
				|| !genLibWeb.isElementFoundByXPath("doctorQAPrevConsultReasonSubmitBtn.ngClick.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Cancel or Submit buttons NOT found");	
			Assert.fail("Cancel or Submit buttons NOT found");		
		}
		log.info("Cancel and Submit buttons Found");			
	}

	public void verifyCancelActionOnReasonPopUp(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByXPath("doctorQAPrevConsultReasonCancelBtn.ngClick.xpath", null, driver);
		if(!genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorPrevConsultsPageTitleH1.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Cancel on reason did NOT bring the Doctor back to Previous Consults screen");	
			Assert.fail("Cancel on reason did NOT bring the Doctor back to Previous Consults screen");				
		}
		log.info("Cancel on reason brought the Doctor back to Previous Consults screen");
		Thread.sleep(1000);
	}

	public void submitReasonForPrevConsult(String reasonToViewConsultation, WebDriver driver) throws Exception {
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorQAPrevConsultReasonPopUpPageTitleH4.xpath", null, driver);
		genLibWeb.enterTextValueByID("doctorQAPrevConsultReasonTxtAr.id", reasonToViewConsultation, driver);
		genLibWeb.clickOnElementByXPath("doctorQAPrevConsultReasonSubmitBtn.ngClick.xpath", null, driver);
		Thread.sleep(3000);
	}

	public void verifyAuditLogWithReason(String reasonToViewConsultation, WebDriver driver) throws Exception {
		Thread.sleep(3000);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorPrevConsultAuditLogAccordionI.xpath", null, driver);
		genLibWeb.scrollToViewElementWithXPath("doctorPrevConsultAuditLogAccordionI.xpath", null, driver);
		genLibWeb.scrollToViewElementWithXPath("doctorPrevConsultAuditLogAccordionI.xpath", null, driver);//extra scroll to make sure it at the bottom of the page
		genLibWeb.clickOnElementByXPath("doctorPrevConsultAuditLogAccordionI.xpath", null, driver);
		genLibWeb.scrollToViewElementWithXPath("doctorPrevConsultAuditLogAccordionI.xpath", null, driver);
		genLibWeb.scrollToViewElementWithXPath("doctorPrevConsultAuditLogAccordionI.xpath", null, driver);//extra scroll to make sure it at the bottom of the page
		SimpleDateFormat sdf = new SimpleDateFormat("M/d/yy");
		Date date = new Date();
		String currentDate = sdf.format(date);
		if(!(genLibWeb.getTextByXPath("doctorPrevConsultAuditLogFirstRowTimeTd.xpath", null, driver).contains(currentDate)
				&& reasonToViewConsultation.equalsIgnoreCase(genLibWeb.getTextByXPath("doctorPrevConsultAuditLogFirstRowReasonTd.xpath", null, driver)))){
			TestCaseInit.testCaseStatus = false;
			log.error("Reason: "+reasonToViewConsultation+" NOT found in Audit Log");	
			Assert.fail("Reason: "+reasonToViewConsultation+" NOT found in Audit Log");				
		}
		log.info("Reason: "+reasonToViewConsultation+" Found in Audit Log");	
	}
	

	public void verifyPreviousConsultGeneralInfo(String patName, String vistReason, String patEmail, String diagCode, String prefPharmName, String prefPharmAddr1, String prefPharmAddr2, 
			String prefPharmCity, String prefPharmState, String prefPharmZipCode, String prefPharmPhone, int nbrOfPhotos, WebDriver driver) throws Exception{
		String errMsg = "Failed on Previous Consult Info on Doctor asserts, ";
		try{
			if(patName != null){
				Assert.assertTrue(patName.equalsIgnoreCase(genLibWeb.getTextByID("doctorPrevConsultPatientNameP.id", driver)), errMsg+"Patient Name");
			}
			if(vistReason != null){
				Assert.assertTrue(vistReason.equals(genLibWeb.getTextByID("doctorPrevConsultReasonForVisitP.id", driver)), errMsg+"Reason for visit");	
			}
			if(patEmail != null){
				Assert.assertTrue(patEmail.equalsIgnoreCase(genLibWeb.getTextByID("doctorPrevConsultEmailP.id", driver)), errMsg+"Email");
			}			
			if(diagCode != null){
				Assert.assertTrue((cmnUtilsPage.verifyDiagnosisCodeContained(diagCode, "doctorPrevConsultDiagnosisCodeListSpan.xpath", null, "doctorPrevConsultDiagnosisCodeSpan.xpath", driver)), errMsg+"Diagnosis Code");				
			}			
			if(prefPharmName != null){
				Assert.assertTrue(prefPharmName.equals(genLibWeb.getTextByID("doctorPrevConsultPrefPharmNameDiv.id", driver)), errMsg+"Preferred Pharmacy Name");
			}
			if(prefPharmAddr1 != null){
				Assert.assertTrue(prefPharmAddr1.equals(genLibWeb.getTextByID("doctorPrevConsultPrefPharmAddr1Div.id", driver)), errMsg+"Preferred Pharmacy Address1");	
			}
			if(prefPharmAddr2 != null){
				Assert.assertTrue(prefPharmAddr2.equals(genLibWeb.getTextByID("doctorPrevConsulPrefPharmtAddr2Div.id", driver)), errMsg+"Preferred Pharmacy Address2");	
			}	
			if(!(prefPharmCity == null && prefPharmState == null && prefPharmZipCode == null)){
				String address3 = genLibWeb.getTextByID("doctorPrevConsultPrefPharmCityStateZipDiv.id", driver);
				Assert.assertTrue(address3.contains(prefPharmCity), errMsg+"Preferred Pharmacy City");
				Assert.assertTrue(address3.contains(prefPharmState), errMsg+"Preferred Pharmacy State");
				Assert.assertTrue(address3.contains(prefPharmZipCode), errMsg+"Preferred Pharmacy Zip Code");
			}
			if(prefPharmPhone != null){
				Assert.assertTrue(prefPharmPhone.equals(genLibWeb.getTextByID("doctorPrevConsultPrefPharmPhoneDiv.id", driver)), errMsg+"Preferred Pharmacy Phone");	
			}			
			if(nbrOfPhotos > 0){
				Assert.assertTrue(nbrOfPhotos == genLibWeb.getNumberOfElementsByXPath("doctorPrevConsultPhotosNonEmptyLi.xpath", null, driver), errMsg+"Number of Photos");	
			}
			
			log.info("Passed all asserts on Previous Consult Info on Doctor");
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}

	public void verifyPreviousConsultMedHistory(String primDocName, String primDocPhone, String smoke, String smokePacksNum, String alcohol, String heighFeet, String heighInches, String weightLbs, 
			String allergies, String famMedProb, String medications, String medCondition, String surgeries, WebDriver driver) throws Exception {
		genLibWeb.scrollToViewElementWithID("doctorPrevConsultMedHistCollapseI.id", driver);
		genLibWeb.clickOnElementByID("doctorPrevConsultMedHistCollapseI.id", driver);
		genLibWeb.explicitWaitUntilElementWithIDIsVisible("doctorPrevConsultMedHistPrimDocNameP.id", driver);//wait till the data loaded
		String errMsg = "Failed on Previous Consult Medical History Info on Doctor asserts, ";
		try{
			if(primDocName != null){
				Assert.assertTrue(primDocName.equalsIgnoreCase(genLibWeb.getTextByID("doctorPrevConsultMedHistPrimDocNameP.id", driver)), errMsg+"Primary Doctor Name");	
			}
			if(primDocPhone != null){
				Assert.assertTrue(primDocPhone.equals(genLibWeb.getTextByID("doctorPrevConsultMedHistPrimDocPhoneDiv.id", driver)), errMsg+"Primary Doctor Phone");				
			}
			if(smoke != null){
				Assert.assertTrue(smoke.equalsIgnoreCase(genLibWeb.getTextByID("doctorPrevConsultMedHistSmokeSpan.id", driver)), errMsg+"Social History, Smoke");
			}			
			if(StringUtils.isNotBlank(smoke) && smoke.equalsIgnoreCase((VMedixUtils.YES))){
				Assert.assertTrue((genLibWeb.getTextByID("doctorPrevConsultMedHistSmokeNumberSpan.id", driver).contains(smokePacksNum)), errMsg+"Social History, Number of smoke packs");
			}
			if(!(heighFeet == null && heighInches == null)){
				String heightStr= genLibWeb.getTextByID("doctorPrevConsultMedHistHeightSpan.id", driver);
				Assert.assertTrue(heightStr.contains(heighFeet), errMsg+"Height Feet");
				Assert.assertTrue(heightStr.contains(heighInches), errMsg+"Height Inches");				
			}
			if(weightLbs != null){
				Assert.assertTrue((genLibWeb.getTextByID("doctorPrevConsultMedHistWeightSpan.id", driver).contains(weightLbs)), errMsg+"Weight lbs");	
			}			
			if(!(StringUtils.isBlank(weightLbs) || (StringUtils.isBlank(heighFeet) && StringUtils.isBlank(heighInches)))){
				Assert.assertTrue(StringUtils.isNotBlank(genLibWeb.getTextByID("doctorPrevConsultMedHistBMISpan.id", driver)), errMsg+"BMI");
			}
			//allergies
			if(allergies !=  null) {
				String allergiesActual = genLibWeb.getTextByXPath("doctorPrevConsultMedHistAllergiesComDelim.xpath", null, driver);
				ArrayList<String> allergiesList = VMedixUtils.getValuesFromCommaDelimitedText(allergies);
				for(String allerVal : allergiesList){
					Assert.assertTrue(allergiesActual.contains(allerVal), errMsg+"Allergies");
				}
			}
			//family history
			if(famMedProb != null){
				String famHistoryActual = genLibWeb.getTextByXPath("doctorPrevConsultMedHistFamHistComDelim.xpath", null, driver);
				ArrayList<String> famHistoryList = VMedixUtils.getValuesFromCommaDelimitedText(famMedProb);
				for(String famHist : famHistoryList){
					Assert.assertTrue(famHistoryActual.contains(famHist), errMsg+"Family History");
				}				
			}
			//medications
			if(medications !=  null){
				String medicationsActual = genLibWeb.getTextByXPath("doctorPrevConsultMedHistMedicationComDelim.xpath", null, driver);
				ArrayList<String> medicationsList = VMedixUtils.getValuesFromCommaDelimitedText(medications);
				for(String med : medicationsList){
					Assert.assertTrue(medicationsActual.contains(med), errMsg+"Medications");
				}				
			}

//			TODO:----- After the fix: VM-4179		
//			//medCondition
//			String medCondActual = genLibWeb.getTextByXPath("-----???-----", null, driver);
//			ArrayList<String> medCondList = VMedixUtils.getValuesFromCommaDelimitedText(medCondition);
//			for(String medCond : medCondList){
//				Assert.assertTrue(medCondActual.contains(medCond), errMsg+"Medical Condition");
//			}
//			
//			//surgeries
//			String surgeriesActual = genLibWeb.getTextByXPath("doctorPrevConsultMedHistSurgicalHistComDelim.xpath", null, driver);
//			ArrayList<String> surgeriesList = VMedixUtils.getValuesFromCommaDelimitedText(surgeries);
//			for(String surgery : surgeriesList){
//				Assert.assertTrue(surgeriesActual.contains(surgery), errMsg+"Surgical History");
//			}
			log.info("Passed all asserts on Previous Consult Medical History Info on Doctor ");
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}

	public void verifyPreviousConsultSoapNotes(String hpSoapSub, String hpSoapObj, WebDriver driver) throws Exception {
		genLibWeb.scrollToViewElementWithID("doctorPrevConsultSoapNoteDiv.id", driver);
		String errMsg = "Failed on Previous Consult SOAP Note on Doctor asserts, ";
		try{
			if(hpSoapSub != null){
				Assert.assertTrue(hpSoapSub.equals(genLibWeb.getTextByXPath("doctorPrevConsultSoapNoteSubjectiveP.xpath", null, driver)), errMsg+"SOAP Note: Subjective");	
			}			
			if(hpSoapObj != null){
				Assert.assertTrue(hpSoapObj.equals(genLibWeb.getTextByXPath("doctorPrevConsultSoapNoteObjectiveP.xpath", null, driver)), errMsg+"SOAP Note: Objective");	
			}			
			log.info("Passed all asserts on Previous Consult SOAP Note on Doctor");
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
	}

	public String verifyPreviousConsultPatientDischargeRep(String patName, String docName, String price, String diagCode, String followUp, String returnToSchWrk, String restrt, 
			String durOfRestrt, String persDInstr, WebDriver driver) throws Exception{
		String patDischRepUrl = genLibWeb.getAttributeByID("doctorPrevConsultPatientDischargeReportBtn.id", "href", driver);
		if(StringUtils.isBlank(patDischRepUrl)){
			TestCaseInit.testCaseStatus = false;
			log.error("Patient Discharge Report URL NOT found");	
			Assert.fail("Patient Discharge Report URL NOT found");	
		}
		log.info("Patient Discharge Report URL found");
		String prevConsultPanelHandler = driver.getWindowHandle();
		genLibWeb.clickOnElementByID("doctorPrevConsultPatientDischargeReportBtn.id", driver);
		String patDischRepText = VMedixUtils.readPDFDataFromUrl(patDischRepUrl);
		if(StringUtils.isBlank(patDischRepText)){
			TestCaseInit.testCaseStatus = false;
			log.error("Patient Discharge Report is Empty");	
			Assert.fail("Patient Discharge Report is Empty");		
		}
		log.error("Patient Discharge Report text Retrieved: "+ patDischRepText);
		String errMsg = "Failed on Previous Consult Patient Discharge Report on Doctor asserts, ";
		try{			
			Assert.assertTrue(StringUtils.containsIgnoreCase(patDischRepText, patName), errMsg+"Patient Name");
			Assert.assertTrue(StringUtils.containsIgnoreCase(patDischRepText, docName), errMsg+"Doctor Name");
			DateFormat dateForm = new SimpleDateFormat("M/d/yyyy");
			String currentDate = dateForm.format(new Date());
			Assert.assertTrue(patDischRepText.contains(currentDate), errMsg+"Today's Date");
			Assert.assertTrue(patDischRepText.contains(price), errMsg+"Price");
			if(diagCode != null){				
				if(diagCode.contains(",")) { //more than one diag code comma delimited appended with general
					String[] listOfDiagCode = diagCode.split("\\,");
					for(String diagCodeVal : listOfDiagCode ) {
						Assert.assertTrue(patDischRepText.contains(diagCodeVal), errMsg+"Diagnosis Code");	
					}
				} else {
					Assert.assertTrue(patDischRepText.contains(diagCode), errMsg+"Diagnosis Code");	
				}
			}
			if(followUp !=  null){
				Assert.assertTrue(patDischRepText.contains(followUp), errMsg+"Follow Up");	
			}
			if(returnToSchWrk != null){
				Assert.assertTrue(patDischRepText.contains(returnToSchWrk), errMsg+"Return to School/Work");	
			}
			if(restrt != null){
				Assert.assertTrue(patDischRepText.contains(restrt), errMsg+"Restrictions");	
			}
			if(durOfRestrt != null){
				Assert.assertTrue(patDischRepText.contains(durOfRestrt), errMsg+"Duration of Restrictions");	
			}
			if(persDInstr != null){
				Assert.assertTrue(patDischRepText.contains(persDInstr), errMsg+"Personal discharge information");
			}
			log.info("Passed all asserts on Previous Consult Patient Discharge Report on Doctor");
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
		return prevConsultPanelHandler;
	}
}
