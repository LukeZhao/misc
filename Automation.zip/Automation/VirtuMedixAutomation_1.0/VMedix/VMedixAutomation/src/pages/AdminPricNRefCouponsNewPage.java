package pages;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class AdminPricNRefCouponsNewPage {
	static Logger log = Logger.getLogger(AdminPricNRefCouponsNewPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if on on Admin New Coupons Page
	 */	
	public boolean verifyOnAdminNewCouponPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminPricNRefNewCouponTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin New Coupons Page
	 */
	public void verifyNValidateOnAdminNewCouponPage(WebDriver driver)throws Exception {
		if(!verifyOnAdminNewCouponPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on New Coupon Page");
			Assert.fail("NOT on New Coupon Page");
		}		
		log.info("On New Coupon Page");
	}

	/**
	 * This method is used to create a new Coupon
	 */
	public void submitNewCoupon(String sampleCoupon, String price, WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByID("docAdminPricNRefNewCouponCodeInp.id", sampleCoupon, driver);
		String format = "MM/dd/yyyy";
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		String currDate = dateFormat.format(new Date());
		Calendar cal = Calendar.getInstance();    
		cal.setTime(dateFormat.parse(currDate));
		cal.add(Calendar.YEAR, 1);		
		String endDate = dateFormat.format(cal.getTime());		
		genLibWeb.enterTextValueByID("docAdminPricNRefNewCouponEndDateInp.id", endDate, driver);
		genLibWeb.enterTextValueByName("docAdminPricNRefNewCouponPriceInp.name", price, driver);
		genLibWeb.clickOnElementByID("docAdminPricNRefNewCouponSubmitBtn.id", driver);		
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);		
		if(!MessageFormat.format(TestCaseInit.messagesVMedixProp.getProperty("couponCreated.success"), sampleCoupon).equals(toastMsg)) {
			TestCaseInit.testCaseStatus = false;
			log.error("Coupon NOT created: " + sampleCoupon);
			Assert.fail("Coupon NOT created: " + sampleCoupon);			
		}
		log.info("Coupon created: " + sampleCoupon);
	}
}
