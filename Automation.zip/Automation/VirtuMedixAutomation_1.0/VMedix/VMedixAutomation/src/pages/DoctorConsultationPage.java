package pages;

import java.text.MessageFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class DoctorConsultationPage {
	static Logger log = Logger.getLogger(DoctorConsultationPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	CommonUtilsPage cmnUtilsPage = new CommonUtilsPage(); 
	
	/**
	 * This method is used to verify if doctor is in video consultation
	 */	
	public boolean verifyDoctorInVideoConsultation(WebDriver driver) throws Exception{
		return genLibWeb.isElementFoundByID("docViConsultEndBtn.id", driver);
	}
	
	/**
	 * This method is used to validate if doctor is in consultation
	 */
	public void verifyNValidateDoctorInVideoConsultation(WebDriver driver)throws Exception {
		if(!verifyDoctorInVideoConsultation(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT in consultation");
			Assert.fail("Doctor is NOT in consultation");
		}		
		log.info("Doctor is in consultation");
	}
	
	/**
	 * This method is used to verify if doctor is waiting on patient for consultation
	 */	
	public boolean verifyDoctorIsWaitingOnPatient(WebDriver driver) throws Exception{
		return genLibWeb.isElementFoundByID("docViConsultCancelBtn.id", driver);
	}
	
	/**
	 * This method is used to validate if doctor is waiting on patient for consultation
	 */
	public void verifyNValidateDoctorIsWaitingOnPatient(WebDriver driver)throws Exception {
		if(!verifyDoctorIsWaitingOnPatient(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT waiting on patient for consultation");
			Assert.fail("Doctor is NOT waiting on patient for consultation");
		}		
		log.info("Doctor is waiting on patient for consultation");
	}
	
	/**
	 * This method is used to verify if on Notify Doctor popup
	 */	
	public boolean verifyDoctorOnPhoneNotifyPopUp(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docInConsultPhoneNotifyPopUpTitleH4.xpath", null, driver);
	}
	

	/**
	 * This method is used to verify the phone notification popup on Doctor end
	 * @param driver
	 * @throws Exception
	 */
	public void verifyNValidateDoctorOnPhoneNotifyPopUpWindow(WebDriver driver)throws Exception {
		if(!verifyDoctorOnPhoneNotifyPopUp(driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT on Phone Notify Doctor Popup");
			Assert.fail("Doctor is NOT on Phone Notify Doctor Popup");
		}
		log.info("Doctor is on Phone Notify Doctor Popup");			
	}	

	public void verifyNotificationNumOnPopUp(String depFName, String notifPhone, WebDriver driver) throws Exception {
		String notifyPopUpPhoneText = genLibWeb.getTextByXPath("docInConsultPhoneNotifyPopUpPhoneDiv.xpath", null, driver);
		String notifyPopUpNameText = genLibWeb.getTextByXPath("docInConsultPhoneNotifyPopUpNameDiv.xpath", null, driver);
		if(!(notifyPopUpPhoneText.contains(notifPhone) &&  notifyPopUpNameText.contains(depFName))){
			TestCaseInit.testCaseStatus = false;
			log.error("Notify Phone number for patient is NOT found on Popup");
			Assert.fail("Notify Phone number for patient is NOT found on Popup");
		}
		log.info("Notify Phone number for patient is Found on Popup");
	}
	
	/**
	 * This method is used to click ok on phone notification popup on Doctor end
	 * @param driver
	 * @throws Exception
	 */
	public void clickOkOnPhoneNotifyPopUpWindow(WebDriver driver)throws Exception {
		genLibWeb.clickOnElementByID("docInConsultPhoneNotifyPopUpOkBtn.id", driver);
	}

	/**
	 * This method ends the consultation from Doctor end
	 * @param driver
	 * @throws Exception
	 */
	public void cancelOrEndVideoConsultationFromDoctor(WebDriver driver) throws Exception {
		if(verifyDoctorIsWaitingOnPatient(driver)){ //began consultation and waiting for patient to accept
			cancelViDoctorConsultation(driver);
		} else if (verifyDoctorInVideoConsultation(driver)){ //in consultation
			endViDoctorConsultation(driver);
		}
	}	
	
	/**
	 * This method ends the Telephone consultation from Doctor end
	 * @param driver
	 * @throws Exception
	 */
	public void endPhoneConsultationFromDoctor(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docPhConsultEndBtn.id", driver);	
		genLibWeb.explicitWaitUntilElementWithIDIsVisible("docConsultEndConfirmPopupYesBtn.id", driver);
		genLibWeb.clickOnElementByID("docConsultEndConfirmPopupYesBtn.id", driver);		
	}	
	
	/**
	 * This method cancels video consultation from Doctor end
	 * @param driver
	 * @throws Exception
	 */
	public void cancelViDoctorConsultation(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByID("docViConsultCancelBtn.id", driver);
		genLibWeb.explicitWaitUntilElementWithIDIsVisible("docViConsultCancelConfirmPopupYesBtn.id", driver);
		genLibWeb.clickOnElementByID("docViConsultCancelConfirmPopupYesBtn.id", driver);
	}
	
	/**
	 * This method ends video consultation from Doctor end
	 * @param driver
	 * @throws Exception
	 */
	public void endViDoctorConsultation(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByID("docViConsultEndBtn.id", driver);
		genLibWeb.explicitWaitUntilElementWithIDIsVisible("docConsultEndConfirmPopupYesBtn.id", driver);
		genLibWeb.clickOnElementByID("docConsultEndConfirmPopupYesBtn.id", driver);
	}
	
	
	/**
	 * This Method checks the duration of consultation
	 * @param driver
	 * @throws Exception 
	 */
	public void checkConsultationTimerUpdate(WebDriver driver) throws Exception{
		String timerTxtNow = genLibWeb.getTextByID("docInConsultTimerSpan.id", driver);
		Thread.sleep(5000);
		String timerTxtLater = genLibWeb.getTextByID("docInConsultTimerSpan.id", driver);
		if(timerTxtLater.compareTo(timerTxtNow) > 0){
			log.info("Consultation timer is Updated");
		} else{
			TestCaseInit.testCaseStatus = false;
			log.error("Consultation timer NOT Updated");				
			Assert.fail("Consultation timer NOT Updated");	
		}
	}
	
	/**
	 * This method is used to check doctor video pane
	 * @param driver
	 * @throws Exception
	 */
	public void checkDoctorVideoPane(WebDriver driver) throws Exception {
		if(!genLibWeb.isElementFoundByID("docNPatVideoSubscriberPaneDiv.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor video pane NOT found");				
			Assert.fail("Doctor video pane NOT found");	
		}
		log.info("Doctor video pane Found");	
	}
	
	/**
	 * This method is used to check patient's video pane on Doctor
	 * @param driver
	 * @throws Exception
	 */
	public void checkPatientVideoPaneOnDoc(WebDriver driver) throws Exception {
		if(!genLibWeb.isElementFoundByID("docNPatVideoPublisherPaneDiv.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Patient video pane NOT found on Doctor");				
			Assert.fail("Patient video pane NOT found on Doctor");	
		}
		log.info("Patient video pane Found on Doctor");		
	}
	
	/**
	 * This method is used to check patient's video pane on Doctor is movable
	 * @param driver
	 * @throws Exception
	 */
	public void checkPatientVideoPaneMovableOnDoc(WebDriver driver) throws Exception {
		if(!genLibWeb.dragAndDropToTargetPointElementById("docNPatVideoPublisherPaneDiv.id", "300", "-200", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Patient video pane NOT moveable on Doctor");				
			Assert.fail("Patient video pane NOT moveable on Doctor");	
		}
		log.info("Patient video pane moveable on Doctor");
	}
	
	/**
	 * This method is used to verify the patient's uploaded photo on Doctor
	 * @param photoTitleToRemove
	 * @param driver
	 * @throws Exception
	 */
	public void verifyPhotosUploaded(int numOfPhotosUploaded, WebDriver driver) throws Exception {
		Thread.sleep(5000);//wait till all photos are uploaded
		if(!(genLibWeb.getNumberOfElementsByXPath("docInConsultPhotosList.xpath", null, driver) == numOfPhotosUploaded)){
			TestCaseInit.testCaseStatus = false;
			log.error("Number of photos uploaded by patient and seen on doctor did NOT match");				
			Assert.fail("Number of photos uploaded by patient and seen on doctor did NOT match");	
		}
		log.info("Number of photos uploaded by patient and seen on doctor Matched: " + numOfPhotosUploaded);		
	}
	
	/**
	 * This method is used to verify the specified photo was removed on Doctor
	 * @param photoTitleToRemove
	 * @param driver
	 * @throws Exception
	 */
	public void verifyPhotoRemoved(String photoTitleToRemove, WebDriver driver) throws Exception {
		//verify the photo element, with specified title not found
		Thread.sleep(5000);
		String photoXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docInConsultPhotoAnc.xpath"), photoTitleToRemove.trim());		
		if(genLibWeb.isElementFoundByXPath(null, photoXpathVal, driver)) {
			TestCaseInit.testCaseStatus = false;
			log.error("Photo NOT removed on Doctor side: "+ photoTitleToRemove);
			Assert.fail("Photo NOT removed on Doctor side: "+ photoTitleToRemove);	
		}
		log.info("Photo removed on Doctor side too: "+ photoTitleToRemove);
	}	
	
	public void verifyNonSoapHnPTemplatePatInfoHeader(String hnpTemplate, String newHnPTemplateHeader, WebDriver driver) throws Exception {
		genLibWeb.scrollToViewElementWithID("docInConsultHnPFormChooseDrpBx.id", driver);
        genLibWeb.selectByVisibleTextFromSelectElementID("docInConsultHnPFormChooseDrpBx.id", hnpTemplate, driver); 
        Thread.sleep(1000);
		try{
			if(StringUtils.isNotBlank(newHnPTemplateHeader)){
				Assert.assertTrue(genLibWeb.getTextByXPath("docInConsultHnPTemplatePatInfoHeaderSpan.xpath", null, driver).equalsIgnoreCase(newHnPTemplateHeader), "Failed asserts for Patient Information Header Text on Doctor In-Consultation Page");
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}	
	}
	
	public void verifyMedicalHistoryInConsult(String visitReason, String heighFeet, String heighInches, String weightLbs, String medications, String allergies, 
			String medCondition, String surgeries, String famMedProb, String smoke, String smokePacksNum, String alcohol, String jobProf,  
			String primDocName, String primDocPhone, 
			String prefPharmName, String prefPharmPhone, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, String prefPharmState, String prefPharmZipCode, WebDriver driver) throws Exception {
		verifyVistNHealthInfo(visitReason, heighFeet, heighInches, weightLbs, medications, allergies, driver);// check BMI here!
		verifyMedNSocialHist(medCondition, surgeries, famMedProb, smoke, smokePacksNum, alcohol, jobProf, driver); 
		verifyPrimaryDoctorInfo(primDocName, primDocPhone, driver); 
		verifyPreferredPharmacyInfo(prefPharmName, prefPharmPhone, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driver);
	}

	/**
	 * This method is used to verify visit reason and Health info entered by patient by doctor in-consultation
	 * @param visitReason
	 * @param heighFeet
	 * @param heighInches
	 * @param weightLbs
	 * @param patMeds
	 * @param patAllergies
	 * @param driver
	 * @throws Exception
	 */
	public void verifyVistNHealthInfo(String visitReason, String heighFeet, String heighInches, String weightLbs, String patMeds, String patAllergies, WebDriver driver) throws Exception {
		String errMsg = "Failed asserts for patient/dependent Visit and Health Info on in-consultation doctor, ";
		try{
			if(visitReason != null){
				Assert.assertEquals(genLibWeb.getTextByID("docInConsultVisitReasonP.id", driver), visitReason,  errMsg+"Reason for visit");
			}

			if(StringUtils.isNotBlank(heighFeet) || StringUtils.isNotBlank(heighInches)){
				String heightTxt = genLibWeb.getTextByID("docInConsultHeightP.id", driver);
				String[] heightTxtSplit = heightTxt.split("\\'");				
				if(StringUtils.isNotBlank(heighFeet)){
					Assert.assertTrue(heightTxtSplit[0].contains(heighFeet), errMsg+"Height Feet");
				}				
				if(StringUtils.isNotBlank(heighInches)){
					Assert.assertTrue(heightTxtSplit[1].contains(heighInches), errMsg+"Height Inches");
				}
			}
			
			if(StringUtils.isNotBlank(weightLbs)){
				Assert.assertTrue(genLibWeb.getTextByID("docInConsultWeightP.id", driver).contains(weightLbs), errMsg+"Weight");
			}
			
			//BMI
			if(StringUtils.isNotBlank(weightLbs) && (StringUtils.isNotBlank(heighFeet) || StringUtils.isNotBlank(heighInches))){
				String bmiTxt =  genLibWeb.getTextByID("docInConsultWeightP.id", driver);
				Assert.assertTrue(StringUtils.isNotBlank(bmiTxt)||!bmiTxt.contains("--"), errMsg+"BMI");
			} 
			
			//med conds
			if(StringUtils.isBlank(patMeds)){ //default None
				if(!genLibWeb.isElementFoundByID("docInConsultMedicationsCommaDelimP.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("docInConsultMedicationsCommaDelimP.id", driver))){
					log.info("Expecting Medications: None");
					Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicationsNoneP.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMsg+"Medications");					
				}
			}else {
				Assert.assertEquals(genLibWeb.getTextByID("docInConsultMedicationsCommaDelimP.id", driver), patMeds,  errMsg+"Medications");
			}
			
			//allergeis
			if(StringUtils.isBlank(patMeds)){ //default None
				if(!genLibWeb.isElementFoundByID("docInConsultAllergiesCommaDelimP.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("docInConsultAllergiesCommaDelimP.id", driver))){
					log.info("Expecting Allergies: None");
					Assert.assertTrue(genLibWeb.getTextByID("docInConsultAllergiesNoneP.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMsg+"Allergies");					
				}
			}else {
				Assert.assertEquals(genLibWeb.getTextByID("docInConsultAllergiesCommaDelimP.id", driver), patAllergies,  errMsg+"Allergies");
			}			
			
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}
	
	public void uncollapseMedicalHistorySection(WebDriver driver)throws Exception {
		//uncollapse/open medical history section if not
		if(!genLibWeb.isElementFoundByXPath("docInConsultMedicalHistCollapsedI.xpath", null, driver)){
			if(!genLibWeb.isElementFoundByXPath("docInConsultMedicalHistUnCollapsedI.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("Medical History section NOT found");				
				Assert.fail("Medical History section NOT found");	
			}
		} else {
			genLibWeb.clickOnElementByID("docInConsultMedicalHistCollapseI.id", driver);
		}
		Thread.sleep(1000);
		genLibWeb.scrollToViewElementWithXPath("docInConsultMedicalHistUnCollapsedI.xpath", null, driver);
	}
	

	/**
	 * This method is used to verify medical history entered by patient on doctor in-consultation
	 * @param medCondition
	 * @param surgeries
	 * @param famMedProb
	 * @param smoke
	 * @param smokePacksNum
	 * @param alcohol
	 * @param jobProf
	 * @param driver
	 * @throws Exception
	 */
	public void verifyMedNSocialHist(String medCondition, String surgeries, String famMedProb, String smoke, String smokePacksNum, String alcohol, String jobProf, WebDriver driver) throws Exception {
		//uncollapse/open medical history section if not
		uncollapseMedicalHistorySection(driver);		
		String errMsg = "Failed asserts for Medical/Social History on in-consultation doctor, ";
		try{
			//med conds
			if(StringUtils.isNotBlank(medCondition)){
				if(!genLibWeb.isElementFoundByID("docInConsultMedicalHistMedConditionsCommaDelimP.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("docInConsultMedicalHistMedConditionsCommaDelimP.id", driver))){
					log.info("Expecting Medical condition: None");
					Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicalHistMedConditionsNoneP.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMsg+"Medical Conditions");					
				}
			}else {
				Assert.assertEquals(genLibWeb.getTextByID("docInConsultMedicalHistMedConditionsCommaDelimP.id", driver), medCondition, errMsg+"Medical Conditions");				
			}			
			//surgeries
			if(StringUtils.isBlank(surgeries)){ //default None
				if(!genLibWeb.isElementFoundByID("docInConsultMedicalHistSurgeriesCommaDelimP.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("docInConsultMedicalHistSurgeriesCommaDelimP.id", driver))){
					log.info("Expecting Surgeries: None");
					Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicalHistSurgeriesNoneP.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMsg+"Surgical History");
				}
			}else {
				Assert.assertEquals(genLibWeb.getTextByID("docInConsultMedicalHistSurgeriesCommaDelimP.id", driver), surgeries, errMsg+"Surgical History");
			}
			//med fam prob
			if(StringUtils.isBlank(famMedProb)){ //default None
				if(!genLibWeb.isElementFoundByID("docInConsultMedicalHistFamMedProbCommaDelimP.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("docInConsultMedicalHistFamMedProbCommaDelimP.id", driver))){
					log.info("Expecting Family Medical History: None");
					Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicalHistFamMedProbNoneP.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMsg+"Family Medical History");
				}
			}else {
				Assert.assertEquals(genLibWeb.getTextByID("docInConsultMedicalHistFamMedProbCommaDelimP.id", driver), famMedProb, errMsg+"Family Medical History");
			}

			//smoke 
			if(StringUtils.isNotBlank(smoke)){ // default is empty
				if(smoke.equalsIgnoreCase(VMedixUtils.YES)){
					//equals				
					if(StringUtils.isBlank(smokePacksNum) || (!smokePacksNum.equalsIgnoreCase(cmnUtilsPage.smokePacksLessThan1) && Integer.parseInt(smokePacksNum) > 5)){
						smokePacksNum = "0";
					}
					Assert.assertTrue((StringUtils.containsIgnoreCase(genLibWeb.getTextByID("docInConsultMedicalHistSmokeSpan.id",driver), VMedixUtils.YES) 
							&& StringUtils.containsIgnoreCase(genLibWeb.getTextByID("docInConsultMedicalHistSmokePackSpan.id", driver), smokePacksNum)), errMsg+"Smoke Cigarettes" );
				}else{
					log.info("Expecting Smoke: No");
					Assert.assertTrue(StringUtils.containsIgnoreCase(genLibWeb.getTextByID("docInConsultMedicalHistSmokeSpan.id", driver), VMedixUtils.NO), errMsg+"Smoke Cigarettes" );
				}
			}			
			//alcohol
			if(StringUtils.isNotBlank(alcohol)){
				Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicalHistAlcoholSpan.id", driver).equalsIgnoreCase(alcohol.trim()), errMsg+"Alcohol");
			}			
			//job/profession
			if(StringUtils.isNotBlank(jobProf)){
				Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicalHistJobProfSpan.id", driver).equalsIgnoreCase(jobProf.trim()), errMsg+"Job/Profession");				
			}			
			
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}
	
	/**
	 * This method is used to verify Primary Doctor info entered by patient by doctor in-consultation
	 * @param primDocName
	 * @param primDocPhone
	 * @param driver
	 * @throws Exception
	 */
	public void verifyPrimaryDoctorInfo(String primDocName, String primDocPhone, WebDriver driver) throws Exception {
		String errMsg = "Failed asserts for Primary Doctor on in-consultation doctor, ";
		try{
			if(StringUtils.isNotBlank(primDocName)){
				Assert.assertTrue(StringUtils.containsIgnoreCase(genLibWeb.getTextByID("docInConsultMedicalHistPrimDocNameP.id", driver), primDocName.trim()), errMsg+"Primary Care Physician Name");
			}
			if(StringUtils.isNotBlank(primDocPhone)){
				Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicalHistPrimDocPhoneSpan.id", driver).equalsIgnoreCase(primDocPhone.trim()), errMsg+"Primary Care Physician Phone Number");
			}		
			
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}
	
	/**
	 * This method is used to verify Preferred Pharmacy info entered by patient by doctor in-consultation
	 * @param prefPharmName
	 * @param prefPharmPhone
	 * @param prefPharmAddr1
	 * @param prefPharmAddr2
	 * @param prefPharmCity
	 * @param prefPharmState
	 * @param prefPharmZipCode
	 * @param driver
	 * @throws Exception
	 */
	public void verifyPreferredPharmacyInfo(String prefPharmName, String prefPharmPhone, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, String prefPharmState, String prefPharmZipCode, WebDriver driver) throws Exception {
		String errMsg = "Failed asserts for Preferred Pharmacy Info on in-consultation doctor, ";
		try{
			if(StringUtils.isNotBlank(prefPharmName)){
				Assert.assertTrue(StringUtils.containsIgnoreCase(genLibWeb.getTextByID("docInConsultMedicalHistPrefPharmNameP.id", driver), prefPharmName.trim()), errMsg+"Preferred Pharmacy Name");
			}
			if(StringUtils.isNotBlank(prefPharmPhone)){
				Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicalHistPrefPharmPhoneSpan.id", driver).equalsIgnoreCase(prefPharmPhone.trim()), errMsg+"Preferred Pharmacy Phone Number");
			}	
			if(StringUtils.isNotBlank(prefPharmAddr1)){
				Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicalHistPrefPharmAddr1Span.id", driver).equalsIgnoreCase(prefPharmAddr1.trim()), errMsg+"Preferred Pharmacy Addres1");
			}
			if(StringUtils.isNotBlank(prefPharmAddr2)){
				Assert.assertTrue(genLibWeb.getTextByID("docInConsultMedicalHistPrefPharmAddr2Span.id", driver).equalsIgnoreCase(prefPharmAddr2.trim()), errMsg+"Preferred Pharmacy Address2");
			}
			if(StringUtils.isNotBlank(prefPharmCity)){
				Assert.assertTrue(StringUtils.containsIgnoreCase(genLibWeb.getTextByID("docInConsultMedicalHistPrefPharmCityP.id", driver), prefPharmCity.trim()), errMsg+"Preferred Pharmacy Phone Number");
			}					
			if(StringUtils.isNotBlank(prefPharmState)){
				Assert.assertTrue(StringUtils.containsIgnoreCase(genLibWeb.getTextByID("docInConsultMedicalHistPrefPharmStateP.id", driver), prefPharmState.trim()), errMsg+"Preferred Pharmacy Addres1");
			}
			if(StringUtils.isNotBlank(prefPharmZipCode)){
				Assert.assertTrue(StringUtils.containsIgnoreCase(genLibWeb.getTextByID("docInConsultMedicalHistPrefPharmZipCodeP.id", driver), prefPharmZipCode.trim()), errMsg+"Preferred Pharmacy Address2");
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
	}
	
	/**
	 * This method is used to click on edit button to open Medical History Edit Page in consultation
	 */
	public void clickOnMedicalHistoryEdit(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docInConsultMedicalHistEditBtn.id", driver);		
	}
		
	/**
	 * This method is used to edit medicines and allergies info of the patient by doctor in-consultation
	 * @param patMeds
	 * @param patAllergies
	 * @param driver
	 * @throws Exception
	 */
	public void editMedicinesNAllergiesOfPatient(String docMedicinesEnt, String docAllergyEnt, WebDriver driver) throws Exception {
		//remove old and add new 
		//medications
		//click to edit medications if not already clicked
		clickOnEditMedications(driver);
		log.info("Edit Medications option NOT found");
		if (StringUtils.isNotBlank(docMedicinesEnt)){
			//remove all medications
			cmnUtilsPage.removeOldMedications("docInConsultMedicationOldListP.xpath", null, "docInConsultMedicationOldRemoveSpan.xpath", driver);
			if(!cmnUtilsPage.enterMedications(docMedicinesEnt, "docInConsultMedicationInp.xpath", null, "docInConsultMedicationAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Medications were NOT added");				
				Assert.fail("One of the Medications were NOT added");		
			}
			log.info("All Medications were added");
		}
		//click close
		genLibWeb.clickOnElementByID("docInConsultMedicationsCloseSpan.id", driver);
		
		//allergies
		//click to edit allergies if not already clicked
		if(!genLibWeb.isElementFoundByID("docInConsultAllergiesEditSpan.id", driver)){
			if(!genLibWeb.isElementFoundByID("docInConsultAllergiesCloseSpan.id", driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("Edit Medications option NOT found");				
				Assert.fail("Edit Medications option NOT found");	
			}
		} else {
			genLibWeb.clickOnElementByID("docInConsultAllergiesEditSpan.id", driver);
		}
		if (StringUtils.isNotBlank(docAllergyEnt)){
			//remove all allergies
			cmnUtilsPage.removeOldAllergies("docInConsultAllergiesOldListP.xpath", null, "docInConsultAllergiesOldRemoveSpan.xpath", driver);
			if(!cmnUtilsPage.enterAllergies(docAllergyEnt, "docInConsultAllergiesInp.xpath", null, "docInConsultAllergiesAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Allergies were NOT added");				
				Assert.fail("One of the Allergies were NOT added");		
			}
			log.info("All Allergies were added");
		}
		//click close
		genLibWeb.clickOnElementByID("docInConsultAllergiesCloseSpan.id", driver);
	}
	
	public void clickOnEditMedications(WebDriver driver) throws Exception{
		if(!genLibWeb.isElementFoundByID("docInConsultMedicationsEditSpan.id", driver)){
			if(!genLibWeb.isElementFoundByID("docInConsultMedicationsCloseSpan.id", driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("Edit Medications option NOT found");				
				Assert.fail("Edit Medications option NOT found");	
			}
		} else {
			genLibWeb.clickOnElementByID("docInConsultMedicationsEditSpan.id", driver);
		}
	}
	
	/**
	 * This method enters D&D values when in Consultation
	 * @param diagCode
	 * @param followUp
	 * @param schWrkReturn
	 * @param restrt
	 * @param durOfRestrt
	 * @param driver
	 * @throws Exception
	 */
	public void enterDnDDataInConsultation(String diagCode, String followUp, String schWrkReturn, String restrt, String durOfRestrt, String personalizedDInstr, WebDriver driver) throws Exception {
		if(!(genLibWeb.isElementFoundByXPath("docInConsultDnDSectionSpan.xpath", null, driver) 
				&& genLibWeb.isElementFoundByID("docInConsultDnDSectionCollapseI.id", driver))){
			TestCaseInit.testCaseStatus = false;
			log.info("Discharge & Disposition section NOT found for Doctor in consultation");
			Assert.fail("Discharge & Disposition section NOT found for Doctor in consultation");			
		} 
		log.info("Discharge & Disposition section is Found for Doctor in consultation");
		genLibWeb.clickOnElementByID("docInConsultDnDSectionCollapseI.id", driver);
		Thread.sleep(1000);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docInConsultDnDSecDiagnosisCodeInp.xpath", null, driver);
		if(diagCode != null){
			cmnUtilsPage.enterDiagnosisCodes(diagCode, "docInConsultDnDSecDiagnosisCodeInp.xpath", null, "docInConsultDnDSecDiagnosisCodeBtn.xpath", null, driver);
		}
		if(followUp != null){
			genLibWeb.enterTextValueByID("docDnDFollowUpInp.id", followUp, driver);
		}
		if(schWrkReturn != null){
			genLibWeb.enterTextValueByID("docDnDReturnToSchOrWrkInp.id", schWrkReturn, driver);
		}
		if(restrt != null){
			genLibWeb.enterTextValueByID("docDnDWrkSchRestrictionInp.id", restrt, driver);
		}
		if(durOfRestrt != null){
			genLibWeb.enterTextValueByID("docDnDWrkSchRestrictDurationInp.id", durOfRestrt, driver);
		}
		if(personalizedDInstr != null){
			genLibWeb.enterTextValueWithActionByXPath("docInConsultDnDSecPersonalizedDInstrP.xpath", null, personalizedDInstr, driver);			
		}
	}		

	/**
	 * This method is used to enter Soap Note H&P Template
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @param driver
	 * @throws Exception 
	 */
	public void enterHnPTemplateSoapNotes(String hpSoapSub, String hpSoapObj, WebDriver driver) throws Exception {
		genLibWeb.scrollToViewElementWithID("docInConsultHnPFormChooseDrpBx.id", driver);
        genLibWeb.selectByVisibleTextFromSelectElementID("docInConsultHnPFormChooseDrpBx.id", VMedixUtils.SOAP_HnP_TEMPLATE, driver); 
        genLibWeb.enterTextValueWithActionByXPath("docHnPSoapNoteSubjectiveBr.xpath", null, hpSoapSub, driver);        
	    genLibWeb.enterTextValueWithActionByXPath("docHnPSoapNoteObjectiveBr.xpath", null, hpSoapObj, driver);     
	    //click outside, so Objective value is saved 
        genLibWeb.clickOnElementByXPath("docHnPSoapNoteTitleH2.xpath", null, driver); //clicked on SOAP Note Title
     }
	
	/**
	 * This method is used to verify if on Patient Ended Consult notify PopUp 
	 */	
	public boolean verifyPatientEndedConsultPopUp(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docInConsultPatEndedConsultPopUpTitleH4.xpath", null, driver);
	}
	

	/**
	 * This method is used to verify if on Patient Ended Consult notify PopUp 
	 * @param driver
	 * @throws Exception
	 */
	public void verifyNValidatePatientEndedConsultPopUp(WebDriver driver)throws Exception {
		if(!verifyPatientEndedConsultPopUp(driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT on Patient Ended Consult notify PopUp");
			Assert.fail("Doctor is NOT on Patient Ended Consult notify PopUp ");
		}
		log.info("Doctor is on Patient Ended Consult notify PopUp");			
	}
	
	/**
	 * This method is used to click on End Consultation on the Patient Ended Consult notify PopUp 
	 * @param driver
	 * @throws Exception
	 */
	public void clickEndConsultOnPatientEndedConsultPopUp(WebDriver driver)throws Exception {
		genLibWeb.clickOnElementByID("docInConsultPatEndedConsultPopUpEndBtn.id", driver);
	}

	/**
	 * This method is used to verify medication added by Admin is present and auto displayed on Doctor in-consult
	 * @param driver
	 * @throws Exception 
	 */
	public void verifyMedicationAddedByAdmin(String med1Add, WebDriver driver) throws Exception {
		//click to edit medications
		clickOnEditMedications(driver);
		if(!cmnUtilsPage.verifyPresentInDropBoxAfterAutoDisplay(med1Add, "docInConsultMedicationInp.xpath", null, "docInConsultMedicationDrpBxWithVal.ngClick.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Medication added NOT found on Doctor in DnD: " +med1Add);
			Assert.fail("Medication added NOT found on Doctor in DnD: " +med1Add);
		}
		log.info("Medication added was Found on Doctor in DnD: " +med1Add);			
	}
}
