package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class CallRepAdminCallCenterAgentsPage {
	static Logger log = Logger.getLogger(CallRepAdminCallCenterAgentsPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	CallRepAdminNewCallCenterAgentPage adminNewCallCenterAgent = new CallRepAdminNewCallCenterAgentPage();
	
	/**
	 * This method is used to verify if on Call Center Agents Page
	 */	
	public boolean verifyOnCallCenterAgentsPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("callCenterAgentsPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Call Center Agents Page
	 */
	public void verifyNValidateOnCallCenterAgentsPage(WebDriver driver)throws Exception {
		if(!verifyOnCallCenterAgentsPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on  Call Center Agents Page");
			Assert.fail("NOT on  Call Center Agents Page");
		}		
		log.info("On  Call Center Agents Page");
	}

	public void addNewCallCenter(String firstName, String lastName, String phone, String emailForRegister, WebDriver driver) throws Exception {
		//Click add
		if(genLibWeb.explicitWaitUntilElementWithIDIsVisible("callCenterAgentsAddNewLinkAnc.id", driver)){
			genLibWeb.clickOnElementByID("callCenterAgentsAddNewLinkAnc.id", driver);
		}
		adminNewCallCenterAgent.verifyNValidateOnNewCallCenterAgentPage(driver);
		adminNewCallCenterAgent.saveNewCallRep(firstName, lastName, phone, emailForRegister, driver);
		
	}
}
