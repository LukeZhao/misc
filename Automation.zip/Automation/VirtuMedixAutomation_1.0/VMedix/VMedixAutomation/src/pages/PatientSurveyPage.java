package pages;

import java.text.MessageFormat;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class PatientSurveyPage {	
	static Logger log = Logger.getLogger(PatientSurveyPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if patient is on Survey Page
	 */	
	public boolean verifyPatientOnSurveyPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultSurveyPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if patient is on Survey Page
	 */
	public void verifyNValidatePatientOnSurveyPage(WebDriver driver)throws Exception {
		if(!verifyPatientOnSurveyPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Patient is NOT on Survey Page");
			Assert.fail("Patient is NOT on Survey Page");
		}		
		log.info("Patient is on Survey Page");
	}
	
	/**
	 * This method is used to skip the survey from Patient side
	 * @param driver
	 * @throws Exception
	 */
	public void skipSurvey(WebDriver driver) throws Exception {
		if(!genLibWeb.isElementFoundByID("patConsultSurveySkipLinkAnc.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Skip option NOT present on Survey Page");
			Assert.fail("Skip option NOT present on Survey Page");
		}		
		log.info("Skip option Present on Survey Page");
		genLibWeb.clickOnElementByID("patConsultSurveySkipLinkAnc.id", driver);
	}
	
	/**
	 * This method is used to fill the survey from Patient side
	 * @param driver
	 * @throws Exception
	 */
	public void fillSurvey(WebDriver driver) throws Exception {
		//find list of qs and ans 
		if(genLibWeb.isElementEnabledByID("patConsultSurveySubmitBtn.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Survey Submit is NOT disabled when survey not filled");
			Assert.fail("Survey Submit is NOT disabled when survey not filled");
		}
		log.info("Survey Submit is Disabled when survey not filled");
		int numOfQs = genLibWeb.getNumberOfElementsByXPath("patConsultSurveyQsListSection.xpath", null, driver);
		for(int i=1; i<=numOfQs; i++){
			genLibWeb.clickOnElementByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultSurveyAnsRadioLable.xpath"), Integer.toString(i), Integer.toString(i)), driver);
		}
		Thread.sleep(1000);
		if(!genLibWeb.isElementEnabledByID("patConsultSurveySubmitBtn.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Survey Submit is NOT enabled when survey is filled");
			Assert.fail("Survey Submit is NOT enabled when survey is filled");
		}
		log.info("Survey Submit is Enabled when survey is filled");
		genLibWeb.clickOnElementByID("patConsultSurveySubmitBtn.id", driver);
	}
}
