package pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import library.BussinessLib;
import library.EnvironmentConfigSettings;
import library.GenericExcelMethods;
import library.GenericLibMobile;
import library.GenericLibWeb;
import tests.TestCaseInit;

public class MobilePage {
	static Logger Log = Logger.getLogger(MobilePage.class.getName());
	GenericLibMobile genLibMobile = new GenericLibMobile();
	GenericLibWeb genLibWeb = new GenericLibWeb();
	BussinessLib bussLib = new BussinessLib();
	GenericExcelMethods genExcelMethods = new GenericExcelMethods();
	DoctorConsultationPage video_consult = new DoctorConsultationPage();
	PatientConsultationRequestPaymentPage makePayment = new PatientConsultationRequestPaymentPage();
	GMailPage gmailPage = new GMailPage();

	/**
	 * This method is used to login and verify the account on GMail
	 * @param email
	 * @param password
	 * @param driver
	 * @throws Exception
	 */
	public void loginToGmailVerifyEmail(String email, String password, WebDriver driver) throws Exception {
		gmailPage.loginGmail(email, password, driver);
		genLibWeb.clickOnElementByID("gmailSearchBoxInp.id", driver);
		genLibWeb.enterTextValueByID("gmailSearchBoxInp.id", "VirtuMedix: Email Verification", driver);
		genLibWeb.clickOnElementByID("gmailSearchBtn.id", driver);
		Thread.sleep(5000);
		genLibWeb.clickOnElementByXPath("gmailFirstSearchEmailTr.xpath", null, driver);
		int iCount = 0;
		String ClickOnVerifyEmail_xpath = "//a[contains(@href,'http://api-virtumedix-"+EnvironmentConfigSettings.getServerNameEnvConfig()+".nimaws.com/account/email_verify')]";
		iCount = driver.findElements(By.xpath(ClickOnVerifyEmail_xpath)).size();
		int elemtoclick = iCount - 1;
		List<WebElement> a = driver.findElements(By.xpath(ClickOnVerifyEmail_xpath));
		a.get(elemtoclick).click();
	}
	
	/**
	 * This method is used to perform swipe from Bottom to Top
	 * @param appiumDriver
	 * @throws InterruptedException
	 */
	public void swipeVrticalBottomToTop(AppiumDriver<?> appiumDriver) throws InterruptedException {
		Log.info("Swipe the screen from Bottom To Top");
		Dimension size = appiumDriver.manage().window().getSize();
		int startY = (int) (size.height * 0.80);
		int endY = (int) (size.height * 0.20);
		int startX = size.width / 2;
		appiumDriver.swipe(startX, startY, startX, endY, 3000);
		Log.info("Swipping is completed at position--->" + size);
	}
	
	/**
	 * This method is used to perform swipe from Top to Bottom 
	 * @param appiumDriver
	 * @throws InterruptedException
	 */
	public void swipeVrticalTopToBottom(AppiumDriver<?> appiumDriver) throws InterruptedException {
		Log.info("Swipe the screen from Top To Bottom");
		Dimension size = appiumDriver.manage().window().getSize();
		int startY = (int) (size.height * 0.80);
		int endY = (int) (size.height * 0.20);
		int startX = size.width / 2;
		appiumDriver.swipe(startX, endY, startX, startY, 3000);
		Log.info("Swipping is completed at position--->" + size);
	}
	
	/**
	 * This method is used to perform swipe only on TAB
	 * @param appiumDriver
	 * @throws InterruptedException
	 */
	public void swipeVrticalTopToBottomForTab(AppiumDriver<?> appiumDriver)	throws InterruptedException {
		Log.info("Swipe the screen from Top To Bottom");
		Dimension size = appiumDriver.manage().window().getSize();
		int startY = (int) (size.height * 0.80);
		int endY = (int) (size.height * 0.40);
		int startX = size.width / 2;
		appiumDriver.swipe(startX, endY, startX, startY, 3000);
		Log.info("Swipping is completed at position--->" + size);
	}
    /**
	 * This method is used to perform logout on android app
	 * @param appiumDriver
	 */
	public void logoutPatientFromApp(AppiumDriver<?> appiumDriver) {
		try {
			genLibMobile.clickOnButtonByIDOnAndroid("MenuIcon_ID", appiumDriver);
			if (TestCaseInit.mobileOnIOS) {
				signOutFromAppForIOS(appiumDriver);
				if (genLibMobile.isElementFoundByXPathOnIOS(TestCaseInit.iosLocatorProp.getProperty("LandingPageText_ID"), appiumDriver)) {
					Log.info("Patient is LoggedOut from the App");
				} else {
					Log.info("Failed to LogOut Patient from the App");
				}
			} else {
				appiumDriver.findElement(By.xpath(TestCaseInit.androidLocatorProp.getProperty("SignOut_xpath")));
				Thread.sleep(3000);
				genLibMobile.clickOnButtonByXPathOnAndroid("SignOut_xpath", appiumDriver);
				Thread.sleep(3000);
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("LandingPageText_ID", appiumDriver)) {
					Log.info("Patient is LoggedOut from the App");
					Thread.sleep(3000);
				} else {
					Log.info("Failed to LogOut Patient from the App");
				}
			}
		} catch (Exception e) {
			Log.info("Failed to LogOut Patient from the App");
			Log.info(e.toString());
		}
	}
	
	/**
	 * This method validate the Medical History from Doctor end
	 * @param driver
	 * @param primaryCareName
	 * @param primaryCarePhone
	 * @param pharmacyName
	 * @param pharmacyPhone
	 * @param pharmacyAddress
	 * @param pharmacyCity
	 * @param pharmacyZip
	 * @param medHistory
	 * @param surgery
	 * @param job
	 * @param familyHistory
	 */
	public void validateMedicalHistoryUpdateAtDoctor( WebDriver driver, String primaryCareName, String primaryCarePhone, String pharmacyName, String pharmacyPhone,
			String pharmacyAddress, String pharmacyCity, String pharmacyZip, String medHistory, String surgery, String job, String familyHistory) throws Exception{
		Log.info("To validate Doctor can see all medical history updates made by patient from mobile App");
		String actualPhysicianName = genLibWeb.getTextByXPath("PhysicianName_xpath", null, driver);
		if (actualPhysicianName.contains(primaryCareName)) {
			Log.info("PhysicianName in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("PhysicianName in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("PhysicianName in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}
		String actualPhysicianPhone = genLibWeb.getTextByXPath("PhysicianPhone_xpath", null, driver);
		Log.info(actualPhysicianPhone);
		if (actualPhysicianPhone.contains(primaryCarePhone)) {
			Log.info("PhysicianPhone in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("PhysicianPhone in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("PhysicianPhone in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}
		String actualPreferredPharName = genLibWeb.getTextByXPath("PreferredPharName_xpath", null, driver);
		if (actualPreferredPharName.contains(pharmacyName)) {
			Log.info("PreferredPharName in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("PreferredPharName in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("PreferredPharName in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}
		String actualPreferredPharPhone = genLibWeb.getTextByXPath("PreferredPharPhone_xpath", null, driver);
		if (actualPreferredPharPhone.contains(pharmacyPhone)) {
			Log.info("PreferredPharPhone in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("PreferredPharPhone in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("PreferredPharPhone in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}
		String actualPreferredPharAddress = genLibWeb.getTextByXPath("PreferredPharAddress_xpath", null, driver);
		if (actualPreferredPharAddress.contains(pharmacyAddress)) {
			Log.info("PreferredPharAddress in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("PreferredPharAddress in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("PreferredPharAddress in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}
		String actualPreferredPharCity = genLibWeb.getTextByXPath("PreferredPharCity_xpath", null, driver);
		if (actualPreferredPharCity.contains(pharmacyCity)) {
			Log.info("PreferredPharCity in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("PreferredPharCity in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("PreferredPharCity in the Medical History is NOT the same as when the patient updated from the Mobile App");
    	}
    	String actualPreferredPharState = genLibWeb.getTextByXPath("PreferredPharState_xpath", null, driver);
    	if (TestCaseInit.mobileOnIOS) {
			Log.info("For iOS selecting state randomly");
		} else {
			if(actualPreferredPharState.contains("AK") && !TestCaseInit.mobileOnIOS){
	    		Log.info("PreferredPharState in the Medical History is the same as when the patient updated from the Mobile App");
	    	}else{
	    		Log.info("PreferredPharState in the Medical History is NOT the same as when the patient updated from the Mobile App");
				TestCaseInit.testCaseStatus = false;
				Assert.fail("PreferredPharState in the Medical History is NOT the same as when the patient updated from the Mobile App");
	    	}
		}    	
    	String actualPreferredPharZip = genLibWeb.getTextByXPath("PreferredPharZip_xpath", null, driver);
    	if(actualPreferredPharZip.contains(pharmacyZip)){
    		Log.info("PreferredPharZip in the Medical History is the same as when the patient updated from the Mobile App");
    	}else{
    		Log.info("PreferredPharZip in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("PreferredPharZip in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}
		String actualMedicalCondition = genLibWeb.getTextByXPath("MedicalCondition_xpath", null, driver);
		if (actualMedicalCondition.contains(medHistory)) {
			Log.info("MedicalCondition in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("MedicalCondition in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("MedicalCondition in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}
		String actualSurgicalHistory = genLibWeb.getTextByXPath("SurgicalHistory_xpath", null, driver);
		if (actualSurgicalHistory.contains(surgery)) {
			Log.info("SurgicalHistory in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("SurgicalHistory in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("SurgicalHistory in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}		
		String actualJob = genLibWeb.getTextByXPath("Job_xpath", null, driver);
		if (actualJob.contains(job)) {
			Log.info("Job in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("Job in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Job in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}
		String actualFamHistory = genLibWeb.getTextByXPath("FamHistory_xpath", null, driver);
		if (actualFamHistory.contains(familyHistory)) {
			Log.info("FamHistory in the Medical History is the same as when the patient updated from the Mobile App");
		} else {
			Log.info("FamHistory in the Medical History is NOT the same as when the patient updated from the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("FamHistory in the Medical History is NOT the same as when the patient updated from the Mobile App");
		}
	}
	
	/**
	 * This method update the Medical History from Doctor side
	 * @param passedInDriver
	 * @param weight
	 * @param heighInFeet
	 * @param heighInInch
	 * @param drink
	 * @param job
	 * @param primaryCareName
	 * @param primaryCarePhone
	 * @param pharmacyName
	 * @param pharmacyPhone
	 * @param pharmacyAddress
	 * @param pharmacyCity
	 * @param pharmacyZip
	 */
	public void updateMHAtDoctorSide(WebDriver passedInDriver, String weight, String heighInFeet, String heighInInch, String drink, String job, String primaryCareName, String primaryCarePhone,
			String pharmacyName, String pharmacyPhone, String pharmacyAddress, String pharmacyCity, String pharmacyZip) {
		try {
			bussLib.enterTextValueByXPathOnNgmodelOrIdOrText("bodySize.pounds", weight, passedInDriver);
			bussLib.selectByValueByXPathOnNgmodelOrNameOrClass("medicalHistFeet", heighInFeet, passedInDriver);
			bussLib.selectByValueByXPathOnNgmodelOrNameOrClass("medicalHistInch", heighInInch, passedInDriver);
			passedInDriver.findElement(By.xpath(TestCaseInit.webLocatorProp.getProperty("Patient_SmokesB_History_Xpath"))).click();
			bussLib.selectByValueByXPathOnNgmodelOrNameOrClass("drinksSelect", drink, passedInDriver);
			bussLib.enterTextValueByXPathOnNgmodelOrIdOrText("record.social_history.job", job, passedInDriver);
			bussLib.enterTextValueByXPathOnNgmodelOrIdOrText("patient.primary_care.name", primaryCareName, passedInDriver);
			bussLib.enterTextValueByXPathOnNgmodelOrIdOrText("patient.primary_care.phone_number", primaryCarePhone, passedInDriver);
			bussLib.enterTextValueByXPathOnNgmodelOrIdOrText("patient.preferred_pharmacy.name", pharmacyName, passedInDriver);
			bussLib.enterTextValueByXPathOnNgmodelOrIdOrText("patient.preferred_pharmacy.phone_number", pharmacyPhone, passedInDriver);
			bussLib.enterTextValueByXPathOnNgmodelOrIdOrText("patient.preferred_pharmacy.address.address_line1", pharmacyAddress, passedInDriver);
			bussLib.enterTextValueByXPathOnNgmodelOrIdOrText("patient.preferred_pharmacy.address.city", pharmacyCity, passedInDriver);
			bussLib.enterTextValueByXPathOnNgmodelOrIdOrText("patient.preferred_pharmacy.address.zip_code", pharmacyZip, passedInDriver);
			passedInDriver.findElement(By.xpath(TestCaseInit.webLocatorProp.getProperty("WaitingRoom_Popup_Next_Button"))).click();
			passedInDriver.findElement(By.xpath(TestCaseInit.webLocatorProp.getProperty("WaitingRoom_Popup_ReviewNext_Button"))).click();
			genLibWeb.clickOnElementByCommonXPath("MHDoctorAccordian_xpath", null, passedInDriver);
			if (genLibWeb.isElementFoundByXPath("doctorConsultCancelBtn.ngClick.xpath", null, passedInDriver)) {
				passedInDriver.findElement(By.xpath(TestCaseInit.webLocatorProp.getProperty("doctorConsultCancelBtn.ngClick.xpath"))).click();
			} else {
				passedInDriver.findElement(By.xpath(TestCaseInit.webLocatorProp.getProperty("doctorConsultEndBtn.ngClick.xpath"))).click();
			}
			genLibWeb.clickOnElementByCommonXPath("Cencel_Consultation_Patient_Popup_xpath", null, passedInDriver);
			Thread.sleep(5000);
			passedInDriver.findElement(By.xpath(TestCaseInit.webLocatorProp.getProperty("Doctor_Submit_Discharge_Xpath"))).click();
			genLibWeb.clickOnElementByCommonXPath("LogOut_xpath", null , passedInDriver);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method update the Medical History from Patient side on app
	 * @param appiumDriver
	 * @param weight
	 * @param medHistory
	 * @param surgery
	 * @param job
	 * @param primaryCareName
	 * @param pharmacyName
	 * @param familyHistory
	 * @throws Exception
	 */
	public void validateMedicalHistoryUpdateAtPatientApp(AppiumDriver<?> appiumDriver, String weight, String medHistory, String surgery, String job, String primaryCareName,
			String pharmacyName, String familyHistory) throws Exception {
		Log.info("To validate Patient on Mobile app can see all medical history updates made by Doctor from Web");
		String actualBMI = null;
		if (TestCaseInit.mobileOnIOS) {
			actualBMI = genLibMobile.getTextByXPathOnIOS("BMIHealthRecord_ID", appiumDriver);
		} else {
			actualBMI = genLibMobile.getTextByIDOnAndroid("BMIHealthRecord_ID", appiumDriver);
		}
		if (actualBMI.contains(weight)) {
			Log.info("Weight in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("Weight in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Weight in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		try {
			swipeVrticalBottomToTop(appiumDriver);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String actualMedicalHist = null;
		if (TestCaseInit.mobileOnIOS) {
			actualMedicalHist = genLibMobile.getTextByXPathOnIOS("MedicalhistHealthRecord_ID", appiumDriver);
		} else {
			actualMedicalHist = genLibMobile.getTextByIDOnAndroid("MedicalhistHealthRecord_ID", appiumDriver);
		}
		if (actualMedicalHist.contains(medHistory)) {
			Log.info("MedicalHist in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("MedicalHist in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("MedicalHist in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		String actualSurgicalHist = null;
		if (TestCaseInit.mobileOnIOS) {
			actualSurgicalHist = genLibMobile.getTextByXPathOnIOS("SurgicalhistHealthRecord_ID", appiumDriver);
		} else {
			actualSurgicalHist = genLibMobile.getTextByIDOnAndroid("SurgicalhistHealthRecord_ID", appiumDriver);
		}
		if (actualSurgicalHist.contains(surgery)) {
			Log.info("SurgicalHist in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("SurgicalHist in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("SurgicalHist in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		try {
			swipeVrticalBottomToTop(appiumDriver);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String actualFamilyhist = null;
		if (TestCaseInit.mobileOnIOS) {
			actualFamilyhist = genLibMobile.getTextByXPathOnIOS("FamilyhistHealthRecord_ID", appiumDriver);
		} else {
			actualFamilyhist = genLibMobile.getTextByIDOnAndroid("FamilyhistHealthRecord_ID", appiumDriver);
		}
		if (actualFamilyhist.contains(familyHistory)) {
			Log.info("Familyhist in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("Familyhist in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Familyhist in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		String actualjob = null;
		if (TestCaseInit.mobileOnIOS) {
			actualjob = genLibMobile.getTextByXPathOnIOS("SocialhistHealthRecord_ID", appiumDriver);
		} else {
			actualjob = genLibMobile.getTextByIDOnAndroid("SocialhistHealthRecord_ID", appiumDriver);
		}
		if (actualjob.contains(job)) {
			Log.info("job in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("job in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("job in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		try {
			swipeVrticalBottomToTop(appiumDriver);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String actualprimaryCareName = null;
		if (TestCaseInit.mobileOnIOS) {
			actualprimaryCareName = genLibMobile.getTextByXPathOnIOS("PrimaryCareHealthRecord_ID", appiumDriver);
		} else {
			actualprimaryCareName = genLibMobile.getTextByIDOnAndroid("PrimaryCareHealthRecord_ID", appiumDriver);
		}
		if (actualprimaryCareName.contains(primaryCareName)) {
			Log.info("PrimaryCareName in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("PrimaryCareName in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("PrimaryCareName in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		String actualpharmacyName = null;
		if (TestCaseInit.mobileOnIOS) {
			actualpharmacyName = genLibMobile.getTextByXPathOnIOS("PharmacyHealthRecord_ID", appiumDriver);
		} else {
			actualpharmacyName = genLibMobile.getTextByIDOnAndroid("PharmacyHealthRecord_ID", appiumDriver);
		}
		if (actualpharmacyName.contains(pharmacyName)) {
			Log.info("pharmacyName in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("pharmacyName in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("pharmacyName in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
	}
	
	/**
	 * This method validate the updated Medical History after login from Patient side in the app
	 * @param appiumDriver
	 * @param weight
	 * @param medHistory
	 * @param surgery
	 * @param job
	 * @param primaryCareName
	 * @param pharmacyName
	 * @param familyHistory
	 * @throws Exception
	 */
	public void validateMedicalHistoryUpdateAtPatientAppAfterRelogin(AppiumDriver<?> appiumDriver, String weight, String medHistory, String surgery, String job, String primaryCareName,
			String pharmacyName, String familyHistory) throws Exception {
		Log.info("To validate Patient on Mobile app can see all medical history updates made by Doctor from Web");
		String actualBMI = null;
		if (TestCaseInit.mobileOnIOS) {
			actualBMI = genLibMobile.getTextByXPathOnIOS("BMIHealthRecord_ID", appiumDriver);
		} else {
			actualBMI = genLibMobile.getTextByIDOnAndroid("BMIHealthRecord_ID", appiumDriver);
		}
		if (actualBMI.contains(weight)) {
			Log.info("Weight in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("Weight in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Weight in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		String actualMedicalHist = null;
		if (TestCaseInit.mobileOnIOS) {
			actualMedicalHist = genLibMobile.getTextByXPathOnIOS("MedicalhistHealthRecord_ID", appiumDriver);
		} else {
			actualMedicalHist = genLibMobile.getTextByIDOnAndroid("MedicalhistHealthRecord_ID", appiumDriver);
		}
		if (actualMedicalHist.contains(medHistory)) {
			Log.info("MedicalHist in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("MedicalHist in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("MedicalHist in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("SurgicalhistHealthRecord_ID", appiumDriver)) {
			Log.info("Social History is visible");
		} else {
			swipeVrticalBottomToTop(appiumDriver);
		}
		String actualSurgicalHist = null;
		if (TestCaseInit.mobileOnIOS) {
			actualSurgicalHist = genLibMobile.getTextByXPathOnIOS("SurgicalhistHealthRecord_ID", appiumDriver);
		} else {
			actualSurgicalHist = genLibMobile.getTextByIDOnAndroid("SurgicalhistHealthRecord_ID", appiumDriver);
		}
		if (actualSurgicalHist.contains(surgery)) {
			Log.info("SurgicalHist in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("SurgicalHist in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("SurgicalHist in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("SocialhistHealthRecord_ID", appiumDriver)) {
			Log.info("Social History is visible");
		} else {
			swipeVrticalBottomToTop(appiumDriver);
		}
		String actualJob = null;
		if (TestCaseInit.mobileOnIOS) {
			actualJob = genLibMobile.getTextByXPathOnIOS("SocialhistHealthRecord_ID", appiumDriver);
		} else {
			actualJob = genLibMobile.getTextByIDOnAndroid("SocialhistHealthRecord_ID", appiumDriver);
		}
		if (actualJob.contains(job)) {
			Log.info("job in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("job in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("job in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("FamilyhistHealthRecord_ID", appiumDriver)) {
			Log.info("Family History is visible");
		} else {
			swipeVrticalBottomToTop(appiumDriver);
		}
		String actualFamilyhist = null;
		if (TestCaseInit.mobileOnIOS) {
			actualFamilyhist = genLibMobile.getTextByXPathOnIOS("FamilyhistHealthRecord_ID", appiumDriver);
		} else {
			actualFamilyhist = genLibMobile.getTextByIDOnAndroid("FamilyhistHealthRecord_ID", appiumDriver);
		}
		if (actualFamilyhist.contains(familyHistory)) {
			Log.info("Familyhist in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("Familyhist in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Familyhist in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		try {
			swipeVrticalBottomToTop(appiumDriver);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String actualPrimaryCareName = null;
		if (TestCaseInit.mobileOnIOS) {
			actualPrimaryCareName = genLibMobile.getTextByXPathOnIOS("PrimaryCareHealthRecord_ID", appiumDriver);
		} else {
			actualPrimaryCareName = genLibMobile.getTextByIDOnAndroid("PrimaryCareHealthRecord_ID", appiumDriver);
		}
		if (actualPrimaryCareName.contains(primaryCareName)) {
			Log.info("PrimaryCareName in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("PrimaryCareName in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("PrimaryCareName in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
		String actualPharmacyName = null;
		if (TestCaseInit.mobileOnIOS) {
			actualPharmacyName = genLibMobile.getTextByXPathOnIOS("PharmacyHealthRecord_ID", appiumDriver);
		} else {
			actualPharmacyName = genLibMobile.getTextByIDOnAndroid("PharmacyHealthRecord_ID", appiumDriver);
		}
		if (actualPharmacyName.contains(pharmacyName)) {
			Log.info("pharmacyName in the Medical History is the same as when the Doctor updated from the Web App");
		} else {
			Log.info("pharmacyName in the Medical History is NOT the same as when the Doctor updated from the Web App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("pharmacyName in the Medical History is NOT the same as when the Doctor updated from the Web App");
		}
	}
	
	/**
	 * This method is used to verify the summary of the consultation
	 * @param appiumDriver
	 * @param visitReason
	 * @param medication
	 * @param allergy
	 * @throws Exception
	 */
	public void verifySummaryOfConsultation(AppiumDriver<?> appiumDriver, String visitReason, String medication, String allergy) throws Exception {
		String actualChiefComplaint = null;
		if (TestCaseInit.mobileOnIOS) {
			actualChiefComplaint = genLibMobile.getTextByXPathOnIOS("MHChiefComplaintCon_ID", appiumDriver);
			Log.info(actualChiefComplaint);
		} else {
			actualChiefComplaint = genLibMobile.getTextByIDOnAndroid("MHChiefComplaintCon_ID", appiumDriver);
		}
		if (actualChiefComplaint.contains(visitReason)) {
			Log.info("ChiefComplaint in the Medical History is the same");
		} else {
			Log.info("ChiefComplaint in the Medical History is NOT the same");
			TestCaseInit.testCaseStatus = false;
			if (!TestCaseInit.mobileOnIOS) {
				Assert.fail("ChiefComplaint in the Medical History is NOT the same");
			}
		}
		String actualMedication = null;
		if (TestCaseInit.mobileOnIOS) {
			actualMedication = genLibMobile.getTextByXPathOnIOS("MHMedicationsCon_ID", appiumDriver);
		} else {
			actualMedication = genLibMobile.getTextByIDOnAndroid("MHMedicationsCon_ID", appiumDriver);
		}
		if (actualMedication.contains(medication)) {
			Log.info("Medication in the Medical History is the same");
		} else {
			Log.info("Medication in the Medical History is NOT the same");
			TestCaseInit.testCaseStatus = false;
			if (!EnvironmentConfigSettings.isMobileOnIOSEnvConfig()) {
				Assert.fail("Medication in the Medical History is NOT the same");
			}
		}
		String actualAllergies = null;
		if (TestCaseInit.mobileOnIOS) {
			actualAllergies = genLibMobile.getTextByXPathOnIOS("MHAllergiesCon_ID", appiumDriver);
		} else {
			actualAllergies = genLibMobile.getTextByIDOnAndroid("MHAllergiesCon_ID", appiumDriver);
		}
		if (actualAllergies.contains(allergy)) {
			Log.info("Allergies in the Medical History is the same");
		} else {
			Log.info("Allergies in the Medical History is NOT the same");
			TestCaseInit.testCaseStatus = false;
			if (!EnvironmentConfigSettings.isMobileOnIOSEnvConfig()) {
				Assert.fail("Allergies in the Medical History is NOT the same");
			}
		}
	}
	
	/**
	 * This method is used for login purpose in the mobile app
	 * @param appiumDriver
	 * @param username
	 * @param password
	 */
	public void loginApp(AppiumDriver<?> appiumDriver, String username, String password) {
		try {
			if (TestCaseInit.mobileOnIOS) {
				Log.info("Login to VMedix on iOS Device");
				genLibMobile.clickOnButtonByXpathOnIOS("LogInButton_ID", appiumDriver);
				genLibMobile.enterTextValueByXPathCreatedForNameOnIOS("LogInUserName_ID", username, appiumDriver);
				genLibMobile.hideKeyBoardVisibility(appiumDriver);
				genLibMobile.enterTextValueByXPathOnIOS("Password_ID", password, appiumDriver);
				genLibMobile.hideKeyBoardVisibility(appiumDriver);
				Log.info("Clicking on Login Button after entering the credentials.");
				genLibMobile.clickOnButtonByXPathOnAndroid("ClickOnLoginButton_XPath",appiumDriver);
			} else {
				Log.info("Login to VMedix");
				genLibMobile.clickOnButtonByIDOnAndroid("LogInButton_ID", appiumDriver);
				genLibMobile.enterTextValueByIDOnAndroid("LogInUserName_ID", username, appiumDriver);
				genLibMobile.hideKeyBoardVisibility(appiumDriver);
				genLibMobile.enterTextValueByIDOnAndroid("Password_ID", password, appiumDriver);
				genLibMobile.hideKeyBoardVisibility(appiumDriver);
				Log.info("Clicking on Login Button after entering the credentials.");
				genLibMobile.clickOnButtonByXpathOnIOS("ClickOnLoginButton_XPath",appiumDriver);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.info("User is not able to login the Mobile App");
			TestCaseInit.testCaseStatus = false;
			Assert.fail("User is not able to login the Mobile App");
		}
	}
	
	/**
	 * This method is used to click on continue button upon invoking app
	 * @param appiumDriver
	 */
	public void clickOnContinueButton(AppiumDriver<?> appiumDriver) {
		if (!TestCaseInit.mobileOnTab) {
			if (TestCaseInit.mobileOnIOS) {
				appiumDriver.findElement(By.xpath(TestCaseInit.iosLocatorProp.getProperty("InvokeVMedixApp_class"))).click();
			} else {
				appiumDriver.findElement(By.className(TestCaseInit.androidLocatorProp.getProperty("InvokeVMedixApp_class"))).click();
			}
		}
	}
	
	/**
	 * This method is used to fill Survey form on the iOS mobile app
	 * @param appiumDriver
	 */
	public void fillSurveyFormForIOS(AppiumDriver<?> appiumDriver) {
		try {
			appiumDriver.findElement(By.xpath(TestCaseInit.iosLocatorProp.getProperty("SurveyQuestion_1"))).click();
			appiumDriver.findElement(By.xpath(TestCaseInit.iosLocatorProp.getProperty("SurveyQuestion_2"))).click();
			appiumDriver.findElement(By.xpath(TestCaseInit.iosLocatorProp.getProperty("SurveyQuestion_3"))).click();
			appiumDriver.findElement(By.xpath(TestCaseInit.iosLocatorProp.getProperty("SurveyQuestion_4"))).click();
			appiumDriver.findElement(By.xpath(TestCaseInit.iosLocatorProp.getProperty("SurveyQuestion_5"))).click();
		} catch (Exception e) {
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to fill the Survey form from App due to : " + e);
		}
	}
	
	/**
	 * This method is used to perform sign out on the iOS mobile app
	 * @param passedInDriver
	 */
	public void signOutFromAppForIOS(WebDriver passedInDriver) {
		try {
			WebElement elem = passedInDriver.findElement(By.xpath(TestCaseInit.iosLocatorProp.getProperty("TableView_SignOut_xpath")));
			((AppiumDriver<?>) passedInDriver).tap(100, elem, 200);
			Log.info("Sign Out from the Application is succesful");
		} catch (Exception e) {
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to sign out from App due to : " + e);
		}
	}
	
	/**
	 * Helper
	 * @param appiumDriver
	 */
	public void cancelConsultationInAppFromConsultationScreen(AppiumDriver<?> appiumDriver) {
		try {
			if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("WaitingRoomPageTitle_xpath", appiumDriver)) {
				Log.info("Patient is on Waiting Room");
				Thread.sleep(8000);
				swipeVrticalBottomToTop(appiumDriver);
				swipeVrticalBottomToTop(appiumDriver);
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("CancelConsultationButton_xpath", appiumDriver)) {
					Log.info("Cancel Consultation Button is visible");
					if (TestCaseInit.mobileOnIOS) {
						genLibMobile.clickOnButtonByXpathOnIOS("CancelConsultationButton_xpath", appiumDriver);
						Log.info("Cancel Consultation button is clicked");
						if (!TestCaseInit.sauceLabForMobile) {
							genLibMobile.clickOnButtonByXpathOnIOS("ConfirmCancelConsultation_xpath", appiumDriver);
						}						
					} else {
						genLibMobile.clickOnButtonByXPathOnAndroid("CancelConsultationButton_xpath", appiumDriver);
						Log.info("Cancel Consultation button is clicked");
						if (!TestCaseInit.sauceLabForMobile) {
							genLibMobile.clickOnButtonByXPathOnAndroid("ConfirmCancelConsultation_xpath", appiumDriver);
						}						
					}
					Log.info("Confirmed the cancellation of consultation");
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("HomeScreenVerification_xpath", appiumDriver)) {
						Log.info("Patient is successfully brought back to Home Screen in the mobile app");
					}
					else {
						Log.info("Patient is still not on Home Screen");
						Log.info("Failed to bring the Patient back to Home Screen");
						TestCaseInit.testCaseStatus = false;
						Assert.fail("Failed to bring the Patient to Home Screen in the mobile app");
					}
				} else {
					Log.info("Failed to locate the cancel consultation button on screen");
					TestCaseInit.testCaseStatus = false;
					Assert.fail("Failed to locate the cancel consultation button on screen");
				}
			} else {
				Log.info("Waiting room page title didn't matched");
				TestCaseInit.testCaseStatus = false;
				Assert.fail("Waiting room page title didn't matched");
			}
		} catch (Exception e) {
			Log.info(e);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to bring the Patient to home screen due to exception : "+e);
		}
	}
	
	/**
	 * This method bring back the Patient on app to home screen
	 * @param appiumDriver
	 */
	public void bringMobileAppToHomeScreen(AppiumDriver<?> appiumDriver) {
		try {
			genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("HomeScreenVerification_xpath", appiumDriver);
			if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("HomeScreenVerification_xpath", appiumDriver) == true && 
					genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("HomeScreenVerification2_xpath", appiumDriver) == false) {
				Log.info("Patient is on Home Screen");
			} else {	
				Log.info("Patient is NOT on Home Screen, bringing the patient back to Home Screen");
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("HomeScreenVerification2_xpath", appiumDriver) == true) {
					if (TestCaseInit.mobileOnIOS) {
						genLibMobile.clickOnButtonByXpathOnIOS("HomeScreenVerification2_xpath", appiumDriver);
					} else {
						genLibMobile.clickOnButtonByXPathOnAndroid("HomeScreenVerification2_xpath", appiumDriver);
					}
					genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("AlertContinueButton_ID", appiumDriver);
					genLibMobile.clickOnButtonByIDOnAndroid("AlertContinueButton_ID", appiumDriver);
					if (TestCaseInit.mobileOnIOS) {
						genLibMobile.clickOnButtonByXpathOnIOS("MedicalHistorySaveButton_XPath", appiumDriver);
					} else {
						genLibMobile.clickOnButtonByXPathOnAndroid("MedicalHistorySaveButton_XPath", appiumDriver);
					}					
					cancelConsultationInAppFromConsultationScreen(appiumDriver);
				}
				else if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("WaitingRoomButton_xpath", appiumDriver)) {					
					Log.info("Waiting room button is visible on Home screen of Patient");
					if (TestCaseInit.mobileOnIOS) {
						genLibMobile.clickOnButtonByXpathOnIOS("WaitingRoomButton_xpath", appiumDriver);
					} else {
						genLibMobile.clickOnButtonByXPathOnAndroid("WaitingRoomButton_xpath", appiumDriver);
					}					
					cancelConsultationInAppFromConsultationScreen(appiumDriver);
				}
				else if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("GoToConsultationScreen_xpath", appiumDriver)) {
					Log.info("Consultation button is visible");
					if (TestCaseInit.mobileOnIOS) {
						genLibMobile.clickOnButtonByXpathOnIOS("GoToConsultationScreen_xpath", appiumDriver);
						Log.info("Clicked on the Consultation button");
						genLibMobile.clickOnButtonByXpathOnIOS("CancelConsultationButton_ID", appiumDriver);
						genLibMobile.clickOnButtonByXpathOnIOS("ConfirmCancelConsultation_xpath", appiumDriver);
						Log.info("Confirmed the cancellation of consultation");	
						genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("SubmitSurvey_ID", appiumDriver);
						fillSurveyFormForIOS(appiumDriver);
					} else {
						genLibMobile.clickOnButtonByXPathOnAndroid("GoToConsultationScreen_xpath", appiumDriver);
						Log.info("Clicked on the Consultation button");
						genLibMobile.clickOnButtonByIDOnAndroid("EndConsultationFromApp_ID", appiumDriver);
						genLibMobile.clickOnButtonByXPathOnAndroid("ConfirmCancelConsultation_xpath", appiumDriver);
						Log.info("Confirmed the cancellation of consultation");	
						Thread.sleep(5000); // Wait added, since on android app submit button appeares first and then after some time when question appears then submit button moves out of screen area.
						genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("SubmitSurvey_ID", appiumDriver);
						swipeVrticalBottomToTop(appiumDriver);
						swipeVrticalBottomToTop(appiumDriver);
						swipeVrticalBottomToTop(appiumDriver);
						genLibMobile.clickOnButtonByIDOnAndroid("SubmitSurvey_ID", appiumDriver);
					}					
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("SubmitSurvey_ID", appiumDriver)) {
					Log.info("Confirmed the cancellation of consultation");					
					genLibMobile.clickOnButtonByIDOnAndroid("SubmitSurvey_ID", appiumDriver);
					}					
				}
				else {
					Log.info("Patient is on some different screen. Please bring back the Patient to home screen");
					TestCaseInit.testCaseStatus = false;
					Assert.fail("Failed to bring the Patient back to home screen");
				}
			}			 
		} catch (Exception e) {
			Log.info(e);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to bring the Patient to home screen due to exception : "+e);
		}
	}
	
	/**
	 * This method is used to upload images during consultation
	 * @param appiumDriver
	 */
	public void uploadImageDuringConsultation(AppiumDriver<?> appiumDriver) {
		try {
			if((! EnvironmentConfigSettings.getMobileDeviceNameEnvConfig().equalsIgnoreCase("Emulator")) && (!TestCaseInit.sauceLabForMobile && !TestCaseInit.mobileOnIOS)){
				genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("AddPhotosDuringConsultation_ID", appiumDriver);
				Thread.sleep(2000);
				genLibMobile.clickOnButtonByIDOnAndroid("AddPhotosDuringConsultation_ID", appiumDriver);
				Thread.sleep(5000);
				genLibMobile.clickOnButtonByXPathOnAndroid("Gallery_xpath", appiumDriver);
				genLibMobile.clickOnButtonByIDOnAndroid("ThumbnailImage_ID", appiumDriver);
				genLibMobile.clickOnButtonByIDOnAndroid("AddImagefromGalleryDoneButton_ID",	appiumDriver);
				Log.info("Image successfully uploaded during Consultation");
				Thread.sleep(3000);
			}
		} catch (Exception e) {
			Log.info(e);
		}
	}
	
	/**
	 * This method check the Mobile app for mandatory Fields
	 * @param appiumDriver
	 */
	public void checkPaymentPageForMandatoryFieldsOnMobileApp(AppiumDriver<?> appiumDriver) {
		try {
			if (!TestCaseInit.sauceLabForMobile) {
				genLibMobile.clickOnButtonByIDOnAndroid("PaymentScreenSubmitButton_ID", appiumDriver);
				if (TestCaseInit.mobileOnIOS) {
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("PaymentPageMandatoryMsg_xpath", appiumDriver) == true) {					
						genLibMobile.clickOnButtonByXpathOnIOS("SubmitErrorPopup_xpath", appiumDriver);
						genLibMobile.clickOnButtonByXpathOnIOS("SubmitErrorPopup_xpath", appiumDriver);
						genLibMobile.clickOnButtonByXpathOnIOS("SubmitErrorPopup_xpath", appiumDriver);
						Log.info("Error message appeared and Patient is not allowed to pass throgh the Payment page without filling Payment details");
					} else {
						Log.info("Error message is not appearing upon submitting the Blank Payment Page");
						TestCaseInit.testCaseStatus = false;
						Assert.fail("Error message is not appearing upon submitting the Blank Payment Page");
					}
				} else {
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("PaymentPageMandatoryMsg_xpath", appiumDriver) == true) {
						String errMsgText = genLibMobile.getTextByXPathOnAndroid("PaymentPageMandatoryMsg_xpath", appiumDriver);
						Log.info(errMsgText);
						Log.info("Error message appeared and Patient is not allowed to pass throgh the Payment page without filling Payment details");
					} else {
						Log.info("Error message is not appearing upon submitting the Blank Payment Page");
						TestCaseInit.testCaseStatus = false;
						Assert.fail("Error message is not appearing upon submitting the Blank Payment Page");
					}
				}				
				
				// verify invalid credit card number
				genLibMobile.enterTextValueByIDOnAndroid("CardNumber_ID", "424242", appiumDriver);
				genLibMobile.hideKeyBoardVisibility(appiumDriver);
				swipeVrticalBottomToTop(appiumDriver);
				genLibMobile.clickOnButtonByIDOnAndroid("PaymentScreenSubmitButton_ID", appiumDriver);
				if (TestCaseInit.mobileOnIOS) {
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("PaymentPageMandatoryMsg_xpath", appiumDriver) == true) {					
						genLibMobile.clickOnButtonByXpathOnIOS("SubmitErrorPopup_xpath", appiumDriver);
						genLibMobile.clickOnButtonByXpathOnIOS("SubmitErrorPopup_xpath", appiumDriver);
						genLibMobile.clickOnButtonByXpathOnIOS("SubmitErrorPopup_xpath", appiumDriver);
						Log.info("Error message appeared and Patient is not allowed to pass throgh the Payment page without filling Payment details");
					} else {
						Log.info("Error message is not appearing upon submitting the Blank Payment Page");
						TestCaseInit.testCaseStatus = false;
						Assert.fail("Error message is not appearing upon submitting the Blank Payment Page");
					}
				} else {
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("PaymentPageMandatoryMsg_xpath", appiumDriver) == true) {
						Log.info("Error message is appearing for incorrect credit card number");
					} else {
						Log.info("Error message is NOT appearing for incorrect credit card number");
						TestCaseInit.testCaseStatus = false;
						Assert.fail("Error message is NOT appearing for incorrect credit card number");
					}
				}
				//verify the checkboxes for mandatory fields
				genLibMobile.enterTextValueByIDOnAndroid("CardNumber_ID", "4242424242424242", appiumDriver);
				genLibMobile.hideKeyBoardVisibility(appiumDriver);
				genLibMobile.clickOnButtonByIDOnAndroid("CardExpiration_ID", appiumDriver);
				if (TestCaseInit.mobileOnIOS) {
					genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
				} else {
					appiumDriver.findElement(By.id(TestCaseInit.androidLocatorProp.getProperty("SetDropDown_ID"))).click();
				}
				genLibMobile.enterTextValueByIDOnAndroid("CardSecurityCode_ID", "123", appiumDriver);
				genLibMobile.hideKeyBoardVisibility(appiumDriver);
				genLibMobile.clickOnButtonByIDOnAndroid("PaymentScreenSubmitButton_ID", appiumDriver);
				if (TestCaseInit.mobileOnIOS) {
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("PaymentPageCheckBoxesErrorMsg_xpath", appiumDriver) == true) {					
						genLibMobile.clickOnButtonByXpathOnIOS("SubmitErrorPopup_xpath", appiumDriver);
						Log.info("Error message appeared and Patient is not allowed to pass throgh the Payment page without filling Payment details");
					} else {
						Log.info("Error message is not appearing upon submitting the Blank Payment Page");
						TestCaseInit.testCaseStatus = false;
						Assert.fail("Error message is not appearing upon submitting the Blank Payment Page");
					}
				} else {
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("PaymentPageCheckBoxesErrorMsg_xpath", appiumDriver) == true) {
						Log.info("Error message appeared for Mandatory checkboxes on Payment screen in mobile app");
					} else {
						Log.info("Error message didn't appeared for mandatory checkboxes on Android app");
						TestCaseInit.testCaseStatus = false;
						Assert.fail("Error message didn't appeared for mandatory checkboxes on Android app");
					}
				}
			}			
		} catch (Exception e) {
			Log.info(e);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Exception on checking the Mandatory fields on Payment page in mobile app : "+e.toString());
		}
	}
	
	/**
	 * This method upload images from Patient side
	 * @param appiumDriver
	 */
	public void validatePhotoUploadOnWaitingRoom(AppiumDriver<?> appiumDriver) {
		try {
			if((!EnvironmentConfigSettings.getMobileDeviceNameEnvConfig().equalsIgnoreCase("Emulator")) && (!TestCaseInit.sauceLabForMobile)){
				genLibMobile.clickOnButtonByIDOnAndroid("WaitingRoomAddPhotosButton_ID", appiumDriver);
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("Cam_xpath", appiumDriver)) {
					Log.info("CAMERA option are visible to end user for uploading image");
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("Gallery_xpath", appiumDriver)) {
						Log.info("GALLERY option are visible to end user for uploading image");
					} else {
						Log.info("GALLERY option is not visible to end user's for uploading the image file");
						TestCaseInit.testCaseStatus = false;
						Assert.fail("GALLERY option is not visible to end user's for uploading the image file");
					}
				} else {
					Log.info("CAMERA option is not visible to end user's for uploading the image file");
					TestCaseInit.testCaseStatus = false;
					Assert.fail("CAMERA option is not visible to end user's for uploading the image file");
				}
				genLibMobile.clickOnButtonByXPathOnAndroid("Cam_xpath",appiumDriver);
				genLibMobile.clickOnButtonByIDOnAndroid("SelfCameraButton_ID", appiumDriver);
				Thread.sleep(2000);
				genLibMobile.clickOnButtonByIDOnAndroid("SelfCameraButtonDONE_ID", appiumDriver);
				Log.info("Successfully uploaded the image on waiting room from Camera");
				if (TestCaseInit.mobileOnIOS) {
					Log.info("Skipping the upload image functinality from Gallery on iOS.");
				} else {
					genLibMobile.clickOnButtonByIDOnAndroid("WaitingRoomAddPhotosButton_ID", appiumDriver);
					genLibMobile.clickOnButtonByXPathOnAndroid("Gallery_xpath", appiumDriver);						
					genLibMobile.clickOnButtonByIDOnAndroid("ThumbnailImage_ID", appiumDriver);
					genLibMobile.clickOnButtonByIDOnAndroid("AddImagefromGalleryDoneButton_ID", appiumDriver);
					Log.info("Successfully uploaded the image on waiting room from phone Gallery");
					genLibMobile.clickOnButtonByIDOnAndroid("WaitingRoomAddPhotosButton_ID", appiumDriver);
					genLibMobile.clickOnButtonByXPathOnAndroid("Gallery_xpath", appiumDriver);						
					genLibMobile.clickOnButtonByIDOnAndroid("ThumbnailImage_ID", appiumDriver);
					genLibMobile.clickOnButtonByIDOnAndroid("AddImagefromGalleryDoneButton_ID", appiumDriver);
					Log.info("Successfully uploaded the image on waiting room from phone Gallery");
					genLibMobile.clickOnButtonByIDOnAndroid("ThumbnailListImage_ID", appiumDriver);
					genLibMobile.clickOnButtonByIDOnAndroid("DeleteImage_ID", appiumDriver);
					Log.info("Successfully deleted the uploaded image");
					genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("WaitingRoomAddPhotosButton_ID", appiumDriver);
				}
			}
			
		} catch (Exception e) {
			Log.info(e);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Exception in uploading images on Waiting room : "+e);
		}
	}
	
	/**
	 * This method is used to verify the alert options on alert pop-up
	 * @param appiumDriver
	 */
	public void validateAlertOptions(AppiumDriver<?> appiumDriver){
		try {
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("AlertOption1_xpath", appiumDriver) == true && genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("AlertOption2_xpath", appiumDriver) == true 
						&& genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("AlertOption3_xpath", appiumDriver) == true) {
					Log.info("Alert in App, Alert SMS and Alert Phone options are visible in alert pop-up");
				} else {
					Log.info("Alert in App, Alert SMS and Alert Phone options are NOT visible in alert pop-up");
					TestCaseInit.testCaseStatus = false;
					Assert.fail("Alert in App, Alert SMS and Alert Phone options are NOT visible in alert pop-up");
				}
		} catch (Exception e) {
			Log.info(e);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Exception in validating the Alert options : "+e);
		}
	}
	public void submitSurveyForAndroid(AppiumDriver<?> appiumDriver){
		try {
			Thread.sleep(5000); // Wait added, since on android app submit button appears first and then after some time when question appears then submit button moves out of screen area.
			genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("SubmitSurvey_ID", appiumDriver);
			swipeVrticalBottomToTop(appiumDriver);
			swipeVrticalBottomToTop(appiumDriver);
			swipeVrticalBottomToTop(appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("SubmitSurvey_ID", appiumDriver);
		} catch (Exception e) {
			Log.info("Exception in Submitting Survey on Android App");
			Assert.fail("Exception in Submitting Survey on Android App "+e);
		}
	}
	
	public void clickOnDismissButton(AppiumDriver<?> appiumDriver){
		try {
			Thread.sleep(5000);
			if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("ButtonNoDismiss_ID", appiumDriver) == true) {
				genLibMobile.clickOnButtonByIDOnAndroid("ButtonNoDismiss_ID", appiumDriver);
			}
		} catch (Exception e) {
		}
	}
}
