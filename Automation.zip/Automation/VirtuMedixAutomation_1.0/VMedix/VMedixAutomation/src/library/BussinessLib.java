package library;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BussinessLib {

	GenericLibWeb genLibWeb = new GenericLibWeb();

//Angular-JS locators/functionalities using selenium locators	
	
	/**
	 * This method is used to enter value into text box by XPath on ng-model, id or text
	 * @param locatorVal
	 * @param enterVal
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean enterTextValueByXPathOnNgmodelOrIdOrText(String locatorVal, String enterVal, WebDriver driver) throws Exception
	{		
		boolean textEntered = false;
		try{				
			textEntered = genLibWeb.enterTextValueByXPath(null, "//input[@ng-model='"+locatorVal+"']", enterVal, driver);
			if(!textEntered){
				textEntered = genLibWeb.enterTextValueByXPath(null, "//input[@id='"+locatorVal+"']", enterVal, driver);
			}
			if(!textEntered){
				textEntered = genLibWeb.enterTextValueByXPath(null, "//div/p[contains(text(),'"+locatorVal+"')]/following-sibling::input", enterVal, driver);
			}
			if(!textEntered){
				textEntered = genLibWeb.enterTextValueByXPath(null, "//div/label[contains(text(),'"+locatorVal+"')]/input", enterVal, driver);
			}
		} catch (Exception exp) {
			throw exp;
		}		
		return textEntered;		
	}
	
	/**
	 * This method is used to enter value into text box by ng-model
	 * @param ngModel
	 * @param enterVal
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean enterTextValueByXPathOnNgmodel(String ngModel, String enterVal, WebDriver driver) throws Exception
	{		
		try{			
			return genLibWeb.enterTextValueByXPath(null, "//input[@ng-model='"+ngModel+"']", enterVal, driver);
		} catch (Exception exp) {
			throw exp;
		}
	}
	
	/**
	 * This method is used to enter value into text box by XPath on id
	 * @param id
	 * @param enterVal
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean enterTextValueByXPathOnId(String id, String enterVal, WebDriver driver) throws Exception
	{		
		try{			
			return genLibWeb.enterTextValueByXPath(null, "//input[@id='"+id+"']", enterVal, driver);
		} catch (Exception exp) {
			throw exp;
		}
	}
	
	/**
	 * This method is used to enter value into text box by XPath on text
	 * @param text
	 * @param enterVal
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean enterTextValueByXPathOnText(String text, String enterVal, WebDriver driver) throws Exception
	{
		boolean textEntered = false;
		try{			
			textEntered = genLibWeb.enterTextValueByXPath(null, "//div/p[contains(text(),'"+text+"')]/following-sibling::input", enterVal, driver);
			if(!textEntered){
				textEntered = genLibWeb.enterTextValueByXPath(null, "//div/label[contains(text(),'"+text+"')]/input", enterVal, driver);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return textEntered;	
	}
	
	
	/**
	 * This method is used to upload a file by XPath on id
	 * @param id
	 * @param fileLocation
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean uploadFileByXPathOnId(String id, String fileLocation, WebDriver driver) throws Exception {
		try {
			//ng-click="uploadPhotos()"
			return genLibWeb.enterTextValueByXPath(null, "//*[@ng-click='uploadPhotos()']", fileLocation, driver);
		} catch (Exception exp) {
			throw exp;
		}
	}
	
	/**
	 * This method is used to click on button by XPath on ng-model property
	 * @param ngModel
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */	
	public boolean clickOnButtonWithActionByXPathOnNgModel(String ngModel, WebDriver driver) throws Exception {
		try {
			return genLibWeb.clickOnElementWithActionByXPath(null, "//button[@ng-model='"+ngModel+"']", driver);
		} catch (Exception exp) {
			throw exp;
		}
	}
	
	/**
	 * This method is use to click on a button by XPath on ng-click 
	 * @param ngClick
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean clickOnButtonWithActionByXPathOnNgClick(String ngClick, WebDriver driver) throws Exception {	
		try {			
			return genLibWeb.clickOnElementWithActionByXPath(null, "//button[@ng-click=\""+ngClick+"\"]", driver);
		} catch (Exception exp) {
			throw exp;
		}
	}
	
	/**
	 * This method is used to click on button by XPath on name property
	 * @param name
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean clickOnButtonWithActionByXPathOnName(String name, WebDriver driver) throws Exception {
		try {
			return genLibWeb.clickOnElementWithActionByXPath(null, "//*[@name='"+name+"']", driver);
		} catch (Exception exp) {
			throw exp;
		}
	}
	
	/**
	 * This method is used to click on a button by XPath on for property
	 * @param forLocatorVal
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean clickOnButtonWithActionByXPathOnFor(String forLocatorVal, WebDriver driver) throws Exception {
		try {
			return genLibWeb.clickOnElementWithActionByXPath(null, "//*[@for='"+forLocatorVal+"']/span/span", driver);		
		} catch (Exception exp) {
			throw exp;
		}
	}
	
	/**
	 * This method is used to select value from the drop down based on index by xpath on ng-model or name.
	 * @param locatorVal
	 * @param indexValue
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean selectByIndexValueByXPathOnNgmodelOrName(String locatorVal, int indexValue, WebDriver driver) throws Exception{
		boolean selected = false;
		try {
			if(driver.findElements(By.xpath("//select[@ng-model='"+locatorVal+"']")).size() != 0) {
				selected = genLibWeb.selectByIndexValueWithSelectElementXPath(null, "//select[@ng-model='"+locatorVal+"']", indexValue, driver);
			}
			if(!selected && driver.findElements(By.xpath("//select[@name='"+locatorVal+"']")).size() != 0){
				selected = genLibWeb.selectByIndexValueWithSelectElementXPath(null, "//select[@name='"+locatorVal+"']", indexValue, driver);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return selected;
	}

	/**
	 * This method is used to select value from the drop down based on index by xpath on ng-model.
	 * @param ngModel
	 * @param indexValue
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean selectByIndexValueByXPathOnNgmodel(String ngModel, int indexValue, WebDriver driver) throws Exception{
		boolean selected = false;
		try {
			if(driver.findElements(By.xpath("//select[@ng-model='"+ngModel+"']")).size() != 0) {
				selected = genLibWeb.selectByIndexValueWithSelectElementXPath(null, "//select[@ng-model='"+ngModel+"']", indexValue, driver);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return selected;
	}	
	
	/**
	 * This method is used to select value from the drop down based on index by xpath on name.
	 * @param name
	 * @param indexValue
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean selectByIndexValueByXPathOnName(String name, int indexValue, WebDriver driver) throws Exception{
		boolean selected = false;
		try {
			if (driver.findElements(By.xpath("//select[@name='"+name+"']")).size() != 0) {
				selected = genLibWeb.selectByIndexValueWithSelectElementXPath(null, "//select[@name='"+name+"']", indexValue, driver);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return selected;
	}
	
	
	/**
	 * This method is used to select value from the drop down based on value by xpath on ng-model or name or class
	 * @param locatorVal
	 * @param selectVal
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean selectByValueByXPathOnNgmodelOrNameOrClass(String locatorVal, String selectVal, WebDriver driver) throws Exception {
		boolean selected = false;
		try {
			if(driver.findElements(By.xpath("//select[@ng-model='"+locatorVal+"']")).size() != 0) {
				selected = genLibWeb.selectByValueFromSelectElementXPath(null, "//select[@ng-model='"+locatorVal+"']", selectVal, driver);
			} 
			if(!selected && driver.findElements(By.xpath("//select[@name='"+locatorVal+"']")).size() != 0){
				selected = genLibWeb.selectByValueFromSelectElementXPath(null, "//select[@name='"+locatorVal+"']", selectVal, driver);
			}
			if(!selected && driver.findElements(By.xpath("//select[@class='"+locatorVal+"']")).size() != 0){
				selected = genLibWeb.selectByValueFromSelectElementXPath(null, "//select[@class='"+locatorVal+"']", selectVal, driver);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return selected;		
	}
	
	/**
	 * This method is used to select value from the drop down based on value by xpath on ng-model
	 * @param ngModel
	 * @param selectVal
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean selectByValueByXPathOnNgmodel(String ngModel, String selectVal, WebDriver driver) throws Exception {
		boolean selected = false;
		try {			
			if (driver.findElements(By.xpath("//select[@ng-model='"+ngModel+"']")).size() != 0) {
				selected = genLibWeb.selectByValueFromSelectElementXPath(null, "//select[@ng-model='"+ngModel+"']", selectVal, driver);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return selected;		
	}
	
	/**
	 * This method is used to select value from the drop down based on value by xpath on name
	 * @param name
	 * @param selectVal
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean selectByValueByXPathOnName(String name, String selectVal, WebDriver driver) throws Exception {
		boolean selected = false;
		try {			
			if (driver.findElements(By.xpath("//select[@name='"+name+"']")).size() != 0) {		
				selected = genLibWeb.selectByValueFromSelectElementXPath(null, "//select[@name='"+name+"']", selectVal, driver);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return selected;		
	}
	
	/**
	 * This method is used to select value from the drop down based on value by xpath on class
	 * @param classLocatorVal
	 * @param selectVal
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */
	public boolean selectByValueByXPathOnClass(String classLocatorVal, String selectVal, WebDriver driver) throws Exception {
		boolean selected = false;
		try {			
			if (driver.findElements(By.xpath("//select[@class='"+classLocatorVal+"']")).size() != 0) {
				selected = genLibWeb.selectByValueFromSelectElementXPath(null, "//select[@class='"+classLocatorVal+"']", selectVal, driver);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return selected;		
	}
	
	
	/**
	 * This method is used to get text by xpath on name or text
	 * @param locatorVal
	 * @param driver
	 * @return String text; An empty string if NOT found
	 * @throws Exception
	 */
	public String getTextByXPathOnNameOrText(String locatorVal, WebDriver driver) throws Exception {
		String expectedText = "";
		try {
			if (driver.findElements(By.xpath("//*[@name='"+locatorVal+"']")).size() != 0) {				
				expectedText = genLibWeb.getTextByXPath(null, "//*[@name='"+locatorVal+"']", driver);
			}
			if(expectedText.isEmpty() && driver.findElements(By.xpath("//*[text()='"+locatorVal+"']")).size() != 0){
				expectedText = genLibWeb.getTextByXPath(null, "//*[text()='"+locatorVal+"']", driver);
			}
			if(expectedText.isEmpty() && driver.findElements(By.xpath(" //*[contains(text(),'"+locatorVal+"')]")).size() != 0){
				expectedText = genLibWeb.getTextByXPath(null, " //*[contains(text(),'"+locatorVal+"')]", driver);						
			}
		} catch (Exception exp) {
			throw exp;
		}		
		return expectedText;
	}	
	
	/**
	 * This method is used to get text by xpath on name
	 * @param name
	 * @param driver
	 * @return String text; An empty string if NOT found
	 * @throws Exception
	 */
	public String getTextByXPathOnName(String name, WebDriver driver) throws Exception {
		String expectedText = "";
		try {
			if (driver.findElements(By.xpath("//*[@name='"+name+"']")).size() != 0) {				
				expectedText = genLibWeb.getTextByXPath(null, "//*[@name='"+name+"']", driver);
			}
		} catch (Exception exp) {
			throw exp;
		}		
		return expectedText;
	}
	
	/**
	 * This method is used to get text by xpath on partial or full text
	 * @param text
	 * @param driver
	 * @return String text; An empty string if NOT found
	 * @throws Exception
	 */
	public String getTextByXPathOnText(String text, WebDriver driver) throws Exception {
		String expectedText = "";
		try {
			if(driver.findElements(By.xpath("//*[text()='"+text+"']")).size() != 0) {				
				expectedText = genLibWeb.getTextByXPath(null, "//*[text()='"+text+"']", driver);
			}
			if(expectedText.isEmpty() && driver.findElements(By.xpath(" //*[contains(text(),'"+text+"')]")).size() != 0){
				expectedText = genLibWeb.getTextByXPath(null, " //*[contains(text(),'"+text+"')]", driver);
			}			
		} catch (Exception exp) {
			throw exp;
		}		
		return expectedText;
	}		
	
	/**
	 * This method is used to get select text of first option from dropdown by xpath on @Name
	 * @param xpath
	 * @param driver
	 * @return String text; An empty string if option NOT found
	 * @throws Exception
	 */
	public String getFirstOptionFromSelectDropboxByXPathOnName(String xpath, WebDriver driver) throws Exception{
		try {
			return genLibWeb.getFirstOptionFromSelectDropboxByXPath(null, "//select[@name='"+xpath+"']", driver);
		} catch (Exception exp) {
			throw exp;
		}
	}

}
