package library;

import org.apache.log4j.Logger;

import tests.TestCaseInit;

public final class EnvironmentConfigSettings {

	private static Logger log = Logger.getLogger(EnvironmentConfigSettings.class.getName());

	static final private String TEST_ON_SERVER_PROP							= "test.on.server";
	static final private String TEST_IS_SEQUENTIAL_PROP						= "test.is.sequential";
	static final private String TEST_NO_OF_ITERATIONS_PROP					= "test.no.of.iterations";
	static final private String TEST_PARALLEL_COUNT_PROP					= "test.parallel.count";	
	static final private String TEST_TYPE_SMOKE_PROP						= "test.type.smoke";
	static final private String TEST_TYPE_REGRESSION_PROP					= "test.type.regression";
	static final private String TEST_TYPE_PERFORMANCE_PROP					= "test.type.performance";
	static final private String TEST_PERFORMANCE_SYNC_RUN_NUM_PROP			= "test.performance.sync.run.num";	
	static final private String TEST_PERFORMANCE_CONSULTS_START_COUNT_PROP	= "test.perf.consults.start.count";
	static final private String TEST_PERFORMANCE_CONSULTS_END_COUNT_PROP	= "test.perf.consults.end.count";
	static final private String WAIT_IMPLICIT_PROP							= "wait.implicit";
	static final private String WAIT_EXPLICIT_PROP							= "wait.explicit";
	static final private String WAIT_EXTRA_EXPLICIT_PROP					= "wait.extra.explicit";
	static final private String SCREENSHOT_ON_PASS_PROP						= "screenshot.on.pass";
	static final private String TEST_SUITE_FILE_NAME_PROP					= "test.suite.file.name";
	static final private String TEST_SUITE_SMOKE_SHEET_NAME_PROP			= "test.suite.smoke.sheet.name";
	static final private String TEST_SUITE_REGRESSION_SHEET_NAME_PROP		= "test.suite.regression.sheet.name";
	static final private String TEST_SUITE_PERFORMANCE_SHEET_NAME_PROP		= "test.suite.performance.sheet.name";	
	static final private String TEST_DATA_SMOKE_FILE_NAME_PROP				= "test.data.smoke.file.name";
	static final private String TEST_DATA_REGRESSION_FILE_NAME_PROP			= "test.data.regression.file.name";
	static final private String TEST_DATA_PERFORMANCE_FILE_NAME_PROP		= "test.data.performance.file.name";
	static final private String GMAIL_URL_PROP 								= "gmail.url";
	static final private String WEB_VERSION_NUMBER_PROP						= "web.version.number";	
	static final private String WEB_BROWSER_FOR_DOCTOR_PROP 				= "web.browser.for.doctor";
	static final private String WEB_BROWSER_FOR_PATIENT_PROP 				= "web.browser.for.patient";
	static final private String MOBILE_EXECUTE_TEST_PROP					= "mobile.execute.test";
	static final private String MOBILE_APPIUM_HOST_PROP						= "mobile.appium.host";
	static final private String MOBILE_PLATFORM_VERSION_PROP				= "mobile.platform.version";
	static final private String MOBILE_PLATFORM_NAME_PROP					= "mobile.platform.name";
	static final private String MOBILE_DEVICE_NAME_PROP						= "mobile.device.name";	
	static final private String MOBILE_ANDROID_APP_ACTIVITY_PROP			= "mobile.android.app.activity";
	static final private String MOBILE_ANDROID_APP_PACKAGE_PROP				= "mobile.android.app.package";	
	static final private String MOBILE_ANDROID_ON_TAB_PROP					= "mobile.android.on.tab";
	static final private String MOBILE_ON_IOS_PROP							= "mobile.on.ios";
	static final private String MOBILE_IOS_DEVICE_UDID_PROP					= "mobile.ios.device.udid";
	static final private String MOBILE_IOS_APP_PROP							= "mobile.ios.app";
	static final private String SAUCE_LAB_WEB_PROP							= "sauce.lab.web";
	static final private String SAUCE_LAB_MOBILE_PROP						= "sauce.lab.mobile";
	static final private String SAUCE_LAB_USER_NAME_PROP					= "sauce.lab.user.name";
	static final private String SAUCE_LAB_KEY_PROP							= "sauce.lab.key";
	static final private String SAUCE_LAB_WEB_PLATFORM_PROP 				= "sauce.lab.web.platform";
	static final private String SAUCE_LAB_WEB_BROWSER_VERSION_PROP			= "sauce.lab.web.browser.version";	
	static final private String SAUCE_LAB_MOBILE_APPIUM_VERSION_PROP		= "sauce.lab.mobile.appium.version";
	static final private String SAUCE_LAB_MOBILE_DEVICE_NAME_PROP			= "sauce.lab.mobile.device.name";
	static final private String SAUCE_LAB_MOBILE_PLATFORM_VERSION_PROP		= "sauce.lab.mobile.platform.version";
	static final private String SAUCE_LAB_MOBILE_PLATFORM_NAME_PROP			= "sauce.lab.mobile.platform.name";
	static final private String SAUCE_LAB_APP_STORAGE_PROP					= "sauce.lab.app.storage";
	static final private String SAUCE_LAB_NEW_COMMAND_TIME_OUT_PROP			= "sauce.lab.new.command.time.out";

	
	//config setting
	static private String TEST_ON_SERVER_SETTING 						= null;
	static private Boolean TEST_IS_SEQUENTIAL_SETTING					= null;
	static private int TEST_NO_OF_ITERATION_SETTINGS					= 0;
	static private int TEST_PARALLEL_COUNT_SETTING						= 0;
	static private Boolean TEST_TYPE_SMOKE_SETTING						= null;
	static private Boolean TEST_TYPE_REGRESSION_SETTING					= null;
	static private Boolean TEST_TYPE_PERFORMANCE_SETTING				= null;
	static private int TEST_PERFORMANCE_SYNC_RUN_NUM_SETTING			= 0;
	static private int TEST_PERFORMANCE_CONSULTS_START_COUNT_SETTING	= 0;
	static private int TEST_PERFORMANCE_CONSULTS_END_COUNT_SETTING		= 0;
	static private int WAIT_IMPLICIT_SETTING							= 0;
	static private int WAIT_EXPLICIT_SETTING							= 0;
	static private int WAIT_EXTRA_EXPLICIT_SETTING						= 0;
	static private Boolean SCREENSHOT_ON_PASS_SETTING					= null;
	static private String TEST_SUITE_FILE_NAME_SETTING					= null;	
	static private String TEST_SUITE_SMOKE_SHEET_NAME_SETTING			= null;
	static private String TEST_SUITE_REGRESSION_SHEET_NAME_SETTING		= null;
	static private String TEST_SUITE_PERFORMANCE_SHEET_NAME_SETTING		= null;	
	static private String TEST_DATA_SMOKE_FILE_NAME_SETTING				= null;
	static private String TEST_DATA_REGRESSION_FILE_NAME_SETTING		= null;
	static private String TEST_DATA_PERFORMANCE_FILE_NAME_SETTING		= null;	
	static private String GMAIL_URL_SETTING 							= null;
	static private String WEB_VERSION_NUMBER_SETTING 					= null;
	static private String WEB_BROWSER_FOR_DOCTOR_SETTING 				= null;
	static private String WEB_BROWSER_FOR_PATIENT_SETTING 				= null;
	static private Boolean MOBILE_EXECUTE_TEST_SETTING					= null;	
	static private String MOBILE_APPIUM_HOST_SETTING					= null;
	static private String MOBILE_PLATFORM_VERSION_SETTING 				= null;
	static private String MOBILE_PLATFORM_NAME_SETTING					= null;
	static private String MOBILE_DEVICE_NAME_SETTING					= null;
	static private String MOBILE_ANDROID_APP_ACTIVITY_SETTING			= null;
	static private String MOBILE_ANDROID_APP_PACKAGE_SETTING			= null;
	static private Boolean MOBILE_ANDROID_ON_TAB_SETTING				= null;
	static private Boolean MOBILE_ON_IOS_SETTING						= null;	
	static private String MOBILE_IOS_DEVICE_UDID_SETTING				= null;
	static private String MOBILE_IOS_APP_SETTING						= null;	
	static private Boolean SAUCE_LAB_WEB_SETTING						= null;
	static private Boolean SAUCE_LAB_MOBILE_SETTING						= null;	
	static private String SAUCE_LAB_USER_NAME_SETTING					= null;
	static private String SAUCE_LAB_KEY_SETTING							= null;
	static private String SAUCE_LAB_WEB_PLATFORM_SETTING 				= null;
	static private String SAUCE_LAB_WEB_BROWSER_VERSION_SETTING 		= null;
	static private String SAUCE_LAB_MOBILE_APPIUM_VERSION_SETTING		= null;
	static private String SAUCE_LAB_MOBILE_DEVICE_NAME_SETTING			= null;
	static private String SAUCE_LAB_MOBILE_PLATFORM_VERSION_SETTING		= null;
	static private String SAUCE_LAB_MOBILE_PLATFORM_NAME_SETTING		= null;
	static private String SAUCE_LAB_APP_STORAGE_SETTING					= null;
	static private String SAUCE_LAB_NEW_COMMAND_TIME_OUT_SETTING		= null;
	
	private EnvironmentConfigSettings() {	} //Avoid instantiation		
	
	public static String getServerNameEnvConfig() {
		if(TEST_ON_SERVER_SETTING == null){
			TEST_ON_SERVER_SETTING = TestCaseInit.envConfigProp.getProperty(TEST_ON_SERVER_PROP);
			log.info("Environment Config property for " + TEST_ON_SERVER_PROP + " is : "+ TEST_ON_SERVER_SETTING);
		}
		return TEST_ON_SERVER_SETTING;
	}	
	
	public static boolean isTestSequentialEnvConfig() {
		if(TEST_IS_SEQUENTIAL_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(TEST_IS_SEQUENTIAL_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				TEST_IS_SEQUENTIAL_SETTING = true;
			}else {
				TEST_IS_SEQUENTIAL_SETTING = false;
			}
			String yesOrNo = TEST_IS_SEQUENTIAL_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + TEST_IS_SEQUENTIAL_PROP + " is : " + yesOrNo); //log it only once when its set for the first time
		}
		return TEST_IS_SEQUENTIAL_SETTING;
	}
	
	public static int getTestNoOfIterationsEnvConfig() {
		if(TEST_NO_OF_ITERATION_SETTINGS == 0) {
			TEST_NO_OF_ITERATION_SETTINGS = Integer.valueOf(TestCaseInit.envConfigProp.getProperty(TEST_NO_OF_ITERATIONS_PROP));
			log.info("Environment Config property for " + TEST_NO_OF_ITERATIONS_PROP + " is : "+ TEST_NO_OF_ITERATION_SETTINGS);
		}		
		return TEST_NO_OF_ITERATION_SETTINGS;
	}
	
	public static int getTestParallelCountEnvConfig() {
		if(TEST_PARALLEL_COUNT_SETTING == 0){
			TEST_PARALLEL_COUNT_SETTING = Integer.valueOf(TestCaseInit.envConfigProp.getProperty(TEST_PARALLEL_COUNT_PROP));
			log.info("Environment Config property for " + TEST_PARALLEL_COUNT_PROP + " is : "+ TEST_PARALLEL_COUNT_SETTING);
		}
		return TEST_PARALLEL_COUNT_SETTING;
	}
	
	public static boolean isTestTypeSmoke() {
		if(TEST_TYPE_SMOKE_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(TEST_TYPE_SMOKE_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				TEST_TYPE_SMOKE_SETTING = true;
			}else {
				TEST_TYPE_SMOKE_SETTING = false;
			}
			String yesOrNo = TEST_TYPE_SMOKE_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + TEST_TYPE_SMOKE_PROP + " is : " + yesOrNo); //log it only once when its set for the first time
		}
		return TEST_TYPE_SMOKE_SETTING;
	}
	
	public static boolean isTestTypeRegression() {
		if(TEST_TYPE_REGRESSION_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(TEST_TYPE_REGRESSION_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				TEST_TYPE_REGRESSION_SETTING = true;
			}else {
				TEST_TYPE_REGRESSION_SETTING = false;
			}
			String yesOrNo = TEST_TYPE_REGRESSION_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + TEST_TYPE_REGRESSION_PROP + " is : " + yesOrNo); //log it only once when its set for the first time
		}
		return TEST_TYPE_REGRESSION_SETTING;
	}
	
	public static boolean isTestTypePerformance() {
		if(TEST_TYPE_PERFORMANCE_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(TEST_TYPE_PERFORMANCE_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				TEST_TYPE_PERFORMANCE_SETTING = true;
			}else {
				TEST_TYPE_PERFORMANCE_SETTING = false;
			}
			String yesOrNo = TEST_TYPE_PERFORMANCE_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + TEST_TYPE_PERFORMANCE_PROP + " is : " + yesOrNo); //log it only once when its set for the first time
		}
		return TEST_TYPE_PERFORMANCE_SETTING;
	}
	
	public static int getPerformanceSynchronusRunNumberEnvConfig() {
		if(TEST_PERFORMANCE_SYNC_RUN_NUM_SETTING == 0){
			TEST_PERFORMANCE_SYNC_RUN_NUM_SETTING = Integer.valueOf(TestCaseInit.envConfigProp.getProperty(TEST_PERFORMANCE_SYNC_RUN_NUM_PROP));
			log.info("Environment Config property for " + TEST_PERFORMANCE_SYNC_RUN_NUM_PROP + " is : "+ TEST_PERFORMANCE_SYNC_RUN_NUM_SETTING);
		}
		return TEST_PERFORMANCE_SYNC_RUN_NUM_SETTING;
	}
	
	public static int getPerformanceConsultsStartCountEnvConfig() {
		if(TEST_PERFORMANCE_CONSULTS_START_COUNT_SETTING == 0){
			TEST_PERFORMANCE_CONSULTS_START_COUNT_SETTING = Integer.valueOf(TestCaseInit.envConfigProp.getProperty(TEST_PERFORMANCE_CONSULTS_START_COUNT_PROP));
			log.info("Environment Config property for " + TEST_PERFORMANCE_CONSULTS_START_COUNT_PROP + " is : "+ TEST_PERFORMANCE_CONSULTS_START_COUNT_SETTING);
		}
		return TEST_PERFORMANCE_CONSULTS_START_COUNT_SETTING;
	}
	
	public static int getPerformanceConsultsEndCountEnvConfig() {
		if(TEST_PERFORMANCE_CONSULTS_END_COUNT_SETTING == 0){
			TEST_PERFORMANCE_CONSULTS_END_COUNT_SETTING = Integer.valueOf(TestCaseInit.envConfigProp.getProperty(TEST_PERFORMANCE_CONSULTS_END_COUNT_PROP));
			log.info("Environment Config property for " + TEST_PERFORMANCE_CONSULTS_END_COUNT_PROP + " is : "+ TEST_PERFORMANCE_CONSULTS_END_COUNT_SETTING);
		}
		return TEST_PERFORMANCE_CONSULTS_END_COUNT_SETTING;
	}
	public static int getImplicitWaitEnvConfig() {
		if(WAIT_IMPLICIT_SETTING == 0) {
			WAIT_IMPLICIT_SETTING = Integer.parseInt(TestCaseInit.envConfigProp.getProperty(WAIT_IMPLICIT_PROP));
			log.info("Environment Config property for " + WAIT_IMPLICIT_PROP + " is : "+ WAIT_IMPLICIT_SETTING);
		}
		return WAIT_IMPLICIT_SETTING;
	}

	public static int getExplicitWaitEnvConfig() {
		if(WAIT_EXPLICIT_SETTING == 0) {
			WAIT_EXPLICIT_SETTING = Integer.parseInt(TestCaseInit.envConfigProp.getProperty(WAIT_EXPLICIT_PROP));
			log.info("Environment Config property for " + WAIT_EXPLICIT_PROP + " is : "+ WAIT_EXPLICIT_SETTING);
		}
		return WAIT_EXPLICIT_SETTING;
	}
	
	public static int getExtraExplicitWaitEnvConfig() {
		if(WAIT_EXTRA_EXPLICIT_SETTING == 0) {
			WAIT_EXTRA_EXPLICIT_SETTING = Integer.parseInt(TestCaseInit.envConfigProp.getProperty(WAIT_EXTRA_EXPLICIT_PROP));
			log.info("Environment Config property for " + WAIT_EXTRA_EXPLICIT_PROP + " is : "+ WAIT_EXTRA_EXPLICIT_SETTING);
		}
		return WAIT_EXTRA_EXPLICIT_SETTING;
	}
	
	public static boolean isScreenshotOnPassEnvConfig() {
		if(SCREENSHOT_ON_PASS_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(SCREENSHOT_ON_PASS_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				SCREENSHOT_ON_PASS_SETTING = true;
			}else {
				SCREENSHOT_ON_PASS_SETTING = false;
			}
			String yesOrNo = SCREENSHOT_ON_PASS_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + SCREENSHOT_ON_PASS_PROP + " is : " + yesOrNo);
		}
		return SCREENSHOT_ON_PASS_SETTING;
	}
	
	public static String getTestSuiteFileNameEnvConfig() {
		if(TEST_SUITE_FILE_NAME_SETTING == null){
			TEST_SUITE_FILE_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(TEST_SUITE_FILE_NAME_PROP);
			log.info("Environment Config property for " + TEST_SUITE_FILE_NAME_PROP + " is : "+ TEST_SUITE_FILE_NAME_SETTING);
		}
		return TEST_SUITE_FILE_NAME_SETTING;
	}
	
	public static String getTestSuiteSmokeSheetNameEnvConfig() {
		if(TEST_SUITE_SMOKE_SHEET_NAME_SETTING == null){
			TEST_SUITE_SMOKE_SHEET_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(TEST_SUITE_SMOKE_SHEET_NAME_PROP);
			log.info("Environment Config property for " + TEST_SUITE_SMOKE_SHEET_NAME_PROP + " is : "+ TEST_SUITE_SMOKE_SHEET_NAME_SETTING);
		}
		return TEST_SUITE_SMOKE_SHEET_NAME_SETTING;
	}
	
	public static String getTestSuiteRegressionSheetNameEnvConfig() {
		if(TEST_SUITE_REGRESSION_SHEET_NAME_SETTING == null){
			TEST_SUITE_REGRESSION_SHEET_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(TEST_SUITE_REGRESSION_SHEET_NAME_PROP);
			log.info("Environment Config property for " + TEST_SUITE_REGRESSION_SHEET_NAME_PROP + " is : "+ TEST_SUITE_REGRESSION_SHEET_NAME_SETTING);
		}
		return TEST_SUITE_REGRESSION_SHEET_NAME_SETTING;
	}
	
	public static String getTestSuitePerformanceSheetNameEnvConfig() {
		if(TEST_SUITE_PERFORMANCE_SHEET_NAME_SETTING == null){
			TEST_SUITE_PERFORMANCE_SHEET_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(TEST_SUITE_PERFORMANCE_SHEET_NAME_PROP);
			log.info("Environment Config property for " + TEST_SUITE_PERFORMANCE_SHEET_NAME_PROP + " is : "+ TEST_SUITE_PERFORMANCE_SHEET_NAME_SETTING);
		}
		return TEST_SUITE_PERFORMANCE_SHEET_NAME_SETTING;
	}
	
	public static String getTestDataSmokeFileNameEnvConfig() {
		if(TEST_DATA_SMOKE_FILE_NAME_SETTING == null){
			TEST_DATA_SMOKE_FILE_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(TEST_DATA_SMOKE_FILE_NAME_PROP);
			log.info("Environment Config property for " + TEST_DATA_SMOKE_FILE_NAME_PROP + " is : "+ TEST_DATA_SMOKE_FILE_NAME_SETTING);
		}
		return TEST_DATA_SMOKE_FILE_NAME_SETTING;
	}		
	
	public static String getTestDataRegressionFileNameEnvConfig() {
		if(TEST_DATA_REGRESSION_FILE_NAME_SETTING == null){
			TEST_DATA_REGRESSION_FILE_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(TEST_DATA_REGRESSION_FILE_NAME_PROP);
			log.info("Environment Config property for " + TEST_DATA_REGRESSION_FILE_NAME_PROP + " is : "+ TEST_DATA_REGRESSION_FILE_NAME_SETTING);
		}
		return TEST_DATA_REGRESSION_FILE_NAME_SETTING;
	}
	
	public static String getTestDataPerformanceFileNameEnvConfig() {
		if(TEST_DATA_PERFORMANCE_FILE_NAME_SETTING == null){
			TEST_DATA_PERFORMANCE_FILE_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(TEST_DATA_PERFORMANCE_FILE_NAME_PROP);
			log.info("Environment Config property for " + TEST_DATA_PERFORMANCE_FILE_NAME_PROP + " is : "+ TEST_DATA_PERFORMANCE_FILE_NAME_SETTING);
		}
		return TEST_DATA_PERFORMANCE_FILE_NAME_SETTING;
	}

	public static String getGmailUrlEnvConfig() {
		if(GMAIL_URL_SETTING == null){
			GMAIL_URL_SETTING = TestCaseInit.envConfigProp.getProperty(GMAIL_URL_PROP);
			log.info("Environment Config property for " + GMAIL_URL_PROP + " is : "+ GMAIL_URL_SETTING);
		}
		return GMAIL_URL_SETTING;
	}		

	public static String getWebVersionEnvConfig() {
		if(WEB_VERSION_NUMBER_SETTING == null){
			WEB_VERSION_NUMBER_SETTING = TestCaseInit.envConfigProp.getProperty(WEB_VERSION_NUMBER_PROP);
			log.info("Environment Config property for " + WEB_VERSION_NUMBER_PROP + " is : "+ WEB_VERSION_NUMBER_SETTING);
		}
		return WEB_VERSION_NUMBER_SETTING;
	}	
	
	public static String getWebBrowserForDoctorEnvConfig() {
		if(WEB_BROWSER_FOR_DOCTOR_SETTING == null) {
			WEB_BROWSER_FOR_DOCTOR_SETTING = TestCaseInit.envConfigProp.getProperty(WEB_BROWSER_FOR_DOCTOR_PROP);
			log.info("Environment Config property for " + WEB_BROWSER_FOR_DOCTOR_PROP + " is : "+ WEB_BROWSER_FOR_DOCTOR_SETTING);
		}
		return WEB_BROWSER_FOR_DOCTOR_SETTING;
	}
	
	public static String getWebBrowserForPatientEnvConfig() {
		if(WEB_BROWSER_FOR_PATIENT_SETTING == null) {
			WEB_BROWSER_FOR_PATIENT_SETTING = TestCaseInit.envConfigProp.getProperty(WEB_BROWSER_FOR_PATIENT_PROP);
			log.info("Environment Config property for " + WEB_BROWSER_FOR_PATIENT_PROP + " is : "+ WEB_BROWSER_FOR_PATIENT_SETTING);
		}
		return WEB_BROWSER_FOR_PATIENT_SETTING;
	}	

// Mobile Settings
	
	public static boolean isExecuteMobileTestEnvConfig() {
		if(MOBILE_EXECUTE_TEST_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(MOBILE_EXECUTE_TEST_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				MOBILE_EXECUTE_TEST_SETTING = true;
			}else {
				MOBILE_EXECUTE_TEST_SETTING = false;
			}
			String yesOrNo = MOBILE_EXECUTE_TEST_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + MOBILE_EXECUTE_TEST_PROP + " is : " + yesOrNo);
		}
		return MOBILE_EXECUTE_TEST_SETTING;
	}
	
	public static String getMobileAppiumHostEnvConfig() {
		if(MOBILE_APPIUM_HOST_SETTING == null) {
			MOBILE_APPIUM_HOST_SETTING = TestCaseInit.envConfigProp.getProperty(MOBILE_APPIUM_HOST_PROP);
			log.info("Environment Config property for " + MOBILE_APPIUM_HOST_PROP + " is : "+ MOBILE_APPIUM_HOST_SETTING);
		}
		return MOBILE_APPIUM_HOST_SETTING;
	}
		
	public static String getMobilePlatformVersionEnvConfig() {
		if(MOBILE_PLATFORM_VERSION_SETTING == null) {
			MOBILE_PLATFORM_VERSION_SETTING = TestCaseInit.envConfigProp.getProperty(MOBILE_PLATFORM_VERSION_PROP);
			log.info("Environment Config property for " + MOBILE_PLATFORM_VERSION_PROP + " is : "+ MOBILE_PLATFORM_VERSION_SETTING);
		}
		return MOBILE_PLATFORM_VERSION_SETTING;
	}
	
	public static String getMobilePlatformNameEnvConfig() {
		if(MOBILE_PLATFORM_NAME_SETTING == null) {
			MOBILE_PLATFORM_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(MOBILE_PLATFORM_NAME_PROP);
			log.info("Environment Config property for " + MOBILE_PLATFORM_NAME_PROP + " is : "+ MOBILE_PLATFORM_NAME_SETTING);
		}
		return MOBILE_PLATFORM_NAME_SETTING;
	}
	
	public static String getMobileDeviceNameEnvConfig() {
		if(MOBILE_DEVICE_NAME_SETTING == null) {
			MOBILE_DEVICE_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(MOBILE_DEVICE_NAME_PROP);
			log.info("Environment Config property for " + MOBILE_DEVICE_NAME_PROP + " is : "+ MOBILE_DEVICE_NAME_SETTING);
		}
		return MOBILE_DEVICE_NAME_SETTING;
	}	
	
	public static String getMobileAndroidAppActivityEnvConfig() {
		if(MOBILE_ANDROID_APP_ACTIVITY_SETTING == null) {
			MOBILE_ANDROID_APP_ACTIVITY_SETTING = TestCaseInit.envConfigProp.getProperty(MOBILE_ANDROID_APP_ACTIVITY_PROP);
			log.info("Environment Config property for " + MOBILE_ANDROID_APP_ACTIVITY_PROP + " is : "+ MOBILE_ANDROID_APP_ACTIVITY_SETTING);
		}
		return MOBILE_ANDROID_APP_ACTIVITY_SETTING;
	}
	
	public static String getMobileAndroidAppPackageEnvConfig() {
		if(MOBILE_ANDROID_APP_PACKAGE_SETTING == null) {
			MOBILE_ANDROID_APP_PACKAGE_SETTING = TestCaseInit.envConfigProp.getProperty(MOBILE_ANDROID_APP_PACKAGE_PROP);
			log.info("Environment Config property for " + MOBILE_ANDROID_APP_PACKAGE_PROP + " is : "+ MOBILE_ANDROID_APP_PACKAGE_SETTING);
		}
		return MOBILE_ANDROID_APP_PACKAGE_SETTING;
	}
	
	public static boolean isMobileAndroidOnTabEnvConfig() {
		if(MOBILE_ANDROID_ON_TAB_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(MOBILE_ANDROID_ON_TAB_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				MOBILE_ANDROID_ON_TAB_SETTING = true;
			}else {
				MOBILE_ANDROID_ON_TAB_SETTING = false;
			}
			String yesOrNo = MOBILE_ANDROID_ON_TAB_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + MOBILE_ANDROID_ON_TAB_PROP + " is : " + yesOrNo);
		}
		return MOBILE_ANDROID_ON_TAB_SETTING;
	}	
	
	public static boolean isMobileOnIOSEnvConfig() {
		if(MOBILE_ON_IOS_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(MOBILE_ON_IOS_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				MOBILE_ON_IOS_SETTING = true;
			}else {
				MOBILE_ON_IOS_SETTING = false;
			}
			String yesOrNo = MOBILE_ON_IOS_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + MOBILE_ON_IOS_PROP + " is : " + yesOrNo);
		}
		return MOBILE_ON_IOS_SETTING;
	}
	
	public static String getMobileIOSDeviceUDIDEnvConfig() {
		if(MOBILE_IOS_DEVICE_UDID_SETTING == null) {
			MOBILE_IOS_DEVICE_UDID_SETTING = TestCaseInit.envConfigProp.getProperty(MOBILE_IOS_DEVICE_UDID_PROP);
			log.info("Environment Config property for " + MOBILE_IOS_DEVICE_UDID_PROP + " is : "+ MOBILE_IOS_DEVICE_UDID_SETTING);
		}
		return MOBILE_IOS_DEVICE_UDID_SETTING;
	}

	public static String getMobileIOSAppEnvConfig() {
		if(MOBILE_IOS_APP_SETTING == null) {
			MOBILE_IOS_APP_SETTING = TestCaseInit.envConfigProp.getProperty(MOBILE_IOS_APP_PROP);
			log.info("Environment Config property for " + MOBILE_IOS_APP_PROP + " is : "+ MOBILE_IOS_APP_SETTING);
		}
		return MOBILE_IOS_APP_SETTING;
	}	
	
// Sauce Lab Settings
	public static boolean isSauceLabForWebEnvConfig() {
		if(SAUCE_LAB_WEB_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_WEB_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				SAUCE_LAB_WEB_SETTING = true;
			}else {
				SAUCE_LAB_WEB_SETTING = false;
			}
			String yesOrNo = SAUCE_LAB_WEB_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + SAUCE_LAB_WEB_PROP + " is : " + yesOrNo);
		}
		return SAUCE_LAB_WEB_SETTING;
	}
	
	public static boolean isSauceLabForMobileEnvConfig() {
		if(SAUCE_LAB_MOBILE_SETTING == null){
			String envConfigSetting = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_MOBILE_PROP);			
			if(VMedixUtils.YES.equalsIgnoreCase(envConfigSetting)){
				SAUCE_LAB_MOBILE_SETTING = true;
			}else {
				SAUCE_LAB_MOBILE_SETTING = false;
			}
			String yesOrNo = SAUCE_LAB_MOBILE_SETTING.booleanValue() ? "YES" : "NO";
			log.info("Environment Config property for " + SAUCE_LAB_MOBILE_PROP + " is : " + yesOrNo);
		}
		return SAUCE_LAB_MOBILE_SETTING;
	}
	
	public static String getSauceLabUserNameEnvConfig() {
		if(SAUCE_LAB_USER_NAME_SETTING == null) {
			SAUCE_LAB_USER_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_USER_NAME_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_USER_NAME_PROP + " is : "+ SAUCE_LAB_USER_NAME_SETTING);
		}
		return SAUCE_LAB_USER_NAME_SETTING;
	}
	
	public static String getSauceLabKeyEnvConfig() {
		if(SAUCE_LAB_KEY_SETTING == null) {
			SAUCE_LAB_KEY_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_KEY_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_KEY_PROP + " is : "+ SAUCE_LAB_KEY_SETTING);
		}
		return SAUCE_LAB_KEY_SETTING;
	}
	
	public static String getSauceLabWebPlatformEnvConfig() {
		if(SAUCE_LAB_WEB_PLATFORM_SETTING == null) {
			SAUCE_LAB_WEB_PLATFORM_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_WEB_PLATFORM_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_WEB_PLATFORM_PROP + " is : "+ SAUCE_LAB_WEB_PLATFORM_SETTING);
		}
		return SAUCE_LAB_WEB_PLATFORM_SETTING;
	}
	
	public static String getSauceLabWebBrowserVersionEnvConfig() {
		if(SAUCE_LAB_WEB_BROWSER_VERSION_SETTING == null) {
			SAUCE_LAB_WEB_BROWSER_VERSION_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_WEB_BROWSER_VERSION_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_WEB_BROWSER_VERSION_PROP + " is : "+ SAUCE_LAB_WEB_BROWSER_VERSION_SETTING);
		}
		return SAUCE_LAB_WEB_BROWSER_VERSION_SETTING;
	}
	
	public static String getSauceLabMobileAppiumVersionEnvConfig() {
		if(SAUCE_LAB_MOBILE_APPIUM_VERSION_SETTING == null) {
			SAUCE_LAB_MOBILE_APPIUM_VERSION_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_MOBILE_APPIUM_VERSION_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_MOBILE_APPIUM_VERSION_PROP + " is : "+ SAUCE_LAB_MOBILE_APPIUM_VERSION_SETTING);
		}
		return SAUCE_LAB_MOBILE_APPIUM_VERSION_SETTING;
	}
	
	public static String getSauceLabMobileDeviceNameEnvConfig() {
		if(SAUCE_LAB_MOBILE_DEVICE_NAME_SETTING == null) {
			SAUCE_LAB_MOBILE_DEVICE_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_MOBILE_DEVICE_NAME_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_MOBILE_DEVICE_NAME_PROP + " is : "+ SAUCE_LAB_MOBILE_DEVICE_NAME_SETTING);
		}
		return SAUCE_LAB_MOBILE_DEVICE_NAME_SETTING;
	}
	
	public static String getSauceLabMobilePlatformVersionEnvConfig() {
		if(SAUCE_LAB_MOBILE_PLATFORM_VERSION_SETTING == null) {
			SAUCE_LAB_MOBILE_PLATFORM_VERSION_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_MOBILE_PLATFORM_VERSION_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_MOBILE_PLATFORM_VERSION_PROP + " is : "+ SAUCE_LAB_MOBILE_PLATFORM_VERSION_SETTING);
		}
		return SAUCE_LAB_MOBILE_PLATFORM_VERSION_SETTING;
	}
	
	public static String getSauceLabMobilePlatformNameEnvConfig() {
		if(SAUCE_LAB_MOBILE_PLATFORM_NAME_SETTING == null) {
			SAUCE_LAB_MOBILE_PLATFORM_NAME_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_MOBILE_PLATFORM_NAME_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_MOBILE_PLATFORM_NAME_PROP + " is : "+ SAUCE_LAB_MOBILE_PLATFORM_NAME_SETTING);
		}
		return SAUCE_LAB_MOBILE_PLATFORM_NAME_SETTING;
	}
	
	public static String getSauceLabAppStorageEnvConfig() {
		if(SAUCE_LAB_APP_STORAGE_SETTING == null) {
			SAUCE_LAB_APP_STORAGE_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_APP_STORAGE_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_APP_STORAGE_PROP + " is : "+ SAUCE_LAB_APP_STORAGE_SETTING);
		}
		return SAUCE_LAB_APP_STORAGE_SETTING;
	}
	
	public static String getSauceLabNewCommandTimeOutEnvConfig() {
		if(SAUCE_LAB_NEW_COMMAND_TIME_OUT_SETTING == null) {
			SAUCE_LAB_NEW_COMMAND_TIME_OUT_SETTING = TestCaseInit.envConfigProp.getProperty(SAUCE_LAB_NEW_COMMAND_TIME_OUT_PROP);
			log.info("Environment Config property for " + SAUCE_LAB_NEW_COMMAND_TIME_OUT_PROP + " is : "+ SAUCE_LAB_NEW_COMMAND_TIME_OUT_SETTING);
		}
		return SAUCE_LAB_NEW_COMMAND_TIME_OUT_SETTING;
	}
}
