package library;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import tests.TestCaseInit;

public class GenericLibWeb extends GenericLib{
	
	
	private static Logger log = Logger.getLogger(GenericLibWeb.class.getName());
	
	/**
	 * This method is used to check the browser
	 * @param	browserType
	 * @return	WebDriver
	 */
	public WebDriver getWebDriver(String browserType) {
		WebDriver driver = null;
		try {
			if (EnvironmentConfigSettings.isSauceLabForWebEnvConfig()) {
				log.info("Execution is beginning on SauceLab");				
				if (browserType.equalsIgnoreCase("firefox")) {
					DesiredCapabilities capability = DesiredCapabilities.firefox();
					capability.setCapability("platform", EnvironmentConfigSettings.getSauceLabWebPlatformEnvConfig());
					capability.setCapability("version", EnvironmentConfigSettings.getSauceLabWebBrowserVersionEnvConfig());
					capability.setCapability("idle-timeout","800");
					capability.setCapability("maxDuration","7200");
					capability.setCapability("commandTimeout","450");
					capability.setCapability("name", TestCaseInit.testCaseName);					
					driver = new RemoteWebDriver(new URL("http://"+EnvironmentConfigSettings.getSauceLabUserNameEnvConfig()+":"+
							   EnvironmentConfigSettings.getSauceLabKeyEnvConfig()+"@ondemand.saucelabs.com:80/wd/hub"), capability);
					log.info("Firefox browser is initiated for Execution");
				} else if (browserType.equalsIgnoreCase("Chrome")) {
					DesiredCapabilities capability = DesiredCapabilities.chrome();
					capability.setCapability("platform", EnvironmentConfigSettings.getSauceLabWebPlatformEnvConfig());
					capability.setCapability("version", EnvironmentConfigSettings.getSauceLabWebBrowserVersionEnvConfig());
					capability.setCapability("idle-timeout","800");
					capability.setCapability("maxDuration","7200");
					capability.setCapability("commandTimeout","450");
					capability.setCapability("name", TestCaseInit.testCaseName);
					driver = new RemoteWebDriver(new URL("http://"+EnvironmentConfigSettings.getSauceLabUserNameEnvConfig()+":"+
								EnvironmentConfigSettings.getSauceLabKeyEnvConfig()+"@ondemand.saucelabs.com:80/wd/hub"), capability);
					log.info("Chrome browser is initiated for Execution");
				} else {
					log.info("Unsupported Browser Selected ");
					TestCaseInit.testCaseStatus = false;
					Assert.fail("Unsupported Browser Selected ");
					throw new Exception("Unsupported Browser is selected ");
				}
				
			} else {
				if (browserType.equalsIgnoreCase("firefox")) {
					FirefoxProfile fp = new FirefoxProfile();
					fp.setPreference("browser.cache.disk.enable", false);
			        fp.setPreference("browser.cache.memory.enable", false);
			        fp.setPreference("browser.cache.offline.enable", false);
			        fp.setPreference("network.http.use-cache", false);
			        fp.setPreference("security.mixed_content.block_active_content", false);
			        fp.setPreference("security.mixed_content.block_display_content", true);
			        if(!StringUtils.equalsIgnoreCase(TestCaseInit.testCaseName, "testNewConsultsPerf")){
			        	fp.setPreference("media.navigator.permission.disabled", true);//camera auto set
			        }
			        //setting to avoid firefox from showing the pop-up for download 
//			        fp.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/msword, application/csv, application/ris, text/csv, image/png, application/pdf, text/html, text/plain, application/zip, application/x-zip, application/x-zip-compressed, application/download, application/octet-stream");
			        fp.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/csv, text/csv, application/pdf");
			        driver = new FirefoxDriver(fp);
					log.info("FireFox browser initiated");
					driver.manage().window().maximize();
					log.info("Browser is Maximized");					
				} else if (browserType.equalsIgnoreCase("Chrome")) {
					System.setProperty("webdriver.chrome.driver",TestCaseInit.chromeDriver);
					ChromeOptions options = new ChromeOptions();
					if(!StringUtils.equalsIgnoreCase(TestCaseInit.testCaseName, "testNewConsultsPerf")){
						options.addArguments("--use-fake-ui-for-media-stream");//camera auto set
					}
					options.addArguments("--disable-extensions");//developer mode extension pop up disabled
					driver = new ChromeDriver(options);
					log.info("Chrome browser initiated");
					driver.manage().window().maximize();
					log.info("Browser is Maximized");				
				} else if (browserType.equalsIgnoreCase("ie")) {
					System.setProperty("webdriver.chrome.driver",TestCaseInit.ieDriver);
					driver = new InternetExplorerDriver();
					log.info("IE browser initiated");
					driver.manage().window().maximize();
					log.info("Browser is Maximized");					
				} else {
					log.info("Unsupported Browser Selected "+ browserType);
					TestCaseInit.testCaseStatus = false;
					Assert.fail("Unsupported Browser selected: "+ browserType);
				}
			}
		} catch (MalformedURLException mue) {
			log.error("Failed to open the browser because of malformed URL: ", mue);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed to open the browser because of malformed URL");
		} catch (Exception exp) {
			log.error("An Exception occurred in getWebDriver: ", exp);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("An Exception occurred in getWebDriver");
		}
		return driver;
	}
	
	/**
	 * This method is used to quit all open drivers closing all associated windows.
	 * Doctor and patient driver is quit and set to null. 
	 * @throws Exception 
	 */
	public void quitAllWebDrivers() throws Exception {	
		//patient driver
		if (TestCaseInit.driverPatient != null && TestCaseInit.driverPatient.getWindowHandle().toString() != null){
			log.info("Closing Patient driver...");
			TestCaseInit.driverPatient.quit();
			TestCaseInit.driverPatient=null;
			log.info("Closed Patient driver!");
		}
		
		//doctor driver
		if (TestCaseInit.driverDoctor != null && TestCaseInit.driverDoctor.getWindowHandle().toString() != null) {
			log.info("Closing Doctor driver...");
			log.info(TestCaseInit.driverDoctor+"is Closing Now....");
			TestCaseInit.driverDoctor.quit();
			TestCaseInit.driverDoctor = null;
			log.info("Closed Doctor driver!");
		}
		
		//doctor admin driver
		if (TestCaseInit.driverAdmin != null && TestCaseInit.driverAdmin.getWindowHandle().toString() != null) {
			log.info("Closing Doctor Admin driver...");
			log.info(TestCaseInit.driverAdmin+"is Closing Now....");
			TestCaseInit.driverAdmin.quit();
			TestCaseInit.driverAdmin = null;
			log.info("Closed Doctor Admin driver!");
		}
		
		//gmail driver
		if (TestCaseInit.driverGmail != null && TestCaseInit.driverGmail.getWindowHandle().toString() != null) {
			log.info("Closing Gmail driver...");
			log.info(TestCaseInit.driverGmail+"is Closing Now....");
			closeDriveWithAlertPopUpIfAny(TestCaseInit.driverGmail);
			TestCaseInit.driverGmail = null;
			log.info("Closed Gmail driver!");
		}
		
		//callRep driver
		if (TestCaseInit.driverCallRep != null && TestCaseInit.driverCallRep.getWindowHandle().toString() != null) {
			log.info("Closing Call Rep driver...");
			log.info(TestCaseInit.driverCallRep+"is Closing Now....");
			closeDriveWithAlertPopUpIfAny(TestCaseInit.driverCallRep);
			TestCaseInit.driverCallRep = null;
			log.info("Closed Call Rep driver!");
		}		
	}	
	
	/**
	 * This method is used to quit an open driver closing all associated windows.
	 * Driver is quit and set to null. 
	 * @throws Exception 
	 */
	public boolean quitAWebDriver(WebDriver driver) throws Exception {	
		boolean closed = false;
		if (driver != null && driver.getWindowHandle().toString() != null){
			log.info("Closing driver...");
			driver.quit();
			driver=null;
			closed = true;
			log.info("Closed driver!");
		}
		return closed;
	}
	
	
	/**
	 * This method is used to close the drivers accepting the alert pop-up if any
	 * @param driver
	 */
	public void closeDriveWithAlertPopUpIfAny(WebDriver driver) throws Exception {
		//if the alert is present, accept it and then close the driver
		try {			
			//handle alert pop up
			WebDriverWait wait = new WebDriverWait(driver, 2);		
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			alert.accept();
			log.info("Alert accepted with text: " + alertText);		
		} catch (TimeoutException toExp){
			log.info("Timed out with No Alert pop");  
		} catch (NoAlertPresentException neExp){
			log.error("Could NOT switch to alert pop up");  
		} catch (Exception exp) {
			throw exp;
		} finally {
			//closing the driver after verifying the alert if any
			try{
				driver.quit();
			} catch (Exception exp){
				log.error("Exception found while closing the driver. Exception: " + exp);
			}
		}
	}
	
    /**
	 * This method  is used  to set Implicit Wait time on a driver
	 * @param	driver
	 */
	public void setImplicitWait(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(TestCaseInit.implicitwait, TimeUnit.SECONDS);
	}
	
    /**
	 * This method is used to explicitly wait until an element with ID is visible  
	 * @param	id 
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception
	 */
	public boolean explicitWaitUntilElementWithIDIsVisible(String id, WebDriver driver) throws Exception {
		boolean visible = false;
		String idLoc = TestCaseInit.webLocatorProp.getProperty(id);
		try {
			log.info("Explicit wait of "+ TestCaseInit.explicitWait + " seconds until the presence of element is located by XPath: "+ idLoc);
			WebDriverWait wait = new WebDriverWait(driver, TestCaseInit.explicitWait);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(idLoc)));
			visible = true;
		} catch(TimeoutException tmExp){
			log.error("Element NOT Visible with id: " + idLoc +" in the given explicit wait time: "+TestCaseInit.explicitWait);					
		} catch (Exception e) {
			throw e;
		}
		return visible;
	}	
	
    /**
	 * This method is used to explicitly wait until an element with Name is visible  
	 * @param	name 
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception
	 */
	public boolean explicitWaitUntilElementWithNameIsVisible(String name, WebDriver driver) throws Exception {
		boolean visible = false;
		String nameLoc = TestCaseInit.webLocatorProp.getProperty(name);
		try {
			log.info("Explicit wait of "+ TestCaseInit.explicitWait + " seconds until the presence of element is located by XPath: "+ nameLoc);
			WebDriverWait wait = new WebDriverWait(driver, TestCaseInit.explicitWait);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(nameLoc)));
			visible = true;
		} catch(TimeoutException tmExp){
			log.error("Element NOT Visible with name: " + nameLoc +" in the given explicit wait time: "+TestCaseInit.explicitWait);					
		} catch (Exception e) {
			throw e;
		}
		return visible;
	}	
		
    /**
	 * This method is used to explicitly wait until an element with XPath is visible  
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception
	 */
	public boolean explicitWaitUntilElementWithXPathIsVisible(String xpathProp, String xpathValue, WebDriver driver) throws Exception {
		boolean visible = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			log.info("Explicit wait of "+ TestCaseInit.explicitWait + " seconds until the presence of element is located by XPath: "+ xpathLoc);
			WebDriverWait wait = new WebDriverWait(driver, TestCaseInit.explicitWait);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathLoc)));
			visible = true;
		} catch(TimeoutException tmExp){
			log.error("Element NOT Visible with XPATH: " + xpathLoc +" in the given explicit wait time: "+TestCaseInit.explicitWait);					
		} catch (Exception e) {
			throw e;
		}
		return visible;
	}	
	
	/**
     * This is used to set the explicit wait condition till the visibility of element
     * @param css
     * @param driver
     * @return boolean
     * @throws Exception
     */
	public boolean explicitWaitUntilElementByCSSIsVisible(String css, WebDriver driver) throws Exception {
		boolean visible = false;
		String cssLoc = TestCaseInit.webLocatorProp.getProperty(css);
		try {
			log.info("Explicit wait of "+ TestCaseInit.explicitWait + " seconds until the presence of element is located by CSS: "+ cssLoc);
			WebDriverWait wait = new WebDriverWait(driver, TestCaseInit.explicitWait);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(cssLoc)));		
			visible = true;
		}  catch(TimeoutException tmExp){
			log.error("Element NOT Visible by CSS: " + cssLoc +" in the given explicit wait time: "+TestCaseInit.explicitWait);					
		} catch (Exception e) {
			throw e;
		}
		return visible;
	}
	
	/**
	 * This method is used to get text of html body
	 * @param	driver
	 * @return	String
	 * @throws	Exception
	 */
	public String getHtmlBodyTextByXPath(WebDriver driver) throws Exception {
		String fullText = "";
		try {			
			fullText = driver.findElement(By.xpath("/html/body")).getText();	
			log.info("Text Found for html/body");
		} catch (Exception e) {
			throw e;
		}
		return fullText;
	}	

    /**
	 * This method is used to get an element with ID given web locator property or value
	 * @param	idProp		id property to retrieve id value
	 * @param	idVal		actual id value	
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception 
	 */
	public WebElement getElementByID(String idProp, String idVal, WebDriver driver) throws Exception {
		WebElement elem = null;
		String idLoc = idVal;
		try {
			if(StringUtils.isNotBlank(idProp)) {
				idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
			}
			elem = driver.findElement(By.id(idLoc));
			log.info("Element Found with ID: " + idLoc);			
		} catch(NoSuchElementException nse){
			log.error("Element NOT Found with ID: " + idLoc);
		} catch (Exception e) {
			throw e;
		}
		return elem;
	}
	
    /**
	 * This method is used to get an element with unique xpath 
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception 
	 */	
	public WebElement getElementByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception {
		WebElement elem = null;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			elem = driver.findElement(By.xpath(xpathLoc));
			log.info("Element Found with xpath :"+xpathLoc);
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with xpath: " + xpathLoc);				
		} catch (Exception e) {
			throw e;
		}
		return elem;
	}
	
    /**
	 * This method is used to click an element with ID 
	 * @param	idProp
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception 
	 */
	public boolean clickOnElementByID(String idProp, WebDriver driver) throws Exception {
		boolean found = false;
		String idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
		try {
			driver.findElement(By.id(idLoc)).click();
			found = true;
			log.info("Element Found with ID: " + idLoc);			
		} catch(NoSuchElementException nse){
			log.error("Element NOT Found with ID: " + idLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to click an element with ID given web locator property or value
	 * @param	idProp		id property to retrieve id value
	 * @param	idVal		actual id value	
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception 
	 */
	public boolean clickOnElementByID(String idProp, String idVal, WebDriver driver) throws Exception {
		boolean found = false;
		String idLoc = idVal;
		try {
			if(StringUtils.isNotBlank(idProp)) {
				idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
			}
			driver.findElement(By.id(idLoc)).click();
			found = true;
			log.info("Element Found with ID: " + idLoc);			
		} catch(NoSuchElementException nse){
			log.error("Element NOT Found with ID: " + idLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to click an element with Name 
	 * @param	nameProp
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception 
	 */
	public boolean clickOnElementByName(String nameProp, WebDriver driver) throws Exception {
		boolean found = false;
		String nameLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try {
			driver.findElement(By.name(nameLoc)).click();
			found = true;
			log.info("Element Found with name: " + nameLoc);			
		} catch(NoSuchElementException nse){
			log.error("Element NOT Found with name: " + nameLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}

    /**
	 * This method is used to click an element with unique xpath 
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception 
	 */	
	public boolean clickOnElementByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception {
		boolean found = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			driver.findElement(By.xpath(xpathLoc)).click();
			found = true;
			log.info("Element Found with xpath :"+xpathLoc);
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with xpath: " + xpathLoc);				
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to click an Element with class 
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception 
	 */	
	public boolean clickOnElementByClass(String clsLocProp, WebDriver driver) throws Exception {
		boolean found = false;
		String classLoc =  TestCaseInit.webLocatorProp.getProperty(clsLocProp);
		try{
			driver.findElement(By.className(classLoc)).click();
			found = true;
			log.info("Element Found with xpath :"+classLoc);
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with xpath: " + classLoc);				
		} catch (Exception e) {
			throw e;
		}
		return found;
	}	
	
    /**
	 * This method is used to click an Element with link Text
	 * @param	linkTextProp
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception 
	 */
	public boolean clickOnElementByLinkText(String linkTextProp, WebDriver driver) throws Exception {
		boolean found = false;
		String linkTextLoc = TestCaseInit.webLocatorProp.getProperty(linkTextProp);
		try {
			driver.findElement(By.linkText(linkTextLoc)).click(); 
			found = true;
			log.info("Element Found with Link Text: " + linkTextLoc);
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with Link Text: " + linkTextLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}	
	
	/**
	 * This method is used to click an Element with with partial link text
	 * @param	partialLinkTextProp
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception 
	 */
	public boolean clickOnElementByPartialLinkText(String partialLinkTextProp, WebDriver driver) throws Exception{
		boolean found = false;
		String partialLinkTextLoc = TestCaseInit.webLocatorProp.getProperty(partialLinkTextProp);
		try {
			driver.findElement(By.partialLinkText(partialLinkTextLoc)).click(); 
			found = true;
			log.info("Element Found with Partial Link Text: " + partialLinkTextLoc);
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with Partial Link Text: " + partialLinkTextLoc);
		}catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to click an Element with xpath by performing click action 
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception 
	 */	
	public boolean clickOnElementWithActionByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception {
		boolean buttonClicked = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}			
			if (driver.findElements(By.xpath(xpathLoc)).size() != 0) {
				WebElement elementToClick = driver.findElement(By.xpath(xpathLoc));
				Actions actions = new Actions(driver);
				actions.moveToElement(elementToClick).click().perform();
				buttonClicked = true;
				log.info("Element Found with xpath :"+xpathLoc);
			} else {
				log.error("Element NOT found with xpath: " + xpathLoc);	
			}	
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with xpath: " + xpathLoc);				
		} catch (Exception e) {
			throw e;
		}
		return buttonClicked;
	}

    /**
	 * This method is used to click an Element with non-unique xpath. 
	 * If more than one element exists for the same xpath, the first element from the list is selected  
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception 
	 */
	public boolean clickOnElementByCommonXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		boolean found = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			} 
			if (driver.findElements(By.xpath(xpathLoc)).size() != 0) {
				WebElement elementToClick = driver.findElement(By.xpath(xpathLoc)); //picks the first element
				Actions actions = new Actions(driver);
				actions.moveToElement(elementToClick).click().perform();
				found = true;
				log.info("Element Found with XPATH: " + xpathLoc);
			} else {
				log.error("Element NOT found with XPATH: " + xpathLoc);
			}
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with XPATH: " + xpathLoc);				
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to click on a last element with xpath 
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception 
	 */	
	public boolean clickOnLastElementByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception {
		boolean found = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			List<WebElement> elemList = driver.findElements(By.xpath(xpathLoc));			
			if (elemList.size() != 0) {				
				elemList.get(elemList.size()-1).click();
				found = true;
				log.info("Element Found with xpath :"+xpathLoc);			
			} else {
				log.error("Element NOT found with xpath: " + xpathLoc);	
			}
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to locate a radio button by name and click on it by value 
	 * @param	nameProp
	 * @param 	rdBtnValue
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception 
	 */
	public boolean clickRadioButtonByValueWithElementName(String nameProp, String rdBtnValue, WebDriver driver) throws Exception{
		boolean found = false;
		String nameLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try {
			List<WebElement> rdBtnList = driver.findElements(By.name(nameLoc));
			if(! rdBtnList.isEmpty()) {
				for (WebElement rdBtnElem : rdBtnList) {
					if(rdBtnElem.getAttribute("value").equalsIgnoreCase(rdBtnValue)) {
						rdBtnElem.click();
						found = true;
						log.info("Element Found with name: " + nameLoc);
						break;
					}
				}
			} else {
				log.error("Element NOT Found with name: " + nameLoc);
			}
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to locate a radio button by xpath and click on it by value 
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param 	rdBtnValue
	 * @param	driver
	 * @return  boolean
	 * @throws	Exception 
	 */
	public boolean clickRadioButtonByValueWithElementXPath(String xpathProp, String xpathValue, String rdBtnValue, WebDriver driver) throws Exception{
		boolean found = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			List<WebElement> rdBtnList = driver.findElements(By.xpath(xpathLoc));
			if(! rdBtnList.isEmpty()) {
				for (WebElement rdBtnElem : rdBtnList) {
					if(rdBtnElem.getAttribute("value").equalsIgnoreCase(rdBtnValue)) {
						rdBtnElem.click();
						found = true;
						log.info("Element Found with xpath: " + xpathLoc);
						break;
					}
				}
			} else {
				log.error("Element NOT Found with xpath: " + xpathLoc);
			}
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to select from the drop down element by index with ID 
	 * @param	selectIdProp
	 * @param	indexValue
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean selectByIndexValueWithSelectElementID(String selectIdProp, int indexValue, WebDriver driver) throws Exception {
		boolean found = false;
		String selectIdLoc = TestCaseInit.webLocatorProp.getProperty(selectIdProp);
		try {
			Select sel = new Select(driver.findElement(By.id(selectIdLoc)));
			sel.selectByIndex(indexValue);
			found = true;
			log.info("Element found by id: "+selectIdLoc+" and selected index values is: "+ indexValue);
		} catch (NoSuchElementException nse) {
			log.error("Element NOT found by id on Dropdown: "+ selectIdLoc+ " and index value: "+ indexValue);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to select from the drop down element by index with name 
	 * @param	selectNameProp
	 * @param	indexValue
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean selectByIndexValueWithSelectElementName(String selectNameProp, int indexValue, WebDriver driver) throws Exception {
		boolean found = false;
		String selectNameLoc = TestCaseInit.webLocatorProp.getProperty(selectNameProp);
		try {
			Select sel = new Select(driver.findElement(By.name(selectNameLoc)));
			sel.selectByIndex(indexValue);
			found = true;
			log.info("Element found by name: "+selectNameLoc+" and selected index values is: "+ indexValue);
		} catch (NoSuchElementException nse) {
			log.error("Element NOT found by name on Dropdown: "+ selectNameLoc+ " and index value: "+ indexValue);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to select from the drop down element by index with xpath 
	 * @param	selectXPathProp		xpath property to retrieve xpath value
	 * @param 	selectXPathValue	actual xpath value
	 * @param	selectValue
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean selectByIndexValueWithSelectElementXPath(String selectXPathProp, String selectXPathValue, int indexValue, WebDriver driver) throws Exception {
		boolean found = false;
		String selectXPathLoc = selectXPathValue;
		try {
			if(StringUtils.isNotBlank(selectXPathProp)) {
				selectXPathLoc = TestCaseInit.webLocatorProp.getProperty(selectXPathProp);
			} 
			Select sel = new Select(driver.findElement(By.xpath(selectXPathLoc)));
			sel.selectByIndex(indexValue);
			found = true;
			log.info("Element found by xpath: "+selectXPathLoc+" and selected index values is: "+ indexValue);
		} catch (NoSuchElementException nse) {
			log.error("Element NOT found by xpath on Dropdown: "+ selectXPathLoc+ " and index value: "+ indexValue);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to select value from the drop down element by value with id 
	 * @param	selectIdProp
	 * @param	selectValue
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean selectByValueFromSelectElementID(String selectIdProp, String selectValue, WebDriver driver) throws Exception {
		boolean found = false;
		String selectIdLoc = TestCaseInit.webLocatorProp.getProperty(selectIdProp);
		try{
			Select sel = new Select(driver.findElement(By.id(selectIdLoc)));
			sel.selectByValue(selectValue);
			found = true;
			log.info("Element found by id: "+selectIdLoc+" and selected values is: "+ selectValue);			
		} catch (NoSuchElementException nse) {
			log.error("Element NOT found by id on Dropdown: "+ selectIdLoc+ " and select value: "+ selectValue);		
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to select value from the drop down element by value with name 
	 * @param	selectNameProp
	 * @param	selectValue
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean selectByValueFromSelectElementName(String selectNameProp, String selectValue, WebDriver driver) throws Exception {
		boolean found = false;
		String selectNameLoc = TestCaseInit.webLocatorProp.getProperty(selectNameProp);
		try{
			Select sel = new Select(driver.findElement(By.name(selectNameLoc)));
			sel.selectByValue(selectValue);
			found = true;
			log.info("Element found by xpath: "+selectNameLoc+" and selected values is: "+ selectValue);			
		} catch (NoSuchElementException nse) {
			log.error("Element NOT found by xpath on Dropdown: "+ selectNameLoc+ " and select value: "+ selectValue);		
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to select value from the drop down element by value with xpath 
	 * @param	selectXPathProp		xpath property to retrieve xpath value
	 * @param 	selectXPathValue	actual xpath value
	 * @param	selectValue
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean selectByValueFromSelectElementXPath(String selectXPathProp, String selectXPathValue, String selectValue, WebDriver driver) throws Exception {
		boolean found = false;
		String selectXPathLoc = selectXPathValue;
		try {
			if(StringUtils.isNotBlank(selectXPathProp)) {
				selectXPathLoc = TestCaseInit.webLocatorProp.getProperty(selectXPathProp);
			} 
			Select sel = new Select(driver.findElement(By.xpath(selectXPathLoc)));
			sel.selectByValue(selectValue);
			found = true;
			log.info("Element found by xpath: "+selectXPathLoc+" and selected values is: "+ selectValue);			
		} catch (NoSuchElementException nse) {
			log.error("Element NOT found by xpath on Dropdown: "+ selectXPathLoc+ "and select value: "+ selectValue);		
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
 	/**
	 * This method is used to select visible text from the drop down select element with ID
	 * @param	idProp
	 * @param	visibleText
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean selectByVisibleTextFromSelectElementID(String idProp, String visibleText, WebDriver driver) throws Exception {
		boolean found = false;
		String selectIdLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
		try {			
			WebElement webElmnt = driver.findElement(By.id(selectIdLoc));
			log.info("Element Found with id: " + selectIdLoc);
			Select sel = new Select(webElmnt);
			sel.selectByVisibleText(visibleText);
			found = true;
			log.info("Visible Text Found in dropdown: " + visibleText);
		} catch (NoSuchElementException e) {
			log.error("Visible Text NOT found in dropdown: " + visibleText + " for Element with id: "+ selectIdLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
 	/**
	 * This method is used to select visible text from the drop down select element with name
	 * @param	nameProp
	 * @param	visibleText
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean selectByVisibleTextFromSelectElementName(String nameProp, String visibleText, WebDriver driver) throws Exception {
		boolean found = false;
		String selectNameLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try {			
			WebElement webElmnt = driver.findElement(By.name(selectNameLoc));
			log.info("Element Found with name: " + selectNameLoc);
			Select sel = new Select(webElmnt);
			sel.selectByVisibleText(visibleText);
			found = true;
			log.info("Visible Text Found in dropdown: " + visibleText);
		} catch (NoSuchElementException e) {
			log.error("Visible Text NOT found in dropdown: " + visibleText + " for Element with name: "+ selectNameLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
 	/**
	 * This method is used to select visible text from the drop down select element with xpath
	 * @param	selectXPathProp		xpath property to retrieve xpath value
	 * @param 	selectXPathValue	actual xpath value
	 * @param	visibleText
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean selectByVisibleTextFromSelectElementXPath(String selectXPathProp, String selectXPathValue, String visibleText, WebDriver driver) throws Exception {
		boolean found = false;
		String selectXPathLoc = selectXPathValue;
		try {
			if(StringUtils.isNotBlank(selectXPathProp)) {
				selectXPathLoc = TestCaseInit.webLocatorProp.getProperty(selectXPathProp);
			} 
			WebElement webElmnt = driver.findElement(By.xpath(selectXPathLoc));
			log.info("Element Found with xpath: " + selectXPathLoc);
			Select sel = new Select(webElmnt);
			sel.selectByVisibleText(visibleText);
			found = true;
			log.info("Visible Text Found in dropdown: " + visibleText);
		} catch (NoSuchElementException e) {
			log.error("Visible Text NOT found in dropdown: " + visibleText + " for Element with xpath: "+ selectXPathLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to select first option from the list drop down element by xpath 
	 * @param	listXPathProp	xpath property to retrieve xpath value
	 * @param 	listXPathValue	actual xpath value
	 * @param 	driver
	 * @return 	boolean
	 * @throws 	Exception
	 */
	public boolean selectFirstOptionFromListDropboxByXPath(String listXPathProp, String listXPathValue,  WebDriver driver) throws Exception {		
		boolean foundFirstInLi = false;
		String listXPathLoc = listXPathValue;
		try {
			if(StringUtils.isNotBlank(listXPathProp)) {
				listXPathLoc = TestCaseInit.webLocatorProp.getProperty(listXPathProp);
			} 
			List<WebElement> listOfElems = driver.findElements(By.xpath(listXPathLoc));
			String firstOptText = listOfElems.get(0).getText();
			listOfElems.get(0).click();
			foundFirstInLi = true;
			log.info("Element found by xpath: "+ listXPathLoc + " with text of first option from list drop down: "+ firstOptText);
		} catch (NoSuchElementException nse){
			log.error("Element NOT found by xpath: "+ listXPathLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return foundFirstInLi;
	}
	
	/**
	 * This method is used to mouseOver an element with xpath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean mouseOverElementWithXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		boolean found = true;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			WebElement wb = driver.findElement(By.xpath(xpathLoc));
			log.info("Element for mouse over Found with xpath: " + xpathLoc);
			Actions act = new Actions(driver);
			act.moveToElement(wb).perform();
			found = true;
			log.info("Mouse over action performed on element with xpath: " + xpathLoc);
		} catch (NoSuchElementException nse) {
			log.error("Element for mouse over NOT Found with xpath: " +  xpathLoc);
		} catch (Exception e) {
			throw e;			
		}
		return found;
	}
	
	/**
	 * This method is used to mouseOver an element with linkText
	 * @param	linkTextProp
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean mouseOverElementWithLinkText(String linkTextProp, WebDriver driver) throws Exception{
		boolean found = true;
		String linkTextLoc = TestCaseInit.webLocatorProp.getProperty(linkTextProp);
		try {
			WebElement wb = driver.findElement(By.linkText(linkTextLoc));
			log.info("Element for mouse over Found with link text: " + linkTextLoc);
			Actions act = new Actions(driver);
			act.moveToElement(wb).perform();
			found = true;
			log.info("Mouse over action performed on element with link text: " + linkTextLoc);
		} catch (NoSuchElementException nsee) {
			log.error("Element for mouse over NOT found with link text: " + linkTextLoc);
		} catch (Exception e) {
			throw e;			
		}
		return found;
	}	
	

	/**
	 * This method is used to verify if an element is displayed by xpath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementDisplayedByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		boolean displayed = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			WebElement elem = driver.findElement(By.xpath(xpathLoc));
			if (elem.isDisplayed()) {
				displayed = true;
				log.info("Element is displayed with xpath: "+xpathLoc);				
			} else {
				log.info("Element is NOT displayed with xpath: "+xpathLoc);
			}
		} catch(NoSuchElementException nse){
			log.error("Element not found with xpath: "+ xpathLoc);
		} catch (Exception e) {
			throw e;
		}
		return displayed;
	}
	
	/**
	 * This method is used to verify if an element is enabled by ID
	 * @param	idProp
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementEnabledByID(String idProp, WebDriver driver) throws Exception{
		boolean elemEnabled = false;
		String idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
		try {
			WebElement elem = driver.findElement(By.id(idLoc));
			if (elem.isEnabled()) {
				elemEnabled = true;
				log.info("Element is Enabled with id: "+idLoc);				
			} else {
				log.info("Element is NOT enabled with id: "+idLoc);
			}
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with id: "+ idLoc);
		} catch (Exception e) {
			throw e;
		}
		return elemEnabled;
	}

	
	/**
	 * This method is used to verify if an element is enabled by xpath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementEnabledByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		boolean elemEnabled = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			WebElement elem = driver.findElement(By.xpath(xpathLoc));
			if (elem.isEnabled()) {
				elemEnabled = true;
				log.info("Element is enabled with xpath: "+xpathLoc);				
			} else {
				log.info("Element is NOT enabled with xpath: "+xpathLoc);
			}
		} catch(NoSuchElementException nse){
			log.error("Element not found with xpath: "+ xpathLoc);
		} catch (Exception e) {
			throw e;
		}
		return elemEnabled;
	}

	/**
	 * This method is used to find element by ID
	 * @param	idProp
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByID(String idProp, WebDriver driver) throws Exception{
		boolean found = false;
		String idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
		try{
			if (driver.findElements(By.id(idLoc)).size()!=0) {
				found = true;
				log.info("Element Found with id: "+ idLoc);
			} else{
				log.error("Element NOT found with id: " + idLoc);
			}
		} catch (NoSuchElementException nsee) {
			log.error("Element NOT found with id: " + idLoc);
		} catch (Exception e) {
			throw e;		
		}
		return found;
	}	
	
	/**
	 * This method is used to find element by Name
	 * @param	nameProp
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByName(String nameProp, WebDriver driver) throws Exception{
		boolean found = false;
		String nameLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try{
			if (driver.findElements(By.name(nameLoc)).size()!=0) {
				found = true;
				log.info("Element Found with name: "+ nameLoc);
			} else{
				log.error("Element NOT found with name: " + nameLoc);
			}
		} catch (NoSuchElementException nsee) {
			log.error("Element NOT found with name: " + nameLoc);
		} catch (Exception e) {
			throw e;		
		}
		return found;
	}
	
	/**
	 * This method is used to find element by XPath 
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		boolean found = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			if (driver.findElements(By.xpath(xpathLoc)).size()!=0) {
				found = true;
				log.info("Element Found with xpath: "+ xpathLoc);
			}else {
				log.error("Element NOT found with xpath: " + xpathLoc);
			} 
		} catch (NoSuchElementException nsee) {
			log.error("Element NOT found with xpath: " + xpathLoc);
		} catch (Exception e) {
			throw e;		
		}
		return found;
	}	
	
	/**
	 * This method is used to find element by Css Selector
	 * @param	cssSelectProp
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByCssSelector(String cssSelectProp, WebDriver driver) throws Exception{
		boolean found = false;
		String cssSelectLoc = TestCaseInit.webLocatorProp.getProperty(cssSelectProp);
		try{
			if (driver.findElements(By.cssSelector(cssSelectLoc)).size()!=0) {
				found = true;
				log.info("Element Found with CSS Selector: "+ cssSelectLoc);
			}
		} catch (NoSuchElementException nsee) {
			log.error("Element NOT found with CSS Selector: " + cssSelectLoc);
		} catch (Exception e) {
			throw e;		
		}
		return found;
	}
	
	/**
	 * This method is used to verify if the Element with Link Text is visible
	 * @param	driver
	 * @param	linkTextProp
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByLinkText(String linkTextProp, WebDriver driver) throws Exception{
		boolean visible = false;
		String linkTextLoc = TestCaseInit.webLocatorProp.getProperty(linkTextProp);
	 	try{
	 		if (driver.findElements(By.linkText(linkTextLoc)).size() != 0) {
	 			visible = true;
	 			log.info("Element Found with link text: " + linkTextLoc);
			} else {
	 			log.error("Element NOT found with link text: " + linkTextLoc);
			}
	 	}catch(Exception e){
 			log.error("Element NOT found with link text: " + linkTextLoc);
 			throw e;
	 	}
	 	return visible;
	 } 
	
	/**
	 * This method is used to find element by XPath 
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementReadOnlyByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		boolean found = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			String readonlyVal = driver.findElement(By.xpath(xpathLoc)).getAttribute("readonly");
			if(!StringUtils.isBlank(readonlyVal)){
				found = Boolean.parseBoolean(readonlyVal);
			} else {
				log.error("Readonly attribute NOT set for Element with xpath: " + xpathLoc);
			}
		} catch (NoSuchElementException nse){ 
			log.error("Element NOT Found with xpath: " + xpathLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
	/**
	 * This method is used to retrieve Text from Element by ID
	 * @param	idProp
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getTextByID(String idProp, WebDriver driver) throws Exception{
		String textRetrieved = "";
		String idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
		try {
			textRetrieved = driver.findElement(By.id(idLoc)).getText();
			log.info("Element Found with id: "+ idLoc + " with Text retrieved: " + textRetrieved);
		} catch (NoSuchElementException nse) {
			log.info("Element NOT Found with id: "+ idLoc);
		}catch (Exception e) {
			log.error("Text NOT retrieved for Element with id: "+idLoc);
			throw e;
		}
		return textRetrieved;
	}	
	
	/**
	 * This method is used to retrieve Text from Element by ID given web locator property or value
	 * @param	idProp		id property to retrieve id value
	 * @param	idVal		actual id value	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getTextByID(String idProp, String idValue, WebDriver driver) throws Exception{
		String textRetrieved = "";
		String idLoc = idValue;
		try {
			if(StringUtils.isNotBlank(idProp)) {
				idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
			}
			textRetrieved = driver.findElement(By.id(idLoc)).getText();
			log.info("Element Found with id: "+ idLoc + " with Text retrieved: " + textRetrieved);
		} catch (NoSuchElementException nse) {
			log.info("Element NOT Found with id: "+ idLoc);
		}catch (Exception e) {
			log.error("Text NOT retrieved for Element with id: "+idLoc);
			throw e;
		}
		return textRetrieved;
	}	
	
	/**
	 * This method is used to retrieve Text from Element by Name
	 * @param	nameProp
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getTextByName(String nameProp, WebDriver driver) throws Exception{
		String textRetrieved = "";
		String nameLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try {
			textRetrieved = driver.findElement(By.name(nameLoc)).getText();
			log.info("Element Found with name: "+ nameLoc + "with Text retrieved: "+textRetrieved);
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with name: "+ nameLoc);
		}catch (Exception e) {
			log.error("Text NOT retrieved for Element with name: "+nameLoc);
			throw e;
		}
		return textRetrieved;
	}

	/**
	 * This method is used to retrieve Text from Element by XPath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getTextByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		String textRetrieved = "";
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			if (driver.findElements(By.xpath(xpathLoc)).size() != 0) {
				log.info("Element Found with xpath: "+xpathLoc);
				textRetrieved = driver.findElement(By.xpath(xpathLoc)).getText();
				log.info("Text retrieved: "+textRetrieved);
			} else {
				log.error("Text NOT retrieved for Element with xpath: "+ xpathLoc);
			}
		} catch (Exception e) {
			log.error("Text NOT retrieved for Element with xpath: "+ xpathLoc);
			throw e;
		}
		return textRetrieved;
	}
	
	/**
	 * This method is used to retrieve Text from Element by cssSelector
	 * @param	cssSelectorProp
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getTextByCssSelector(String cssSelectorProp, WebDriver driver) throws Exception{
		String textRetrieved = "";
		String cssSelectLoc = TestCaseInit.webLocatorProp.getProperty(cssSelectorProp);
		try {
			textRetrieved = driver.findElement(By.cssSelector(cssSelectLoc)).getText();
			log.info("Element Found with cssSelector: "+ cssSelectLoc + " with Text retrieved: "+textRetrieved);
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with cssSelector: "+cssSelectLoc );
		} catch (Exception e) {
			log.error("Text NOT retrieved for Element with cssSelector: "+cssSelectLoc);
			throw e;
		}
		return textRetrieved;
	}
	
	/**
	 * This method is used to retrieve Text from Element by Tag
	 * @param	tagProp
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getTextByTag(String tagProp, WebDriver driver) throws Exception{
		String textRetrieved = "";
		String tagLoc= TestCaseInit.webLocatorProp.getProperty(tagProp);
		try {			
			textRetrieved = driver.findElement(By.tagName(tagLoc)).getText();
			log.info("Element Found with tag: "+ tagLoc + " with Text retrieved: "+textRetrieved);
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with tag: "+ tagLoc);
		} catch (Exception e) {
			log.error("Text NOT retrieved for Element with tag: "+tagLoc);
			throw e;
		}
		return textRetrieved;
	}
	
	/**
	 * This method is used to retrieve Text from Last Element by XPath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getTextOfLastElementByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		String textRetrieved = "";
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}			
			List<WebElement> elemList = driver.findElements(By.xpath(xpathLoc));
			if(elemList.size() != 0){
				log.info("Element Found with xpath: "+xpathLoc);
				textRetrieved = elemList.get(elemList.size()-1).getText();
				log.info("Text from last element retrieved: "+textRetrieved);
			} else {
				log.error("Text NOT retrieved for Element with xpath: "+ xpathLoc);
			}
		} catch (Exception e) {
			log.error("Text NOT retrieved for Element with xpath: "+ xpathLoc);
			throw e;
		}
		return textRetrieved;
	}
	
	/**
	 * This method is used to retrieve Text of a selected option from a dropdown by ID
	 * @param	selectIdProp
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getSelectOptionTextBySelectElementID(String selectIdProp, WebDriver driver) throws Exception{
		String textRetrieved = "";
		String selectIdLoc = TestCaseInit.webLocatorProp.getProperty(selectIdProp);
		try {
			Select sel = new Select(driver.findElement(By.id(selectIdLoc)));
			textRetrieved = sel.getFirstSelectedOption().getText();
			log.info("Element Found with id: "+selectIdLoc + " with Text retrieved: " + textRetrieved);
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with id: "+selectIdLoc);
		} catch (Exception e) {
			log.error("Text NOT retrieved for Element with id: "+ selectIdLoc);
			throw e;
		}
		return textRetrieved;
	}
	
	/**
	 * This method is used to retrieve Text of a selected option from a dropdown by Name
	 * @param	selectNameProp
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getSelectOptionTextBySelectElementName(String selectNameProp, WebDriver driver) throws Exception{
		String textRetrieved = "";
		String selectNameLoc = TestCaseInit.webLocatorProp.getProperty(selectNameProp);
		try {
			Select sel = new Select(driver.findElement(By.name(selectNameLoc)));
			textRetrieved = sel.getFirstSelectedOption().getText();
			log.info("Element Found with name: "+selectNameLoc + " with Text retrieved: " + textRetrieved);
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with name: "+selectNameLoc);
		} catch (Exception e) {
			log.error("Text NOT retrieved for Element with name: "+ selectNameLoc);
			throw e;
		}
		return textRetrieved;
	}
	
    /**
	 * This method is used to select first option from the drop down element by xpath 
	 * @param	selectXPathProp		xpath property to retrieve xpath value
	 * @param 	selectXPathValue	actual xpath value
	 * @param 	driver
	 * @return 	String text; An empty string if option NOT found
	 * @throws 	Exception
	 */
	public String getFirstOptionFromSelectDropboxByXPath(String selectXPathProp, String selectXPathValue, WebDriver driver) throws Exception {		
		String firtsOptionText = "";
		String selectXPathLoc = selectXPathValue;
		try {
			if(StringUtils.isNotBlank(selectXPathProp)) {
				selectXPathLoc = TestCaseInit.webLocatorProp.getProperty(selectXPathProp);
			} 
			Select select = new Select((driver.findElement(By.xpath(selectXPathLoc))));
			firtsOptionText = select.getFirstSelectedOption().getText();
			log.info("Element found by xpath: "+ selectXPathLoc + " with text of first option from drop down: "+ firtsOptionText);
		} catch (NoSuchElementException nse){
			log.error("Element NOT found by xpath: "+ selectXPathLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return firtsOptionText;
	}
	
	/**
	 * This method is used to retrieve select Option by select element name
	 * @param	selectNameProp
	 * @param	driver	
	 * @return	List<WebElement>; null if empty
	 * @throws	Exception
	 */
	public List<WebElement> getDropDownSelectOptionsByName(String selectNameProp, WebDriver driver) throws Exception {
		List<WebElement> selOptions = null;
		String selectNameLoc = TestCaseInit.webLocatorProp.getProperty(selectNameProp);
		try {
			Select select = new Select((driver.findElement(By.name(selectNameLoc))));
			selOptions = select.getOptions();
			if(selOptions.isEmpty()){
				selOptions = null;
			}
		} catch (NoSuchElementException nse){
			log.error("Element NOT found by xpath: "+ selectNameLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return selOptions;
	}
	
	/**
	 * This method is used to enter Text into text field element by ID
	 * @param 	idProp	
	 * @param	enterText
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean enterTextValueByID(String idProp, String enterText, WebDriver driver) throws Exception{
		boolean textEntered = false;
		String idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
		try {
			WebElement webElem = driver.findElement(By.id(idLoc));
			webElem.clear();
			webElem.sendKeys(enterText);
			textEntered = true;
			log.info("Text Element Found with id: " + idLoc+ " and the value entered into Text box: "+ enterText);
		} catch(NoSuchElementException nse ){
			log.error("Text Element NOT found with id: " + idLoc);
		} catch (Exception e) {
			log.error("Text Element NOT found with id: " + idLoc);
			throw e;
		}
		return textEntered;
	}
	
	/**
	 * This method is used to enter Text into text field element by Name
	 * @param 	nameProp	
	 * @param	enterText
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean enterTextValueByName(String nameProp, String enterText, WebDriver driver) throws Exception{
		boolean textEntered = false;
		String nameLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try {
			WebElement webElem = driver.findElement(By.name(nameLoc));
			webElem.clear();
			webElem.sendKeys(enterText);
			textEntered = true;
			log.info("Text Element Found with name: " + nameLoc+ " and the value entered into Text box: "+ enterText);
		} catch (NoSuchElementException nse){
			log.error("Text Element NOT found with name: " + nameLoc);
		} catch (Exception e) {
			log.error("Text Element NOT found with name: " + nameLoc);
			throw e;
		}
		return textEntered;
	}
	
	/**
	 * This method is used to enter Text into text field element by XPath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	enterText
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean enterTextValueByXPath(String xpathProp, String xpathValue, String enterText, WebDriver driver) throws Exception{
		boolean textEntered = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			if (driver.findElements(By.xpath(xpathLoc)).size() != 0) {				
				WebElement webElem = driver.findElement(By.xpath(xpathLoc));
				webElem.clear();
				webElem.sendKeys(enterText);
				textEntered = true;
				log.info("Text Element Found with xpath: " + xpathLoc+ " and the value entered into Text box: "+ enterText);
			} else {
				log.error("Text Element NOT found with xpath: " + xpathLoc);
			}
		} catch (Exception e) {
			log.error("Text Element NOT found with xpath: " + xpathLoc);
			throw e;
		}
		return textEntered;
	}
	
	/**
	 * This method is used to enter Text into text field element by XPath using Actions
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	enterText
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean enterTextValueWithActionByXPath(String xpathProp, String xpathValue, String enterText, WebDriver driver) throws Exception{
		boolean textEntered = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			if (driver.findElements(By.xpath(xpathLoc)).size() != 0) {				
				WebElement webElem = driver.findElement(By.xpath(xpathLoc));
		        Actions actions = new Actions(driver);
		        actions.moveToElement(webElem);
		        actions.click();
		        actions.sendKeys(enterText);
		        actions.build().perform();
				log.info("Text Element Found with xpath: " + xpathLoc+ " and the value entered into Text box: "+ enterText);
			} else {
				log.error("Text Element NOT found with xpath: " + xpathLoc);
			}
		} catch (Exception e) {
			log.error("Text Element NOT found with xpath: " + xpathLoc);
			throw e;
		}
		return textEntered;
	}
	
	/**
	 * This method is used to enter Text into text field element by CSS Selector
	 * @param	cssSelectProp
	 * @param	enterText
	 * @param	driver	
	 * @return	String
	 * @throws	Exception
	 */
	public boolean enterTextValueByCssSelector(String cssSelectProp, String enterText, WebDriver driver) throws Exception{
		boolean textEntered = false;
		String cssSelectLoc = TestCaseInit.webLocatorProp.getProperty(cssSelectProp);
		try {
			WebElement webElem = driver.findElement(By.cssSelector(cssSelectLoc));
			webElem.clear();
			webElem.sendKeys(cssSelectLoc);
			textEntered = true;
			log.info("Text Element Found with css selector: " + cssSelectLoc+ " and the value entered into Text box: "+ enterText);
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with css selector: " + cssSelectLoc);
		} catch (Exception e) {
			log.error("Element NOT found with css selector: " + cssSelectLoc);
			throw e;
		}
		return textEntered;
	}
	
	/**
	 * This method is used to get list of elements by Name
	 * @param	nameProp
	 * @param	driver	
	 * @return	List<WebElement>
	 * @throws	Exception
	 */
	public List<WebElement> getElementsByName(String nameProp, WebDriver driver) throws Exception{
		List<WebElement> elemList;
		String nameLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try {
			elemList = driver.findElements(By.name(nameLoc));
			log.info("Elements Found with name: " + nameLoc);			
		} catch (Exception e) {
			throw e;
		}
		return elemList;
	}
	
	/**
	 * This method is used to get list of elements by XPath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver	
	 * @return	List<WebElement>
	 * @throws	Exception
	 */
	public List<WebElement> getElementsByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		List<WebElement> elemList;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			elemList = driver.findElements(By.xpath(xpathLoc));
			log.info("Elements Found with name: " + xpathLoc);			
		} catch (Exception e) {
			throw e;
		}
		return elemList;
	}
	
	/**
	 * This method is used to retrieve value from Element by ID
	 * @param	idProp
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getValueByID(String idProp, WebDriver driver) throws Exception{
		String valueRetrieved = "";
		String idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
		try {
			valueRetrieved = driver.findElement(By.id(idLoc)).getAttribute("value");	
			log.info("Element Found with id: "+ idLoc + " with Value retrieved: " + valueRetrieved);			
			if(valueRetrieved == null) {
				valueRetrieved = "";
			}			
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with id: " + idLoc);
		} catch (Exception e) {
			log.error("Value NOT retrieved for Element with id: "+idLoc);
			throw e;
		}
		return valueRetrieved;
	}	
	
	/**
	 * This method is used to retrieve value from Element by Name
	 * @param	nameProp
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getValueByName(String nameProp, WebDriver driver) throws Exception{
		String valueRetrieved = "";
		String nameLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try {
			valueRetrieved = driver.findElement(By.name(nameLoc)).getAttribute("value");	
			log.info("Element Found with name: "+ nameLoc + " with Value retrieved: " + valueRetrieved);			
			if(valueRetrieved == null) {
				valueRetrieved = "";
			}			
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with name: " + nameLoc);
		} catch (Exception e) {
			log.error("Value NOT retrieved for Element with name: "+nameLoc);
			throw e;
		}
		return valueRetrieved;
	}
	
	/**
	 * This method is used to retrieve value from Element by xpath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getValueByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		String valueRetrieved = "";
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			valueRetrieved = driver.findElement(By.xpath(xpathLoc)).getAttribute("value");	
			log.info("Element Found with xpath: "+ xpathLoc + " with Value retrieved: " + valueRetrieved);			
			if(valueRetrieved == null) {
				valueRetrieved = "";
			}			
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with xpath: " + xpathLoc);
		} catch (Exception e) {
			log.error("Value NOT retrieved for Element with xpath: "+xpathLoc);
			throw e;
		}
		return valueRetrieved;
	}
	
	/**
	 * This method is used to retrieve attribute value from Element by id
	 * @param	idProp
	 * @param 	attributeType example: value, href etc
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getAttributeByID(String idProp, String attributeType, WebDriver driver) throws Exception{
		String attributeVal = "";
		String idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
		try {
			attributeVal = driver.findElement(By.id(idLoc)).getAttribute(attributeType);	
			log.info("Element Found with id: "+ idLoc + " for attribute type: "+ attributeType+" and with Value retrieved is: " + attributeVal);			
			if(attributeVal == null) {
				attributeVal = "";
			}			
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with id: " + idLoc+ " for attribute type: "+ attributeType);
		} catch (Exception e) {
			log.error(" Attribute value NOT retrieved for Element with id: "+idLoc+ " and Attribute type: "+ attributeType);
			throw e;
		}
		return attributeVal;
	}
	
	/**
	 * This method is used to retrieve attribute value from Element by xpath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param 	attributeType example: value, href etc
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getAttributeByXPath(String xpathProp, String xpathValue, String attributeType, WebDriver driver) throws Exception{
		String attributeVal = "";
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			attributeVal = driver.findElement(By.xpath(xpathLoc)).getAttribute(attributeType);	
			log.info("Element Found with xpath: "+ xpathLoc + " for attribute type: "+ attributeType+" and with Value retrieved is: " + attributeVal);			
			if(attributeVal == null) {
				attributeVal = "";
			}			
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with xpath: " + xpathLoc+ " for attribute type: "+ attributeType);
		} catch (Exception e) {
			log.error(" Attribute value NOT retrieved for Element with xpath: "+xpathLoc+ " and Attribute type: "+ attributeType);
			throw e;
		}
		return attributeVal;
	}
	
	/**
	 * This method is used to retrieve value of selected element from Radio button list by Name
	 * @param	nameProp
	 * @param	driver	
	 * @return	String; An empty string if NOT found
	 * @throws	Exception
	 */
	public String getValueOfCheckedRadioButtonByName(String nameProp, WebDriver driver) throws Exception{
		String valueRetrieved = "";
		String idLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try {
			List<WebElement> rdBtnList = driver.findElements(By.name(idLoc));
			if(! rdBtnList.isEmpty()) {
				for (WebElement rdBtnElem : rdBtnList) {
					if(rdBtnElem.isSelected()){
						valueRetrieved = rdBtnElem.getAttribute("value");
						break;
					}
				}
				if(valueRetrieved.isEmpty()){
					log.error("NO element is checked for group with id: " + idLoc);
				}
			} else {
				log.error("Radio button list with id: " + idLoc + " is empty");
			}
		} catch (NoSuchElementException nse){ 
			log.error("Element NOT Found with id: " + idLoc);
		} catch (Exception e) {
			throw e;
		}
		return valueRetrieved;
	}
	
	/**
	 * This method is used to retrieve number of elements for a specified xpath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver	
	 * @return	int; 0, if none found
	 * @throws	Exception
	 */
	public int getNumberOfElementsByXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		int numberOfElements = 0;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			numberOfElements = driver.findElements(By.xpath(xpathLoc)).size();	
			log.info("Elements Found with xpath: " + numberOfElements);	
		}catch (Exception e) {
			log.error("Value NOT retrieved for Element with xpath: "+xpathLoc);
			throw e;
		}
		return numberOfElements;
	}
	
	/**
	 * This method is used to scroll to view an element with ID
	 * @param	idProp 
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean scrollToViewElementWithID(String idProp, WebDriver driver) throws Exception{
		boolean elementViewed = false;
		String idLoc = TestCaseInit.webLocatorProp.getProperty(idProp);
		try {	
			WebElement elementToView = driver.findElement(By.id(idLoc));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elementToView);
			elementViewed = true;
			log.info("Scrolled to View element with id: "+ idLoc);		
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with id: " + idLoc);
		} catch (Exception e) {
			log.error("Failed to scroll to view element with id: "+ idLoc);
			throw e;
		}
		return elementViewed;
	}
	
	/**
	 * This method is used to scroll to view an element with Class name
	 * @param	clsProp 
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean scrollToViewElementWithClass(String clsProp, WebDriver driver) throws Exception{
		boolean elementViewed = false;
		String idClass = TestCaseInit.webLocatorProp.getProperty(clsProp);
		try {	
			WebElement elementToView = driver.findElement(By.className(idClass));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elementToView);
			elementViewed = true;
			log.info("Scrolled to View element with class: "+ idClass);		
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with class: " + idClass);
		} catch (Exception e) {
			log.error("Failed to scroll to view element with class: "+ idClass);
			throw e;
		}
		return elementViewed;
	}
	
	/**
	 * This method is used to scroll to view an element with XPath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean scrollToViewElementWithXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		boolean elementViewed = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}		
			WebElement elementToView = driver.findElement(By.xpath(xpathLoc));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elementToView);
			elementViewed = true;
			log.info("Scrolled to View element with xpath: "+ xpathLoc);		
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with xpath: " + xpathLoc);
		} catch (Exception e) {
			log.error("Failed to scroll to view element with xpath: "+ xpathLoc);
			throw e;
		}
		return elementViewed;
	}
	
	/**
	 * This method is used to scroll to view an element with name
	 * @param	nameProp 
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean scrollToViewElementWithName(String nameProp, WebDriver driver) throws Exception{
		boolean elementViewed = false;
		String nameLoc = TestCaseInit.webLocatorProp.getProperty(nameProp);
		try {	
			WebElement elementToView = driver.findElement(By.name(nameLoc));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elementToView);
			elementViewed = true;
			log.info("Scrolled to View element with name: "+ nameLoc);		
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with name: " + nameLoc);
		} catch (Exception e) {
			log.error("Failed to scroll to view element with name: "+ nameLoc);
			throw e;
		}
		return elementViewed;
	}
	
	/**
	 * This method is used to move mouse to the middle of the element with xpath
	 * @param	xpathProp	xpath property to retrieve xpath value
	 * @param 	xpathValue	actual xpath value 
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean moveToElementtWithXPath(String xpathProp, String xpathValue, WebDriver driver) throws Exception{
		boolean movedToElement = false;
		String xpathLoc = xpathValue;
		try {
			if(StringUtils.isNotBlank(xpathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(xpathProp);
			}
			WebElement elementInFocus = driver.findElement(By.xpath(xpathLoc));
			Actions actions = new Actions(driver);
			actions.moveToElement(elementInFocus);
			actions.perform();
			movedToElement = true;
			log.info("Moved mouse to the middle of the element");		
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with xpath: " + xpathLoc);
		} catch (Exception e) {
			log.error("Failed to move mouse to the middle of the element with xpath: "+ xpathLoc);
			throw e;
		}
		return movedToElement;
	}
	
	
	/**
	 * This method is used to move mouse to an offset of an element and click
	 * @param	elemXPathProp	xpath property to retrieve xpath value
	 * @param 	elemXPathValue	actual xpath value 
	 * @param	xOffset	xOffset from the element
	 * @param	yOffset	yOffset from the element
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean moveFromElementNClicktWithXPath(String elemXPathProp, String elemXPathValue, int xOffset, int yOffset, WebDriver driver) throws Exception{
		boolean movedToElement = false;
		String xpathLoc = elemXPathValue;
		try {
			if(StringUtils.isNotBlank(elemXPathProp)) {
				xpathLoc = TestCaseInit.webLocatorProp.getProperty(elemXPathProp);
			}
			WebElement elementInFocus = driver.findElement(By.xpath(xpathLoc));
			Actions actions = new Actions(driver);
			actions.moveToElement(elementInFocus, xOffset, yOffset).click().perform();;
			movedToElement = true;
			log.info("Moved to offset: ("+xOffset+", "+yOffset+") of element with xpath: "+xpathLoc+" and clicked");		
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with xpath: " + xpathLoc);
		} catch (Exception e) {
			log.error("Failed to move to offset: ("+xOffset+", "+yOffset+") of element with xpath: "+xpathLoc);
			throw e;
		}
		return movedToElement;
	}
	
	
	/**
	 * This method is used to drag and drop an element from source to target by ids
	 * @param	sourceIdProp
	 * @param 	targetIdProp
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean dragAndDropElementById(String sourceIdProp, String targetIdProp, WebDriver driver) throws Exception{
		boolean elementMoved = false;
		WebElement srcElem = null;
		WebElement tarElem = null;
		String idSrcLoc = TestCaseInit.webLocatorProp.getProperty(sourceIdProp);
		String idTarLoc = TestCaseInit.webLocatorProp.getProperty(targetIdProp);
		try{
			srcElem = driver.findElement(By.id("publisherStream"));
			tarElem = driver.findElement(By.id("subscriberStream"));
			(new Actions(driver)).dragAndDrop(srcElem, tarElem).perform();
			elementMoved = true;
			log.info("Element is moved from source to target");		
		} catch(NoSuchElementException nse){
			if(srcElem == null) {
				log.error("Element NOT found with id: " + idSrcLoc);
			} else{
				log.error("Element NOT found with id: " + idTarLoc);
			}
		} catch (Exception e) {
			log.error("Failed to move element with id: "+ idSrcLoc +" to target element with id: "+ idTarLoc);
			throw e;
		}
		return elementMoved;
	}
	
	/**
	 * This method is used to drag and drop an element with ID from source to target point
	 * @param	sourceIdProp
	 * @param 	targetX; x offset
	 * @param 	targetY; y offset
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean dragAndDropToTargetPointElementById(String sourceIdProp, String targetX, String targetY, WebDriver driver) throws Exception{
		boolean elementMoved = false;
		WebElement srcElem = null;
		String idSrcLoc = TestCaseInit.webLocatorProp.getProperty(sourceIdProp);
		try{
			srcElem = driver.findElement(By.id("publisherStream"));
			(new Actions(driver)).dragAndDropBy(srcElem, Integer.parseInt(targetX), Integer.parseInt(targetY)).build().perform();
			elementMoved = true;
			log.info("Element is moved from source to target");		
		} catch(NoSuchElementException nse){
			if(srcElem == null) {
				log.error("Element NOT found with id: " + idSrcLoc);
			}
		} catch (Exception e) {
			log.error("Failed to move element with id: "+ idSrcLoc +" to target point: ("+ targetX+", "+ targetY+")");
			throw e;
		}
		return elementMoved;
	}
		
	/**
	 * This method is used to bring browser with window handler to the front
	 * @param	windowHandler 
	 * @param	driver	
	 * @return	boolean
	 * @throws	Exception
	 */
	public void bringBrowserToFront(String windowHandler, WebDriver driver) throws Exception{
		((JavascriptExecutor)driver).executeScript ("alert('Bringing window to front')");
		driver.switchTo().alert().accept();
		driver.switchTo().window(windowHandler);
	}
	
	/**
	 * This method is used to switch focus to the element by class
	 * @param	clsLocProp 
	 * @param	driver	
	 * @throws	Exception
	 */
	public void switchFocusToElementByClass(String clsLocProp, WebDriver driver) throws Exception{
		String classLoc =  TestCaseInit.webLocatorProp.getProperty(clsLocProp);
		try{
			driver.findElement(By.className(classLoc)).click();
			log.info("Element Found with class : " + classLoc);
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with class: " + classLoc);				
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * This method is used to validated expected and actual values
	 * @param	expected
	 * @param	actualXpathProp		xpath property to retrieve xpath value
	 * @param	actualXpathValue	xpath value 
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean validateExpectedWithActualByXPath(String expected, String actualXpathProp, String actualXpathValue, WebDriver driver) throws Exception {
		String actualXpathLoc = actualXpathValue;
		boolean matched = false;
		try {
			if(StringUtils.isNotBlank(actualXpathProp)) {
				actualXpathLoc = TestCaseInit.webLocatorProp.getProperty(actualXpathProp);
			}		
			String actual = driver.findElement(By.xpath(actualXpathLoc)).getText();
			if (expected.equalsIgnoreCase(actual)) {
				matched = true;
				log.info("Expected is: "+expected+ System.lineSeparator() +"Actual is: "+ actual + System.lineSeparator() +"Expected and actual Matched");				
			} else {
				log.error("Expected is: "+expected+ System.lineSeparator() +"Actual is: "+ actual + System.lineSeparator() +"Expected and actual did NOT match");				
			}
		} catch (NoSuchElementException nse){
			log.error("Element NOT found with xpath: "+ actualXpathLoc);				
		} catch (Exception e) {
			log.error("An Exception occurred in validateExpectedWithActualByXPath");
			throw e;
		}
		return matched;
	}
	
	/**
	 * This method is used to validate error message for mandatory fields with click on submit button with xpath.
	 * @param	xpathButtonProp
	 * @param	xpathButtonValue
	 * @param	expectedErrorMessage
	 * @param	xpathActualErrorMessageProp
	 * @param	xpathActualErrorMessageValue
	 * @param	driver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean validateErrorMessageOnMandatoryFieldsWithSubmitByXPath(String xpathButtonProp, String xpathButtonValue, String expectedErrorMessage, String xpathActualErrorMessageProp, String xpathActualErrorMessageValue, WebDriver driver) throws Exception {
		boolean isValidErrMessage = false;
		String xpathButtonLoc = xpathButtonValue;
		String xpathActualErrorMessageLoc = xpathActualErrorMessageValue;		
		try {
			if(StringUtils.isNotBlank(xpathButtonProp)) {
				xpathButtonLoc = TestCaseInit.webLocatorProp.getProperty(xpathButtonProp);
			}
			if(StringUtils.isNotBlank(xpathActualErrorMessageProp)) {
				xpathActualErrorMessageLoc = TestCaseInit.webLocatorProp.getProperty(xpathActualErrorMessageProp);
			}
			
			if (driver.findElements(By.xpath(xpathButtonLoc)).size() != 0) {
				log.info("Button is Present with xpath: "+xpathButtonLoc);
				driver.findElement(By.xpath(xpathButtonLoc)).click();
				log.info("Button is Clicked with xpath: "+xpathButtonLoc);
				String actualErrMsg = driver.findElement(By.xpath(xpathActualErrorMessageLoc)).getText();
				if (actualErrMsg.equalsIgnoreCase(expectedErrorMessage)) {
					isValidErrMessage = true;
					log.info("Expected is: "+expectedErrorMessage+ System.lineSeparator() +"Actual is: "+actualErrMsg+ System.lineSeparator() +"Expected and actual error message Matched");
				} else {
					log.info("Expected is: "+expectedErrorMessage+ System.lineSeparator() +"Actual is: "+actualErrMsg+ System.lineSeparator() +"Expected and actual error message did NOT match");
				}
			} else {
				log.error("Button is NOT present with xpath: "+ xpathButtonLoc);
			}
		} catch (Exception e) {
			log.error("An Exception occurred in validateExpectedErrorMessageOnMandatoryFieldsWithSubmitByXPath");
			throw e;
		}
		return isValidErrMessage;
	}
	
	/**
	 * This method is used to validate expected with actual strings
	 * @param	expected
	 * @param	actual
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean validateExpectedWithActual(String expected, String actual) throws Exception {
		boolean matched = false;
		try {
			if (expected.equalsIgnoreCase(actual)) {
				matched = true;
				log.info("Expected is: "+expected+ System.lineSeparator() +"Actual is: "+actual+ System.lineSeparator() +"Expected and actual Matched");
			} else {
				log.error("Expected is: "+expected+ System.lineSeparator() +"Actual is: "+actual+ System.lineSeparator() +"Expected and actual did NOT match");
			}
		} catch (Exception e) {
			log.error("An Exception occurred in validateExpectedAndActual");
			throw e;
		}
		return matched;
	}
}
