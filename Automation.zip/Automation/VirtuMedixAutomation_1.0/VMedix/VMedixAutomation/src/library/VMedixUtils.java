package library;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import tests.TestCaseInit;

public final class VMedixUtils {
	
	public static final String YES = "YES";
	public static final String NO = "NO";
	public static final String NONE = "None";
	public static final String NOT_APPLICABLE_NAN = "NAN";
	
	public static final String TEST_TYPE_SMOKE = "Smoke";
	public static final String TEST_TYPE_REGRESSION = "Regression";
	public static final String TEST_TYPE_PERFORMANCE = "Performance";	
	
	public static final String TEST_CASE_TYPE_MOBILE = "mobile";	
	
	public static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	public static final int DYNAMIC_CHARS_LENGTH = 3;
	
	//vmedix user types
	public static final String USERTYPE_DOCTOR = "doctor";
	public static final String USERTYPE_PATIENT = "patient";
	public static final String USERTYPE_CALLREP = "callrep";
	public static final String USERTYPE_DOCTORADMIN = "doctor_admin";
	public static final String USERTYPE_CALLREPADMIN = "callrep_admin";
	
	//browser Types
	public static final String BROWSER_TYPE_CHROME = "chrome";
	public static final String BROWSER_TYPE_FIREFOX = "firefox";
	
	//credit card
	public static final String CREDIT_CARD_NUMBER = "4242424242424242";
	public static final String CREDIT_CARD_CVC_3DIGIT = "123";
	public static final String CREDIT_CARD_CVC_4DIGIT = "1234";
	
	//self pay
	public static final String ZERO_CONSULTATION_PAY = "0.00";
	
	//alcohol
	public static final String ALCOHOL_OCCASIONALLY = "Occasionally";
	public static final String ALCOHOL_NEVER = "Never";
	public static final String ALCOHOL_DAILY = "Daily";
	
	//Notify doc Methods
	public enum NotifyDoctorMethod {
		TEXT_ME, CALL_ME, NO_THANKS, CONTINUE
	}
	
	//Patient Photos
	public static final int PHOTO_LIMIT = 6;
	
	//Chat messages
	public static final String MESSAGE1_FROM_PAT = "Hi, Doctor";
	public static final String RESPONSE1_FROM_DOC = "Hi Patient, What would you like to discuss today?";
	public static final String MESSAGE2_FROM_PAT = "I have high temperature and has been 104 since sometime";
	public static final String RESPONSE2_FROM_DOC = "Take a cold bath! ... you do not need a doctor ;)";
	
	//profile photo
	public static final String DEFAULT_PROFILE_PHOTO_IMG_SRC = "images/avatar-guest.png";
	
	//non-existing Diagnosis code suffix
	public static final String NON_EXISTING_DIAGNOSIS_CODE_SUFFIX = ":General";
	
	//H&P template selects
	public static final String NON_SOAP_HnP_TEMPLATE = "Adult Back Pain";
	public static final String SOAP_HnP_TEMPLATE = "SOAP Note";
	
	//D&D dummyfile upload
	public static final String DUMMY_FILE_RELATIVE_PATH ="\\Test_Data\\DUMMY.pdf";
	
	//new dependent required field
	public static final int NEW_DEPENDENT_REQUIRED_NUMBER_OF_FIElDS = 9;
	
	//Admin H&P Template 	
	public static final String HnP_TEMPLATE_HEADER_ORIGINAL = "Patient Information";
	
	//Refund Status
	public static final String REFUND_STATUS_PENDING = "pending";
	public static final String REFUND_STATUS_APPROVED = "approved";
	public static final String REFUND_STATUS_REJECTED = "rejected";
	public static final String REFUND_STATUS_SUCCESS = "success";
	
	//Consultation Summary Includes
	public static final String CONSULT_SUMM_REP_INCLUDE_HnP = "H&P";
	public static final String CONSULT_SUMM_REP_INCLUDE_STATE = "State";
	public static final String CONSULT_SUMM_REP_INCLUDE_DIAGNOSIS = "Diagnosis";
	
	//Facilitated Patient Consultation States
	public static final String FAC_PAT_PRE_CHECK_IN = "Pre-Check in";
	public static final String FAC_PAT_IN_QUEUE = "In-Queue";
	public static final String FAC_PAT_WAITING = "Doctor waiting";
	public static final String FAC_PAT_IN_CONSULT = "In-Consult";
	
	private static Logger log = Logger.getLogger(VMedixUtils.class.getName());
	
	private VMedixUtils(){	} //Avoid instantiation
	
	/**
	 * This method is used to get Current System Date and Time: EEEE dd-MM-yyy 'at' hh:mm:ss a zzz
	 * @return	String
	 */
	public static String getSystemTime() {
	      Calendar cal = Calendar.getInstance();
	      SimpleDateFormat sdf = new SimpleDateFormat("EEEE dd-MM-yyy 'at' hh:mm:ss a zzz");
	      String strDate = sdf.format(cal.getTime());
	      return strDate;
	}
	
	/**
	 * This method is used to generate the current date
	 * @param Format
	 * @return String
	 */
	public static String getCurrentDate(String Format) {
		DateFormat dateFormat = new SimpleDateFormat(Format);
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	/**
	 * This method is used to create random string with alphabets of length 3
	 * @return	String
	 */
	public static String generateRandomStringForName() {
		int length = 3;
	    boolean useLetters = true;
	    boolean useNumbers = false;
	    String name = RandomStringUtils.random(length, useLetters, useNumbers); 
	    log.info(name);
	    return name;
	}
	
	/**
	 * This method is used to generate Dynamic string
	 * @return	String
	 */
	public static String generateDynamicString() {
		StringBuffer randStr = new StringBuffer();
		for (int i = 0; i < DYNAMIC_CHARS_LENGTH; i++) {
			char ch = CHAR_LIST.charAt(getRandomNumber());
			randStr.append(ch);
		}
		return randStr.toString();
	}
	
	// Method used to get the Random Number to generate a dynamic string
	private static int getRandomNumber() {
		int randomInt = 0;
		Random randomGenerator = new Random();
		randomInt = randomGenerator.nextInt(CHAR_LIST.length());
		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}
	}	
	
	/**
	 * This method is used to generate a valid email adding characters to a specified email  
	 * @param	origEmail
	 * @param	dynChars
	 * @return	String
	 */
	public static String generateEmailId(String origEmail, String dynChars) {	
	    String generatedEmail = null;
		int charLocation = origEmail.indexOf("@");
		String emailBegin = origEmail.substring(0,charLocation);
	    String emailEnd = origEmail.substring(charLocation);
	    if(emailBegin.contains("+")){
	    	generatedEmail = emailBegin + dynChars + emailEnd;
	    } else {
	    	generatedEmail = emailBegin + "+" + dynChars + emailEnd;
	    }
	    return generatedEmail;
	}		
	
	/**
	 * This method is returns the Current Working Dirctory 
	 * @return 
	 * @return: Current Working Directory
	 */
	public static Path returnCurrentWorkingDirectoryPath() {
		Path path = Paths.get(System.getProperty("user.dir"));
		Path CWD;
		String temp = System.getProperty("user.dir");
		int var = temp.indexOf("bin" );
		if (var>=0){
			CWD = path.getParent().getParent().getParent();
		}
		else{
			CWD = path.getParent().getParent();
		}
		return CWD;
	}
		
	/**
	 * This method is used  to Move old reports to Archive
	 * @param :  String  Archive folder location
	 */
	public static void moveOldReportToArchive() {
		File dir = new File(TestCaseInit.Current_Directory+"/Results/XSLT_Report/");
		File[] foundFiles = dir.listFiles(new FilenameFilter() {
		    public boolean accept(File dir, String name) {
		        return name.startsWith("testng-xslt_");
		    }
		});	
		for (File file : foundFiles) {
			String file_path = file.toString();
			String folder_name = file_path.substring(file_path.lastIndexOf('\\') + 1).trim();
			File source = new File(TestCaseInit.Current_Directory+"/Results/XSLT_Report/"+folder_name);
			try {
				new File(TestCaseInit.Current_Directory+"/Results/XSLT_Report/Archive/"+folder_name).mkdir();
				File dest = new File(TestCaseInit.Current_Directory+"/Results/XSLT_Report/Archive/"+folder_name);
			    FileUtils.copyDirectory(source, dest);
			    File source_delete = new File(TestCaseInit.Current_Directory+"/Results/XSLT_Report/"+folder_name);
			    FileUtils.deleteDirectory(source_delete);
			} catch (Exception e) {
				log.error("An Exception occurred in moveOldReportToArchive", e);
			}
		}
	}
	
	/**
	 * Method to read data from PDF 
	 */
	public static String readPDF(String PDF_Location) {
	    PDFParser parser = null;
	    PDDocument pdDoc = null;
	    COSDocument cosDoc = null;
	    PDFTextStripper pdfStripper;

	    String parsedText;
	    String fileName = PDF_Location;
	    File file = new File(fileName);
	    try {
	        parser = new PDFParser(new FileInputStream(file));
	        parser.parse();
	        cosDoc = parser.getDocument();
	        pdfStripper = new PDFTextStripper();
	        pdDoc = new PDDocument(cosDoc);
	        parsedText = pdfStripper.getText(pdDoc);
	        return parsedText;
	    } catch (Exception e) {
	        e.printStackTrace();
	        try {
	            if (cosDoc != null)
	                cosDoc.close();
	            if (pdDoc != null)
	                pdDoc.close();
	        } catch (Exception e1) {
	            e.printStackTrace();
	        }
	        return "PDF NOT FOUND";
	    }
	}
	
	/**
	 * Method to read data PDF file given the url
	 * @throws Exception 
	 * @returns String 
	 */
	public static String readPDFDataFromUrl(String pdfUrl) throws Exception {
		PDFTextStripper pdfStripper = null;
		PDDocument pdDoc = null;
		COSDocument cosDoc = null;
		String parsedText = null;		
		try {
			URL url = new URL(pdfUrl);
			BufferedInputStream file = new BufferedInputStream(url.openStream());
			PDFParser parser = new PDFParser(file);
			
			parser.parse();
			cosDoc = parser.getDocument();
			pdfStripper = new PDFTextStripper();
			pdDoc = new PDDocument(cosDoc);
			parsedText = pdfStripper.getText(pdDoc);
		} catch (Exception e) {
			throw new Exception("Could not read data from url: "+ pdfUrl);
		} finally{
			if (cosDoc != null)
				cosDoc.close();
			if (pdDoc != null)
				pdDoc.close();
		}
		return parsedText;
	}
	
	
	/**
	 * Method to read data from csv file
	 */
	public static String readCSV(String csvLocation) throws Exception{
		CSVReader reader = null;
		StringBuilder sb = null;
		try {
			reader = new CSVReader(new FileReader(csvLocation));
			List<String[]> allRows = reader.readAll();
			sb = new StringBuilder();
			for(String[] row : allRows){							    	 
				sb.append(Arrays.toString(row));				
			}
			return sb.toString();				
		} catch (Exception e) {
			throw new Exception("Could not read csv file under the location: "+ csvLocation);
		} finally{
			if(reader != null){
				reader.close();
			}
		}
	}
	
	/**
	 * Method to write a line of data to csv file
	 */
	public static void writeIntoCSVFile(String csvFile, String[] dataEntry) throws Exception {
		CSVWriter writer = null;
		try {
			//writer = new CSVWriter(new FileWriter(csvFile), ',', CSVWriter.NO_QUOTE_CHARACTER);
			writer = new CSVWriter(new FileWriter(csvFile));
			List<String[]> data = new ArrayList<String[]>();
			data.add(dataEntry);		
			writer.writeAll(data);
			log.info("Successfully written into csv file: "+ csvFile);
		} catch (Exception e) {
			throw new Exception("Failed to write into csv file: " + csvFile);
		}finally{
			if(writer != null){
				writer.close();
			}
		}		
	}
	
	public static void verifyDatesNIncludesInCSV(String expectedFilename, String startDate, String endDate, String hnp, String state, String diagnosis) throws Exception {
		//Verify if the file exists in the default location
		String defDownloadLoc = getDefaultDownloadLocation();
		String latestFileInLoc = getLatestFilefromDir(defDownloadLoc);
	    if (latestFileInLoc == null || latestFileInLoc.isEmpty() || !latestFileInLoc.contains(FilenameUtils.removeExtension(expectedFilename))) {// there could be copies if run more than ones
			throw new Exception("File "+ expectedFilename + " NOT found at location : " + defDownloadLoc);
	    } 
	    log.info("File "+latestFileInLoc+ " Found at location : " + defDownloadLoc);
	    //Read the file with absolute path to verify the expected dates are present
		String csvContent = readCSV(defDownloadLoc + latestFileInLoc);
		if(StringUtils.isBlank(csvContent)){
			throw new Exception("File "+ latestFileInLoc + " is Blank. Please verify if any consultations exist between the dates specified: " + startDate + " - " + endDate);
		}
		//start date
		if(csvContent.contains(startDate)){
			log.info("File "+ latestFileInLoc + " contains Start date for the report custome dates specified: " + startDate + " - " + endDate);
		}else{
			log.info("File "+ latestFileInLoc + " does NOT contain Start date for the report custome dates specified: " + startDate + " - " + endDate);
		}
		//end date
		if(csvContent.contains(endDate)){
			log.info("File "+ latestFileInLoc + " contains End date for the report custome dates specified: " + startDate + " - " + endDate);
		}else{
			log.info("File "+ latestFileInLoc + " does NOT contain End date for the report custome dates specified: " + startDate + " - " + endDate);
		}
		//includes
		if(!StringUtils.containsIgnoreCase(csvContent, hnp)){
			throw new Exception("File "+ latestFileInLoc + " does NOT contain: " +hnp);
		}
		log.info("File "+ latestFileInLoc + " Contains: " +hnp);
		
		if(!StringUtils.containsIgnoreCase(csvContent, state)){
			throw new Exception("File "+ latestFileInLoc + " does NOT contain: " +state);
		}
		log.info("File "+ latestFileInLoc + " Contains: " +state);
		
		if(!StringUtils.containsIgnoreCase(csvContent, diagnosis)){
			throw new Exception("File "+ latestFileInLoc + " does NOT contain: " +diagnosis);
		}
		log.info("File "+ latestFileInLoc + " Contains: " +diagnosis);
	}
	
	//* Get the latest file from a specific directory
	private static String getLatestFilefromDir(String dirLoc){
		File dir = new File(dirLoc);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) {
	        return null;
	    }
	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	       }
	    }
	    return lastModifiedFile.getName();
	}
	
	private static String getDefaultDownloadLocation(){
		//TODO: Add DefaultDownloadLocation to properties file
		String defaultDownloadLoc = TestCaseInit.envConfigProp.getProperty("DefaultDownloadLocation");
		if(defaultDownloadLoc == null || defaultDownloadLoc.isEmpty()){
			defaultDownloadLoc = "C:/Users/" + System.getProperty("user.name") + "/Downloads/";
		}
		return defaultDownloadLoc;
	}
	
	/**
	 * This method is used to Alert  Handled 
	 * @param : WebDriver driver instance
	 * @return: boolean
	 */
	public static boolean handleAlert(WebDriver driver) {
		boolean alertpresent = true;
		try{
			Alert alert=driver.switchTo().alert();
			alert.accept();
			alertpresent = true;
		} catch (Exception e) {
			log.info("Alert is not present"+" "+e.toString());
			return false;
		}
		return alertpresent;
	}	
	
	/**
	 * This method is used to Alert  Handled
	 * @param : String commaDelimStr  
	 * @return: boolean
	 */
	public static ArrayList<String> getValuesFromCommaDelimitedText(String commaDelimStr) {
		ArrayList<String> listOfvalues = new ArrayList<String>();
		if(commaDelimStr.contains(",")) {
			listOfvalues.addAll(Arrays.asList(commaDelimStr.split("\\,")));
		}else{
			listOfvalues.add(commaDelimStr);
		}
		return listOfvalues;
	}
	
	/**
	 * This method is used to get new comma delimited String appended with given chars from a old comma delimited String
	 * @param  oldCommaDelimStr ; String 
	 * @param  charsToAppend
	 * @return String 
	 */
	public static String getNewCommaDelimStrWithCharsAppended(String oldCommaDelimStr, String charsToAppend) {
		String newCommaDelimStr = null;
		if(oldCommaDelimStr.contains(",")) {
			String[] listOfvaluesToAdd = oldCommaDelimStr.split("\\,");
			for( String valToAdd :  listOfvaluesToAdd ) {
				if(newCommaDelimStr!=null){
					newCommaDelimStr = newCommaDelimStr +","+valToAdd+charsToAppend;
				}else{
					newCommaDelimStr = valToAdd+charsToAppend;
				}				
			}
		} else{
			newCommaDelimStr = oldCommaDelimStr+charsToAppend;
		}
		return newCommaDelimStr;		
	}
	
	/**
	 * This method is used to get new email with specified characters appended
	 * @param  oldEmail ; String 
	 * @param  charsToAppend
	 * @return String 
	 */
	public static String getEmailWithCharsAppended(String oldEmail, String charsToAppend){
		//split at @
		String[] splitAtEmail = oldEmail.split("\\@");	
		return splitAtEmail[0]+charsToAppend +"@"+splitAtEmail[1];		
	}
}
