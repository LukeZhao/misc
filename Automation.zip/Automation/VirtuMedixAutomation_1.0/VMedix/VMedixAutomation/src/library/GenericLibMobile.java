package library;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import tests.TestCaseInit;

public class GenericLibMobile extends GenericLib {

	private static Logger log = Logger.getLogger(GenericLibMobile.class.getName());
	
	/**
	 * This method  is used for mobile automation and used to instantiate Appium driver 
	 * @return AppiumDriver
	 */
	public AppiumDriver<MobileElement> getAppiumDriver() {
		AppiumDriver<MobileElement> appiumDriver = null;
		try {			
			if (EnvironmentConfigSettings.isSauceLabForMobileEnvConfig()) {
				log.info("Executing framework on SauceLab");
				DesiredCapabilities caps = DesiredCapabilities.android();
				caps.setCapability("appiumVersion", EnvironmentConfigSettings.getSauceLabMobileAppiumVersionEnvConfig());  
				caps.setCapability("deviceName", EnvironmentConfigSettings.getSauceLabMobileDeviceNameEnvConfig());
				caps.setCapability("platformVersion", EnvironmentConfigSettings.getSauceLabMobilePlatformVersionEnvConfig());
				caps.setCapability("autoAcceptAlerts",true);
				caps.setCapability("browserName", "");	
				caps.setCapability("platformName", EnvironmentConfigSettings.getSauceLabMobilePlatformNameEnvConfig());
				caps.setCapability("app",EnvironmentConfigSettings.getSauceLabAppStorageEnvConfig());
				caps.setCapability("newCommandTimeout","360");
				caps.setCapability("idle-timeout","800");
				caps.setCapability("maxDuration","7200");
				caps.setCapability("commandTimeout","450");
				if(TestCaseInit.mobileOnIOS){
					appiumDriver = new IOSDriver<>(new URL("http://"+EnvironmentConfigSettings.getSauceLabUserNameEnvConfig()+":"+EnvironmentConfigSettings.getSauceLabKeyEnvConfig()+"@ondemand.saucelabs.com:80/wd/hub"), caps);
				} else {
					appiumDriver = new AndroidDriver<>(new URL("http://"+EnvironmentConfigSettings.getSauceLabUserNameEnvConfig()+":"+EnvironmentConfigSettings.getSauceLabKeyEnvConfig()+"@ondemand.saucelabs.com:80/wd/hub"), caps);
				}				
				return appiumDriver;
			} else {
				StringBuilder capabilitiesSetStrBldr = new StringBuilder();
				DesiredCapabilities capability = new DesiredCapabilities();
		        capability.setCapability("platformVersion", EnvironmentConfigSettings.getMobilePlatformVersionEnvConfig());
		        capability.setCapability("platformName", EnvironmentConfigSettings.getMobilePlatformNameEnvConfig());
		        capability.setCapability("deviceName", EnvironmentConfigSettings.getMobileDeviceNameEnvConfig());
		        capability.setCapability("newCommandTimeout", "360");
		        capabilitiesSetStrBldr.append(EnvironmentConfigSettings.getMobilePlatformVersionEnvConfig()).append(EnvironmentConfigSettings.getMobilePlatformNameEnvConfig()).append(EnvironmentConfigSettings.getMobileDeviceNameEnvConfig());
		        if (TestCaseInit.mobileOnIOS) {
		        	capability.setCapability("udid", EnvironmentConfigSettings.getMobileIOSDeviceUDIDEnvConfig());
			        capability.setCapability("app", EnvironmentConfigSettings.getMobileIOSAppEnvConfig());
			        log.info("Capabilities set: "+capabilitiesSetStrBldr.append(EnvironmentConfigSettings.getMobileIOSDeviceUDIDEnvConfig()).append(EnvironmentConfigSettings.getMobileIOSAppEnvConfig()).toString());
			        appiumDriver = new IOSDriver<>(new URL(EnvironmentConfigSettings.getMobileAppiumHostEnvConfig()), capability);
				} else {
					capability.setCapability("appActivity",EnvironmentConfigSettings.getMobileAndroidAppActivityEnvConfig());
					capability.setCapability("appPackage", TestCaseInit.androidSrcPkgName);
			        log.info("Capabilities set: "+ capabilitiesSetStrBldr.append(EnvironmentConfigSettings.getMobileAndroidAppActivityEnvConfig()).append(TestCaseInit.androidSrcPkgName).toString());			        
					appiumDriver = new AndroidDriver<>(new URL(EnvironmentConfigSettings.getMobileAppiumHostEnvConfig()), capability);
				}
			}
		} catch (MalformedURLException mue) {
			log.error("Failed get appium browser because of malformed URL", mue);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("Failed get appium browser because of malformed URL");
		} catch (Exception exp) {
			log.error("An Exception occurred in getAppiumDriver: ", exp);
			TestCaseInit.testCaseStatus = false;
			Assert.fail("An Exception occurred in getAppiumDriver: ");
		}
		return appiumDriver;
	}
	
	/**
	 * This method  is used to close mobile App 
	 */
	public void closeMobileApp() {
		//close mobile app
		if (TestCaseInit.appiumStarted  && TestCaseInit.appiumDriver != null) {
			TestCaseInit.appiumDriver.closeApp();
			log.info("App is CLOSED!");
		}		
	}
	
	/**
	 * This method is used to close an open appium driver 
	 */
	public void closeAppiumDriver() {
		if (TestCaseInit.appiumStarted  && TestCaseInit.appiumDriver != null){
			TestCaseInit.appiumDriver.close();
			TestCaseInit.appiumDriver.quit();
			log.info("Closed appium driver!");
		}
	}	
	
	/**
	 * This method is used to hide keyboard visibility on the mobile screen
	 * @param 	appiumDriver
	 * @throws 	Exception
	 */
	public void hideKeyBoardVisibility(AppiumDriver<?> appiumDriver) throws Exception {
		try {
			log.info("Hiding the keyboard visibility for further execution");
			appiumDriver.hideKeyboard();
		} catch (Exception e) {
			throw e;
		}
	}
	
	
//ANDROID
	
    /**
	 * This method is used to explicitly wait until an element with id is visible on Android 
	 * @param	id
	 * @param	appiumDriver
	 * @throws	Exception
	 */
	public void explicitWaitUntilElementByIDIsVisibleOnAndroid(String id, AppiumDriver<?> appiumDriver) throws Exception {
		String idLoc = TestCaseInit.androidSrcPkgName + TestCaseInit.androidLocatorProp.getProperty(id);
		try {
			log.info("Setting Explicit wait of "+ TestCaseInit.explicitWait + " seconds until the presence of element is located by id: "+ idLoc);
			WebDriverWait wait = new WebDriverWait(appiumDriver, TestCaseInit.explicitWait);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(idLoc)));
		} catch(TimeoutException tmExp){
			log.error("Element NOT Visible by ID: " + idLoc +" within the given explicit wait time: "+TestCaseInit.explicitWait);					
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * This method is used to explicitly wait for an extra time until an element with xpath is visible on android
	 * @param id
	 * @param appiumDriver
	 * @throws Exception
	 */
	public void extraExplicitWaitUntilElementByIDIsVisibleOnAndroid(String id, AppiumDriver<?> appiumDriver) throws Exception {
		String idLoc = TestCaseInit.androidSrcPkgName + TestCaseInit.androidLocatorProp.getProperty(id);
		try {
			log.info("Extra explicit wait of "+ TestCaseInit.extraExplicitWait + " seconds until the presence of element is located by id: "+ idLoc);
			WebDriverWait wait = new WebDriverWait(appiumDriver, TestCaseInit.extraExplicitWait);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(idLoc)));
			log.info("Element Found with id: " +idLoc);
		} catch(TimeoutException tmExp){
			log.error("Element NOT Visible by ID: " + idLoc +" within the given extra explicit wait time: "+TestCaseInit.extraExplicitWait);					
		} catch (Exception e) {
			throw e;
		}
	}	
	
	/**
	 * This method is used to hide keyboard visibility on Android mobile screen by tapping
	 * @param 	appiumDriver
	 * @throws 	Exception
	 */
	public void hideKeyBoardVisibilityByXPathWithTapOnAndroid(AppiumDriver<?> appiumDriver) throws Exception {
		String xpathLoc = TestCaseInit.androidLocatorProp.getProperty("HandleHideKeyboardOnConsultationScreen_xpath");
		try {
			log.info("Hiding the keyboard visibility by tapping for further execution");
			Point size = appiumDriver.findElement(By.xpath(xpathLoc)).getLocation();				
			int x = size.getX();				
			int y = size.getY();
			log.info("(x,y): (" +x+","+ y+")");
			TouchAction actions = new TouchAction(appiumDriver);
			actions.tap(x,y).perform();
			log.info("Tap operation is sucessful at point: (" +x+","+ y+") for the element with xpath: "+ xpathLoc);
		} catch (Exception e) {			
			throw e;
		}
	}
	
	/**
	 * This method is used to click on a button with ID on Android
	 * @param 	id
	 * @param 	appiumDriver
	 * @return  boolean
	 * @throws 	Exception
	 */
	public boolean clickOnButtonByIDOnAndroid(String id, AppiumDriver<?> appiumDriver) throws Exception {
		return clickOnBtnByIDForAndroid(TestCaseInit.androidSrcPkgName+TestCaseInit.androidLocatorProp.getProperty(id), appiumDriver );
	}
	
	/**
	 * This method is used to click on a button with ID on Android; Id does NOT include source package
	 * @param 	id
	 * @param 	appiumDriver
	 * @return  boolean
	 * @throws 	Exception
	 */
	public boolean clickOnButtonByIDNoSourcPackageOnAndroid(String id, AppiumDriver<?> appiumDriver) throws Exception {
		return clickOnBtnByIDForAndroid(TestCaseInit.androidLocatorProp.getProperty(id), appiumDriver );
	}
	
	private boolean clickOnBtnByIDForAndroid (String id, AppiumDriver<?> appiumDriver) throws Exception {
		boolean found = false;
		try {
			appiumDriver.findElementById(id).click();
			found = true;
			log.info("Button found with ID: "+id);
		} catch(NoSuchElementException nse){
			log.error("Element NOT found with ID: " + id);				
		}  
		catch (Exception e) {
			throw e;
		}
		return found;
	}
	
    /**
	 * This method is used to click a button with xpath on Android
	 * @param  xpath
	 * @param  appiumDriver
	 * @return boolean 
	 * @throws Exception
	 */	
	public boolean clickOnButtonByXPathOnAndroid(String xpath, AppiumDriver<?> appiumDriver) throws Exception {
		boolean found = false;
		String xpathLoc = TestCaseInit.androidLocatorProp.getProperty(xpath);
		try {
			appiumDriver.findElement(By.xpath(xpathLoc)).click();
			found = true;
			log.info("Element found with XPATH: " + xpathLoc);
		} catch(NoSuchElementException nse){
			log.error("Element NOT Found with XPATH: " + xpathLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}	
	
	/**
	 * This method is used to verify if an element is found by locator: XPath or ID or CssSelector on Android
	 * @param	locator
	 * @param	appiumDriver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByIDOrXPathOrCssSelectorOnAndroid(String locator, AppiumDriver<?> appiumDriver) throws Exception{
		boolean found = false;
		String elementLoc = TestCaseInit.androidLocatorProp.getProperty(locator);
		String elementLocWithSrcPkg = TestCaseInit.androidSrcPkgName + elementLoc;
	 	try{
			if (appiumDriver.findElements(By.id(elementLocWithSrcPkg)).size()!=0) {
				log.info("Element Found by id: "+ elementLocWithSrcPkg);
				found = true;
			} else if (elementLoc.startsWith("//") && appiumDriver.findElements(By.xpath(elementLoc)).size()!=0) {
				log.info("Element Found by xpath: "+ elementLoc);
	 			found = true;
			} else if (appiumDriver.findElements(By.cssSelector(elementLocWithSrcPkg)).size()!=0) {
				log.info("Element Found by css selector: "+ elementLocWithSrcPkg);
				found = true;
			} else{
				log.error("Element NOT found with locator: "+ locator);
			}
	 	} catch (NoSuchElementException nse) {
			log.error("Element NOT found with locator: "+ locator);
		} catch(Exception e){
			throw e;
	 	}
	 	return found;
	 } 	
	
	/**
	 * This method is used to verify if an element is found by ID on Android
	 * @param	id
	 * @param	appiumDriver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByIDOnAndroid(String id, AppiumDriver<?> appiumDriver) throws Exception{
		boolean found = false;
		String idLoc = TestCaseInit.androidSrcPkgName +TestCaseInit.androidLocatorProp.getProperty(id);
	 	try{
			if (appiumDriver.findElements(By.id(idLoc)).size()!=0) {
				log.info("Element Found by id: "+ idLoc);
				found = true;
			} else {
				log.error("Element NOT found by id: "+ idLoc);
			}
	 	} catch (NoSuchElementException nsee) {
			log.error("Element NOT found with locator: "+ idLoc);
		} catch(Exception e){
			throw e;
	 	}
	 	return found;
	 }
	
	/**
	 * This method is used to verify if an element is found by XPath on Android
	 * @param	xpath
	 * @param	appiumDriver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByXPathOnAndroid(String xpath, AppiumDriver<?> appiumDriver) throws Exception{
		boolean found = false;
		String xpathLoc = TestCaseInit.androidLocatorProp.getProperty(xpath);
	 	try{
	 		if (xpathLoc.startsWith("//") && appiumDriver.findElements(By.xpath(xpathLoc)).size()!=0) {
				log.info("Element Found by xpath: "+ xpathLoc);
	 			found = true;
			} else{
				log.error("Element NOT found by xpath: "+ xpathLoc);
			}
	 	} catch (NoSuchElementException nsee) {
			log.error("Element NOT found by xpath: "+ xpathLoc);
		} catch(Exception e){
			throw e;
	 	}
	 	return found;
	 } 
	
	/**
	 * This method is used to verify if an element is found by locator: XPath or ID or CssSelector on Android
	 * @param	cssSelector
	 * @param	appiumDriver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByCssSelectorOnAndroid(String cssSelector, AppiumDriver<?> appiumDriver) throws Exception{
		boolean found = false;
		String cssSelectLoc = TestCaseInit.androidSrcPkgName +TestCaseInit.androidLocatorProp.getProperty(cssSelector); 
	 	try{
	 		if (appiumDriver.findElements(By.cssSelector(cssSelectLoc)).size()!=0) {
				log.info("Element Found by css slector: "+ cssSelectLoc);
				found = true;
			} else{
				log.error("Element NOT found by css selector: "+ cssSelectLoc);
			}
	 	} catch (NoSuchElementException nsee) {
			log.error("Element NOT found by css selector: "+ cssSelectLoc);
		} catch(Exception e){
			throw e;
	 	}
	 	return found;
	 } 
	
	/**
	 * This method is used to get text for an element by id on Android
	 * @param id
	 * @param driver
	 * @return String		An empty string if NOT found
	 * @throws Exception
	 */
	public String getTextByIDOnAndroid(String id, AppiumDriver<?> appiumDriver) throws Exception {
		String textFound = "";
		String idLoc = TestCaseInit.androidSrcPkgName + TestCaseInit.androidLocatorProp.getProperty(id);
		try {
			textFound = appiumDriver.findElement(By.id(idLoc)).getText();
			log.info("Element found with ID :"+ idLoc + " text found: "+ textFound);
		} catch(NoSuchElementException nse) {
			log.error("Element is NOT found with id: "+ idLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return textFound;		
	}
	
	/**
	 * This method is used to get text for an element by xpath on Android
	 * @param 	idxpath
	 * @param 	driver
	 * @return 	String		An empty string if NOT found
	 * @throws 	Exception
	 */
	public String getTextByXPathOnAndroid(String xpath, AppiumDriver<?> appiumDriver) throws Exception {
		String textFound = "";
		String xpathLoc = TestCaseInit.androidLocatorProp.getProperty(xpath);
		try {
			textFound = appiumDriver.findElement(By.xpath(xpathLoc)).getText();
			log.info("Element found with xpath :"+ xpathLoc + " text found: "+ textFound);
		} catch(NoSuchElementException nse) {
			log.error("Element is NOT found with xpath: "+ xpathLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return textFound;		
	}
	
	/**
	 * This method is used to enter text into text box by ID on Android
	 * @param 	id
	 * @param 	value
	 * @param 	appiumDriver
	 * @return 	boolean
	 * @throws	Exception
	 */	
	public boolean enterTextValueByIDOnAndroid(String id, String value, AppiumDriver<?> appiumDriver) throws Exception {	
		boolean valueEntered = false;
		String idLoc =  TestCaseInit.androidSrcPkgName + TestCaseInit.androidLocatorProp.getProperty(id);
		try{
			appiumDriver.findElement(By.id(idLoc)).clear();
			appiumDriver.findElement(By.id(idLoc)).sendKeys(value);
			valueEntered = true;
			log.info("Text field found with id: "+ idLoc +" and value entered: " + value);	
		} catch(NoSuchElementException nse) {
			log.error("Text field NOT found with id: "+ idLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return valueEntered;
	}
	
	/**
	 * This method is used to enter text into text box by xpath on Android
	 * @param 	xpath
	 * @param 	value
	 * @param 	appiumDriver
	 * @return 	boolean
	 * @throws	Exception
	 */	
	public boolean enterTextValueByXPathOnAndroid(String xpath, String value, AppiumDriver<?> appiumDriver) throws Exception {	
		boolean valueEntered = false;
		String xpathLoc = TestCaseInit.androidLocatorProp.getProperty(xpath);
		try{
			appiumDriver.findElement(By.xpath(xpathLoc)).clear();
			appiumDriver.findElement(By.xpath(xpathLoc)).sendKeys(value);
			valueEntered = true;
			log.info("Text field found with xpath: "+ xpathLoc +" and value entered: " + value);	
		} catch(NoSuchElementException nse) {
			log.error("Text field NOT found with xpath: "+ xpathLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return valueEntered;
	}
	
	
	/**
	 * This method is used to clear the text field on Android
	 * @param 	id
	 * @param 	appiumDriver
	 * @return	boolean
	 * @throws 	Exception
	 */	
	public boolean clearTextFieldByIDOnAndroid(String id, AppiumDriver<?> appiumDriver) throws Exception {	
		boolean textCleared = false;
		String idLoc = TestCaseInit.androidSrcPkgName + TestCaseInit.androidLocatorProp.getProperty(id);
		try{
			appiumDriver.findElement(By.id(idLoc)).clear();
			textCleared = true;
			log.info("Text field found and cleared with id: "+ idLoc);
		} catch (NoSuchElementException nse){
			log.error("Text field NOT found with id: "+ idLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return textCleared;
	}
	
//IOS

	/**
	 * This method is used to explicitly wait until an element with XPath is visible on iOS 
	 * @param	xpath
	 * @param	appiumDriver
	 * @throws	Exception
	 */
	public void explicitWaitUntilElementByXPathIsVisibleOnIOS(String xpath, AppiumDriver<?> appiumDriver) throws Exception {
		String xpathLoc = TestCaseInit.iosLocatorProp.getProperty(xpath);
		try {
			log.info("Explicit wait of "+ TestCaseInit.explicitWait + " seconds until the presence of element is located by XPath: "+ xpathLoc);
			WebDriverWait wait = new WebDriverWait(appiumDriver, TestCaseInit.explicitWait);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathLoc)));
			log.info("Element Found with xpath :" +xpathLoc);
		} catch(TimeoutException tmExp){
			log.error("Element NOT Visible by XPath: " + xpathLoc +" within the given explicit wait time: "+TestCaseInit.explicitWait);					
		} catch (Exception e) {
			log.error("An Exception occurred", e);
			throw e;
		}
	}
	
	/**
	 * This method is used to explicitly wait for an extra time until an element with xpath is visible on iOS
	 * @param xpath
	 * @param appiumDriver
	 * @throws Exception
	 */
	public void extraExplicitWaitUntilElementByXPathIsVisibleOnIOS(String xpath, AppiumDriver<?> appiumDriver) throws Exception {
		String xpathLoc = TestCaseInit.iosLocatorProp.getProperty(xpath);
		try {
			log.info("Extra explicit wait of "+ TestCaseInit.extraExplicitWait + " seconds until the presence of element is located by XPath: "+ xpathLoc);
			WebDriverWait wait = new WebDriverWait(appiumDriver, TestCaseInit.extraExplicitWait);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathLoc)));
			log.info("Element Found with xpath :" +xpathLoc);
		} catch(TimeoutException tmExp){
			log.error("Element NOT Visible by XPath: " + xpathLoc +" within the given extra explicit wait time: "+TestCaseInit.extraExplicitWait);					
		} catch (Exception e) {
			throw e;
		}
	}
	
    /**
	 * This method is used to click a button with ID for iOS
	 * @param  id
	 * @param  appiumDriver
	 * @return boolean 
	 * @throws Exception
	 */
	public boolean clickOnButtonByIDOnIOS(String id, AppiumDriver<?> appiumDriver) throws Exception {
		boolean found = false;
		String idLoc = TestCaseInit.iosLocatorProp.getProperty(id);
		try {
			appiumDriver.findElement(By.id(idLoc)).click();
			log.info("Element found with XPATH: " + idLoc);
			found = true;
		} catch(NoSuchElementException nse){
			log.error("Element NOT Found with XPATH: " + idLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}	
	
    /**
	 * This method is used to click a button with xpath for iOS
	 * @param  xpath
	 * @param  appiumDriver
	 * @return boolean 
	 * @throws Exception
	 */
	public boolean clickOnButtonByXpathOnIOS(String xpath, AppiumDriver<?> appiumDriver) throws Exception {
		boolean found = false;
		String xpathLoc = TestCaseInit.iosLocatorProp.getProperty(xpath);
		try {
			appiumDriver.findElement(By.xpath(xpathLoc)).click();
			log.info("Element found with XPATH: " + xpathLoc);
			found = true;
		} catch(NoSuchElementException nse){
			log.error("Element NOT Found with XPATH: " + xpathLoc);
		} catch (Exception e) {
			throw e;
		}
		return found;
	}
	
	/**
	 * This method is used to find element by XPath for iOS
	 * @param	xpath
	 * @param	appiumDriver
	 * @return	boolean
	 * @throws	Exception
	 */
	public boolean isElementFoundByXPathOnIOS(String xpath, AppiumDriver<?> appiumDriver) throws Exception{
		boolean found = false;
		String xpathLoc = TestCaseInit.iosLocatorProp.getProperty(xpath);
	 	try{
 			if (appiumDriver.findElements(By.xpath(xpathLoc)).size() != 0) {
 				log.info("Element Found with xpath: "+ xpathLoc);
	 			found = true;
			}
	 	} catch (NoSuchElementException nsee) {
			log.error("Element NOT found with xpath: "+ xpathLoc);
		} catch(Exception e){
			throw e;
	 	}
	 	return found;
	 }	
	
	/**
	 * This method is used to get text for an element by id on iOS
	 * @param id
	 * @param driver
	 * @return String; An empty string if NOT found
	 * @throws Exception
	 */
	public String getTextByIDOnIOS(String id, AppiumDriver<?> appiumDriver) throws Exception {
		String textFound = "";
		String idLoc = TestCaseInit.iosLocatorProp.getProperty(id);
		try {
			textFound = appiumDriver.findElement(By.xpath(idLoc)).getText();
			log.info("Element found with id: "+ idLoc + " text found: "+ textFound);
		} catch(NoSuchElementException nse) {
			log.error("Element is NOT found with id: "+ idLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return textFound;	
	}
	
	/**
	 * This method is used to get text for an element by xpath on iOS
	 * @param xpath
	 * @param driver
	 * @return String; An empty string if NOT found
	 * @throws Exception
	 */
	public String getTextByXPathOnIOS(String xpath, AppiumDriver<?> appiumDriver) throws Exception {
		String textFound = "";
		String xpathLoc = TestCaseInit.iosLocatorProp.getProperty(xpath);
		try {
			textFound = appiumDriver.findElement(By.xpath(xpathLoc)).getText();
			log.info("Element found with xpath: "+ xpathLoc + " text found: "+ textFound);
		} catch(NoSuchElementException nse) {
			log.error("Element is NOT found with xpath: "+ xpathLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return textFound;	
	}
	
	/**
	 * This method is used to enter text into text box by xpath created for @Name on IOS
	 * @param xpath
	 * @param value
	 * @param appiumDriver
	 * @return boolean
	 * @throws Exception
	 */	
	public boolean enterTextValueByXPathCreatedForNameOnIOS(String xpath, String value, AppiumDriver<?> appiumDriver) throws Exception {	
		boolean valueEntered = false;
		String xpathCreate = "//UIAStaticText[@name='"+TestCaseInit.iosLocatorProp.getProperty(xpath)+"']/following-sibling::UIATextField[1]";	
		try{		
			if (appiumDriver.findElements(By.xpath(xpathCreate)) != null && appiumDriver.findElements(By.xpath(xpathCreate)).size() != 0) {
				appiumDriver.findElement(By.xpath(xpathCreate)).click();
				appiumDriver.findElement(By.xpath(xpathCreate)).clear();
				appiumDriver.findElement(By.xpath(xpathCreate)).sendKeys(value);
				valueEntered = true;
				log.info("Text field found with xpath created: "+ xpathCreate+" values entered to Text box = " + value);
			} else {
				log.error("Text field NOT found with xpath created: " +xpathCreate);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return valueEntered;
	}
	
	/**
	 * This method is used to enter text into text box by xpath on IOS
	 * @param xpath
	 * @param value
	 * @param appiumDriver
	 * @return boolean
	 * @throws Exception
	 */	
	public boolean enterTextValueByXPathOnIOS(String xpath, String value, AppiumDriver<?> appiumDriver) throws Exception {	
		boolean valueEntered = false;
		String xpathLoc = TestCaseInit.iosLocatorProp.getProperty(xpath);
		try{		
			if (appiumDriver.findElements(By.xpath(xpathLoc)) != null && appiumDriver.findElements(By.xpath(xpathLoc)).size() != 0){
				appiumDriver.findElement(By.xpath(xpathLoc)).click();
				appiumDriver.findElement(By.xpath(xpathLoc)).clear();
				appiumDriver.findElement(By.xpath(xpathLoc)).sendKeys(value);
				valueEntered = true;
				log.info("Text field found with xpath: "+ xpathLoc+" values entered to Text box = " + value);
			} else {
				log.error("Text field NOT found with xpath: "+ xpathLoc);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return valueEntered;
	}	
	
	/**
	 * This method is used to enter text into text box by xpath without clearing the text on IOS
	 * @param xpath
	 * @param value
	 * @param appiumDriver
	 * @return boolean
	 * @throws Exception
	 */	
	public boolean enterTextValueByXPathWithoutClearOnIOS(String xpath, String value, AppiumDriver<?> appiumDriver) throws Exception {	
		boolean valueEntered = false;
		String xpathLoc = TestCaseInit.iosLocatorProp.getProperty(xpath);
		try{		
			if (appiumDriver.findElements(By.xpath(xpathLoc)) != null && appiumDriver.findElements(By.xpath(xpathLoc)).size() != 0){
				appiumDriver.findElement(By.xpath(xpathLoc)).click();
				appiumDriver.findElement(By.xpath(xpathLoc)).sendKeys(value);
				valueEntered = true;
				log.info("Text field found with xpath: "+ xpathLoc+" values entered to Text box = " + value);
			} else {
				log.error("Text field NOT found with xpath: "+ xpathLoc);
			}
		} catch (Exception exp) {
			throw exp;
		}
		return valueEntered;
	}
	
	/**
	 * This method is used to clear the text field on IOS
	 * @param 	xpath
	 * @param 	appiumDriver
	 * @return	boolean
	 * @throws 	Exception
	 */	
	public boolean clearTextFieldByXPathOnIOS(String xpath, AppiumDriver<?> appiumDriver) throws Exception {	
		boolean textCleared = false;
		String xpathLoc = TestCaseInit.iosLocatorProp.getProperty(xpath);
		try{
			appiumDriver.findElement(By.xpath(xpathLoc)).clear();
			textCleared = true;
			log.info("Text field found and cleared with xpath: "+ xpathLoc);
		} catch (NoSuchElementException nse){
			log.error("Text field NOT found with xpath: "+ xpathLoc);
		} catch (Exception exp) {
			throw exp;
		}
		return textCleared;
	}
	
}

