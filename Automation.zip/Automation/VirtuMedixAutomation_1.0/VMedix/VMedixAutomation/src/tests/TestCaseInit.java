package tests;

import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.util.Properties;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.appium.java_client.AppiumDriver;
import library.BussinessLib;
import library.EnvironmentConfigSettings;
import library.GenericAPIMethods;
import library.GenericCsvMethods;
import library.GenericExcelMethods;
import library.GenericLibMobile;
import library.GenericLibWeb;
import library.VMedixUtils;
import pages.AdminAppChoicesHnPTemplatePage;
import pages.AdminAppChoicesMedicationsPage;
import pages.AdminOtherElemsPreviousConsultsPage;
import pages.AdminPage;
import pages.AdminPricingNRefundsCouponsPage;
import pages.AdminPricingNRefundsPriceConsultFeePage;
import pages.AdminPricingNRefundsPriceGroupsPage;
import pages.AdminPricingNRefundsRefundsPage;
import pages.CallRepAdminCallCenterAgentsPage;
import pages.CallRepAdminPage;
import pages.CallRepConsultInQueuePage;
import pages.CallRepConsultPaymentPage;
import pages.CallRepNewConsultPage;
import pages.CallRepNewPatientPage;
import pages.CallRepPage;
import pages.CommonUtilsPage;
import pages.DependentPage;
import pages.DoctorConsultationPage;
import pages.DoctorDnDPage;
import pages.DoctorPage;
import pages.DoctorPreviousConsultationsPage;
import pages.DoctorProfilePage;
import pages.FacilitatedPatAfterSurveyPage;
import pages.FacilitatedPatientPage;
import pages.FacilitatorNewPatientPage;
import pages.FacilitatorPage;
import pages.GMailPage;
import pages.LoginPage;
import pages.MobilePage;
import pages.NewPatientEmailVerifiedPage;
import pages.PatientAfterSurveyPage;
import pages.PatientConsultHistoryPage;
import pages.PatientConsultWaitingRoomHealthPreQueInfoPage;
import pages.PatientConsultationRequestPage;
import pages.PatientConsultationRequestPaymentPage;
import pages.PatientConsultationVideoOrPhonePage;
import pages.PatientInfoPage;
import pages.PatientPage;
import pages.PatientSurveyPage;
import pages.TrackingBoardScreenPage;

public class TestCaseInit {
	
	public static Logger log = Logger.getLogger(TestCaseInit.class.getName());	
	public static Path Current_Directory ;
	public static String ExecuteOniPhone;

	public static BussinessLib bussLib = new BussinessLib();
	static{
		Current_Directory = VMedixUtils.returnCurrentWorkingDirectoryPath();
	}

	public static GenericLibWeb genLibWeb = new GenericLibWeb();
	public static GenericLibMobile genLibMobile = new GenericLibMobile();
	public static GenericExcelMethods genExcelMethods = new GenericExcelMethods();
	public static GenericCsvMethods genCsvMethods = new GenericCsvMethods();
	public static GenericAPIMethods genApiMethods = new GenericAPIMethods();
	
	//Initialize Properties file
	//external
	public static Properties envConfigProp;
	//internal
	public static Properties webLocatorProp;
	public static Properties messagesVMedixProp;
	public static Properties androidLocatorProp;
	public static Properties iosLocatorProp;
	
	//Driver Initialization
	public static String testOnServer = null;
	public static WebDriver driverDoctor = null;
	public static WebDriver driverPatient = null;
	public static WebDriver driverCallRep = null;
	public static WebDriver driverAdmin = null;
	public static WebDriver driverGmail = null;
	public static AppiumDriver<?> appiumDriver = null;
	public static boolean appiumStarted = false;	
	public static String browserDoctor;
	public static String browserPatient;	
	public static long implicitwait;
	public static long explicitWait;
	public static long extraExplicitWait;	
	public static boolean mobileOnTab;
	public static boolean mobileOnIOS;
	public static String androidSrcPkgName;	
	public static boolean sauceLabForWeb;
	public static boolean sauceLabForMobile;
	public static String webUrl;
	public static String apiUrl;
	public static boolean testCaseExecute;
	public static boolean testCaseStatus;
	public static long startTime;
	public static String testCaseName;
	public static String testCaseType = null;
	public static String TestSuiteFile;
	public static String TestDataFile;
	public static String downloadPath;
	public static String activeTestType = null;
	public static String envConfigFilePath = Current_Directory+"/Configuration/environment_config.properties";
	public static String webLocatorFilePath = Current_Directory+ "/VMedix/VMedixAutomation/src/Locators/webLocators.properties";
	public static String messagesVMedixFilePath = Current_Directory+ "/VMedix/VMedixAutomation/src/Locators/messagesVMedix.properties";
	public static String androidLocatorFilePath = Current_Directory+ "/VMedix/VMedixAutomation/src/Locators/androidLocators.properties";
	public static String iosLocatorFilePath = Current_Directory+ "/VMedix/VMedixAutomation/src/Locators/iosLocators.properties";
	public static String newLine = System.getProperty("line.separator");		
	public static String passedScreenShotsFilePath = Current_Directory+"/Results/Passed_TestCase_ScreenShots/";
	public static String failedScreenShotsFilePath = Current_Directory+"/Results/Failed_TestCase_ScreenShots/";
	//Driver .exe Paths
	public static String chromeDriver = Current_Directory+"/Configuration/Drivers/chromedriver.exe";
	public static String ieDriver = Current_Directory+"/Configuration/Drivers/IEDriverServer.exe";
	
//	//POM Files
	public CommonUtilsPage cmnUtilsForPages = new CommonUtilsPage();
	public LoginPage login = new LoginPage();
	public GMailPage gmailPage = new GMailPage();
	public AdminPage admin = new AdminPage();
	public AdminAppChoicesHnPTemplatePage adminHnPTmplt = new AdminAppChoicesHnPTemplatePage();
	public AdminAppChoicesMedicationsPage adminMedications = new AdminAppChoicesMedicationsPage();
	public AdminPricingNRefundsCouponsPage adminPricNRefCoupons = new AdminPricingNRefundsCouponsPage();
	public AdminPricingNRefundsPriceGroupsPage adminPricNRefPriceGrp = new AdminPricingNRefundsPriceGroupsPage();
	public AdminPricingNRefundsPriceConsultFeePage adminPricNRefConsultFee = new AdminPricingNRefundsPriceConsultFeePage();
	public AdminPricingNRefundsRefundsPage adminPricNRefRefunds = new AdminPricingNRefundsRefundsPage();
	public AdminOtherElemsPreviousConsultsPage adminOthrElemPrevConsults = new AdminOtherElemsPreviousConsultsPage();
	public CallRepAdminPage callRepAdmin = new CallRepAdminPage();
	public CallRepAdminCallCenterAgentsPage adminCallCenterAgents = new CallRepAdminCallCenterAgentsPage();
	public CallRepPage callRep = new CallRepPage();
	public CallRepNewPatientPage callRepNewPatConsult = new CallRepNewPatientPage();
	public CallRepNewConsultPage callRepNewConsult = new CallRepNewConsultPage();
	public CallRepConsultPaymentPage callRepConsultPayment = new CallRepConsultPaymentPage();
	public CallRepConsultInQueuePage callRepConsultInQueue =  new CallRepConsultInQueuePage();
	public PatientPage patientPage = new PatientPage();
	public PatientConsultationRequestPage patientConsultReq = new PatientConsultationRequestPage();
	public PatientConsultationRequestPaymentPage patientConsultPayment = new PatientConsultationRequestPaymentPage();
	public PatientConsultWaitingRoomHealthPreQueInfoPage patConsultWaitRoomHealthInfoPreQ = new PatientConsultWaitingRoomHealthPreQueInfoPage();
	public PatientConsultationVideoOrPhonePage patientConsultation = new PatientConsultationVideoOrPhonePage();
	public PatientSurveyPage survey = new PatientSurveyPage();	
	public DoctorPage doctorPage = new DoctorPage();
	public TrackingBoardScreenPage trackingBoardScreen = new TrackingBoardScreenPage();
	public DoctorProfilePage docprofile = new DoctorProfilePage();
	public DoctorPreviousConsultationsPage docPrevConsult = new DoctorPreviousConsultationsPage();
	public DoctorConsultationPage doctorConsultation = new DoctorConsultationPage();
	public DoctorDnDPage ddscreen = new DoctorDnDPage();
	public PatientAfterSurveyPage afterSurvey = new PatientAfterSurveyPage();
	public PatientConsultHistoryPage patientConsultHistory = new PatientConsultHistoryPage();
	public PatientInfoPage patientInfo = new PatientInfoPage();
	public DependentPage dependent = new DependentPage();
	public NewPatientEmailVerifiedPage newPatEmailVerPage = new NewPatientEmailVerifiedPage();
	public FacilitatorPage facilitator = new FacilitatorPage();
	public FacilitatedPatientPage facPatient = new FacilitatedPatientPage();
	public FacilitatedPatAfterSurveyPage facPatAfterSurvey = new FacilitatedPatAfterSurveyPage();
	public FacilitatorNewPatientPage facNewPat = new FacilitatorNewPatientPage();
	
	public MobilePage mobile = new MobilePage();
//	public PatientValidateHealthRecord patientHealthRecord = new PatientValidateHealthRecord();
//	public MedicalHistoryPOM medpom = new MedicalHistoryPOM();
	
	//API values testdata/ui
	public static int countviewconsultsfromui;
	public static String username;
	public static String password;
	public static String docname;
	public static String docemail;
	public static int countallergy;
	public static int countmedications;
	public static int countcomplaints;
	public static String patientname;
	public static String currentlogin;
	public static String amount;
	public static int statecount;
	public static String cardnumval;
	public static String cardcvvval;
	public static String cardexmonthval;
	public static String cardexyrval;
	public static String chiefcomplaint;
	public static String contactphone;
	public static String location;
	public static String methodofcontact;
	
	/**
	 * This method reads the locators and message property files.
	 * @throws Exception
	 */
	@BeforeSuite
	public static void setUpSuite(ITestContext ctx) throws Exception {
		testOnServer = testOnServer.trim().toLowerCase();		
		webUrl =  "https://vmedix-"+testOnServer+".nimaws.com";
		apiUrl = "https://api-virtumedix-"+testOnServer+".nimaws.com/";
		
		// Read locator and message Properties File
		webLocatorProp = new Properties();
		messagesVMedixProp = new Properties();
		androidLocatorProp = new Properties();
		iosLocatorProp = new Properties();
		try {
			webLocatorProp.load(new FileInputStream(webLocatorFilePath));
			messagesVMedixProp.load(new FileInputStream(messagesVMedixFilePath));
			androidLocatorProp.load(new FileInputStream(androidLocatorFilePath));
			iosLocatorProp.load(new FileInputStream(iosLocatorFilePath));
		} catch (Exception e) {
			log.error("An Exception occurred", e);
		}
		//Move Previous Report to Archive
		VMedixUtils.moveOldReportToArchive();
		
		//get test suite file name
		TestSuiteFile = Current_Directory+"/Test_Data/"+EnvironmentConfigSettings.getTestSuiteFileNameEnvConfig();
		//get test data file name
		String activeTestSuiteName = ctx.getSuite().getName();
		if(StringUtils.containsIgnoreCase(activeTestSuiteName, VMedixUtils.TEST_TYPE_SMOKE)){
			activeTestType = VMedixUtils.TEST_TYPE_SMOKE;
			TestDataFile = Current_Directory+"/Test_Data/"+EnvironmentConfigSettings.getTestDataSmokeFileNameEnvConfig();			
		} else if(StringUtils.containsIgnoreCase(activeTestSuiteName, VMedixUtils.TEST_TYPE_REGRESSION)){
			activeTestType = VMedixUtils.TEST_TYPE_REGRESSION;			
			TestDataFile = Current_Directory+"/Test_Data/"+EnvironmentConfigSettings.getTestDataRegressionFileNameEnvConfig();
		} else if(StringUtils.containsIgnoreCase(activeTestSuiteName, VMedixUtils.TEST_TYPE_PERFORMANCE)){
			activeTestType = VMedixUtils.TEST_TYPE_PERFORMANCE;			
			TestDataFile = Current_Directory+"/Test_Data/"+EnvironmentConfigSettings.getTestDataPerformanceFileNameEnvConfig();
		}		
		downloadPath = envConfigProp.getProperty("DefaultDownloadLocation");
		implicitwait = EnvironmentConfigSettings.getImplicitWaitEnvConfig();
		explicitWait = EnvironmentConfigSettings.getExplicitWaitEnvConfig();
		extraExplicitWait = EnvironmentConfigSettings.getExtraExplicitWaitEnvConfig();
		String frameworkStartTime = VMedixUtils.getSystemTime();
		startTime = System.currentTimeMillis();
		mobileOnTab = EnvironmentConfigSettings.isMobileAndroidOnTabEnvConfig();
		mobileOnIOS = EnvironmentConfigSettings.isMobileOnIOSEnvConfig();
		sauceLabForWeb = EnvironmentConfigSettings.isSauceLabForWebEnvConfig();
		sauceLabForMobile = EnvironmentConfigSettings.isSauceLabForMobileEnvConfig();
		androidSrcPkgName = EnvironmentConfigSettings.getMobileAndroidAppPackageEnvConfig();
		log.info(frameworkStartTime);
		log.info("Automation Execution Started...");
	}
	
	/**
	 * This method executes before every @Test method and check for it's
	 * execution status in the TestSuite.xlsx file. If set to YES then it
	 * executes else method will be skipped.
	 * 
	 * This method uses the "checkValueInExcel" method of "Excel_Generic_Methods" class file. Method name and SheetName will be passed as arguments.
	 * 
	 * @param methodId
	 * @param webBrowserType
	 * @throws Exception
	 */
	@Parameters({"webBrowserType"})
	@BeforeMethod
	public void setUpMethod(Method methodId, String webBrowserType) throws Exception {
		testCaseStatus = true;
		testCaseName = methodId.getName();				
		if(activeTestType.equalsIgnoreCase(VMedixUtils.TEST_TYPE_SMOKE)){
			testCaseExecute = genExcelMethods.getExecuteTestCase(testCaseName, EnvironmentConfigSettings.getTestSuiteSmokeSheetNameEnvConfig());
		}else if(activeTestType.equalsIgnoreCase(VMedixUtils.TEST_TYPE_REGRESSION)){
			testCaseExecute = genExcelMethods.getExecuteTestCase(testCaseName, EnvironmentConfigSettings.getTestSuiteRegressionSheetNameEnvConfig());
		}else if(activeTestType.equalsIgnoreCase(VMedixUtils.TEST_TYPE_PERFORMANCE)){
			testCaseExecute = genExcelMethods.getExecuteTestCase(testCaseName, EnvironmentConfigSettings.getTestSuitePerformanceSheetNameEnvConfig());
		}			
		
		if (!testCaseExecute) {
			log.info(testCaseName + ": This test is Skipped as the execution status is set to NO.");
			throw new SkipException(testCaseName + ": This test is skipped as the execution status is set to NO.");
		}else{
			log.info(newLine + "++++++++++++++++++++++++++++++++++++"
					+ newLine + "------------------------------" + newLine
					+ testCaseName + "->" + "Started Execution..." + newLine
					+ "--------------------------" + newLine
					+ "+++++++++++++++++++++++++++++++++++++++++++++++++++");
			if (testCaseType.equalsIgnoreCase(VMedixUtils.TEST_CASE_TYPE_MOBILE) && EnvironmentConfigSettings.isExecuteMobileTestEnvConfig()) {
				if (appiumDriver == null && !appiumStarted){
					appiumDriver = genLibMobile.getAppiumDriver();
					appiumStarted = true;
					//appiumDriver.closeApp();
				} else {	
					log.info("Appium Driver is already Invoked");
				}
			}
		}
		browserDoctor = webBrowserType;
		browserPatient = webBrowserType;
	}
	
	@DataProvider(name = "getData")
	public Object[][] getData(Method method) throws Exception {
		String Method_Name = method.getName();
		Object[][] arrayObject = null;
		if(StringUtils.containsIgnoreCase(FilenameUtils.getExtension(TestDataFile), "xls")){//excel - smoke and performance
			arrayObject = genExcelMethods.getDataFromExcelTestData(Method_Name);
		} else{ //csv - regression
			arrayObject = genCsvMethods.getDataFromCSVTestData(Method_Name);
		}
		return (arrayObject);
	}
	
	@AfterMethod
	public void tearDownMethod() {
		if(testCaseExecute){			
			try {
				//screen shot
				genLibWeb.takeScreenshot();

				//close web drivers
				genLibWeb.quitAllWebDrivers();
				
				//close mobile app
				genLibMobile.closeMobileApp();
				
				//print out to log the execution status of test case
				String testExecution = "PASSED";
				if (!testCaseStatus){
					testExecution = "FAILED";
				}
				log.info(newLine + "++++++++++++++++++++++++++++++++++++"
						+ newLine + "------------------------------" + newLine
						+ testCaseName + " -> " + "Execution " + testExecution + newLine
						+ "--------------------------" + newLine
						+ "+++++++++++++++++++++++++++++++++++++++++++++++++++");
			} catch (Exception e) {			
				log.error("An Exception occurred in tearDownMethod", e);
			} 
		}
	}
	
	@AfterSuite
	public void tearDownSuite() {
		//close appium driver
		try {			
			genLibMobile.closeAppiumDriver();			
		}catch (Exception e) {
			log.error("An Exception occurred in tearDownSuite", e);
		}		
		log.info("Automation Execution Completed!");
	}
	
	//Credentials for API:-
	public static String getUsername() {
		return username;
	}

	public static void setUsername(String username) {
		TestCaseInit.username = username;
	}

	public static String getPassword() {
		return password;
	}

	public static void setPassword(String password) {
		TestCaseInit.password = password;
	}
	
	public static int getCountviewconsultsfromui() {
		return countviewconsultsfromui;
	}

	public static void setCountviewconsultsfromui(int countviewconsultsfromui) {
		TestCaseInit.countviewconsultsfromui = countviewconsultsfromui;
	}

	public static String getDocname() {
		return docname;
	}

	public static void setDocname(String docname) {
		TestCaseInit.docname = docname;
	}

	public static String getDocemail() {
		return docemail;
	}

	public static void setDocemail(String docemail) {
		TestCaseInit.docemail = docemail;
	}

	public static int getCountallergy() {
		return countallergy;
	}

	public static void setCountallergy(int countallergy) {
		TestCaseInit.countallergy = countallergy;
	}

	public static int getCountmedications() {
		return countmedications;
	}

	public static void setCountmedications(int countmedications) {
		TestCaseInit.countmedications = countmedications;
	}

	public static int getCountcomplaints() {
		return countcomplaints;
	}

	public static void setCountcomplaints(int countcomplaints) {
		TestCaseInit.countcomplaints = countcomplaints;
	}

	public static String getPatientname() {
		return patientname;
	}

	public static void setPatientname(String patientname) {
		TestCaseInit.patientname = patientname;
	}
	
	public static String getCurrentlogin() {
		return currentlogin;
	}

	public static void setCurrentlogin(String currentlogin) {
		TestCaseInit.currentlogin = currentlogin;
	}
	
	public static String getAmount() {
		return amount;
	}

	public static void setAmount(String amount) {
		TestCaseInit.amount = amount;
	}
	
	public static int getStatecount() {
		return statecount;
	}

	public static void setStatecount(int statecount) {
		TestCaseInit.statecount = statecount;
	}
	
	//payment
	public static String getCardnumval() {
		return cardnumval;
	}

	public static void setCardnumval(String cardnumval) {
		TestCaseInit.cardnumval = cardnumval;
	}

	public static String getCardcvvval() {
		return cardcvvval;
	}

	public static void setCardcvvval(String cardcvvval) {
		TestCaseInit.cardcvvval = cardcvvval;
	}

	public static String getCardexmonthval() {
		return cardexmonthval;
	}

	public static void setCardexmonthval(String cardexmonthval) {
		TestCaseInit.cardexmonthval = cardexmonthval;
	}

	public static String getCardexyrval() {
		return cardexyrval;
	}

	public static void setCardexyrval(String cardexyrval) {
		TestCaseInit.cardexyrval = cardexyrval;
	}	
	
	//getconsult
	public static String getChiefcomplaint() {
		return chiefcomplaint;
	}

	public static void setChiefcomplaint(String chiefcomplaint) {
		TestCaseInit.chiefcomplaint = chiefcomplaint;
	}

	public static String getContactphone() {
		return contactphone;
	}

	public static void setContactphone(String contactphone) {
		TestCaseInit.contactphone = contactphone;
	}

	public static String getLocation() {
		return location;
	}

	public static void setLocation(String location) {
		TestCaseInit.location = location;
	}

	public static String getMethodofcontact() {
		return methodofcontact;
	}

	public static void setMethodofcontact(String methodofcontact) {
		TestCaseInit.methodofcontact = methodofcontact;
	}
}
