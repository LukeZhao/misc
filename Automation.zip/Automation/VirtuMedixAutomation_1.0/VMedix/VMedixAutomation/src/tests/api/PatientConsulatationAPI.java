package tests.api;

import org.testng.Assert;
import org.testng.annotations.Test;

import tests.TestCaseInit;

public class PatientConsulatationAPI extends TestCaseInit {
	
	/**
	 * Extra test cases for Patient related API calls. 
	 * APIs verified: Login, Complaints, Medications and Allergy
	 * @param patientEmail
	 * @param patientPwd
	 * @param complaintBegin
	 * @param medicationBegin
	 * @param allergyBegin
	 */
	@Test(dataProvider = "getData", groups = { "API Patient" })
	public void testPatientConsulatationAPIs(String patientEmail, String patientPwd, String complaintBegin, String medicationBegin, String allergyBegin){
		try {
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patientEmail, patientPwd,driverPatient);
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			genApiMethods.apiAssertFailCount = 0;
		//Login API for Patient!
			log.info("Starting LOGIN API...");
			currentlogin = "patient";
			setCurrentlogin(currentlogin);
			setUsername(patientEmail);
			setPassword(patientPwd);
			genApiMethods.getResponse("API", "Login");
			log.info("Login API is completed successfully");
		// API for chief complaints !
			log.info("Starting Chief complaints API...");
			genLibWeb.enterTextValueByName("patientChiefComplaintInp.name", complaintBegin, driverPatient);
			countcomplaints = genLibWeb.getElementsByXPath("patientChiefComplaintDrpBx.ngRepeat.xpath", null, driverPatient).size();
			log.info("countcomplaints: " + countcomplaints);
			genApiMethods.getResponse("API", "Complaints");
			log.info("Chief Complaint API is Completed");
		// API for Medications !
			log.info("Starting Medication API...");
			genLibWeb.enterTextValueByXPath("patientMedicationInp.ngModel.xpath", null, medicationBegin, driverPatient);
			countmedications = genLibWeb.getElementsByXPath("patientMedicationDrpBx.ngClick.xpath", null, driverPatient).size();
			log.info("countmedications: " + countmedications);
			genApiMethods.getResponse("API", "Medication");
			log.info("Medication API is Completed");			
		// API for Allergy !
			log.info("Starting Allergy API...");
			genLibWeb.enterTextValueByXPath("patientAllergyInp.ngModel.xpath", null, allergyBegin, driverPatient);
			countallergy = genLibWeb.getElementsByXPath("patientAllergyDrpBx.ngClick.xpath", null, driverPatient).size();
			log.info("countallergy: " + countallergy);
			genApiMethods.getResponse("API", "Allergy");
			log.info("Allergy API Completed");	
			//verify if all the API asserts passed
			if(genApiMethods.apiAssertFailCount > 0){
				testCaseStatus = false;
				log.error("Number of asserts failed: "+ genApiMethods.apiAssertFailCount);
				throw new AssertionError("Assert failed for certain API calls");
			}
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
}

