/**
 * 
 */
package tests.api;

import org.testng.Assert;
import org.testng.annotations.Test;

import tests.TestCaseInit;

public class DoctorProfileAPI extends TestCaseInit {	
	
	/**
	 * Extra test cases for Doctor related API calls. 
	 * APIs verified: Doclogin, DocDetails, PrevConsults
	 * @param docName
	 * @param docEmail
	 * @param docPwd
	 */
	@Test(dataProvider = "getData", groups = { "API Doctor" })
	public void testDoctorProfileAPIs(String docName, String docEmail, String docPwd) {
		try{
			//Doctor Driver gets opened here.
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverDoctor);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			genApiMethods.apiAssertFailCount = 0;
		//Login API for Doctor !
			log.info("Starting Login API...");
			currentlogin = "clinician";
			docname = docName;
			docemail = docEmail;
			setCurrentlogin(currentlogin);
			setDocname(docname);
			setDocemail(docemail);
			setUsername(docEmail);
			setPassword(docPwd); 
			genApiMethods.getResponse("API", "Doclogin");
			log.info("Login API Completed");		
		// Doctor Details API Call for Doctor Details after login 
			log.info("Starting Doctor Details API...");		
			genApiMethods.getResponse("API", "DocDetails");
			log.info("Doctor Details API Completed");
		// Previous Consults API Call for Doctor			
			docPrevConsult.clickOnPreviousConsults(driverDoctor);
			setCountviewconsultsfromui(docPrevConsult.getTotalCountOfPreviousConsults(driverDoctor));
			log.info("Starting Previous Consults API...");
			genApiMethods.getResponse("API", "PrevConsults");
			log.info("Previous Consults API Completed");
			//verify if all the API asserts passed
			if(genApiMethods.apiAssertFailCount > 0){
				testCaseStatus = false;
				log.error("Number of asserts failed: "+ genApiMethods.apiAssertFailCount);
				throw new AssertionError("Assert failed on certain API calls");
			}
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		} 
	}
}
