package tests.mobile;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import library.EnvironmentConfigSettings;
import library.VMedixUtils;
import tests.TestCaseInit;

public class Verify_Mobile_MergedTestCases extends TestCaseInit{
	@Test(dataProvider = "getData", groups = { "Mobile Automation" })
	public void TC_238194_238197(String Email, String Password, String fname, String lname, String phone, String zip, String password,
			String visitReason, String debitCardNumber, String securityCode,String doc_uname, String doc_pwd) {
		try {
			appiumDriver.launchApp();
			mobile.clickOnContinueButton(appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("SeeADoctorButton_ID", appiumDriver);
			genLibMobile.enterTextValueByIDOnAndroid("RegisterFirstName_ID", fname, appiumDriver);								
			genLibMobile.enterTextValueByIDOnAndroid("RegisterLastName_ID", lname, appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("DOB_ID", appiumDriver);
			if (mobileOnIOS) {
				appiumDriver.findElement(By.xpath(iosLocatorProp.getProperty("SelectYear_DOB_xpath"))).sendKeys("2015");
			}
			genLibMobile.clickOnButtonByIDNoSourcPackageOnAndroid("SetDropDown_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("Gender_male_xpath", appiumDriver);
			genLibMobile.enterTextValueByIDOnAndroid("PhoneNumber_ID", phone, appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			genLibMobile.enterTextValueByIDOnAndroid("Zip_ID", zip,
					appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			String dynamicValue = VMedixUtils.generateDynamicString();
			String EmailToRegister = VMedixUtils.generateEmailId(Email, dynamicValue);
			log.info("Random Email created for this User is : "
					+ EmailToRegister);
			genLibMobile.enterTextValueByIDOnAndroid("Email_ID",
					EmailToRegister, appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			if (mobileOnIOS) {
			} else {
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("RegisterScreenContinueButton_ID", appiumDriver)) {
					log.info("Webelement is Displayed");
				} else {
					for (int i = 0; i < 3; i++) {
						if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("RegisterScreenContinueButton_ID", appiumDriver)) {
							break;
						}
						mobile.swipeVrticalBottomToTop(appiumDriver);
					}
				}
			}
			genLibMobile.enterTextValueByIDOnAndroid("RegisterScreenPassword_xpath", password, appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			genLibMobile.clickOnButtonByXPathOnAndroid("RegisterScreenContinueButton_XPath", appiumDriver);
			genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("EmailVerificationYESButton_ID", appiumDriver);				
			if (mobileOnIOS && !mobileOnTab) {
				genLibMobile.clickOnButtonByXpathOnIOS("MenuIcon_ID", appiumDriver);
				log.info("Clicked on Hamburger to expand the Menu Options");
				mobile.signOutFromAppForIOS(appiumDriver);
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("CancelButtonOnLoginScreen_xpath", appiumDriver)== true) {
					genLibMobile.clickOnButtonByIDOnAndroid("CancelButtonOnLoginScreen_xpath", appiumDriver);
				}					
				mobile.loginApp(appiumDriver, EmailToRegister, password);
			}
			genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("EmailVerificationYESButton_ID", appiumDriver);
			if (!sauceLabForMobile) {
			if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("EmailVerificationYESButton_ID", appiumDriver) == true) {
				genLibMobile.clickOnButtonByIDOnAndroid("EmailVerificationYESButton_ID", appiumDriver);
				log.info("Please Verify Your Email pop-up is visible");
			}
			else {
				log.info("Please Verify Your Email pop-up didn't Appeared");
				Assert.fail("Please Verify Your Email pop-up didn't Appeared for newly created PATIENT. Pop-Up should have appeared as per expected result.");
				}
			}
			if (!mobileOnTab) {
				genLibMobile.clickOnButtonByIDOnAndroid("MenuIcon_ID", appiumDriver);
				log.info("Clicked on Hamburger to expand the Menu Options");
			} else {
				log.info("Menu options are by default expanded due to big screen resolution");
			}
			if (mobileOnIOS) {
				mobile.signOutFromAppForIOS(appiumDriver);
				genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("LandingPageText_ID", appiumDriver);
				log.info("Patient is successfully logged out of the application");
			} else {
				Thread.sleep(3000);
				genLibMobile.clickOnButtonByXPathOnAndroid("SignOut_xpath",appiumDriver);
				Thread.sleep(3000);
				genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("LandingPageText_ID", appiumDriver);
				log.info("Patient is successfully logged out of the application");
			}				
			appiumDriver.closeApp();
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			mobile.loginToGmailVerifyEmail(Email, Password, driverDoctor);
			appiumDriver.launchApp();
			mobile.clickOnContinueButton(appiumDriver);
			mobile.loginApp(appiumDriver, EmailToRegister, password);	
			if (sauceLabForMobile && mobileOnIOS) {

				log.info("Email is successfully verified");
				log.info(newLine
						+ "++++++++++++++++++++++++++++++++++++"
						+ newLine
						+ "------------------------------"
						+ newLine
						+ "TC_238194"
						+ "->"
						+ "Execution is PASSED"
						+ newLine
						+ "--------------------------"
						+ newLine
						+ "+++++++++++++++++++++++++++++++++++++++++++++++++++");
				testCaseStatus = true;
			} else {
				// TO HANDLE SIMULATOR
				if (mobileOnIOS) {
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("EmailVerificationYESButton_ID", appiumDriver)) {
						genLibMobile.clickOnButtonByIDOnAndroid("EmailVerificationYESButton_ID", appiumDriver);
						log.info("Please Verify Your Email pop-up is Still visible");
						testCaseStatus = false;
						Assert.fail("Please Verify Your Email pop-up is Still visible");
					}
					else {
						log.info("Please Verify Your Email pop-up didn't Appeared");
						log.info("Email is successfully verified");
						log.info(newLine
								+ "++++++++++++++++++++++++++++++++++++"
								+ newLine
								+ "------------------------------"
								+ newLine
								+ "TC_238194"
								+ "->"
								+ "Execution is PASSED"
								+ newLine
								+ "--------------------------"
								+ newLine
								+ "+++++++++++++++++++++++++++++++++++++++++++++++++++");
						testCaseStatus = true;
					}
				} else {
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("EmailVerificationYESButton_ID",
							appiumDriver)) {
						log.info("Email Verification PopUp is still Visible");
						testCaseStatus = false;
						Assert.fail("Email Verification PopUp is still Visible");
					} else {
						log.info("Email is successfully verified");
						log.info(newLine
								+ "++++++++++++++++++++++++++++++++++++"
								+ newLine
								+ "------------------------------"
								+ newLine
								+ "TC_238194"
								+ "->"
								+ "Execution is PASSED"
								+ newLine
								+ "--------------------------"
								+ newLine
								+ "+++++++++++++++++++++++++++++++++++++++++++++++++++");
						testCaseStatus = true;
					}
				}			
			}
			if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("WelcomeScreenSeeADoctor_ID", appiumDriver)) {
				genLibMobile.clickOnButtonByIDOnAndroid("WelcomeScreenSeeADoctor_ID", appiumDriver);
			}
			genLibMobile.clickOnButtonByIDOnAndroid("SelfConsultation_ID", appiumDriver);
			genLibMobile.enterTextValueByIDOnAndroid("TodayVisitReason_ID", visitReason, appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			if (mobileOnIOS) {
				genLibMobile.clickOnButtonByXpathOnIOS("SelectState_xpath", appiumDriver);
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
				log.info("STATE is selected for iOS Build, since it's not by default selected");
			} else {
				log.info("STATE is by deafult selected on ANDROID BUILD");
			}
			genLibMobile.clickOnButtonByIDOnAndroid("MyInfoContinueButton_ID", appiumDriver);
			genLibMobile.enterTextValueByIDOnAndroid("CardNumber_ID", debitCardNumber, appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("CardExpiration_ID", appiumDriver);
			if (mobileOnIOS) {
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
			} else {
				appiumDriver.findElement(By.id(androidLocatorProp.getProperty("SetDropDown_ID"))).click();
			}
			genLibMobile.enterTextValueByIDOnAndroid("CardSecurityCode_ID", securityCode, appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("TermsServicesCheckBox_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("PrivacyPolicyCheckBox_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("PhysicalExaminationCheckBox_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("PaymentScreenSubmitButton_ID",	appiumDriver);
			genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("AlertContinueButton_ID",	appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("AlertContinueButton_ID", appiumDriver);
			if (mobileOnIOS) {					
			} else {
				appiumDriver.findElement(By.id(androidLocatorProp.getProperty("MedRoomDropDown_ID"))).click();
				appiumDriver.findElement(By.id(androidLocatorProp.getProperty("MedRoomDropDown_ID"))).click();
			}
			genLibMobile.clickOnButtonByXPathOnAndroid("MedicalHistorySaveButton_XPath", appiumDriver);
			if (!mobileOnTab) {
				genLibMobile.clickOnButtonByIDOnAndroid("MenuIcon_ID", appiumDriver);
				log.info("Clicked on Hamburger to expand the Menu Options");
			} else {
				log.info("Menu options are by default expanded due to big screen resolution");
			}
			if (mobileOnIOS) {
				mobile.signOutFromAppForIOS(appiumDriver);
			} else {
				Thread.sleep(3000);
				genLibMobile.clickOnButtonByXPathOnAndroid("SignOut_xpath",appiumDriver);
				Thread.sleep(3000);
			}				
			if (!mobileOnTab && !mobileOnIOS) {
				mobile.clickOnContinueButton(appiumDriver);					
			}
			if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("LogInButton_ID", appiumDriver)) {
				genLibMobile.clickOnButtonByIDOnAndroid("LogInButton_ID", appiumDriver);
			} else {
				log.info("Patient is on Login Screen");
			}				
			genLibMobile.enterTextValueByIDOnAndroid("LogInUserName_ID", EmailToRegister, appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			genLibMobile.enterTextValueByIDOnAndroid("Password_ID", password, appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			genLibMobile.clickOnButtonByXPathOnAndroid("ClickOnLoginButton_XPath", appiumDriver);
			if (mobileOnIOS) {
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("ConsultationScheduled_xpath",
						appiumDriver)) {
					log.info("Activity State is Matched. Current Activity state is Consultation Scheduled, as expected");
				} else {
					log.info("Activity State didn't Matched. Current Activity state is NOT Consultation Scheduled, as expected");
					testCaseStatus = false;
					Assert.fail("Activity State didn't Matched. Current Activity state is NOT Consultation Scheduled, as expected");
				}
			} else {
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("ConsultationScheduled_xpath",
						appiumDriver)) {
					log.info("Activity State is Matched. Current Activity state is Consultation Scheduled, as expected");
				} else {
					log.info("Activity State didn't Matched. Current Activity state is NOT Consultation Scheduled, as expected");
					testCaseStatus = false;
					Assert.fail("Activity State didn't Matched. Current Activity state is NOT Consultation Scheduled, as expected");
				}
			}
			try {
				if (mobileOnIOS) {
					genLibMobile.clickOnButtonByXpathOnIOS("WaitingRoomButton_xpath", appiumDriver);
				} else {
					genLibMobile.clickOnButtonByIDOnAndroid("GoTOWaitingRoom_ID", appiumDriver);
				}
				driverDoctor = genLibWeb.getWebDriver(browserDoctor);
				genLibWeb.setImplicitWait(driverDoctor);
				driverDoctor.get(webUrl);
				login.loginAsExistingUser(doc_uname, doc_pwd, driverDoctor);
				doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
				mobile.clickOnDismissButton(appiumDriver);
				String patientName = fname+" "+lname;
				trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patientName, driverDoctor);
				genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("StartConsultationFromApp_ID", appiumDriver);
				genLibMobile.clickOnButtonByIDOnAndroid("StartConsultationFromApp_ID", appiumDriver);
				if (mobileOnIOS) {					
				} else {
					if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("BeginConsultation_xpath", appiumDriver)) {
						genLibMobile.clickOnButtonByXPathOnAndroid(androidLocatorProp.getProperty("BeginConsultation_xpath"),appiumDriver);
					} else {
				  }
				}
				doctorConsultation.cancelOrEndVideoConsultationFromDoctor(driverDoctor);
				if (sauceLabForMobile && mobileOnIOS) {
					log.info("Pop-ups are handled by desired capabilities on iOS Simulator");
				}else {
					genLibMobile.clickOnButtonByIDOnAndroid("ContinueOKButton_ID", appiumDriver);
				}
				if (mobileOnIOS) {
					Thread.sleep(4000);
					mobile.fillSurveyFormForIOS(appiumDriver);
				}
				else {
					mobile.submitSurveyForAndroid(appiumDriver);
				}
				genLibWeb.validateExpectedWithActualByXPath(messagesVMedixProp.getProperty("Doctor_DD_Screen_PageTitle"), "D_&_D_Form_PageTitle_xpath", null, driverDoctor);
				bussLib.selectByValueByXPathOnNgmodelOrNameOrClass("reasonForRefund", "0", driverDoctor);
				log.info("Reason for Cancellation is Selected from the DropDown");
				bussLib.clickOnButtonWithActionByXPathOnNgClick("submitDischarge(item, form)", driverDoctor);
				log.info("Discharge Form Filled and Button is Clicked");
			} catch (Exception e) {
				e.printStackTrace();
			}
			log.info("------------------------------" + newLine
					+ "TC_238197" + "->" + "Execution is PASSED" + newLine);
			log.info(newLine + "++++++++++++++++++++++++++++++++++++"
					+ newLine + "------------------------------" + newLine
					+ testCaseName + "->" + "Execution is PASSED" + newLine
					+ "--------------------------" + newLine
					+ "+++++++++++++++++++++++++++++++++++++++++++++++++++");
			
			testCaseStatus = true;				
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	@Test(dataProvider = "getData", groups = { "Mobile Automation" })
	public void TC_238195_238198(String Uname, String password, String visitReason, String debitCardNumber, String securityCode, String patientName,
			String medication, String Allergy, String doc_uname, String doc_pwd) {
		try {				
			appiumDriver.launchApp();
			mobile.clickOnContinueButton(appiumDriver);
			mobile.loginApp(appiumDriver, Uname, password);
			if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("EmailVerificationYESButton_ID", appiumDriver)) {
				genLibMobile.clickOnButtonByIDOnAndroid("EmailVerificationYESButton_ID", appiumDriver);
				log.info("Please Verify Your Email pop-up is visible");
			}
			else {
				log.info("Please Verify Your Email pop-up didn't Appeared");
			}
			mobile.bringMobileAppToHomeScreen(appiumDriver);
			if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("WelcomeScreenSeeADoctor_ID", appiumDriver)) {
				genLibMobile.clickOnButtonByIDOnAndroid("WelcomeScreenSeeADoctor_ID", appiumDriver);
			}
			genLibMobile.clickOnButtonByIDOnAndroid("SelfConsultation_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("BackButton_ID", appiumDriver);
			if (mobileOnIOS) {
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("PickAPatientScreen_xpath", appiumDriver)) {
					log.info("Back Button Functionality is working as expected");
				} else {
					log.info("Back Button functionality is NOT working as expected");
					testCaseStatus = false;
					Assert.fail("Back Button functionality is NOT working as expected");
				}
			} else {
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("PickAPatientScreen_xpath", appiumDriver)) {
					log.info("Back Button Functionality is working as expected");
				} else {
					log.info("Back Button functionality is NOT working as expected");
					testCaseStatus = false;
					Assert.fail("Back Button functionality is NOT working as expected");
				}
			}				
			genLibMobile.clickOnButtonByIDOnAndroid("SelfConsultation_ID", appiumDriver);
			genLibMobile.enterTextValueByIDOnAndroid("TodayVisitReason_ID", visitReason, appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);	
			if (mobileOnIOS) {
				genLibMobile.clickOnButtonByXpathOnIOS("SelectState_xpath", appiumDriver);
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
				log.info("STATE is selected for iOS Build, since it's not by default selected");					
			} else {
				log.info("STATE is by deafult selected on ANDROID BUILD");
			}
			genLibMobile.enterTextValueByIDOnAndroid("Medications_ID", medication, appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			if (!mobileOnIOS) {
				genLibMobile.clickOnButtonByIDOnAndroid("AddMedication_ID", appiumDriver);
			}
			else {
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
			}
			genLibMobile.enterTextValueByIDOnAndroid("Allergy_ID", Allergy, appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			if (!mobileOnIOS) {
				genLibMobile.clickOnButtonByIDOnAndroid("AddAllergy_ID", appiumDriver);
			}
			else {
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
			}
			genLibMobile.clearTextFieldByIDOnAndroid("Medications_ID", appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			genLibMobile.clearTextFieldByIDOnAndroid("Allergy_ID", appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("MyInfoContinueButton_ID", appiumDriver);
			genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("CardExpiration_ID", appiumDriver);
			log.info("Patient is on Payment Screen now");
			genLibMobile.clickOnButtonByIDOnAndroid("BackNavBarButton_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("BackButton_ID", appiumDriver);
			genLibMobile.clickOnButtonByXPathOnAndroid("Dependent_xpath",	appiumDriver);
			genLibMobile.enterTextValueByIDOnAndroid("TodayVisitReason_ID", visitReason, appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			if (mobileOnIOS) {
				genLibMobile.clickOnButtonByXpathOnIOS("SelectState_xpath", appiumDriver);
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
				log.info("STATE is selected for iOS Build, since it's not by default selected");
			} else {
				log.info("STATE is by deafult selected on ANDROID BUILD");
			}
			genLibMobile.enterTextValueByIDOnAndroid("Medications_ID", medication, appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			if (!mobileOnIOS) {
				genLibMobile.clickOnButtonByIDOnAndroid("AddMedication_ID", appiumDriver);
			}
			else {
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
			}
			genLibMobile.enterTextValueByIDOnAndroid("Allergy_ID", Allergy, appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			if (!mobileOnIOS) {
				genLibMobile.clickOnButtonByIDOnAndroid("AddAllergy_ID", appiumDriver);
			}
			else {
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
			}
			genLibMobile.clearTextFieldByIDOnAndroid("Medications_ID", appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			genLibMobile.clearTextFieldByIDOnAndroid("Allergy_ID", appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("MyInfoContinueButton_ID", appiumDriver);
			genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid(androidLocatorProp.getProperty("CardExpiration_ID"),	appiumDriver);
			log.info("Dependent is on Payment Screen now");
			Thread.sleep(5000);
			genLibMobile.clickOnButtonByIDOnAndroid("BackNavBarButton_ID", appiumDriver);
			Thread.sleep(2000);
			genLibMobile.clickOnButtonByIDOnAndroid("BackButton_ID", appiumDriver);
			log.info(newLine + "++++++++++++++++++++++++++++++++++++"
					+ newLine + "------------------------------" + newLine
					+ "TC_238198" + "->" + "Execution is PASSED" + newLine
					+ "--------------------------" + newLine
					+ "+++++++++++++++++++++++++++++++++++++++++++++++++++");
			testCaseStatus = true;				
			genLibMobile.clickOnButtonByIDOnAndroid("SelfConsultation_ID", appiumDriver);
			genLibMobile.enterTextValueByIDOnAndroid("TodayVisitReason_ID", visitReason, appiumDriver);
			genLibMobile.hideKeyBoardVisibilityByXPathWithTapOnAndroid(appiumDriver);
			if (mobileOnIOS) {
				genLibMobile.clickOnButtonByXpathOnIOS("SelectState_xpath", appiumDriver);
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
				log.info("STATE is selected for iOS Build, since it's not by default selected");
			} else {
				log.info("STATE is by deafult selected on ANDROID BUILD");
			}
			genLibMobile.clickOnButtonByIDOnAndroid("MyInfoContinueButton_ID", appiumDriver);				
			genLibMobile.enterTextValueByIDOnAndroid("CardNumber_ID", debitCardNumber, appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("CardExpiration_ID", appiumDriver);
			if (mobileOnIOS) {
				genLibMobile.clickOnButtonByIDOnIOS("SetDropDown_ID", appiumDriver);
			} else {
				appiumDriver.findElement(By.id(androidLocatorProp.getProperty("SetDropDown_ID"))).click();
			}
			genLibMobile.enterTextValueByIDOnAndroid("CardSecurityCode_ID", securityCode, appiumDriver);
			genLibMobile.hideKeyBoardVisibility(appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("TermsServicesCheckBox_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("PrivacyPolicyCheckBox_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("PhysicalExaminationCheckBox_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("PaymentScreenSubmitButton_ID", appiumDriver);
			genLibMobile.clickOnButtonByIDOnAndroid("AlertContinueButton_ID", appiumDriver);
			if (mobileOnIOS) {					
			} else {
				appiumDriver.findElement(By.id(androidLocatorProp.getProperty("MedRoomDropDown_ID"))).click();
				appiumDriver.findElement(By.id(androidLocatorProp.getProperty("MedRoomDropDown_ID"))).click();
			}
			genLibMobile.clickOnButtonByXPathOnAndroid("MedicalHistorySaveButton_XPath", appiumDriver);
			if (!mobileOnTab) {
				genLibMobile.clickOnButtonByIDOnAndroid("MenuIcon_ID", appiumDriver);
			}	
			if (!EnvironmentConfigSettings.isMobileOnIOSEnvConfig()) {
				Thread.sleep(3000);
				genLibMobile.clickOnButtonByXPathOnAndroid("SignOut_xpath", appiumDriver);
				Thread.sleep(3000);
			}
			appiumDriver.closeApp();
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(doc_uname, doc_pwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			appiumDriver.launchApp();
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patientName, driverDoctor);
			if (!mobileOnTab) {
				mobile.clickOnContinueButton(appiumDriver);
			}
			mobile.loginApp(appiumDriver, Uname, password);
			if (mobileOnIOS) {
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("EmailVerificationYESButton_ID", appiumDriver)) {
					genLibMobile.clickOnButtonByIDOnAndroid("EmailVerificationYESButton_ID", appiumDriver);
					log.info("Please Verify Your Email pop-up is visible");
				}
				else {
					log.info("Please Verify Your Email pop-up didn't Appeared");
				}
				genLibMobile.clickOnButtonByXpathOnIOS("EnterConsultation_xpath", appiumDriver);
			} else {
				genLibMobile.explicitWaitUntilElementByIDIsVisibleOnAndroid("StartConsultationFromApp_ID", appiumDriver);
				genLibMobile.clickOnButtonByIDOnAndroid("StartConsultationFromApp_ID", appiumDriver);
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("EmailVerificationYESButton_ID", appiumDriver)) {
					genLibMobile.clickOnButtonByIDOnAndroid("EmailVerificationYESButton_ID", appiumDriver);
					log.info("Please Verify Your Email pop-up is visible");
				}
				else {
					log.info("Please Verify Your Email pop-up didn't Appeared");
				}
			}
			if (mobileOnIOS) {
				
			} else {
				if (genLibMobile.isElementFoundByIDOrXPathOrCssSelectorOnAndroid("BeginConsultation_xpath", appiumDriver)) {
					genLibMobile.clickOnButtonByXPathOnAndroid(androidLocatorProp.getProperty("BeginConsultation_xpath"), appiumDriver);
				} else {
					log.info("Begin Consultation pop-up didn't appeared on Patient mobile app");
				}
			}
			doctorConsultation.cancelOrEndVideoConsultationFromDoctor(driverDoctor);
			if (sauceLabForMobile && mobileOnIOS) {
				log.info("Pop-ups are handled by desired capabilities on iOS Simulator");
			}else {
				genLibMobile.clickOnButtonByIDOnAndroid("ContinueOKButton_ID", appiumDriver);
			}
			if (mobileOnIOS) {
				Thread.sleep(4000);
				mobile.fillSurveyFormForIOS(appiumDriver);
			}
			else {
				mobile.submitSurveyForAndroid(appiumDriver);
			}
			genLibWeb.validateExpectedWithActualByXPath(messagesVMedixProp.getProperty("Doctor_DD_Screen_PageTitle"), "D_&_D_Form_PageTitle_xpath", null, driverDoctor);
			bussLib.selectByValueByXPathOnNgmodelOrNameOrClass("reasonForRefund", "0", driverDoctor);
			log.info("Reason for Cancellation is Selected from the DropDown");				
			bussLib.clickOnButtonWithActionByXPathOnNgClick("submitDischarge(item, form)",
					driverDoctor);
			log.info("Discharge Form Filled and Button is Clicked");				
			log.info(newLine + "++++++++++++++++++++++++++++++++++++"
					+ newLine + "------------------------------" + newLine
					+ testCaseName + "->" + "Execution is PASSED" + newLine
					+ "--------------------------" + newLine
					+ "+++++++++++++++++++++++++++++++++++++++++++++++++++");
			testCaseStatus = true;				
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
}
