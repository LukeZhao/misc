package tests;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.apache.commons.io.FileUtils;

public class MoveXSLTReport {
	
	public static Path Current_Directory ;
	static{
		Current_Directory = returnCurrentWorkingDirectoryPath();
	}
	
	/**
	 * This method is returns the Current Working Directory 
	 * @return 
	 * @return: Current Working Directory
	 */
	public static Path returnCurrentWorkingDirectoryPath() {
		Path path = Paths.get(System.getProperty("user.dir"));
		Path cwd;
		String temp = System.getProperty("user.dir");
		int var = temp.indexOf("bin" );
		if (var>=0){
			cwd = path.getParent().getParent().getParent();
		}
		else{
			cwd = path.getParent().getParent();
		}
		return cwd;
	}
	
	public static void main(String[] args) {
		File dir = new File(Current_Directory+"/VMedix/VMedixAutomation");
		File[] foundFiles = dir.listFiles(new FilenameFilter() {
		    public boolean accept(File dir, String name) {
		        return name.startsWith("testng-xslt_");
		    }
		});

		for (File file : foundFiles) {
			String file_path = file.toString();
			String folder_name = file_path.substring(file_path.lastIndexOf('\\') + 1).trim();
			File source = new File(Current_Directory+"/VMedix/VMedixAutomation/"+folder_name);
			try {
				new File(Current_Directory+"/Results/XSLT_Report/"+folder_name).mkdir();
				File dest = new File(Current_Directory+"/Results/XSLT_Report/"+folder_name);
			    FileUtils.copyDirectory(source, dest);
			    File source_delete = new File(Current_Directory+"/VMedix/VMedixAutomation/"+folder_name);
			    FileUtils.deleteDirectory(source_delete);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
