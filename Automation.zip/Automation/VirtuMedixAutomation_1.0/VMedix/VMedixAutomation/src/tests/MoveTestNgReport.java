package tests;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;

public class MoveTestNgReport {
	
	public static Path Current_Directory ;
	static{
		Current_Directory = returnCurrentWorkingDirectoryPath();
	}
	
	/**
	 * This method is returns the Current Working Directory 
	 * @return 
	 * @return: Current Working Directory
	 */
	public static Path returnCurrentWorkingDirectoryPath() {
		Path path = Paths.get(System.getProperty("user.dir"));
		Path cwd;
		String temp = System.getProperty("user.dir");
		int var = temp.indexOf("bin" );
		if (var>=0){
			cwd = path.getParent().getParent().getParent();
		}
		else{
			cwd = path.getParent().getParent();
		}
		return cwd;
	}
	
	public static void main(String[] args) {		
		File dir = new File(Current_Directory+"/VMedix/VMedixAutomation");
		File[] foundFiles = dir.listFiles(new FilenameFilter() {
		    public boolean accept(File dir, String name) {
		        return name.startsWith("test-output");
		    }
		});
		
		for (File file : foundFiles) {
			String file_path = file.toString();
			String folder_name = file_path.substring(file_path.lastIndexOf('\\') + 1).trim();
			File source = new File(Current_Directory+"/VMedix/VMedixAutomation/"+folder_name);
			try {
			 	Date now = new Date();
		        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
		        String time = dateFormat.format(now);
				new File(Current_Directory+"/Results/TestNG_Report/"+folder_name+"_"+time).mkdir();
				File dest = new File(Current_Directory+"/Results/TestNG_Report/"+folder_name+"_"+time);
			    FileUtils.copyDirectory(source, dest);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

