package tests.web.smoke;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import library.VMedixUtils;
import library.VMedixUtils.NotifyDoctorMethod;
import pages.FacilitatorPage;
import tests.TestCaseInit;

public class FacilitatorETE extends TestCaseInit{

	/**
	 * End to End Video Consultation Flow for Existing Facilitated Patient
	 * @param facEmail	
	 * @param facPwd
	 * @param facFullName
	 * @param facPatFName
	 * @param facPatLName 
	 * @param vistReason	
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName
	 * @param docMedicinesEnt
	 * @param docAllergyEnt
	 * @param docHeighFeetEnt 
	 * @param docHeighInchesEnt 
	 * @param docWeightLbsEnt 
	 * @param docMedConditionEnt 
	 * @param docSurgeriesEnt 
	 * @param docFamMedProbEnt 
	 * @param docSmokeEnt 
	 * @param docSmokePacksNumEnt 
	 * @param docJobProfEnt 
	 * @param docPrimDocNameEnt 
	 * @param docPrimDocPhoneEnt 
	 * @param docPrefPharmNameEnt 
	 * @param docPrefPharmPhoneEnt 
	 * @param docPrefPharmAddr1Ent 
	 * @param docPrefPharmAddr2Ent 
	 * @param docPrefPharmCityEnt 
	 * @param docPrefPharmStateEnt 
	 * @param docPrefPharmZipCodeEnt
	 * @param diagCode
	 * @param followUp
	 * @param returnToSchWrk
	 * @param restrt
	 * @param durOfRestrt
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @throws Exception
	 */
	@Test(dataProvider = "getData", groups = {"Facilitator Existing FacPat" }) //TC_248841
	public void testETEForExistingFacPat(String facEmail, String facPwd, String facFullName, String facPatFName, String facPatLName, String vistReason, String docEmail, String docPwd, String docName, 
			String docMedicinesEnt, String docAllergyEnt, String docHeighFeetEnt, String docHeighInchesEnt, String docWeightLbsEnt, String docMedConditionEnt, String docSurgeriesEnt, 
			String docFamMedProbEnt, String docSmokeEnt, String docSmokePacksNumEnt, String docJobProfEnt, String docPrimDocNameEnt, String docPrimDocPhoneEnt, 
			String docPrefPharmNameEnt, String docPrefPharmPhoneEnt, String docPrefPharmAddr1Ent, String docPrefPharmAddr2Ent, String docPrefPharmCityEnt, String docPrefPharmStateEnt, String docPrefPharmZipCodeEnt,
			String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String hpSoapSub, String hpSoapObj) throws Exception {
		try {
			boolean doctorLoggedIn = false;			
			// Log-In as facilitator			
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);	
			loginAsFacilitatorNlookForFacPat(facEmail, facPwd, facFullName, facPatFName, facPatLName, driverPatient);
			if(FacilitatorPage.facPatConsultState != null) {
				if(!FacilitatorPage.facPatConsultState.equalsIgnoreCase(VMedixUtils.FAC_PAT_IN_CONSULT)){
					facilitator.bringFacPatientToStartConsultState(facFullName, facPatFName, facPatLName, driverPatient);
					facilitator.searchOrSelectOnDashBoard(facPatFName, facPatLName, driverPatient);	
				} else {
					//login as Doctor and end consult
					driverDoctor = genLibWeb.getWebDriver(browserDoctor);
					genLibWeb.setImplicitWait(driverDoctor);
					driverDoctor.get(webUrl);
					login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
					doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);	
					FacilitatorPage.facPatConsultState = null;//doctor has ended the consult
					doctorLoggedIn = true;
					//skip survey on pat
					survey.skipSurvey(driverPatient);
					facPatAfterSurvey.clickOnNextLogOutBtn(driverPatient);	
					Thread.sleep(1000);
					loginAsFacilitatorNlookForFacPat(facEmail, facPwd, facFullName, facPatFName, facPatLName, driverPatient);						
				}	
			}
			startFacilitatedPatConsultn(facEmail, facPwd, facFullName, facPatFName, facPatLName, vistReason, docEmail, docPwd, docName, docMedicinesEnt, docAllergyEnt, docHeighFeetEnt, docHeighInchesEnt, docWeightLbsEnt, 
					docMedConditionEnt, docSurgeriesEnt, docFamMedProbEnt, docSmokeEnt, docSmokePacksNumEnt, docJobProfEnt, docPrimDocNameEnt, docPrimDocPhoneEnt, docPrefPharmNameEnt, docPrefPharmPhoneEnt, docPrefPharmAddr1Ent, 
					docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, docPrefPharmZipCodeEnt, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, hpSoapSub, hpSoapObj, doctorLoggedIn);
		
		} catch (Exception e) {	
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * End to End Video Consultation Flow for New Facilitated Patient
	 * @param facEmail	
	 * @param facPwd
	 * @param facFullName	
	 * @param dobMon
	 * @param dobDay
	 * @param dobYear
	 * @param gender
	 * @param primPhone
	 * @param vistReason	
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName
	 * @param docMedicinesEnt
	 * @param docAllergyEnt
	 * @param docHeighFeetEnt 
	 * @param docHeighInchesEnt 
	 * @param docWeightLbsEnt 
	 * @param docMedConditionEnt 
	 * @param docSurgeriesEnt 
	 * @param docFamMedProbEnt 
	 * @param docSmokeEnt 
	 * @param docSmokePacksNumEnt 
	 * @param docJobProfEnt 
	 * @param docPrimDocNameEnt 
	 * @param docPrimDocPhoneEnt 
	 * @param docPrefPharmNameEnt 
	 * @param docPrefPharmPhoneEnt 
	 * @param docPrefPharmAddr1Ent 
	 * @param docPrefPharmAddr2Ent 
	 * @param docPrefPharmCityEnt 
	 * @param docPrefPharmStateEnt 
	 * @param docPrefPharmZipCodeEnt
	 * @param diagCode
	 * @param followUp
	 * @param returnToSchWrk
	 * @param restrt
	 * @param durOfRestrt
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @throws Exception
	 */
	@Test(dataProvider = "getData", groups = {"Facilitator New FacPat" }) //TC_248844
	public void testETEForNewFacPat(String facEmail, String facPwd, String facFullName, String facPatFName, String facPatLName, String dobMon, String dobDay, String dobYear, String gender, String primPhone, 
			String vistReason, String docEmail, String docPwd, String docName, String docMedicinesEnt, String docAllergyEnt, String docHeighFeetEnt, String docHeighInchesEnt, String docWeightLbsEnt, 
			String docMedConditionEnt, String docSurgeriesEnt, String docFamMedProbEnt, String docSmokeEnt, String docSmokePacksNumEnt, String docJobProfEnt, String docPrimDocNameEnt, String docPrimDocPhoneEnt, 
			String docPrefPharmNameEnt, String docPrefPharmPhoneEnt, String docPrefPharmAddr1Ent, String docPrefPharmAddr2Ent, String docPrefPharmCityEnt, String docPrefPharmStateEnt, String docPrefPharmZipCodeEnt,
			String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String hpSoapSub, String hpSoapObj) throws Exception {
		try {
			// Log-In as facilitator			
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(facEmail, facPwd, driverPatient);
			facilitator.verifyNValidateOnFacilitatorPage(facFullName, driverPatient);
			facilitator.searchRandomNClickOnAddPat(driverPatient);
			facNewPat.verifyNValidateOnFacilitatorNewPatientPage(driverPatient);
			String newPatSuffix = VMedixUtils.generateDynamicString();
			facPatFName = facPatFName + newPatSuffix;
			facPatLName = facPatLName + newPatSuffix;
			facNewPat.addNewFacPat(facPatFName, facPatLName, dobMon, dobDay, dobYear, gender, primPhone, driverPatient);
			facPatient.verifyNValidateOnFacilitatedPatPage(facPatFName + " "+ facPatLName, driverPatient);			
			startFacilitatedPatConsultn(facEmail, facPwd, facFullName, facPatFName, facPatLName, vistReason, docEmail, docPwd, docName, docMedicinesEnt, docAllergyEnt, docHeighFeetEnt, docHeighInchesEnt, docWeightLbsEnt, 
					docMedConditionEnt, docSurgeriesEnt, docFamMedProbEnt, docSmokeEnt, docSmokePacksNumEnt, docJobProfEnt, docPrimDocNameEnt, docPrimDocPhoneEnt, docPrefPharmNameEnt, docPrefPharmPhoneEnt, docPrefPharmAddr1Ent, 
					docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, docPrefPharmZipCodeEnt, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, hpSoapSub, hpSoapObj, false);
		} catch (Exception e) {	
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	private void startFacilitatedPatConsultn(String facEmail, String facPwd, String facFullName, String facPatFName, String facPatLName, String vistReason, String docEmail, String docPwd, String docName, String docMedicinesEnt, 
			String docAllergyEnt, String docHeighFeetEnt, String docHeighInchesEnt, String docWeightLbsEnt, String docMedConditionEnt, String docSurgeriesEnt, String docFamMedProbEnt, String docSmokeEnt, String docSmokePacksNumEnt, 
			String docJobProfEnt, String docPrimDocNameEnt, String docPrimDocPhoneEnt, String docPrefPharmNameEnt, String docPrefPharmPhoneEnt, String docPrefPharmAddr1Ent, String docPrefPharmAddr2Ent, String docPrefPharmCityEnt,
			String docPrefPharmStateEnt, String docPrefPharmZipCodeEnt, String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String hpSoapSub, String hpSoapObj, boolean doctorLoggedIn) throws Exception {
		patientConsultReq.fillConsultationForm(null, vistReason, null, null, driverPatient);
		patientConsultPayment.verifyPatientOnPaymentPage(driverPatient);
		patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);// no health record page for fac pat
		Thread.sleep(2000);
		patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
		patientConsultation.takePatientPhoto(driverPatient);
		Thread.sleep(1000);
		patientConsultation.takePatientPhoto(driverPatient); //2 pics taken
		Thread.sleep(1000);
		if(!doctorLoggedIn){
			//login as Doctor and end consult
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);	
		} else {
			//Doctor - refresh
			driverDoctor.navigate().refresh();
			Thread.sleep(1000);
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);
		}
		trackingBoardScreen.checkPatientAvailableNStartConsultation(true, facPatFName+ " " +facPatLName, driverDoctor);
		trackingBoardScreen.verifyNValidateOnNotifyDocOfFacilitatedPatPopup(driverDoctor);
		trackingBoardScreen.acceptFacPatOnNotifyDocPopup(driverDoctor);
		//fac patient			
		patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);			
		Thread.sleep(2000);//wait to begin consultation
		//Verify chat on both ends 
		patientConsultation.verifyChatWindow(driverPatient);
		cmnUtilsForPages.verify2SetsOfDocPatChatMessages(driverPatient, driverDoctor);
		doctorConsultation.verifyPhotosUploaded(2, driverDoctor);
		doctorConsultation.editMedicinesNAllergiesOfPatient(docMedicinesEnt, docAllergyEnt, driverDoctor);
		doctorConsultation.uncollapseMedicalHistorySection(driverDoctor);
		doctorConsultation.clickOnMedicalHistoryEdit(driverDoctor); //click edit
		cmnUtilsForPages.editNReviewMedicalHistoryOfPatient(docHeighFeetEnt, docHeighInchesEnt, docWeightLbsEnt, docMedConditionEnt, docSurgeriesEnt, docFamMedProbEnt, docSmokeEnt, 
				docSmokePacksNumEnt, VMedixUtils.ALCOHOL_OCCASIONALLY, docJobProfEnt, docPrimDocNameEnt, docPrimDocPhoneEnt, docPrefPharmNameEnt, docPrefPharmPhoneEnt, docPrefPharmAddr1Ent, 
				docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, docPrefPharmZipCodeEnt, driverDoctor);
		Thread.sleep(2000);
		doctorConsultation.endViDoctorConsultation(driverDoctor);
		//Doctor on DnD 			
		ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);
		ddscreen.editDnDValuesOnDnDPage(diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, null, driverDoctor);
		ddscreen.enterHnPTemplateSoapNotes(hpSoapSub, hpSoapObj, driverDoctor);
		ddscreen.submitDnD(driverDoctor);
		//Fac pat
		//skip survey on pat
		survey.skipSurvey(driverPatient);
		facPatAfterSurvey.clickOnNextLogOutBtn(driverPatient);	
		Thread.sleep(1000);
		loginAsFacilitatorNlookForFacPat(facEmail, facPwd, facFullName, facPatFName, facPatLName, driverPatient);	
		patientPage.clickOnPatientInfoOption(driverPatient);
		patientInfo.verifyNValidatePatientOnPatientInfoPage(driverPatient);
		//on fac pat profile only few med history are seen the rest are given as null
		patientInfo.verifyPatientInfo(docHeighFeetEnt, docHeighInchesEnt, docWeightLbsEnt, null, null, null, null, null, null, null, null, null, 
				docPrimDocNameEnt, docPrimDocPhoneEnt, null, null, null, null, null, null, null, 
				docPrefPharmNameEnt, docPrefPharmPhoneEnt, null, null, docPrefPharmAddr1Ent, docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, docPrefPharmZipCodeEnt, driverPatient);
		patientPage.clickOnSeeDoctorOption(driverPatient);
		facPatient.verifyNValidateOnFacilitatedPatPage(facPatFName+" "+facPatLName, driverPatient);
		//start new consultation to verify med history
		vistReason = vistReason+"anotherConsult";
		patientConsultReq.fillConsultationForm(null, vistReason, null, null, driverPatient);
		patientConsultPayment.verifyPatientOnPaymentPage(driverPatient);
		patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);// no health record page for fac pat
		Thread.sleep(2000);
		patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
		//Doctor - refresh
		driverDoctor.navigate().refresh();
		Thread.sleep(1000);
		doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);			
		trackingBoardScreen.checkPatientAvailableNStartConsultation(true, facPatFName+ " " +facPatLName, driverDoctor);
		trackingBoardScreen.verifyNValidateOnNotifyDocOfFacilitatedPatPopup(driverDoctor);
		trackingBoardScreen.acceptFacPatOnNotifyDocPopup(driverDoctor);
		//Fac Patient - Begin Consultation
		patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);
		Thread.sleep(2000);
		//Doctor - verify Med Hist when in consultation
		doctorConsultation.verifyMedicalHistoryInConsult(vistReason, docHeighFeetEnt, docHeighInchesEnt, docWeightLbsEnt, docMedicinesEnt, docAllergyEnt, 
				docMedConditionEnt, docSurgeriesEnt, docFamMedProbEnt, docSmokeEnt, docSmokePacksNumEnt, VMedixUtils.ALCOHOL_OCCASIONALLY, docJobProfEnt, 
				docPrimDocNameEnt, docPrimDocPhoneEnt, 
				docPrefPharmNameEnt, docPrefPharmPhoneEnt, docPrefPharmAddr1Ent, docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, docPrefPharmZipCodeEnt, driverDoctor);
		//Doctor - end consultation
		genLibWeb.scrollToViewElementWithClass("logoH1.class", driverDoctor);
		doctorConsultation.endViDoctorConsultation(driverDoctor);	
		ddscreen.verifyDoctorOnDnDPage(driverDoctor);
		Thread.sleep(5000);
		ddscreen.submitDnD(driverDoctor);		
	}	

	private void loginAsFacilitatorNlookForFacPat(String facEmail, String facPwd, String facFullName, String facPatFName, String facPatLName, WebDriver driverPatient) throws Exception {
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
		login.loginAsExistingUser(facEmail, facPwd, driverPatient);
		facilitator.verifyNValidateOnFacilitatorPage(facFullName, driverPatient);
		facilitator.searchOrSelectOnDashBoard(facPatFName, facPatLName, driverPatient);	
	}
}
