package tests.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import tests.TestCaseInit;
public class DoctorSelfProfile extends TestCaseInit {
	
	/**
	 * To validate My Profile Screen of Doctor
	 * @param docEmail
	 * @param password
	 * @param fName
	 * @param lName
	 * @param gender
	 * @param notification
	 * @param city
	 * @param state
	 * @param country
	 * @param phone
	 * @param npi
	 * @param dea
	 */
	@Test(dataProvider = "getData" , groups = { "Doctor SelfProfile" }) //TC_238793
	public void testDoctorProfile(String docEmail, String password, String fName, String lName, String gender, String notification, String city, String state, 
			String country, String phone, String npi, String dea ){
		try{
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverDoctor);
			login.loginAsExistingUser(docEmail, password, driverDoctor);
			doctorPage.verifyDoctorOnLandingPage(driverDoctor);
			//Related to API checks for Doctor !
			log.info("Starting Doctor Login API...");
			String docFullName = fName + " " + lName;
			if (genLibWeb.isElementFoundByXPath("doctorLandingPageH1.xpath", null, driverDoctor)) {
				currentlogin = "clinician";
				docname = docFullName;
				docemail = docEmail;
			} else {
				testCaseStatus = false;
				log.error("Doctor is NOT on landing page");
			}
			setCurrentlogin(currentlogin);
			setUsername(docEmail);
			setPassword(password);
			genApiMethods.getResponse("API", "Doclogin");
			log.info("Doctor Login API Completed successfully");		
			//clicking on the doctors Profile
			docprofile.clickNVerifyMyProfile(driverDoctor);
			docprofile.assertMyProfileFields(fName, lName, docEmail, gender, notification, city, state, country, phone, npi, dea, driverDoctor);				
			docprofile.verifyChangePasswordScreen(driverDoctor, docFullName);
		}catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}		
	}
}
