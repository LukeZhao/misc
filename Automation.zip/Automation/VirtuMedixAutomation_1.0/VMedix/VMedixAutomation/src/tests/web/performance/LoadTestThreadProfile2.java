package tests.web.performance;

import org.openqa.selenium.WebDriver;

import library.VMedixUtils;
import library.VMedixUtils.NotifyDoctorMethod;

public class LoadTestThreadProfile2 extends Consultations implements Runnable{
	
	public String patEmail, patPwd, patName, vistReason, allergies, heighFeet, heighInches, weightLbs, famMedProb, 
		primDocName, prefPharmName, prefPharmPhone, docEmail, docPwd, docName, diagCode, returnToSchWrk, durOfRestrt;
	public int i;
	boolean failedConsult = false;
	
	public LoadTestThreadProfile2(int i, String patEmail, String patPwd, String patName, String vistReason, String allergies, String heighFeet, String heighInches, String weightLbs, String famMedProb, 
			String primDocName, String prefPharmName, String prefPharmPhone, String docEmail, String docPwd, String docName, String diagCode, String returnToSchWrk, String durOfRestrt) {
		this.i = i;
		this.patEmail = patEmail;
		this.patPwd = patPwd;
		this.patName = patName; 
		this.vistReason = vistReason; 
		this.allergies = allergies; 
		this.heighFeet = heighFeet; 
		this.heighInches = heighInches; 
		this.weightLbs = weightLbs; 
		this.famMedProb = famMedProb; 
		this.primDocName = primDocName; 
		this.prefPharmName = prefPharmName; 
		this.prefPharmPhone = prefPharmPhone;
		this.docEmail = docEmail; 
		this.docPwd = docPwd; 
		this.docName = docName; 
		this.diagCode = diagCode; 
		this.returnToSchWrk = returnToSchWrk; 
		this.durOfRestrt = durOfRestrt;
	}
	
	@Override
	public void run() {		
		WebDriver drvDoctor = null;
		WebDriver drvPatient = null;
		try{
			log.info("**********START OF CONSULTATION between :"+ patEmail+ " and " + docEmail +"**********");			
			//Patient Flow
			drvPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(drvPatient);
			drvPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, drvPatient);
			login.loginAsExistingUser(patEmail, patPwd, drvPatient);			
			patientPage.verifyAndBringPatientToLandingPage(drvPatient);
			Thread.sleep(1000);
			patientConsultReq.fillConsultationForm(true, vistReason+i, null, null, drvPatient);
			patientConsultPayment.verifyPatientOnPaymentPage(drvPatient);
			patientConsultPayment.enterAutoInfoOnPaymentPage(drvPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(drvPatient);
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(drvPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(drvPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(drvPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, drvPatient);
			Thread.sleep(1000);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(drvPatient);
			Thread.sleep(2000);			
			//Doctor Flow
			drvDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(drvDoctor);
			drvDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, drvDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(drvDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patName, drvDoctor);	
			//patient - Begin Consultation
			Thread.sleep(2000);
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, drvPatient);	
			Thread.sleep(2000);
			doctorConsultation.verifyNValidateDoctorInVideoConsultation(drvDoctor);
			Thread.sleep(1*60*1000);//1 minute wait
			patientConsultation.uploadFewPatientPhotos(2, drvPatient); //2 photos uploaded
			doctorConsultation.verifyPhotosUploaded(2, drvDoctor); //verify 2 photos uploaded on doc end
			Thread.sleep(1*60*1000);//1 minute wait
			patientConsultation.verifyChatWindow(drvPatient);
			cmnUtilsForPages.verify2SetsOfDocPatChatMessages(drvPatient, drvDoctor); //2 sets of chat messages
			Thread.sleep(1*30*1000);//1/2 minute wait
			doctorConsultation.editMedicinesNAllergiesOfPatient(null, allergies, drvDoctor);//enter allergy
			doctorConsultation.uncollapseMedicalHistorySection(drvDoctor);
			doctorConsultation.clickOnMedicalHistoryEdit(drvDoctor); //click edit
			cmnUtilsForPages.editNReviewMedicalHistoryOfPatient(heighFeet, heighInches, weightLbs, null, null, famMedProb, null, null, VMedixUtils.ALCOHOL_DAILY, null, 
					primDocName, null, prefPharmName, prefPharmPhone, null, null, null, null, null, drvDoctor); //edit MH
			Thread.sleep(1*60*1000);//1 minute wait
			doctorConsultation.enterDnDDataInConsultation(diagCode, null, returnToSchWrk, null, durOfRestrt, null, drvDoctor); //edit dnd data		
			Thread.sleep(1*30*1000);//1/2 minute wait
			doctorConsultation.endViDoctorConsultation(drvDoctor);
			Thread.sleep(5000);
			ddscreen.submitDnD(drvDoctor);
			//doctor is back on tracking board
			Thread.sleep(3000);
			doctorPage.verifyDoctorOnLandingPage(drvDoctor);
			if(genLibWeb.quitAWebDriver(drvDoctor)){
				drvDoctor = null;
			}			
			//skip survey on patient end
			survey.verifyNValidatePatientOnSurveyPage(drvPatient);
			survey.skipSurvey(drvPatient);
			if(genLibWeb.quitAWebDriver(drvPatient)){
				drvPatient = null;
			}
			log.info("**********END OF CONSULTATION between :"+ patEmail+ " and " + docEmail +"**********");
		}catch(AssertionError | Exception errExp){
			log.error("An Assertion Error/Exception occurred for consultation with pat: "+patEmail+", but will continue tests for other users :"+ errExp.getMessage());
			failedConsult = true;
			testCaseStatus = true;
			try{
				if(genLibWeb.quitAWebDriver(drvDoctor)){
					drvDoctor = null;
				}
				if(genLibWeb.quitAWebDriver(drvPatient)){
					drvPatient = null;
				}	
			} catch (Exception ee) {
				log.info("Quit web driver failed");
			}
		}
	}
}
