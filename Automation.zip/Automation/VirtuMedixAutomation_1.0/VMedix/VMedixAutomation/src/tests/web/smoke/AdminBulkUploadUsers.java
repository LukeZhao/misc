package tests.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import library.VMedixUtils;
import tests.TestCaseInit;

public class AdminBulkUploadUsers extends TestCaseInit {
	
	public static String uniqueEmail;
	public static String BULKUPLOAD_CSVFILE_DOCTOR = Current_Directory+"/Test_Data/upload_clinician_just_one_311_format.csv";
	public static String BULKUPLOAD_CSVFILE_PATIENT_NO_GROUP= Current_Directory+"/Test_Data/upload_patient_no_group_32_format.csv";
	public static String BULKUPLOAD_CSVFILE_CALLREP = Current_Directory+"/Test_Data/upload_callreps_just_one_311_format.csv";
	
	//data
	public static String[] BulkUploadData_Doctor 	= new String[] { "Dr D 301016aF", "DaM", "Dr D 301016aL", uniqueEmail, "1", "9494531111", "male", "sms", "AD4534536", "1336162858" };
	public static String[] BulkUploadData_Patient 	= new String[] { "P b2677aF", "PaM", "Pb1563aL", uniqueEmail, "1", "9494532222", "male", "12/30/1981","address1", "address2", "", "city", "CA", "92656", "USA", "", ""};
	public static String[] BulkUploadData_CallRep 	= new String[] { "Call D 301016aF", "CrM", "Call D 301016aL", uniqueEmail, "1", "9494533333" };
	
	/**
	 * This is a test method for Bulk Upload for Doctor from Admin
	 * @param adminEmail
	 * @param adminPassword
	 * @param newDocGmailSample
	 * @param gmailPwd
	 * @param newPassword
	 */
	@Test(dataProvider = "getData", groups = { "Admin BulkUpload" }) //TC_238071
	public void testBulkUploadDoctor(String adminEmail, String adminPassword, String newDocGmailSample, String gmailPwd, String newPassword) {
		try {
			//prepare unique doc email id and write to the csv file
			String random = VMedixUtils.generateDynamicString();
			uniqueEmail = VMedixUtils.generateEmailId(newDocGmailSample, random);
			BulkUploadData_Doctor[3] = uniqueEmail;
			VMedixUtils.writeIntoCSVFile(BULKUPLOAD_CSVFILE_DOCTOR, BulkUploadData_Doctor);
			//login as doc admin
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);				
			login.loginAsExistingUser(adminEmail, adminPassword, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			admin.bulkUploadUsers(VMedixUtils.USERTYPE_DOCTOR, driverAdmin);
			genLibWeb.clickOnElementByXPath("logoutRef.xpath", null, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverAdmin);
            log.info("Admin has Successfuly Logged Out"); 
        
			//verify email for reset password sent to the doctor from bulk upload
            Thread.sleep(2000);
            driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);	
			gmailPage.bulkUploadGmailVerification(uniqueEmail, gmailPwd, newPassword, VMedixUtils.USERTYPE_DOCTOR, driverGmail);

		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * This is a test method for Bulk Upload for Patient from Admin
	 * @param adminEmail
	 * @param adminPassword
	 * @param newPatGmailSample
	 * @param gmailPwd
	 * @param newPassword
	 */
	@Test(dataProvider = "getData", groups = { "Admin BulkUpload" }) //TC_237529
	public void testBulkUploadPatient(String adminEmail, String adminPassword, String newPatGmailSample, String gmailPwd, String newPassword) {
		try {
			//prepare unique patient email id and write to the csv file
			String random = VMedixUtils.generateDynamicString();
			uniqueEmail = VMedixUtils.generateEmailId(newPatGmailSample, random);
			BulkUploadData_Patient[3] = uniqueEmail;
			VMedixUtils.writeIntoCSVFile(BULKUPLOAD_CSVFILE_PATIENT_NO_GROUP, BulkUploadData_Patient);
			//login as doc admin
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminEmail, adminPassword,driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			admin.bulkUploadUsers(VMedixUtils.USERTYPE_PATIENT,driverAdmin);
			genLibWeb.clickOnElementByXPath("logoutRef.xpath", null, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverAdmin);
			log.info("Admin has Successfuly logged Out.");	
			
			//verify email for reset password sent to the patient from bulk upload
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverGmail);	
			gmailPage.bulkUploadGmailVerification(uniqueEmail, gmailPwd, newPassword, VMedixUtils.USERTYPE_PATIENT, driverGmail);
					
		} catch (Exception e) {	
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());	
		}
	}
	
	/**
	 * This is a test method for Bulk Upload for Call Rep from Admin 
	 * @param adminEmail
	 * @param adminPassword
	 * @param newCallRepGmailSample
	 * @param gmailPwd
	 * @param newPassword
	 */
	@Test(dataProvider = "getData", groups = { "Admin BulkUpload" }) //(TC_237525)
	public void testBulkUploadCallRep(String adminEmail, String adminPassword, String newCallRepGmailSample, String gmailPwd, String newPassword) {
		try {
			//prepare unique call rep email id and write to the csv file
			String random = VMedixUtils.generateDynamicString();
			uniqueEmail = VMedixUtils.generateEmailId(newCallRepGmailSample, random);
			BulkUploadData_CallRep[3] = uniqueEmail;
			VMedixUtils.writeIntoCSVFile(BULKUPLOAD_CSVFILE_CALLREP, BulkUploadData_CallRep);
			//login as a call rep admin
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);			
			login.loginAsExistingUser(adminEmail, adminPassword, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("callRepAdminLandingPageH3.xpath", null, driverAdmin);
			admin.bulkUploadUsers(VMedixUtils.USERTYPE_CALLREP, driverAdmin);
			genLibWeb.clickOnElementByXPath("logoutRef.xpath", null, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverAdmin);
			log.info("Admin has Successfuly logged Out.");	

			//verify email for reset password sent to the call rep from bulk upload
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);				
			gmailPage.bulkUploadGmailVerification(uniqueEmail, gmailPwd, newPassword, VMedixUtils.USERTYPE_CALLREP, driverGmail);
			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}	
}
