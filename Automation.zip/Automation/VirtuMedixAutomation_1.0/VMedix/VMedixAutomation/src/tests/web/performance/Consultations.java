package tests.web.performance;

import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.Test;

import library.EnvironmentConfigSettings;
import tests.TestCaseInit;

public class Consultations extends TestCaseInit {
	int consultStartCount = EnvironmentConfigSettings.getPerformanceConsultsStartCountEnvConfig();
	int consultEndCount = EnvironmentConfigSettings.getPerformanceConsultsEndCountEnvConfig();
	
	/**
	 * End to End Phone Consultation Flow for Existing Patient and Doctor - Profile1
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param vistReason
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 * */
	@Test(dataProvider = "getData", groups = { "Performance New Consultations Video" })
	public void testNewConsultsProfile1(String patEmail, String patPwd, String patName, String vistReason, String docEmail, String docPwd, String docName) throws Exception {
		int i=0; 
		int ind = 0;		
		Thread[] prof1Thrds = new Thread[consultEndCount - consultStartCount + 1];
		LoadTestThreadProfile1[] prof1s = new LoadTestThreadProfile1[consultEndCount - consultStartCount + 1];
		ArrayList<String> failedConsultPats = new ArrayList<String>();
		for(i=consultStartCount; i<=consultEndCount; i++) {	
			String patDocSuffix = Integer.toString(i);
			LoadTestThreadProfile1 prof1 = new LoadTestThreadProfile1(i, StringUtils.replace(patEmail, "_n", "_"+patDocSuffix), patPwd, StringUtils.replace(patName, "_n", "_"+patDocSuffix), 
					vistReason, StringUtils.replace(docEmail, "_n", "_"+patDocSuffix) , docPwd, StringUtils.replace(docName, "_n", "_"+patDocSuffix));			
			Thread prof1Th = new Thread(prof1);
			prof1s[ind] = prof1;
			prof1Thrds[ind++] = prof1Th;
			prof1Th.start();
		}
		for(i=0; i<ind; i++) {	
			try {
				prof1Thrds[i].join();
				if(prof1s[i].failedConsult){
					failedConsultPats.add(prof1s[i].patEmail);
				}
		      }catch(Exception e) {
		         System.out.println("Thread join interrupted.");
		      }
		}
		//print count and pats that failed ETE
		log.info("Number Of Consults Failed: " + failedConsultPats.size());
		if(failedConsultPats.size() > 0) {
			log.info("List of Failed Patients: ");
			for(String failedPat: failedConsultPats){
				log.info(failedPat);
			}
		}
	}
	
	/**
	 * End to End Phone Consultation Flow for Existing Patient and Doctor - Profile2
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param vistReason
	 * @param allergies	
	 * @param heighFeet	
	 * @param heighInches
	 * @param weightLbs
	 * @param famMedProb
	 * @param primDocName
	 * @param prefPharmName
	 * @param prefPharmPhone
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName
	 * @param diagCode	
	 * @param returnToSchWrk	
	 * @param durOfRestrt	
	 * */
	@Test(dataProvider = "getData", groups = { "Performance New Consultations Video" })
	public void testNewConsultsProfile2(String patEmail, String patPwd, String patName, String vistReason, String allergies, String heighFeet, String heighInches, String weightLbs, String famMedProb, 
			String primDocName, String prefPharmName, String prefPharmPhone, String docEmail, String docPwd, String docName, String diagCode, String returnToSchWrk, String durOfRestrt) throws Exception {
		int i=0; 
		int ind = 0;		
		Thread[] prof2Thrds = new Thread[consultEndCount - consultStartCount + 1];
		LoadTestThreadProfile2[] prof2s = new LoadTestThreadProfile2[consultEndCount - consultStartCount + 1];
		ArrayList<String> failedConsultPats = new ArrayList<String>();
		for(i=consultStartCount; i<=consultEndCount; i++) {	
			String patDocSuffix = Integer.toString(i);
			LoadTestThreadProfile2 prof2 = new LoadTestThreadProfile2(i, StringUtils.replace(patEmail, "_n", "_"+patDocSuffix), patPwd, StringUtils.replace(patName, "_n", "_"+patDocSuffix), 
					vistReason, allergies, heighFeet, heighInches, weightLbs, famMedProb, primDocName, prefPharmName, prefPharmPhone, 
					StringUtils.replace(docEmail, "_n", "_"+patDocSuffix) , docPwd, StringUtils.replace(docName, "_n", "_"+patDocSuffix), diagCode, returnToSchWrk, durOfRestrt);			
			Thread prof2Th = new Thread(prof2);
			prof2s[ind] = prof2;
			prof2Thrds[ind++] = prof2Th;
			prof2Th.start();
		}
		for(i=0; i<ind; i++) {	
			try {
				prof2Thrds[i].join();
				if(prof2s[i].failedConsult){
					failedConsultPats.add(prof2s[i].patEmail);
				}
		      }catch(Exception e) {
		         System.out.println("Thread join interrupted.");
		      }
		}
		//print count and pats that failed ETE
		log.info("Number Of Consults Failed: " + failedConsultPats.size());
		if(failedConsultPats.size() > 0) {
			log.info("List of Failed Patients: ");
			for(String failedPat: failedConsultPats){
				log.info(failedPat);
			}
		}
	}
}
