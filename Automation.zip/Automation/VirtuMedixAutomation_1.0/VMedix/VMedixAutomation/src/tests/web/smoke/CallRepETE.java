package tests.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import library.VMedixUtils;
import tests.TestCaseInit;

public class CallRepETE extends TestCaseInit {

	/**
	 * Test Call Rep ETE for existing patient
	 * @param callRepEmail
	 * @param callRepPwd
	 * @param patEmail
	 * @param patPwd
	 * @param patName
	 * @param visitReason
	 * @param medicines	
	 * @param allergies	
	 * @param heighFeet	
	 * @param heighInches
	 * @param weightLbs
	 * @param medCondition	
	 * @param surgeries	
	 * @param famMedProb
	 * @param smoke		
	 * @param smokePacksNum	
	 * @param jobProf
	 * @param primDocName
	 * @param primDocPhone
	 * @param prefPharmName
	 * @param prefPharmPhone
	 * @param prefPharmAddr1
	 * @param prefPharmAddr2
	 * @param prefPharmCity
	 * @param prefPharmState
	 * @param prefPharmZipCode
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName		
	 */
	@Test(dataProvider = "getData", groups = { "Call Rep ETE" }) //TC241827
	public void testCallRepExistingPat(String callRepEmail, String callRepPwd, String patEmail, String patPwd, String patName, String visitReason, String medicines, String allergies, String heighFeet, String heighInches, 
			String weightLbs, String medCondition, String surgeries, String famMedProb, String smoke, String smokePacksNum, String jobProf, String primDocName, String primDocPhone, String prefPharmName, 
			String prefPharmPhone,	String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, String prefPharmState, String prefPharmZipCode, String docEmail, String docPwd, String docName) {
		try {
			//Log-In as call rep to start patient consultation
			driverCallRep = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverCallRep);
			driverCallRep.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverCallRep);
			login.loginAsExistingUser(callRepEmail, callRepPwd, driverCallRep);		
			callRep.verifyNValidateOnCallRepPage(driverCallRep);
			callRep.lookUpNStartNewConsultForExtPat(patEmail, patName, driverCallRep);
			if(callRep.verifyPatAlreadyInConsult(driverCallRep)){
				log.info("Patient has a Pending consultation");
				//bring patient to landing page
				driverPatient = genLibWeb.getWebDriver(browserPatient);
				genLibWeb.setImplicitWait(driverPatient);
				driverPatient.get(webUrl);
				genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
				login.loginAsExistingUser(patEmail, patPwd, driverPatient);	
				patientPage.verifyAndBringPatientToLandingPage(driverPatient);
				genLibWeb.bringBrowserToFront(driverCallRep.getWindowHandle(), driverCallRep);
				callRep.clickStartConsultForExtPat(driverCallRep);
			}			
			callRepNewConsult.verifyNValidateOnCallRepStartNewConsultPage(driverCallRep);		
			callRepNewConsult.startConsultForPatient(visitReason, medicines, allergies, driverCallRep);
			callRepConsultPayment.enterAutoInfoOnCallRepPayment(driverCallRep);
			cmnUtilsForPages.editNReviewMedicalHistoryOfPatient(heighFeet, heighInches, weightLbs, medCondition, surgeries, famMedProb, smoke, smokePacksNum, VMedixUtils.ALCOHOL_NEVER, jobProf, 
					primDocName, primDocPhone, prefPharmName, prefPharmPhone, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverCallRep);
			callRepConsultInQueue.verifyNValidateOnCallRepConsultationInQueuePage(driverCallRep);			
			//Doctor Flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(false, patName, driverDoctor);	
			//Doctor- verify phone notify pop-up on doctor
			doctorConsultation.verifyNValidateDoctorOnPhoneNotifyPopUpWindow(driverDoctor);
			Thread.sleep(1000);
			doctorConsultation.clickOkOnPhoneNotifyPopUpWindow(driverDoctor);
			Thread.sleep(1000);
			doctorConsultation.endPhoneConsultationFromDoctor(driverDoctor);
			Thread.sleep(5000);
			ddscreen.submitDnD(driverDoctor);
			//doctor is back on tracking board
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test Call Rep ETE for existing patient with New dependent 
	 * @param callRepEmail
	 * @param callRepPwd
	 * @param patEmail
	 * @param patPwd
	 * @param patName
	 * @param depFName
	 * @param depLName
	 * @param dobMon
	 * @param dobDay
	 * @param gender
	 * @param primPhone
	 * @param zipCode
	 * @param visitReason
	 * @param medications
	 * @param allergies
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName		
	 */
	@Test(dataProvider = "getData", groups = { "Call Rep ETE" }) //TC241828
	public void testCallRepExtPatNewDependent(String callRepEmail, String callRepPwd, String patEmail, String patPwd, String patName, String depFName, String depLName, 
			String dobMon, String dobDay, String gender, String primPhone, String zipCode, String visitReason, String medicines, String allergies, 
			String docEmail, String docPwd, String docName) {
		try {
			//Log-In as call rep to start patient consultation
			driverCallRep = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverCallRep);
			driverCallRep.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverCallRep);
			login.loginAsExistingUser(callRepEmail, callRepPwd, driverCallRep);		
			callRep.verifyNValidateOnCallRepPage(driverCallRep);
			callRep.lookUpNStartNewConsultForExtPat(patEmail, patName, driverCallRep);
			if(callRep.verifyPatAlreadyInConsult(driverCallRep)){
				log.info("Patient has a Pending consultation");
				//bring patient to landing page
				driverPatient = genLibWeb.getWebDriver(browserPatient);
				genLibWeb.setImplicitWait(driverPatient);
				driverPatient.get(webUrl);
				genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
				login.loginAsExistingUser(patEmail, patPwd, driverPatient);	
				patientPage.verifyAndBringPatientToLandingPage(driverPatient);
				genLibWeb.bringBrowserToFront(driverCallRep.getWindowHandle(), driverCallRep);
				callRep.clickStartConsultForExtPat(driverCallRep);
			}
			callRepNewConsult.verifyNValidateOnCallRepStartNewConsultPage(driverCallRep);		
			callRepNewConsult.startConsultForNewDependant(depFName, depLName, dobMon, dobDay, gender, primPhone, zipCode,visitReason, medicines, allergies, driverCallRep);
			callRepConsultPayment.enterAutoInfoOnCallRepPayment(driverCallRep);
			cmnUtilsForPages.verifyNValidateOnMedicalHistoryEditPage(driverCallRep);
			cmnUtilsForPages.clickNextOnMedicalHistoryEditPage(driverCallRep);
			cmnUtilsForPages.verifyNValidateOnMedicalHistoryEditReviewPage(driverCallRep);
			cmnUtilsForPages.clickSubmitOnMedicalHistoryEditReviewPage(driverCallRep);
			callRepConsultInQueue.verifyNValidateOnCallRepConsultationInQueuePage(driverCallRep);			
			//Doctor Flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(false, depFName+ " " + depLName, driverDoctor);	
			//Doctor- verify phone notify pop-up on doctor
			doctorConsultation.verifyNValidateDoctorOnPhoneNotifyPopUpWindow(driverDoctor);
			Thread.sleep(1000);
			doctorConsultation.clickOkOnPhoneNotifyPopUpWindow(driverDoctor);
			Thread.sleep(1000);
			doctorConsultation.endPhoneConsultationFromDoctor(driverDoctor);
			Thread.sleep(5000);
			ddscreen.submitDnD(driverDoctor);
			//doctor is back on tracking board
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test Call Rep ETE for New patient
	 * @param callRepEmail
	 * @param callRepPwd
	 * @param newPatSampleGmail
	 * @param patPwd
	 * @param patFirstName
	 * @param patLastName
	 * @param patMonth
	 * @param patDay
	 * @param patYear
	 * @param patGender
	 * @param patPrimaryPhone
	 * @param patZipCode
	 * @param visitReason
	 * @param medications
	 * @param allergies
	 * @param heighFeet	
	 * @param heighInches
	 * @param weightLbs
	 * @param medCondition	
	 * @param surgeries	
	 * @param famMedProb
	 * @param smoke		
	 * @param smokePacksNum	
	 * @param jobProf
	 * @param primDocName
	 * @param primDocPhone
	 * @param prefPharmName
	 * @param prefPharmPhone
	 * @param prefPharmAddr1
	 * @param prefPharmAddr2
	 * @param prefPharmCity
	 * @param prefPharmState
	 * @param prefPharmZipCode
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName		
	 */
	@Test(dataProvider = "getData", groups = { "Call Rep ETE" }) //TC241826
	public void testCallRepNewPatient(String callRepEmail, String callRepPwd, String newPatSampleGmail, String patPwd, String patFirstName, String patLastName, 
			String patMonth, String patDay, String patYear, String patGender, String patPrimaryPhone, String patZipCode, String visitReason, String medicines, String allergies, 
			String heighFeet, String heighInches, String weightLbs, String medCondition, String surgeries, String famMedProb, String smoke, String smokePacksNum, String jobProf, 
			String primDocName, String primDocPhone, String prefPharmName, String prefPharmPhone, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, 
			String prefPharmState, String prefPharmZipCode, String docEmail, String docPwd, String docName) {
		try {
			//Log-In as call rep to start patient consultation
			driverCallRep = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverCallRep);
			driverCallRep.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverCallRep);
			login.loginAsExistingUser(callRepEmail, callRepPwd, driverCallRep);		
			Thread.sleep(500);
			callRep.verifyNValidateOnCallRepPage(driverCallRep);	
			callRep.clickOnNewPatConsult(driverCallRep);
			callRepNewPatConsult.verifyNValidateOnCallRepNewPatPage(driverCallRep);
			String dynamicChars = VMedixUtils.generateDynamicString();
			String newPatEmail = VMedixUtils.generateEmailId(newPatSampleGmail, dynamicChars);
			patFirstName = patFirstName + dynamicChars;
			patLastName = patLastName + dynamicChars;
			callRepNewPatConsult.createNewPatNStartConsult(newPatEmail, patFirstName, patLastName, patMonth, patDay, patYear, patGender, patPrimaryPhone, 
					patZipCode, visitReason, medicines, allergies, driverCallRep);
			callRepConsultPayment.enterAutoInfoOnCallRepPayment(driverCallRep);
			cmnUtilsForPages.editNReviewMedicalHistoryOfPatient(heighFeet, heighInches, weightLbs, medCondition, surgeries, famMedProb, smoke, smokePacksNum, VMedixUtils.ALCOHOL_OCCASIONALLY, jobProf, 
					primDocName, primDocPhone, prefPharmName, prefPharmPhone, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverCallRep);
			callRepConsultInQueue.verifyNValidateOnCallRepConsultationInQueuePage(driverCallRep);			
			//Doctor Flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(false, patFirstName+ " " + patLastName, driverDoctor);	
			//Doctor- verify phone notify pop-up on doctor
			doctorConsultation.verifyNValidateDoctorOnPhoneNotifyPopUpWindow(driverDoctor);
			Thread.sleep(1000);
			doctorConsultation.clickOkOnPhoneNotifyPopUpWindow(driverDoctor);
			Thread.sleep(1000);
			doctorConsultation.verifyMedicalHistoryInConsult(visitReason, heighFeet, heighInches, weightLbs, medicines, allergies, medCondition, surgeries, 
					famMedProb, smoke, smokePacksNum, VMedixUtils.ALCOHOL_OCCASIONALLY, jobProf, primDocName, primDocPhone, 
					prefPharmName, prefPharmPhone, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverDoctor);
			doctorConsultation.endPhoneConsultationFromDoctor(driverDoctor);
			Thread.sleep(5000);
			ddscreen.submitDnD(driverDoctor);
			//doctor is back on tracking board
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
}
