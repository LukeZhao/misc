package tests.web.performance;

import org.testng.Assert;
import org.testng.annotations.Test;

import library.EnvironmentConfigSettings;
import tests.TestCaseInit;
import tests.web.smoke.DependentConsultationVideo;

public class NewUsers extends TestCaseInit {
	
	int perfRunNumber = EnvironmentConfigSettings.getPerformanceSynchronusRunNumberEnvConfig();

	/**
	* To Verify vmedix performance on NEW PATIENT and NEW DEPENDENT Video Flow 
	* @param newPatSampleGmail
	* @param patPwd
	* @param patFirstName
	* @param patLastName
	* @param patMonth
	* @param patDay
	* @param patYear
	* @param patGender
	* @param patPrimaryPhone
	* @param patZipCode
	* @param depFName
	* @param depLName
	* @param depDobMon
	* @param depDobDay
	* @param depGender
	* @param depPrimaryPhone
	* @param depZipCode 
	* @param visitReason
	* @param medications
	* @param allergies
	* @param docEmail
	* @param docPwd
	* @param docName
	* @throws Exception
	*/
	@Test(dataProvider = "getData", groups = { "Performance New Patient and Dependent Video" })
	public void testNewPatientDependentPerf(String newPatSampleGmail, String patPwd, String patFirstName, String patLastName, String patMonth, String patDay, String patYear, String patGender, 
			String patPrimaryPhone, String patZipCode, String depFName, String depLName, String depDobMon, String depDobDay, String depGender, String depPrimaryPhone, String depZipCode, 
			String visitReason, String medications, String allergies, String docEmail, String docPwd, String docName) throws Exception {
		try {
			DependentConsultationVideo depConsultVid = new DependentConsultationVideo();
			for(int i=1; i<=perfRunNumber; i++){	
				log.info("******Run number: "+i+ " Started..******");
				depConsultVid.testNewPatientNewDependent(newPatSampleGmail, patPwd, patFirstName, patLastName, patMonth, patDay, patYear, patGender, patPrimaryPhone, patZipCode, depFName, depLName, depDobMon, depDobDay, depGender, depPrimaryPhone, depZipCode, visitReason, medications, allergies, docEmail, docPwd, docName);
				log.info("******Run number: "+i+ " Ended.******");
				if(genLibWeb.quitAWebDriver(driverPatient)){
					driverPatient = null;
				}
				if(genLibWeb.quitAWebDriver(driverDoctor)){
					driverDoctor = null;
				}
			}
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
}
