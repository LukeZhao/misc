package tests.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.DoctorPreviousConsultationsPage;
import tests.TestCaseInit;

public class DoctorQAConsultations extends TestCaseInit{
	
	/**
	 * To verify previous consults under physician QA 
	 * @param qaDocEmail
	 * @param qaDocPwd
	 * @param reasonToViewConsultation
	 */
	@Test(dataProvider = "getData", groups = { "Doctor QA OtherDocConsultation" }) //TC_238065
	public void testAnotherDoctorsConsultation(String qaDocEmail, String qaDocPwd, String qaDocName, String reasonToViewConsultation) {
		try {
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(qaDocEmail, qaDocPwd, driverDoctor);
			doctorPage.verifyDoctorOnLandingPage(driverDoctor);
			docPrevConsult.clickOnPreviousConsults(driverDoctor);
			docPrevConsult.selectPrevConsultOfAnotherDoctor(qaDocName, driverDoctor);			
			docPrevConsult.verifyCancelNSubmitBtnsOnReasonPopUp(driverDoctor);
			docPrevConsult.verifyCancelActionOnReasonPopUp(driverDoctor);
			//click earlier selected prev consult for another doctor
			genLibWeb.clickOnElementByXPath(null, DoctorPreviousConsultationsPage.xpathValueForPrevConsultOfAnotherDoctor, driverDoctor);
			docPrevConsult.submitReasonForPrevConsult(reasonToViewConsultation, driverDoctor);
			docPrevConsult.verifyNValidatePreviousConsultationsPanelOnViewConsult(driverDoctor);
			docPrevConsult.verifyAuditLogWithReason(reasonToViewConsultation, driverDoctor);
			//close
			genLibWeb.clickOnElementByID("doctorPrevConsultCloseBtn.id", driverDoctor);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}	
}
