package tests.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import library.VMedixUtils;
import library.VMedixUtils.NotifyDoctorMethod;
import tests.TestCaseInit;;

public class DependentConsultationVideo extends TestCaseInit {
	/**
	* To Verify NEW DEPENDENT Video Flow 
	* @param extPatEmail
	* @param extPatPwd
	* @param depFName
	* @param depLName
	* @param dobMon
	* @param dobDay
	* @param gender
	* @param primPhone
	* @param zipCode
	* @param visitReason
	* @param medications
	* @param allergies
	* @param notifPhone
	* @param docEmail
	* @param docPwd
	* @param docName
	* @throws Exception
	*/
	@Test(dataProvider = "getData", groups = { "Dependent New Video" })//TC_234557, 241835
	public void testExistingPatientNewDependent(String extPatEmail, String extPatPwd, String depFName, String depLName, String dobMon, String dobDay, String gender, 
			String primPhone, String zipCode, String visitReason, String medications, String allergies, String notifPhone, String docEmail, String docPwd, String docName) throws Exception {
		try {
			// Log-In as existing patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(extPatEmail, extPatPwd, driverPatient);
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);	
			patientConsultReq.clickAddChild(driverPatient);
			dependent.verifyNValidateOnNewDependentPage(driverPatient);
			dependent.createAccountForNewDependent(depFName, depLName, dobMon, dobDay, gender, primPhone, zipCode, null, null, driverPatient);			
			patientConsultReq.fillConsultationFormForNewUser(true, visitReason, medications, allergies, driverPatient);			
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.verifyNValidatePatientOnHealthInfoPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.verifyNValidatePatientOnReviewHealthInfoPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.CALL_ME, notifPhone, driverPatient);
			Thread.sleep(2000);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);			
			//doctor flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, depFName+ " " + depLName, driverDoctor);
			//verify phone notify pop-up on doctor
			doctorConsultation.verifyNValidateDoctorOnPhoneNotifyPopUpWindow(driverDoctor);
			doctorConsultation.verifyNotificationNumOnPopUp(depFName, notifPhone, driverDoctor);
			doctorConsultation.clickOkOnPhoneNotifyPopUpWindow(driverDoctor);
			doctorConsultation.verifyNValidateDoctorIsWaitingOnPatient(driverDoctor);
			//Dependent patient - Begin Consultation
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);
			Thread.sleep(5000);//wait till the consultation begins
			//End Consultation From Doctor End
			doctorConsultation.endViDoctorConsultation(driverDoctor);
			ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);
			//submit D&D
			Thread.sleep(3000);//wait for the page to load and activate submit button
			ddscreen.submitDnD(driverDoctor);
			//doctor is back on tracking board
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);
			//patient on survey page
			survey.verifyNValidatePatientOnSurveyPage(driverPatient);
			Thread.sleep(2000);
			survey.skipSurvey(driverPatient);
			afterSurvey.verifyNValidatePatientOnAfterConsultationPage(driverPatient);
			//bring patient to home page
			afterSurvey.clickOnHomeOption(driverPatient);
			Thread.sleep(2000);
			patientPage.verifyPatientOnLandingPage(driverPatient);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}		
	}

	/**
	 * To verify Existing DEPENDANT FLOW for Video type. 
	 * @param extPatEmail
	 * @param extPatPwd
	 * @param extPatName
	 * @param depenFName
	 * @param depenlName
	 * @param visitReason
	 * @param patMedicinesEnt
	 * @param patAllergyEnt
	 * @param patMedConditionsEnt
	 * @param patSurgeriesEnt
	 * @param docEmail
	 * @param docPwd
	 * @param docName
	 * @param docMedicinesEnt
	 * @param docAllergyEnt
	 * @param docHeighFeetEnt 
	 * @param docHeighInchesEnt 
	 * @param docWeightLbsEnt 
	 * @param docMedConditionEnt 
	 * @param docSurgeriesEnt 
	 * @param docFamMedProbEnt 
	 * @param docSmokeEnt 
	 * @param docSmokePacksNumEnt 
	 * @param docJobProfEnt 
	 * @param docPrimDocNameEnt 
	 * @param docPrimDocPhoneEnt 
	 * @param docPrefPharmNameEnt 
	 * @param docPrefPharmPhoneEnt 
	 * @param docPrefPharmAddr1Ent 
	 * @param docPrefPharmAddr2Ent 
	 * @param docPrefPharmCityEnt 
	 * @param docPrefPharmStateEnt 
	 * @param docPrefPharmZipCodeEnt
	 * @param docMedicationsDnD 
	 * @param docAllergiesDnD
	 * @param diagCode
	 * @param followUp
	 * @param returnToSchWrk
	 * @param restrt
	 * @param durOfRestrt
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @param refundReason
	 * @throws Exception
	 */	
	@Test(dataProvider = "getData", groups = { "Dependent Existing Video" }) //TC_234558, TC_238057, TC_241833
	public void testExistingDependent(String extPatEmail, String extPatPwd, String extPatName, String depenFName, String depenLName, String visitReason, String patMedicinesEnt, String patAllergyEnt, 
			String patMedConditionsEnt, String patSurgeriesEnt, String docEmail, String docPwd, String docName, String docMedicinesEnt, String docAllergyEnt, String docHeighFeetEnt, String docHeighInchesEnt, 
			String docWeightLbsEnt, String docMedConditionEnt, String docSurgeriesEnt, String docFamMedProbEnt, String docSmokeEnt, String docSmokePacksNumEnt, String docJobProfEnt, 
			String docPrimDocNameEnt, String docPrimDocPhoneEnt, String docPrefPharmNameEnt, String docPrefPharmPhoneEnt, String docPrefPharmAddr1Ent, String docPrefPharmAddr2Ent, String docPrefPharmCityEnt,
			String docPrefPharmStateEnt, String docPrefPharmZipCodeEnt, String docMedicationsDnD, String docAllergiesDnD, String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, 
			String hpSoapSub, String hpSoapObj, String refundReason) throws Exception {
		try {				
			// Log-In as existing patient
			String patIsDepenName = depenFName +" "+depenLName;
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(extPatEmail, extPatPwd, driverPatient);
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			patientConsultReq.selectExistingDependent(depenFName, depenLName, driverPatient);
			dependent.verifyNValidateOnExistingDependentPage(driverPatient);
			patientConsultReq.fillConsultationForm(true, visitReason, patMedicinesEnt, patAllergyEnt, driverPatient);	
			patientConsultPayment.verifyPatientOnPaymentPage(driverPatient);
			String pricePart = patientConsultPayment.getConsultationFee(driverPatient);					
			String price = pricePart.indexOf(".") < 0 ? pricePart : pricePart.replaceAll("0*$", "").replaceAll("\\.$", "");//retrieve only amount from the text
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyNValidatePatientOnHealthInfoPage(driverPatient);	
			//remove old and add new medical conditions
			cmnUtilsForPages.removeOldMedicalConditions("patConsultHealthInfoMedCondOldListP.xpath", null, "patConsultHealthInfoMedCondOldRemoveSpan.xpath", driverPatient);
			if(!cmnUtilsForPages.enterMedicalConditions(patMedConditionsEnt,"patConsultHealthInfoMedCondInp.ngModel.xpath", null, "patConsultHealthInfoMedCondAddBtn.xpath", null, driverPatient)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Medical Conditions were NOT added");				
				Assert.fail("One of the Medical Conditions were NOT added");	
			}
			//remove old and add new surgeries
			cmnUtilsForPages.removeOldSurgeries("patConsultHealthInfoSurgeriesOldListP.xpath", null, "patConsultHealthInfoSurgeriesOldRemoveSpan.xpath", driverPatient);
			if(!cmnUtilsForPages.enterSurgeries(patSurgeriesEnt,"patConsultHealthInfoSurgeriesInp.ngModel.xpath", null, "patConsultHealthInfoSurgeriesAddBtn.xpath", null, driverPatient)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Surgeries were NOT added");				
				Assert.fail("One of the Surgeries were NOT added");	
			}
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.verifyNValidatePatientOnReviewHealthInfoPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.CONTINUE, null, driverPatient);
			Thread.sleep(2000);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
			//upload 2 photos
			int numberOfPhotosUpload = 2;
			patientConsultation.uploadFewPatientPhotos(numberOfPhotosUpload, driverPatient);

			//doctor flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);			
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patIsDepenName, driverDoctor);
			//Dependent patient - Begin Consultation
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);			
			Thread.sleep(2000);//wait to begin consultation
			//verify 2 photos seen on Doctor side
			doctorConsultation.verifyPhotosUploaded(numberOfPhotosUpload, driverDoctor);								
			//Verify patient added meds and allergies on doctor end and edit to new ones
			doctorConsultation.verifyVistNHealthInfo(visitReason, null, null, null, patMedicinesEnt, patAllergyEnt, driverDoctor);
			doctorConsultation.editMedicinesNAllergiesOfPatient(docMedicinesEnt, docAllergyEnt, driverDoctor);
			doctorConsultation.verifyMedNSocialHist(patMedConditionsEnt, patSurgeriesEnt, null, null, null, null, null, driverDoctor); // no fam med prob from pat
			doctorConsultation.clickOnMedicalHistoryEdit(driverDoctor); //click edit
			cmnUtilsForPages.editNReviewMedicalHistoryOfPatient(docHeighFeetEnt, docHeighInchesEnt, docWeightLbsEnt, docMedConditionEnt, docSurgeriesEnt, docFamMedProbEnt, docSmokeEnt, 
					docSmokePacksNumEnt, VMedixUtils.ALCOHOL_OCCASIONALLY, docJobProfEnt, docPrimDocNameEnt, docPrimDocPhoneEnt, docPrefPharmNameEnt, docPrefPharmPhoneEnt, docPrefPharmAddr1Ent, 
					docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, docPrefPharmZipCodeEnt, driverDoctor);
			Thread.sleep(1000);
			doctorConsultation.endViDoctorConsultation(driverDoctor);
			ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);
			ddscreen.verifyMedicationsNAllergiesFromInConsultation(docMedicinesEnt, docAllergyEnt, driverDoctor);				
			ddscreen.editMedicationsNAllergies(docMedicationsDnD, docAllergiesDnD, driverDoctor);
			ddscreen.editDnDValuesOnDnDPage(diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, null, driverDoctor);
			ddscreen.enterHnPTemplateSoapNotes(hpSoapSub, hpSoapObj, driverDoctor);
			ddscreen.requestRefund(refundReason, driverDoctor);
			ddscreen.submitDnD(driverDoctor);
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);
			//skip survey on patient end
			Thread.sleep(1000);
			survey.verifyNValidatePatientOnSurveyPage(driverPatient);
			survey.skipSurvey(driverPatient);
			afterSurvey.verifyNValidatePatientOnAfterConsultationPage(driverPatient);
			afterSurvey.verifyOptionsOnAfterConsult(driverPatient);				
			//bring patient to home page
			afterSurvey.clickOnHomeOption(driverPatient);
			Thread.sleep(2000);				
			//verify this consultation data on Doctor's previous consultation - discharge summary
			docPrevConsult.clickOnPreviousConsults(driverDoctor);
			docPrevConsult.findPrevConsultOfDoctor(docName, patIsDepenName, driverDoctor);
			Thread.sleep(3000); // wait for elements to load
			docPrevConsult.verifyNValidatePreviousConsultationsPanelOnViewConsult(driverDoctor);
			Thread.sleep(3000); // wait for elements to load				
			docPrevConsult.verifyPreviousConsultGeneralInfo(patIsDepenName, visitReason, null, diagCode, docPrefPharmNameEnt, docPrefPharmAddr1Ent, docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, 
					docPrefPharmZipCodeEnt, docPrefPharmPhoneEnt, numberOfPhotosUpload, driverDoctor); //email null as its dependent
			docPrevConsult.verifyPreviousConsultMedHistory(docPrimDocNameEnt, docPrimDocPhoneEnt, docSmokeEnt, docSmokePacksNumEnt, VMedixUtils.ALCOHOL_OCCASIONALLY, docHeighFeetEnt, docHeighInchesEnt, 
					docWeightLbsEnt, docAllergiesDnD, docFamMedProbEnt, docMedicationsDnD, docMedConditionEnt, docSurgeriesEnt, driverDoctor);
			docPrevConsult.verifyPreviousConsultSoapNotes(hpSoapSub, hpSoapObj, driverDoctor);
			String prevConsultPanelHandler = docPrevConsult.verifyPreviousConsultPatientDischargeRep(patIsDepenName, docName, price, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, null, driverDoctor);
			for (String winHandle : driverDoctor.getWindowHandles()) {
				if(!winHandle.equalsIgnoreCase(prevConsultPanelHandler)){
					driverDoctor.switchTo().window(winHandle); 
					break;
				}
			}
			driverDoctor.close();//close report window
			driverDoctor.switchTo().window(prevConsultPanelHandler);
			genLibWeb.scrollToViewElementWithID("doctorPrevConsultCloseBtn.id", driverDoctor);
			genLibWeb.clickOnElementByID("doctorPrevConsultCloseBtn.id", driverDoctor);
		
			//verify email received by Patient regarding the pdf report generation
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverGmail);				
			gmailPage.verifyNewConsultReportEmailForPatient(extPatEmail, extPatPwd, driverGmail);
			
			//verify all consultation info on Patient's consult History pdf - discharge summary
			patientPage.clickOnConsultHistoryOption(driverPatient);
			Thread.sleep(5000);
			patientConsultHistory.verifyNValidatePatientOnConsultHistoryPage(driverPatient);
			String pdfUrl = patientConsultHistory.getPatientConsultReportPDF(docName, driverPatient);
			String patConsultPanelHandler = patientConsultHistory.verifyPatConsultHistPdfReportData(pdfUrl, patIsDepenName, docName, price, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, null, driverPatient);// mostly D&D entries
			for (String winHandle : driverPatient.getWindowHandles()) {
				if(!winHandle.equalsIgnoreCase(patConsultPanelHandler)){
					driverPatient.switchTo().window(winHandle); 
					break;
				}
			}
			driverPatient.close();//close report window
			driverPatient.switchTo().window(patConsultPanelHandler);				
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}		
	}	
	
	/**
	* To Verify NEW PATIENT and NEW DEPENDENT Video Flow 
	* @param newPatSampleGmail
	* @param patPwd
	* @param patFirstName
	* @param patLastName
	* @param patMonth
	* @param patDay
	* @param patYear
	* @param patGender
	* @param patPrimaryPhone
	* @param patZipCode
	* @param depFName
	* @param depLName
	* @param depDobMon
	* @param depDobDay
	* @param depGender
	* @param depPrimaryPhone
	* @param depZipCode 
	* @param visitReason
	* @param medications
	* @param allergies
	* @param docEmail
	* @param docPwd
	* @param docName
	* @throws Exception
	*/
	@Test(dataProvider = "getData", groups = { "Dependent New Patient New Video" }) //TC_248608
	public void testNewPatientNewDependent(String newPatSampleGmail, String patPwd, String patFirstName, String patLastName, String patMonth, String patDay, String patYear, String patGender, 
			String patPrimaryPhone, String patZipCode, String depFName, String depLName, String depDobMon, String depDobDay, String depGender, String depPrimaryPhone, String depZipCode, 
			String visitReason, String medications, String allergies, String docEmail, String docPwd, String docName) throws Exception {
		try {	
			//register new patient 
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);			
			String dynamicChars = VMedixUtils.generateDynamicString();
			String newPatEmail = VMedixUtils.generateEmailId(newPatSampleGmail, dynamicChars);
			//appending the random chars to patient first and last name
			login.createAccountForNewPatient(newPatEmail, patPwd, patFirstName+dynamicChars, patLastName+dynamicChars, patMonth, patDay, patYear, patGender, patPrimaryPhone, patZipCode, null, null, driverPatient);		
			patientConsultReq.clickAddChild(driverPatient);
			dependent.verifyNValidateOnNewDependentPage(driverPatient);
			//appending the random chars to patient's dependent first and last name
			depFName = depFName+dynamicChars;
			depLName = depLName+dynamicChars;
			dependent.createAccountForNewDependentNoValidations(depFName, depLName, depDobMon, depDobDay, depGender, depPrimaryPhone, depZipCode, null, null, driverPatient);	
			patientConsultReq.fillConsultationFormForNewUser(true, visitReason, medications, allergies, driverPatient);			
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.verifyNValidatePatientOnHealthInfoPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.verifyNValidatePatientOnReviewHealthInfoPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);	
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);

			//doctor flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, depFName+ " " + depLName, driverDoctor);
			doctorConsultation.verifyNValidateDoctorIsWaitingOnPatient(driverDoctor);
			//dependent is the patient - Begin Consultation
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);
			Thread.sleep(5000);//wait till the consultation begins
			//end Consultation from Doctor End
			doctorConsultation.endViDoctorConsultation(driverDoctor);
			ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);
			//submit D&D
			Thread.sleep(3000);//wait for the page to load and activate submit button
			ddscreen.submitDnD(driverDoctor);
			//doctor is back on tracking board
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);
			//patient on survey page
			survey.verifyNValidatePatientOnSurveyPage(driverPatient);
			Thread.sleep(2000);
			survey.skipSurvey(driverPatient);
			afterSurvey.verifyNValidatePatientOnAfterConsultationPage(driverPatient);
			//bring patient to home page
			afterSurvey.clickOnHomeOption(driverPatient);
			Thread.sleep(2000);
			patientPage.verifyPatientOnLandingPage(driverPatient);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}	
	}	
}
