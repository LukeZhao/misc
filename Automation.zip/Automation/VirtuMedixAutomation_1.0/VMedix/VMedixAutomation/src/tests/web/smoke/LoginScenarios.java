package tests.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import tests.TestCaseInit;
public class LoginScenarios extends TestCaseInit {
	
	/**
	 * Checks various login scenario for a Doctor
	 * @param username
	 * @param password
	 * @param anomaly
	 */
	@Test(dataProvider = "getData", groups = { "Login scenarios" })
	public void testAuthenticateLogin(String username, String password, String anomaly) {
		try {
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			log.info("Logging in as a DOCTOR");				
			if (anomaly.equalsIgnoreCase("Invalid Username") || anomaly.equalsIgnoreCase("Invalid Password") || anomaly.equalsIgnoreCase("Invalid Username And Password")) {					
				if(!login.validateLoginAsExistingUser(username, password, driverDoctor)){
					testCaseStatus = true;
					log.info("Doctor Login was NOT successful with Bad Credentials for scenario: "+ anomaly);
				} else {
					testCaseStatus = false;
					log.error("Doctor Login was successful with Bad Credentials for scenario: "+ anomaly);
					Assert.fail("Doctor Login was successful with Bad Credentials for scenario: "+ anomaly);
				}			
			} else { //valid case	
				if(login.validateLoginAsExistingUser(username, password, driverDoctor) && (genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorLandingPageH1.xpath", null, driverDoctor))){
					testCaseStatus = true;
					log.info("Doctor Login was Successful with Valid Credentials for scenario: "+ anomaly);
				} else {
					testCaseStatus = false;
					log.error("Doctor Login was NOT Successful with Valid Credentials for scenario: "+ anomaly);
					Assert.fail("Doctor Login was NOT Successful with Valid Credentials for scenario: "+ anomaly);
				}
			}
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
}
