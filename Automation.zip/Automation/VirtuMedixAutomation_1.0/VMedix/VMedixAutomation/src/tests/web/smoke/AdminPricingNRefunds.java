package tests.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import library.VMedixUtils;
import library.VMedixUtils.NotifyDoctorMethod;
import tests.TestCaseInit;

public class AdminPricingNRefunds extends TestCaseInit {
	/**
	 * Test to Verify new coupon added by Admin on new patient consultation payment
	 * @param adminUsername
	 * @param adminPasswd
	 * @param sampleCoupon
	 * @param price
	 * @param newPatSampleGmail
	 * @param patPwd
	 * @param patFirstName
	 * @param patLastName
	 * @param patMonth
	 * @param patDay
	 * @param patYear
	 * @param patGender
	 * @param patPrimaryPhone
	 * @param patZipCode	 
	 * @param visitReason	
	 */
	@Test(dataProvider = "getData", groups = { "Admin Pricing N Refunds" }) //TC249098
	public void testAdminNewCouponNewPat(String adminUsername, String adminPasswd, String sampleCoupon, String price, String newPatSampleGmail, String patPwd, String patFirstName, String patLastName, String patMonth, String patDay, String patYear, String patGender, 
			String patPrimaryPhone, String patZipCode, String visitReason) {
		try {
			//admin
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);			
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			admin.clickOnPricingNRefundsCoupons(driverAdmin);
			adminPricNRefCoupons.verifyNValidateOnAdminPricingNRefundsCoupons(driverAdmin);
			sampleCoupon = sampleCoupon+ VMedixUtils.generateDynamicString();
			adminPricNRefCoupons.addNewCoupon(sampleCoupon, price, driverAdmin);			
			//register new patient 
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);			
			String dynamicChars = VMedixUtils.generateDynamicString();
			String newPatEmail = VMedixUtils.generateEmailId(newPatSampleGmail, dynamicChars);
			//appending the random chars to patient first and last name
			login.validateLoginAsNewPatient(newPatEmail, patPwd, patFirstName+dynamicChars, patLastName+dynamicChars, patMonth, patDay, patYear, patGender, patPrimaryPhone, patZipCode, driverPatient);
			//gmail verification
			driverGmail = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverGmail);				
			gmailPage.loginToGmailNValidateEmailVerificationForNewPatient(newPatEmail, patPwd, driverGmail);
			//pat consult
			genLibWeb.bringBrowserToFront(driverPatient.getWindowHandle(), driverPatient);			
			patientConsultReq.fillConsultationForm(true, visitReason, null, null, driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentWithCoupon(sampleCoupon, price, driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			//cancel the consult
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			Thread.sleep(1000);
			patientConsultation.cancelVideoOrPhoneConsultation(driverPatient);			
			patientPage.verifyPatientOnLandingPage(driverPatient);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test to Verify an existing coupon on an existing patient consultation payment
	 * @param extCoupon
	 * @param price
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param visitReason	
	 */
	@Test(dataProvider = "getData", groups = { "Admin Pricing N Refunds" }) //TC241837
	public void testAdminExistingCouponNPat(String extCoupon, String price, String patEmail, String patPwd, String patName, String visitReason) {
		try {
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			Thread.sleep(1000);
			patientConsultReq.fillConsultationForm(true, visitReason, null, null, driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentWithCoupon(extCoupon, price, driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			//cancel the consult
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			Thread.sleep(1000);
			patientConsultation.cancelVideoOrPhoneConsultation(driverPatient);			
			patientPage.verifyPatientOnLandingPage(driverPatient);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
		
	/**
	 * Test to Verify creating new price group and applying in a consult 
	 * @param adminUsername
	 * @param adminPasswd
	 * @param priceGrpNameSample
	 * @param priceGrpIdSample
	 * @param price
	 * @param memberId
	 * @param patEmail	
	 * @param patPwd	
	 * @param visitReason
	 */
	@Test(dataProvider = "getData", groups = { "Admin Pricing N Refunds" }) //TC241818
	public void testAdminNewPriceGroup(String adminUsername, String adminPasswd, String priceGrpNameSample, String priceGrpIdSample, String price, String memberId, 
			String patEmail, String patPwd, String visitReason) {
		try {	
			//admin
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);			
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			admin.clickOnPricingNRefundsPriceGroups(driverAdmin);
			adminPricNRefPriceGrp.verifyNValidateOnAdminPricingNRefundsPriceGroupsPage(driverAdmin);
			String dynChrs = VMedixUtils.generateDynamicString();
			priceGrpNameSample = priceGrpNameSample+ dynChrs;
			priceGrpIdSample = priceGrpIdSample+dynChrs;	
			adminPricNRefPriceGrp.addNewPriceGroup(priceGrpNameSample, priceGrpIdSample, price, memberId, driverAdmin);
			//verify in the priceGroup list
			genLibWeb.clickOnElementByClass("logoH1.class", driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			admin.clickOnPricingNRefundsPriceGroups(driverAdmin);
			adminPricNRefPriceGrp.verifyNValidateOnAdminPricingNRefundsPriceGroupsPage(driverAdmin);
			adminPricNRefPriceGrp.verifyInPriceGroupList(priceGrpNameSample, priceGrpIdSample, price, driverAdmin);
			//apply to the patient
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			Thread.sleep(1000);
			patientConsultReq.fillConsultationForm(true, visitReason, null, null, driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentWithValidPriceGroup(priceGrpIdSample, memberId, price, driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			//cancel the consult
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			Thread.sleep(1000);
			patientConsultation.cancelVideoOrPhoneConsultation(driverPatient);			
			patientPage.verifyPatientOnLandingPage(driverPatient);		
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test to Verify entering an invalid price group and edit to valid on patient consult payment 
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param visitReason
	 * @param priceGroupId
	 * @param memberId
	 * @param priceGrpAmount
	 */
	@Test(dataProvider = "getData", groups = { "Admin Pricing N Refunds" }) //TC241836
	public void testInvalidPriceGroupNEdit(String patEmail, String patPwd, String patName, String visitReason, String priceGroupId, String memberId, String priceGrpAmount) {
		try {
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			Thread.sleep(1000);
			patientConsultReq.fillConsultationForm(true, visitReason, null, null, driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentWithInvalidPriceGroupNEdited(priceGroupId, memberId, priceGrpAmount, driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			//cancel the consult
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			Thread.sleep(1000);
			patientConsultation.cancelVideoOrPhoneConsultation(driverPatient);			
			patientPage.verifyPatientOnLandingPage(driverPatient);			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test to Verify entering an Valid price group on patient consult payment 
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param visitReason
	 * @param priceGroupId
	 * @param memberId
	 * @param priceGrpAmount
	 */
	@Test(dataProvider = "getData", groups = { "Admin Pricing N Refunds" }) //TC241840
	public void testValidPriceGroup(String patEmail, String patPwd, String patName, String visitReason, String priceGroupId, String memberId, String priceGrpAmount) {
		try {
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			Thread.sleep(1000);
			patientConsultReq.fillConsultationForm(true, visitReason, null, null, driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentWithValidPriceGroup(priceGroupId, memberId, priceGrpAmount, driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			//cancel the consult
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			Thread.sleep(1000);
			patientConsultation.cancelVideoOrPhoneConsultation(driverPatient);			
			patientPage.verifyPatientOnLandingPage(driverPatient);			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test to Verify editing Consultation fee
	 * @param adminUsername
	 * @param adminPasswd
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param visitReason
	 */
	@Test(dataProvider = "getData", groups = { "Admin Pricing N Refunds" }) //TC241815
	public void testConsultationFeeEdits(String adminUsername, String adminPasswd, String patEmail, String patPwd, String patName, String visitReason) {
		try {
			//admin
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);			
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			admin.clickOnPricingNRefundsConsultationFee(driverAdmin);
			adminPricNRefConsultFee.verifyNValidateOnAdminPricingNRefundsConsultFeePage(driverAdmin);
			Thread.sleep(1000);
			String originalconsultFee = adminPricNRefConsultFee.getConsultFee(driverAdmin);
			String newConsultFee =  new Double(Double.parseDouble(originalconsultFee) + 5).toString();// adding 5 
			adminPricNRefConsultFee.editConsultFee(newConsultFee, driverAdmin);
			//verify if the change is listed
			genLibWeb.clickOnElementByClass("logoH1.class", driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			admin.clickOnPricingNRefundsConsultationFee(driverAdmin);
			adminPricNRefConsultFee.verifyNValidateOnAdminPricingNRefundsConsultFeePage(driverAdmin);
			Thread.sleep(1000);
			if(!newConsultFee.equalsIgnoreCase(adminPricNRefConsultFee.getConsultFee(driverAdmin))){
				TestCaseInit.testCaseStatus = false;
				log.error("New Consultation Fee NOT listed on consult fee page: " + newConsultFee);
				Assert.fail("New Consultation Fee NOT listed on consult fee page" + newConsultFee);
			}
			log.info("New Consultation Fee Listed on consult fee page: " + newConsultFee);
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			Thread.sleep(1000);
			patientConsultReq.fillConsultationForm(true, visitReason, null, null, driverPatient);
			patientConsultPayment.verifyNValidatePatientOnPaymentPage(driverPatient);
			if(!newConsultFee.equalsIgnoreCase(patientConsultPayment.getConsultationFee(driverPatient))){
				TestCaseInit.testCaseStatus = false;
				log.error("New Consultation Fee NOT correct on Patient Payment page: " + newConsultFee);
				Assert.fail("New Consultation Fee NOT correct on Patient Payment page: " + newConsultFee);
			}
			log.info("New Consultation Fee is Correct on Patient Payment page: " + newConsultFee);			
			// Revert consultation fee to original
			genLibWeb.bringBrowserToFront(driverAdmin.getWindowHandle(), driverAdmin);
			adminPricNRefConsultFee.verifyNValidateOnAdminPricingNRefundsConsultFeePage(driverAdmin);
			adminPricNRefConsultFee.editConsultFee(originalconsultFee, driverAdmin);			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test to Verify consultation refund approve and reject
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param visitReason
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 * @param adminUsername
	 * @param adminPasswd
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param visitReason
	 */
	@Test(dataProvider = "getData", groups = { "Admin Pricing N Refunds" }) //TC241824
	public void testRefundApproveNReject(String patEmail, String patPwd, String patName, String visitReason, String docEmail, String docPwd, String docName, String adminUsername, String adminPasswd, 
			String anthrPatEmail, String anthrPatPwd, String anthrPatName, String anthrPatVisitReason) {
		try {
			log.info("Verify Refund Approve Action!");
			verifyRefundAction(true, patEmail, patPwd, patName, visitReason, docEmail, docPwd, docName, adminUsername, adminPasswd);
			Thread.sleep(1000);
			//close patient driver to start another patient consultation
			if(genLibWeb.quitAWebDriver(driverPatient)){
				driverPatient = null;
			}
			log.info("Verify Refund Reject Action!");
			verifyRefundAction(false, anthrPatEmail, anthrPatPwd, anthrPatName, anthrPatVisitReason, docEmail, docPwd, docName, adminUsername, adminPasswd);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	private void verifyRefundAction(Boolean refundApproveAction, String patEmail, String patPwd, String patName, String visitReason, String docEmail, String docPwd, String docName, String adminUsername, String adminPasswd) throws Exception {
		//Log-In as patient
		driverPatient = genLibWeb.getWebDriver(browserPatient);
		genLibWeb.setImplicitWait(driverPatient);
		driverPatient.get(webUrl);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
		login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
		patientPage.verifyAndBringPatientToLandingPage(driverPatient);
		Thread.sleep(1000);
		patientConsultReq.fillConsultationForm(true, visitReason, null, null, driverPatient);
		patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
		//cancel the consult
		patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
		Thread.sleep(1000);			
		//Doctor Flow
		if(refundApproveAction){
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
		} else{
			genLibWeb.bringBrowserToFront(driverDoctor.getWindowHandle(), driverDoctor);
			driverDoctor.navigate().refresh();
			Thread.sleep(1000);
		}
		doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
		trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patName, driverDoctor);			
		//Patient - Begin Consultation
		patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);			
		//Doctor - end consultation
		Thread.sleep(5000);//wait till the consultation begins
		doctorConsultation.endViDoctorConsultation(driverDoctor);				
		//Doctor on DnD 			
		ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);
		if(refundApproveAction){
			ddscreen.requestRefund("Test refund Approve", driverDoctor);
		} else{
			ddscreen.requestRefund("Test refund Reject", driverDoctor);
		}
		ddscreen.submitDnD(driverDoctor);
		//verify admin approves refund
		//admin
		if(refundApproveAction){
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);	
		} else{
			genLibWeb.bringBrowserToFront(driverAdmin.getWindowHandle(), driverAdmin);
		}
		admin.verifyNValidateOnDocAdminPage(driverAdmin);
		admin.clickOnPricingNRefundsRefunds(driverAdmin);
		adminPricNRefRefunds.verifyNValidateOnAdminPricingNRefundsRefundsPage(driverAdmin);
		if(refundApproveAction){
			adminPricNRefRefunds.approveRefund(patEmail, docName, driverAdmin);
		}else{
			adminPricNRefRefunds.rejectRefund(patEmail, docName, driverAdmin);
		}
		//verify on previous consults
		genLibWeb.clickOnElementByClass("logoH1.class", driverAdmin);
		admin.verifyNValidateOnDocAdminPage(driverAdmin);
		admin.clickOnOtherElemsPrevConsults(driverAdmin);
		Thread.sleep(3000);//wait for page to load with prev consults
		adminOthrElemPrevConsults.verifyNValidateOnAdminOtherElemsPrevConsultsPage(driverAdmin);
		if(refundApproveAction){
			adminOthrElemPrevConsults.verifyRefundSuccessOnPrevConsults(patEmail, docName, driverAdmin);
		}else{
			adminOthrElemPrevConsults.verifyRefundRejectedOnPrevConsults(patEmail, docName, driverAdmin);
		}		
		genLibWeb.clickOnElementByClass("logoH1.class", driverAdmin);
	}
}
