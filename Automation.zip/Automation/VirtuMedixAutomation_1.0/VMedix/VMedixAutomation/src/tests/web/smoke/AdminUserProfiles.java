 package tests.web.smoke;

import java.text.MessageFormat;

import org.testng.Assert;
import org.testng.annotations.Test;

import library.VMedixUtils;
import tests.TestCaseInit;
public class AdminUserProfiles extends TestCaseInit{
	
	final String newDoctorRole = "doctor"; 
	final String newDoctorNotificationPref = "sms"; 
	
	/**
	 * Test to validate Password Reset Email for Doctor by Admin 
	 * @param adminUsername
	 * @param adminPasswd
	 * @param docName
	 * @param docEmail
	 * @param docPasswd
	 */
	@Test(dataProvider = "getData", groups = { "Admin UserProfiles" }) //TC-237524
	public void testPwdResetEmailForDoc(String adminUsername, String adminPasswd, String docName, String docEmail, String docPasswd) {
		try {
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			genLibWeb.clickOnElementByXPath("docAdminDoctorsProfileLinkAnc.xpath", null, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminDoctorsProfilePageTitleH1.xpath", null, driverAdmin);
			genLibWeb.enterTextValueByName("docAdminUserProfileSearchInp.name", docEmail, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminUserProfileSearchBtn.ngClick.xpath", null, driverAdmin);
			genLibWeb.clickOnElementByXPath("docAdminUserProfileSearchBtn.ngClick.xpath", null, driverAdmin);
			admin.sendPasswordReset(docName, driverAdmin);			
			if(genLibWeb.validateExpectedWithActualByXPath(MessageFormat.format(TestCaseInit.messagesVMedixProp.getProperty("resetPassword.success"), docName), "toastMsg.xpath", null, driverAdmin)){
				log.info("Password reset Sent");
			}else{
				testCaseStatus = false;
				log.error("Failed to send password reset for doctor by doc admin");
				Assert.fail("Failed to send password reset for doctor by doc admin");
			}
			//verify reset pwd email for doctor on gmail
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.validateResetPasswordEmailRecieved(docEmail, docPasswd, driverGmail);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test to validate Password Reset Email for Patient by Admin
	 * @param patientName
	 * @param adminUsername
	 * @param adminPasswd
	 * @param patientEmail
	 * @param patientPasswd
	 */
	@Test(dataProvider = "getData", groups = { "Admin UserProfiles" }) //TC-238084
	public void testPwdResetEmailForPat(String adminUsername, String adminPasswd, String patientName, String patientEmail, String patientPasswd) {
		try {
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			genLibWeb.clickOnElementByXPath("docAdminPatientsProfileLinkAnc.xpath", null, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminPatientsProfilePageTitleH1.xpath", null, driverAdmin);
			genLibWeb.enterTextValueByName("docAdminUserProfileSearchInp.name", patientEmail, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminUserProfileSearchBtn.ngClick.xpath", null, driverAdmin);
			genLibWeb.clickOnElementByXPath("docAdminUserProfileSearchBtn.ngClick.xpath", null, driverAdmin);
			Thread.sleep(1000);
			if(genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminPatientProfileSendPwdResetLinkAnc.ngClick.xpath", null, driverAdmin)){
				genLibWeb.clickOnElementByXPath("docAdminPatientProfileSendPwdResetLinkAnc.ngClick.xpath", null, driverAdmin);
				log.info("Password Reset Link is clicked for: "+ patientName);
			} else {
				TestCaseInit.testCaseStatus = false;
				log.error("User: "+patientName+" NOT found for Reset Password");
				Assert.fail("User: "+patientName+" NOT found for Reset Password");
			}			
			if(genLibWeb.validateExpectedWithActualByXPath(MessageFormat.format(TestCaseInit.messagesVMedixProp.getProperty("resetPassword.success"), patientName), "toastMsg.xpath", null, driverAdmin)){
				log.info("Password reset Sent");
			}else{
				testCaseStatus = false;
				log.error("Failed to send password reset for patient by doc admin");
				Assert.fail("Failed to send password reset for patient by doc admin");
			}
			//verify reset pwd email for patient on gmail
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.validateResetPasswordEmailRecieved(patientEmail, patientPasswd, driverGmail);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
 
	/**
	 * Test to validate the password reset functionality for a new Administrator by Admin
	 * @param adminUsername
	 * @param adminPasswd
	 * @param firstName
	 * @param lastName
	 * @param phone
	 * @param newPasswd
	 */
	@Test(dataProvider = "getData", groups = { "Admin UserProfiles" })//TC-237528, TC-241813
	public void testEmailNResetPwdForNewAdmin(String adminUsername, String adminPasswd, String firstName, String lastName, String phone, String newPasswd) {
		try {
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			genLibWeb.clickOnElementByXPath("docAdminAdministratorsProfileLinkAnc.xpath", null, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminAdministratorsProfilePageTitleH1.xpath", null, driverAdmin);
			Thread.sleep(1000);
			if(genLibWeb.explicitWaitUntilElementWithNameIsVisible("docAdminAddNewUserLinkAnc.name", driverAdmin)){
				genLibWeb.clickOnElementByName("docAdminAddNewUserLinkAnc.name", driverAdmin);
			}
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminNewAdministratorPageTitleH1.xpath", null, driverAdmin);
			genLibWeb.enterTextValueByXPath("docAdminNewAdminFirstnameInp.ngModel.xpath", null, firstName, driverAdmin);
			genLibWeb.enterTextValueByXPath("docAdminNewAdminLastnameInp.ngModel.xpath", null, lastName, driverAdmin);
			String emailForRegister = VMedixUtils.generateEmailId(adminUsername, VMedixUtils.generateDynamicString());
			genLibWeb.enterTextValueByXPath("docAdminNewAdminEmailInp.ngModel.xpath", null, emailForRegister, driverAdmin);
			genLibWeb.enterTextValueByXPath("docAdminAddNewUserPhoneInp.ngModel.xpath", null, phone, driverAdmin);
			genLibWeb.clickOnElementByName("docAdminNewAdminSaveBtn.name", driverAdmin);
			if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("createdUserByAdmin.success"), "toastMsg.xpath", null, driverAdmin)){
				testCaseStatus = false;
				log.error("Failed to create New Administrator");
				Assert.fail("Failed to create New Administrator");
			}
			log.info("Successfully created New Administrator with email: " + emailForRegister);	
			
			//gmail verification
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.loginToGmailNValidateEmailVerificationAndPasswordReset(emailForRegister, adminPasswd, newPasswd, VMedixUtils.USERTYPE_DOCTORADMIN, driverGmail);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}  
	}
	
	/**
	 * Test to validate the password reset functionality for Doctor's by Admin
	 * @param adminUsername
	 * @param adminPasswd
	 * @param firstName
	 * @param lastName
	 * @param phone
	 * @param npi
	 * @param dea
	 * @param newDocGmailSample
	 * @param gmailPwd
	 * @param newPasswd
	 */
	@Test(dataProvider = "getData", groups = { "Admin UserProfiles" })//TC-237526, TC-241811
	public void testEmailNResetPwdForNewDoc(String adminUsername, String adminPasswd, String firstName, String lastName, String phone, String npi, String dea, String newDocGmailSample, String gmailPwd, String newPasswd) {
		try {
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			genLibWeb.clickOnElementByXPath("docAdminDoctorsProfileLinkAnc.xpath", null, driverAdmin);
			genLibWeb.isElementFoundByXPath("docAdminDoctorsProfilePageTitleH1.xpath", null, driverAdmin);
			Thread.sleep(1000);
			if(genLibWeb.explicitWaitUntilElementWithNameIsVisible("docAdminAddNewUserLinkAnc.name", driverAdmin)){
				genLibWeb.clickOnElementByName("docAdminAddNewUserLinkAnc.name", driverAdmin);
			}
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminNewDocPageTitleH1.xpath", null, driverAdmin);
			genLibWeb.selectByValueFromSelectElementID("docAdminNewDocRoleDrpBx.id", newDoctorRole, driverAdmin);
			genLibWeb.enterTextValueByName("docAdminNewDocFirstnameInp.name", firstName, driverAdmin);
			genLibWeb.enterTextValueByName("docAdminNewDocLastnameInp.name", lastName, driverAdmin);
			genLibWeb.clickOnElementByID("docAdminNewDocGenderFemaleRdLabel.id", driverAdmin);//gender - female
			genLibWeb.selectByValueFromSelectElementID("docAdminNewDocNotifPrefDrpBx.id", newDoctorNotificationPref, driverAdmin);
			String emailForRegister = VMedixUtils.generateEmailId(newDocGmailSample, VMedixUtils.generateDynamicString());//using the gmail for vmedix email registration
			genLibWeb.enterTextValueByName("docAdminNewDocEmailInp.name", emailForRegister, driverAdmin);
			genLibWeb.enterTextValueByXPath("docAdminAddNewUserPhoneInp.ngModel.xpath", null, phone, driverAdmin);
			genLibWeb.enterTextValueByName("docAdminNewDocNpiInp.name", npi, driverAdmin);
			genLibWeb.enterTextValueByName("docAdminNewDocDeaInp.name", dea, driverAdmin);
			genLibWeb.clickOnElementByName("docAdminNewDocSaveBtn.name", driverAdmin);
			if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("createdUserByAdmin.success"), "toastMsg.xpath", null, driverAdmin)){
				testCaseStatus = false;
				log.error("Failed to create New Doctor");
				Assert.fail("Failed to create New Doctor");
			}
			log.info("Successfully created New Doctor with email: "+ emailForRegister);	
			
			//gmail verification
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.loginToGmailNValidateEmailVerificationAndPasswordReset(emailForRegister, gmailPwd, newPasswd, VMedixUtils.USERTYPE_DOCTOR, driverGmail);
			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test to validate the password reset functionality for new Call Rep by call rep Admin
	 * @param callrepAdminUsrName
	 * @param callRepAdminPwd
	 * @param firstName
	 * @param lastName
	 * @param phone
	 * @param newCallRepGmailSample
	 * @param gmailPwd
	 * @param newPasswd
	 */
	@Test(dataProvider = "getData", groups = { "Admin UserProfiles" })//TC-241820
	public void testEmailNResetPwdForNewCallRep(String callrepAdminUsrName, String callRepAdminPwd, String firstName, String lastName, String phone, String newCallRepGmailSample, String gmailPwd, String newPasswd) {
		try {
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(callrepAdminUsrName, callRepAdminPwd, driverAdmin);
			callRepAdmin.verifyNValidateOnCallRepAdminPage(driverAdmin);			
			callRepAdmin.clickCallCenterAgentsUserProfiles(driverAdmin);
			adminCallCenterAgents.verifyNValidateOnCallCenterAgentsPage(driverAdmin);
			String emailForRegister = VMedixUtils.generateEmailId(newCallRepGmailSample, VMedixUtils.generateDynamicString());//using the gmail for vmedix email registration
			adminCallCenterAgents.addNewCallCenter(firstName, lastName, phone, emailForRegister, driverAdmin);
			//gmail verification
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.loginToGmailNValidateEmailVerificationAndPasswordReset(emailForRegister, gmailPwd, newPasswd, VMedixUtils.USERTYPE_CALLREP, driverGmail);			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
}
