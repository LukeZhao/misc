package tests.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;
import tests.TestCaseInit;

public class DoctorConsultations extends TestCaseInit {
	
	/**
	 * To verify one consultation required values are not null. Assuming we are picking the first consultation 
	 * @param docEmail
	 * @param password
	 */
	@Test(dataProvider = "getData", groups = { "Doctor PreviousConsultation" }) //TC_238059
	public void testPreviousConsultation(String docEmail, String password) {
		try {
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			//Log-In as a doctor
			login.loginAsExistingUser(docEmail, password, driverDoctor);
			doctorPage.verifyDoctorOnLandingPage(driverDoctor);
			docPrevConsult.clickOnPreviousConsults(driverDoctor);
			docPrevConsult.clickOnViewConsults(driverDoctor);
			docPrevConsult.assertRequiredDataOnPrevConsult(driverDoctor);
			//close and log out
			genLibWeb.clickOnElementByID("doctorPrevConsultCloseBtn.id", driverDoctor);
			Thread.sleep(1000);
			genLibWeb.clickOnElementByXPath("logoutRef.xpath", null, driverDoctor);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}		
	}
}
