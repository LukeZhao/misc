package tests.web.smoke;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.Test;

import library.VMedixUtils;
import tests.TestCaseInit;


public class AdminReports extends TestCaseInit{
	//NOTE: All tests Fail on Sauce labs, UTC time issue VM-3949 
	
	final String reportDatesLast7Days = "last7days";
	final String reportDatesLastMonth = "lastmonth";
	final String reportDatesCustom = "custom";
	final String auditTrailReportTitlePrefix = "audit_trail_report_";
	final String surveyResultsReportTitlePrefix = "surveys_report_";
	final String consultSummaryReportTitlePrefix = "consultation_summary_report_";
	
	/**
	 * Test to check Audit trail admin Reports for Last 7 Days
	 * @param adminUsername
	 * @param adminPasswd
	 * @param patientEmail
	 * @param doctorEmail
	 */
	@Test(dataProvider = "getData", groups = { "Admin Reports" }) //TC_237303
	public void testAuditTrailRep7Days(String adminUsername, String adminPasswd, String patientEmail, String doctorEmail) {
		try {			
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			genLibWeb.clickOnElementByName("docAdminRepAuditTrailLinkAnc.name", driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminRepAuditTrailPageTitleH1.xpath", null, driverAdmin);
			genLibWeb.enterTextValueByXPath("docAdminRepAuditTrailPatEmailInp.ngModel.xpath", null, patientEmail, driverAdmin);
			genLibWeb.enterTextValueByXPath("docAdminRepAuditTrailDocEmailInp.ngModel.xpath", null, doctorEmail, driverAdmin);
			genLibWeb.selectByValueFromSelectElementName("docAdminRepDatesDrpBx.name", reportDatesLast7Days, driverAdmin);
			genLibWeb.clickOnElementByID("docAdminRepAuditTrailFormatPdfRdLabel.id", driverAdmin);//pdf
			genLibWeb.clickOnElementByXPath("docAdminRunReportBtn.ngClick.xpath", null, driverAdmin);
			Thread.sleep(1000);			
			if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("auditTrailReport.success"), "toastMsg.xpath", null, driverAdmin)){
				testCaseStatus = false;
				log.error("Failed to run reports for Admin Audit Trail report");
				Assert.fail("Failed to run reports for Admin Audit Trail report");
			}
			log.info("Successfully ran reports for Admin Audit Trail report");
			String adminWindowHandle = driverAdmin.getWindowHandle();
			
			//startDate and endDate for verification in file name
			String format = "yyyy-MM-dd";
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			Date date = new Date();
			String currDate = dateFormat.format(date);
			Calendar cal = Calendar.getInstance();    
			cal.setTime(dateFormat.parse(currDate));
			//from date
			String endDate = dateFormat.format(cal.getTime());    
			//To date
			cal.setTime(dateFormat.parse(currDate)); 
			cal.add(Calendar.DAY_OF_MONTH, -7);
			String startDate = dateFormat.format(cal.getTime()); 
			String reportName = auditTrailReportTitlePrefix + startDate + "_to_" + endDate+".pdf";
						
//			gmail verification
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.loginGmailAsAdminToVerifyReports(adminUsername, adminPasswd, reportName , driverGmail);
			
			//validate if on admin console
			Thread.sleep(1000);
			genLibWeb.bringBrowserToFront(adminWindowHandle, driverAdmin);
			admin.validateRepInGeneratedReportsConsole(reportName, driverAdmin);			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}	
	
	/**
	 * Test to check Audit trail admin Reports for Last Month
	 * @param adminUsername
	 * @param adminPasswd
	 * @param patientEmail
	 * @param doctorEmail
	 */
	@Test(dataProvider = "getData", groups = { "Admin Reports" }) //TC_237523
	public void testAuditTrailRepLastMonth(String adminUsername, String adminPasswd, String patientEmail, String doctorEmail) {
		try {					
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			genLibWeb.clickOnElementByName("docAdminRepAuditTrailLinkAnc.name", driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminRepAuditTrailPageTitleH1.xpath", null, driverAdmin);
			genLibWeb.enterTextValueByXPath("docAdminRepAuditTrailPatEmailInp.ngModel.xpath", null, patientEmail, driverAdmin);
			genLibWeb.enterTextValueByXPath("docAdminRepAuditTrailDocEmailInp.ngModel.xpath", null, doctorEmail, driverAdmin);
			genLibWeb.selectByValueFromSelectElementName("docAdminRepDatesDrpBx.name", reportDatesLastMonth, driverAdmin);
			genLibWeb.clickOnElementByID("docAdminRepAuditTrailFormatPdfRdLabel.id", driverAdmin);//pdf
			genLibWeb.clickOnElementByXPath("docAdminRunReportBtn.ngClick.xpath", null, driverAdmin);
			Thread.sleep(1000);
			if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("auditTrailReport.success"), "toastMsg.xpath", null, driverAdmin)){
				testCaseStatus = false;
				log.error("Failed to run reports for Admin Audit Trail report");
				Assert.fail("Failed to run reports for Admin Audit Trail report");				
			}
			log.info("Successfully ran reports for Admin Audit Trail report");
			String adminWindowHandle = driverAdmin.getWindowHandle();
			
			//startDate and endDate for verification in file name
			String format = "yyyy-MM-dd";
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			//start date
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH, -1);
			cal.set(Calendar.DATE, 1);
			String startDate = dateFormat.format(cal.getTime()); //yesterday			
			//end date
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			String endDate = dateFormat.format(cal.getTime()); //today
			String reportName = auditTrailReportTitlePrefix + startDate + "_to_" + endDate+".pdf";

			//gmail verification
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.loginGmailAsAdminToVerifyReports(adminUsername, adminPasswd, reportName , driverGmail);
			
			//validate if on admin console
			Thread.sleep(1000);
			genLibWeb.bringBrowserToFront(adminWindowHandle, driverAdmin);
			admin.validateRepInGeneratedReportsConsole(reportName, driverAdmin);			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}	  
	}
	
	/** 
	 * Test to check Survey results report for Custom dates
	 * @param adminUsername
	 * @param adminPasswd
	 */
	@Test(dataProvider = "getData", groups = { "Admin Reports" })  //TC_237527
	public void testSurveyResultsRepCustDates(String adminUsername, String adminPasswd) {
		try {
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			genLibWeb.clickOnElementByName("docAdminRepSurveyResultsLinkAnc.name", driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminRepSurveyResultsPageTitleH1.xpath", null, driverAdmin);				
			//startDate and endDate for verification in file name
			String format = "yyyy-MM-dd";
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			//to
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date()); //today
			int toDay = cal.get(Calendar.DAY_OF_MONTH);
			//from
			cal.setTime(new Date()); //today
			cal.add(Calendar.DAY_OF_MONTH, -1);
			int fromDay = cal.get(Calendar.DAY_OF_MONTH);
			String datePickXpathVal = TestCaseInit.webLocatorProp.getProperty("docAdminReportsCustomDatePickerTd.xpath");
			String datePickFromDateXpathVal = MessageFormat.format(datePickXpathVal, Integer.toString(fromDay));
			String datePickToDateXpathVal = MessageFormat.format(datePickXpathVal, Integer.toString(toDay));
			genLibWeb.selectByValueFromSelectElementName("docAdminRepDatesDrpBx.name", reportDatesCustom, driverAdmin);
			genLibWeb.clickOnElementByID("docAdminReportsCustFromDate.id", driverAdmin);
			genLibWeb.clickOnElementByXPath(null, datePickFromDateXpathVal, driverAdmin);
			genLibWeb.clickOnElementByXPath(null, datePickToDateXpathVal, driverAdmin);	
			//get selected dates
			String startDateUI = genLibWeb.getValueByID("docAdminReportsCustFromDate.id", driverAdmin);
			String endDateUI = genLibWeb.getValueByID("docAdminReportsCustToDate.id", driverAdmin);	
			//run reports
			genLibWeb.clickOnElementByXPath("docAdminRunReportBtn.ngClick.xpath", null, driverAdmin);
			Thread.sleep(1000);
			if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("surveyResultReport.success"), "toastMsg.xpath", null, driverAdmin)){
				testCaseStatus = false;
				log.error("Failed to run reports for Survey Result report");
				Assert.fail("Failed to run reports for Survey Result report");
			}
			log.info("Successfully ran reports for Survey Result report");
			String adminWindowHandle = driverAdmin.getWindowHandle();
			
			SimpleDateFormat uiFormat = new SimpleDateFormat("MM/dd/yyyy");
			String startDate = dateFormat.format(uiFormat.parse(startDateUI));
			String endDate = dateFormat.format(uiFormat.parse(endDateUI));			
			String reportName = surveyResultsReportTitlePrefix + startDate + "_to_" + endDate+".pdf";//default pdf
			
			//gmail verification
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.loginGmailAsAdminToVerifyReports(adminUsername, adminPasswd, reportName , driverGmail);
			
			//validate if on admin console
			Thread.sleep(1000);
			genLibWeb.bringBrowserToFront(adminWindowHandle, driverAdmin);
			admin.validateRepInGeneratedReportsConsole(reportName, driverAdmin);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}	
	}	
	
	/**
	 * Test to check Consultation Summary report for Custom dates
	 * @param adminUsername
	 * @param adminPasswd
	 */
	@Test(dataProvider = "getData", groups = { "Admin Reports" }) //TC_237520, TC_241822
	public void testConsultationSumRepCustDates(String adminUsername, String adminPasswd) {//Admin Consultation Summary report with custom dates and csv file verification
		try {
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			genLibWeb.clickOnElementByName("docAdminRepConsultSummaryLinkAnc.name", driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminRepConsultSummaryPageTitleH1.xpath", null, driverAdmin);		
			
			//startDate and endDate for verification in file name
			String format = "yyyy-MM-dd";
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			//to
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date()); 
			int toDay = cal.get(Calendar.DAY_OF_MONTH);		
			//from
			cal.setTime(new Date()); //today
			cal.add(Calendar.DAY_OF_MONTH, -2);
			int fromDay = cal.get(Calendar.DAY_OF_MONTH);

			String datePickXpathVal = TestCaseInit.webLocatorProp.getProperty("docAdminReportsCustomDatePickerTd.xpath");
			String datePickFromDateXpathVal = MessageFormat.format(datePickXpathVal, Integer.toString(fromDay));
			String datePickToDateXpathVal = MessageFormat.format(datePickXpathVal, Integer.toString(toDay));
			genLibWeb.selectByValueFromSelectElementName("docAdminRepDatesDrpBx.name", reportDatesCustom, driverAdmin);
			genLibWeb.clickOnElementByID("docAdminReportsCustFromDate.id", driverAdmin);
			genLibWeb.clickOnElementByXPath(null, datePickFromDateXpathVal, driverAdmin);
			genLibWeb.clickOnElementByXPath(null, datePickToDateXpathVal, driverAdmin);	
			//get selected dates
			String startDateUI = genLibWeb.getValueByID("docAdminReportsCustFromDate.id", driverAdmin);
			String endDateUI = genLibWeb.getValueByID("docAdminReportsCustToDate.id", driverAdmin);
			//select include - H&P, State and Diagnosis 
			genLibWeb.clickOnElementByXPath("docAdminReportsIncludeDiagnosisI.xpath", null, driverAdmin);
			genLibWeb.clickOnElementByXPath("docAdminReportsIncludeH&PI.xpath", null, driverAdmin);
			genLibWeb.clickOnElementByXPath("docAdminReportsIncludeStateI.xpath", null, driverAdmin);
			//run reports
			genLibWeb.clickOnElementByXPath("docAdminRunReportBtn.ngClick.xpath", null, driverAdmin);
			Thread.sleep(1000);
			if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("consultationSummaryReport.success"), "toastMsg.xpath", null, driverAdmin)){
				testCaseStatus = false;
				log.error("Failed to run reports for Consulation Summary report");
				Assert.fail("Failed to run reports for Consulation Summary report");
			}
			log.info("Successfully ran reports for Consulation Summary report");
			String adminWindowHandle = driverAdmin.getWindowHandle();
				
			SimpleDateFormat uiFormat = new SimpleDateFormat("MM/dd/yyyy");
			String startDate = dateFormat.format(uiFormat.parse(startDateUI));
			String endDate = dateFormat.format(uiFormat.parse(endDateUI));		
			String reportName = consultSummaryReportTitlePrefix + startDate + "_to_" + endDate+".csv";

			//gmail verification
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.loginGmailAsAdminToVerifyReports(adminUsername, adminPasswd, reportName , driverGmail);
			
			//validate if on admin console
			Thread.sleep(1000);
			genLibWeb.bringBrowserToFront(adminWindowHandle, driverAdmin);
			admin.validateRepInGeneratedReportsConsole(reportName, driverAdmin);
			Thread.sleep(2000);
			genLibWeb.clickOnElementByXPath("docAdminReportsConsoletReportNameTd.xpath", null, driverAdmin);
			Thread.sleep(2000);
			//verify dates in csv file
			dateFormat = new SimpleDateFormat("M/d/yyyy");
			startDate = dateFormat.format(uiFormat.parse(startDateUI));
			endDate = dateFormat.format(uiFormat.parse(endDateUI));	
			VMedixUtils.verifyDatesNIncludesInCSV(reportName, startDate, endDate, 
					VMedixUtils.CONSULT_SUMM_REP_INCLUDE_HnP, VMedixUtils.CONSULT_SUMM_REP_INCLUDE_STATE, VMedixUtils.CONSULT_SUMM_REP_INCLUDE_DIAGNOSIS);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
}

