package tests.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import library.VMedixUtils;
import library.VMedixUtils.NotifyDoctorMethod;
import tests.TestCaseInit;

public class PatientDoctorConsultation extends TestCaseInit {	
	/**
	 * End to End Video Consultation Flow for Existing Patient
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param vistReason	
	 * @param medications	
	 * @param allergies	
	 * @param heighFeet	
	 * @param heighInches
	 * @param weightLbs
	 * @param medCondition	
	 * @param surgeries	
	 * @param famMedProb
	 * @param smoke		
	 * @param smokePacksNum	
	 * @param jobProf
	 * @param primDocName
	 * @param primDocPhone
	 * @param primDocFax
	 * @param primDocEmail
	 * @param primDocAddr1
	 * @param primDocAddr2
	 * @param primDocCity
	 * @param primDocState
	 * @param primDocZipCode
	 * @param prefPharmName
	 * @param prefPharmPhone
	 * @param prefPharmFax
	 * @param prefPharmEmail
	 * @param prefPharmAddr1
	 * @param prefPharmAddr2
	 * @param prefPharmCity
	 * @param prefPharmState
	 * @param prefPharmZipCode
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 * @param diagCode	
	 * @param followUp	
	 * @param returnToSchWrk	
	 * @param restrt	
	 * @param durOfRestrt
	 * @param persDInstr
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @throws Exception
	 */
	@Test(dataProvider = "getData", groups = {"PatientDoctor Video Consultation Existing" }) //TC_238073, TC_234564, TC_238058, TC_238072, TC_238792, TC_236628, TC_236629, TC_234554, TC_229942, TC_241834, TC_241816
	public void testETEFlowForExistingPatVideo(String patEmail, String patPwd, String patName, String vistReason, String medications, String allergies, String heighFeet, String heighInches, 
			String weightLbs, String medCondition, String surgeries, String famMedProb, String smoke, String smokePacksNum, String jobProf, String primDocName, String primDocPhone, 
			String primDocFax, String primDocEmail, String primDocAddr1, String primDocAddr2, String primDocCity, String primDocState, String primDocZipCode, String prefPharmName, String prefPharmPhone, 
			String prefPharmFax, String prefPharmEmail, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, String prefPharmState, String prefPharmZipCode, String docEmail, String docPwd, 
			String docName, String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String persDInstr, String hpSoapSub, String hpSoapObj, String adminUsername, String adminPasswd) throws Exception {
		try {
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			setUsername(patEmail);
			setPassword(patPwd);
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			// Patient is on Home/Landing page after Login... Starting api validations
		// Verify API patient Login
			log.info("Starting Login API...");			
			currentlogin = "patient";
			setCurrentlogin(currentlogin);
			genApiMethods.getResponse("API", "login");
			log.info("Login API Completed");
		// Verify API patient User Details after login
			log.info("Starting User Details API...");
			if (patientPage.verifyPatientOnLandingPage(driverPatient)) {
				patientname = patName;
			}
			setPatientname(patientname);
			genApiMethods.getResponse("API", "UserDetails");
			log.info("User Details API Completed");
		// Verify API Call for States
			log.info("Starting Patient State options API...");
			statecount = patientPage.getNumberOfPatientStateOptions(driverPatient);
			setStatecount(statecount);
			genApiMethods.getResponse("API", "States");
			log.info("Patient State options API Completed");

			// Starting video consultation
			//1. Fill Consultation form
			patientConsultReq.fillConsultationFormWithValidations(true, vistReason, medications, allergies, driverPatient);
			
		// Verify API Call for Price
			log.info("Starting Price API...");
			patientConsultPayment.verifyPatientOnPaymentPage(driverPatient);
			String pricePart = patientConsultPayment.getConsultationFee(driverPatient);					
			String price = pricePart.indexOf(".") < 0 ? pricePart : pricePart.replaceAll("0*$", "").replaceAll("\\.$", "");//retrieve only amount from the text
			setAmount(price); 
			genApiMethods.getResponse("API", "Price");
			log.info("Price API Completed");
		
			//2. Enter Payment info - auto generated
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
			
		// API Call for PaymentTOKEN and GETConsultation not done to avoid 2 consultations at the same time for an account.

			//3. a.Fill Health Info - Pre-Queue state
			patConsultWaitRoomHealthInfoPreQ.fillNReviewHealthInfo(heighFeet, heighInches, weightLbs, medCondition, surgeries, smoke, smokePacksNum, VMedixUtils.ALCOHOL_NEVER, jobProf, famMedProb, primDocName, 
				primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail, 
				prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverPatient);
			
			//3. b.Notification method for Doctor - Pre-Queue state
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.TEXT_ME, null, driverPatient);
			Thread.sleep(2000);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
			patientConsultation.uploadAPatientPhoto(driverPatient);
			Thread.sleep(8000);//wait 8 seconds for the toast message to disappear
			patientConsultation.removePatientPhoto("photo 1", driverPatient); // photo title to be removed is photo 1, at this point only one photo added
			log.info("TC_238058 is executed successfully - Photo upload before consultation");
			
			// Doctor Flow
			//4.Login as doctor and pick up the consultation of the above patient
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patName, driverDoctor);
			
			// Patient - Begin Consultation
			//5. Begin consultation from patient end and verify video stream seen on doctor end 
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);
			doctorConsultation.checkConsultationTimerUpdate(driverDoctor);
			doctorConsultation.checkDoctorVideoPane(driverDoctor);
			doctorConsultation.checkPatientVideoPaneOnDoc(driverDoctor);
			log.info("TC_238073 is executed successfully");
			doctorConsultation.checkPatientVideoPaneMovableOnDoc(driverDoctor);
			log.info("TC_234564 is executed successfully");
			
			// Doctor to check Discharge and Disposition tab appearing in right side
			//6. Enter D&D and H&P Soap Note when in consultation on doc side
			doctorConsultation.enterDnDDataInConsultation(diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, persDInstr, driverDoctor);
			log.info("TC_229942 is executed successfully here");
			doctorConsultation.enterHnPTemplateSoapNotes(hpSoapSub, hpSoapObj, driverDoctor);						
			
			// check Max photo upload limit from patient end
			//7. Verify photo limits on patient side 
			patientConsultation.checkLimitOnPhotoUpload(driverPatient);
			//verify 6 photos seen on Doctor side
			doctorConsultation.verifyPhotosUploaded(VMedixUtils.PHOTO_LIMIT, driverDoctor);			
			log.info("TC_238792 is executed successfully here");			
			
			String photoTitleToRemove = "photo 3";// photo title to be removed is photo 3
			Thread.sleep(8000);//wait 8 seconds for the toast message to disappear
			patientConsultation.removePatientPhoto(photoTitleToRemove, driverPatient); 
			//verify removed photo on doctor side
			doctorConsultation.verifyPhotoRemoved(photoTitleToRemove, driverDoctor);			
			log.info("TC_238072 is executed successfully here - To remove uploaded photo");			
			
			// Check chat functionality starting on patient
			//8. Verify chat on both ends 
			patientConsultation.verifyChatWindow(driverPatient);
			cmnUtilsForPages.verify2SetsOfDocPatChatMessages(driverPatient, driverDoctor);	
			log.info("TC_236628 and TC_236629 are executed successfully here");
			
			//9. End Consultation From Doctor End
			doctorConsultation.endViDoctorConsultation(driverDoctor);
			log.info("TC_234554 is executed successfully here");
			
			//10. Verify DnD entries from in-consultation state and edit them
			ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);
			Thread.sleep(1000);
			ddscreen.verifyDnDEntriesFromInConsultation(diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, driverDoctor);
			String suffixForNewVal = VMedixUtils.generateDynamicString();
			diagCode = diagCode + suffixForNewVal;
			followUp = followUp + suffixForNewVal;
			returnToSchWrk = returnToSchWrk + suffixForNewVal;
			restrt = restrt + suffixForNewVal; 
			durOfRestrt = durOfRestrt + suffixForNewVal;
			ddscreen.editDnDValuesOnDnDPage(diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, null, driverDoctor);
			
			//11. Verify SOAP Note H&P form entries from in-consultation state and edit them
			ddscreen.verifyHnPSoapNotesEntriesFromInConsultation(hpSoapSub, hpSoapObj, driverDoctor);
			ddscreen.editHnPSoapNotesOnDnDPage(hpSoapSub, hpSoapObj, driverDoctor);
			hpSoapSub = hpSoapSub + hpSoapSub;
			hpSoapObj = hpSoapObj + hpSoapObj;

			//12. verify ePrescribe link and fax button present
			ddscreen.verifyePrescribeAndFaxOnDnD(driverDoctor);
			
			//13. verify refund options
			ddscreen.verifyRefundOptions(driverDoctor);
			
			//14. verify upload files
			ddscreen.verifyUploadFiles(driverDoctor);
			
			//15. submit D&D
			ddscreen.submitDnD(driverDoctor);
			log.info("TC_229942 is executed successfully here");
			
			//doctor is back on tracking board
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);

			//16. fill survey on patient end
			survey.verifyNValidatePatientOnSurveyPage(driverPatient);
			survey.fillSurvey(driverPatient);
			afterSurvey.verifyNValidatePatientOnAfterConsultationPage(driverPatient);
			afterSurvey.verifyOptionsOnAfterConsult(driverPatient);			
			
			//17. bring patient to home page
			afterSurvey.clickOnHomeOption(driverPatient);
			Thread.sleep(2000);
			
			//18a. verify this consultation data on Doctor's previous consultation - discharge summary
			docPrevConsult.clickOnPreviousConsults(driverDoctor);
			docPrevConsult.findPrevConsultOfDoctor(docName, patName, driverDoctor);
			Thread.sleep(3000); // wait for elements to load
			docPrevConsult.verifyNValidatePreviousConsultationsPanelOnViewConsult(driverDoctor);
			Thread.sleep(3000); // wait for elements to load
			docPrevConsult.verifyPreviousConsultGeneralInfo(patName, vistReason, patEmail, diagCode, prefPharmName, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, 
				prefPharmZipCode, prefPharmPhone, VMedixUtils.PHOTO_LIMIT-1, driverDoctor);
			docPrevConsult.verifyPreviousConsultMedHistory(primDocName, primDocPhone, smoke, smokePacksNum, VMedixUtils.ALCOHOL_NEVER, heighFeet, heighInches, weightLbs, allergies, famMedProb, medications, medCondition, surgeries, driverDoctor);
			docPrevConsult.verifyPreviousConsultSoapNotes(hpSoapSub, hpSoapObj, driverDoctor);
			String prevConsultPanelHandler = docPrevConsult.verifyPreviousConsultPatientDischargeRep(patName, docName, price, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, persDInstr, driverDoctor);
			for (String winHandle : driverDoctor.getWindowHandles()) {
				if(!winHandle.equalsIgnoreCase(prevConsultPanelHandler)){
					driverDoctor.switchTo().window(winHandle); 
					break;
				}
			}
			driverDoctor.close();//close report window
			driverDoctor.switchTo().window(prevConsultPanelHandler);
			genLibWeb.scrollToViewElementWithID("doctorPrevConsultCloseBtn.id", driverDoctor);
			genLibWeb.clickOnElementByID("doctorPrevConsultCloseBtn.id", driverDoctor);
		
			//18b. verify consultation on Doctor Admin's previous consultations
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			admin.clickOnOtherElemsPrevConsults(driverAdmin);
			Thread.sleep(3000);//wait for page to load with prev consults
			adminOthrElemPrevConsults.verifyNValidateOnAdminOtherElemsPrevConsultsPage(driverAdmin);
			adminOthrElemPrevConsults.searchByPatEmail(patEmail, driverAdmin);
			adminOthrElemPrevConsults.viewPrevConsult(docName, driverAdmin);
			String reasonToviewConsult = "autoTest verification " + VMedixUtils.generateDynamicString();
			docPrevConsult.submitReasonForPrevConsult(reasonToviewConsult, driverAdmin);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driverAdmin);
			String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driverAdmin);		
			if(!TestCaseInit.messagesVMedixProp.getProperty("viewConsultAuditLog.success").equals(toastMsg)) {
				TestCaseInit.testCaseStatus = false;
				log.error("View consult audit log Saved");
				Assert.fail("View consult audit log Saved");			
			}
			log.info("View consult audit log NOT Saved");	
			docPrevConsult.verifyAuditLogWithReason(reasonToviewConsult, driverAdmin);			
			
			//19. verify email received by Patient regarding the pdf report generation
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverGmail);				
			gmailPage.verifyNewConsultReportEmailForPatient(patEmail, patPwd, driverGmail);
			
			//20. verify all consultation info on Patient's consult History pdf - discharge summary
			genLibWeb.bringBrowserToFront(driverPatient.getWindowHandle(), driverPatient);	
			patientPage.clickOnConsultHistoryOption(driverPatient);
			Thread.sleep(5000);
			patientConsultHistory.verifyNValidatePatientOnConsultHistoryPage(driverPatient);
			String pdfUrl = patientConsultHistory.getPatientConsultReportPDF(docName, driverPatient);
			String patConsultPanelHandler = patientConsultHistory.verifyPatConsultHistPdfReportData(pdfUrl, patName, docName, price, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, null, driverPatient);// mostly D&D entries
			for (String winHandle : driverPatient.getWindowHandles()) {
				if(!winHandle.equalsIgnoreCase(patConsultPanelHandler)){
					driverPatient.switchTo().window(winHandle); 
					break;
				}
			}
			driverPatient.close();//close report window
			driverPatient.switchTo().window(patConsultPanelHandler);
			log.info("TC_241834 is executed successfully here");
			//verify if all the API asserts passed
			if(genApiMethods.apiAssertFailCount > 0) {
				testCaseStatus = false;
				log.error("Number of asserts failed: "+ genApiMethods.apiAssertFailCount);
				throw new AssertionError("Assert failed on certain API calls");
			}						
		} catch (Exception e) {	
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * End to End Video Consultation Flow for Existing Patient with Accent in First and Last name
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param vistReason	
	 * @param medications	
	 * @param allergies	
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 * @param diagCode	
	 * @param followUp	
	 * @param returnToSchWrk	
	 * @param restrt	
	 * @param durOfRestrt
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @throws Exception
	 */
	@Test(dataProvider = "getData", groups = {"PatientDoctor Video Consultation Existing" }) //TC_247039 Accent in First and Last name
	public void testETEFlowPatAccentNameVideo(String patEmail, String patPwd, String patName, String vistReason, String medications, String allergies, String docEmail, String docPwd, 
			String docName, String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String hpSoapSub, String hpSoapObj) throws Exception {
		try {
			testingETEFlowForDiffrentPatFirstNLastname(patEmail, patPwd, patName, vistReason, medications, allergies, docEmail, docPwd, docName, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, 
					hpSoapSub, hpSoapObj);				
		} catch (Exception e) {	
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * End to End Video Consultation Flow for Existing Patient with Special Chars in First and Last name
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param vistReason	
	 * @param medications	
	 * @param allergies	
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 * @param diagCode	
	 * @param followUp	
	 * @param returnToSchWrk	
	 * @param restrt	
	 * @param durOfRestrt
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @throws Exception
	 */
	@Test(dataProvider = "getData", groups = {"PatientDoctor Video Consultation Existing" }) //TC_247039 Special Chars in First and Last name
	public void testETEFlowPatSpecialCharsVideo(String patEmail, String patPwd, String patName, String vistReason, String medications, String allergies, String docEmail, String docPwd, 
			String docName, String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String hpSoapSub, String hpSoapObj) throws Exception {
		try {
			testingETEFlowForDiffrentPatFirstNLastname(patEmail, patPwd, patName, vistReason, medications, allergies, docEmail, docPwd, docName, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, 
					hpSoapSub, hpSoapObj);	
		} catch (Exception e) {	
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	private void testingETEFlowForDiffrentPatFirstNLastname (String patEmail, String patPwd, String patName, String vistReason, String medications, String allergies, String docEmail, String docPwd, 
			String docName, String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String hpSoapSub, String hpSoapObj) throws Exception {
		//Log-In as patient
		driverPatient = genLibWeb.getWebDriver(browserPatient);
		genLibWeb.setImplicitWait(driverPatient);
		driverPatient.get(webUrl);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
		login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
		patientPage.verifyAndBringPatientToLandingPage(driverPatient);			
		patientConsultReq.fillConsultationFormWithValidations(true, vistReason, medications, allergies, driverPatient);			
		patientConsultPayment.verifyPatientOnPaymentPage(driverPatient);
		patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
		patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
		Thread.sleep(1000);
		patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
		Thread.sleep(2000);
		//Doctor Flow
		driverDoctor = genLibWeb.getWebDriver(browserDoctor);
		genLibWeb.setImplicitWait(driverDoctor);
		driverDoctor.get(webUrl);
		login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
		doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
		trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patName, driverDoctor);			
		//Patient - Begin Consultation
		patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);	
		Thread.sleep(3000);//wait for the consultation to begin
		patientConsultation.uploadFewPatientPhotos(2, driverPatient);
		Thread.sleep(1000);
		doctorConsultation.verifyPhotosUploaded(2, driverDoctor);
		patientConsultation.removePatientPhoto("photo 1", driverPatient);
		doctorConsultation.verifyPhotoRemoved("photo 1", driverDoctor);
		// Check chat functionality starting on patient
		patientConsultation.verifyChatWindow(driverPatient);
		cmnUtilsForPages.verify2SetsOfDocPatChatMessages(driverPatient, driverDoctor);		
		//End Consultation From Doctor End
		doctorConsultation.endViDoctorConsultation(driverDoctor);	
		//Doctor on DnD 			
		ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);
		ddscreen.verifyePrescribeAndFaxOnDnD(driverDoctor);
		ddscreen.editDnDValuesOnDnDPage(diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, null, driverDoctor);
		ddscreen.enterHnPTemplateSoapNotes(hpSoapSub, hpSoapObj, driverDoctor);
		ddscreen.submitDnD(driverDoctor);
		//doctor is back on tracking board
		doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);
		//skip survey on patient end
		survey.verifyNValidatePatientOnSurveyPage(driverPatient);
		survey.skipSurvey(driverPatient);
		afterSurvey.verifyNValidatePatientOnAfterConsultationPage(driverPatient);
		//bring patient to home page
		afterSurvey.clickOnHomeOption(driverPatient);
		Thread.sleep(2000);
		//verify all consultation info on Patient's consult History pdf - discharge summary
		patientPage.clickOnConsultHistoryOption(driverPatient);
		Thread.sleep(5000);
		patientConsultHistory.verifyNValidatePatientOnConsultHistoryPage(driverPatient);
		String pdfUrl = patientConsultHistory.getPatientConsultReportPDF(docName, driverPatient);
		String patConsultPanelHandler = patientConsultHistory.verifyPatConsultHistPdfReportData(pdfUrl, patName, docName, null, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, null, driverPatient);// mostly D&D entries
		for (String winHandle : driverPatient.getWindowHandles()) {
			if(!winHandle.equalsIgnoreCase(patConsultPanelHandler)){
				driverPatient.switchTo().window(winHandle); 
				break;
			}
		}
		driverPatient.close();//close report window
		driverPatient.switchTo().window(patConsultPanelHandler);
	}	
	
	/**
	 * End to End Video Consultation Flow for New Patient
	 * @param newPatSampleGmail
	 * @param patPwd
	 * @param patFirstName
	 * @param patLastName
	 * @param patMonth
	 * @param patDay
	 * @param patYear
	 * @param patGender
	 * @param patPrimaryPhone
	 * @param patZipCode
	 * @param vistReason	
	 * @param medications	
	 * @param allergies	
	 * @param heighFeet	
	 * @param heighInches
	 * @param weightLbs
	 * @param medCondition	
	 * @param surgeries	
	 * @param famMedProb
	 * @param smoke		
	 * @param smokePacksNum	
	 * @param jobProf
	 * @param primDocName
	 * @param primDocPhone
	 * @param primDocFax
	 * @param primDocEmail
	 * @param primDocAddr1
	 * @param primDocAddr2
	 * @param primDocCity
	 * @param primDocState
	 * @param primDocZipCode
	 * @param prefPharmName
	 * @param prefPharmPhone
	 * @param prefPharmFax
	 * @param prefPharmEmail
	 * @param prefPharmAddr1
	 * @param prefPharmAddr2
	 * @param prefPharmCity
	 * @param prefPharmState
	 * @param prefPharmZipCode
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 * @param diagCode	
	 * @param followUp	
	 * @param returnToSchWrk	
	 * @param restrt	
	 * @param durOfRestrt
	 * @param persDInstr
	 * @throws Exception
	 */
	@Test(dataProvider = "getData", groups = {"PatientDoctor Video Consultation New" }) //TC_241839
	public void testETEFlowForNewPatVideo(String newPatSampleGmail, String patPwd, String patFirstName, String patLastName, String patMonth, String patDay, String patYear, String patGender, 
			String patPrimaryPhone, String patZipCode, String vistReason, String medications, String allergies, String heighFeet, String heighInches, 
			String weightLbs, String medCondition, String surgeries, String famMedProb, String smoke, String smokePacksNum, String jobProf, String primDocName, String primDocPhone, 
			String primDocFax, String primDocEmail, String primDocAddr1, String primDocAddr2, String primDocCity, String primDocState, String primDocZipCode, String prefPharmName, String prefPharmPhone, 
			String prefPharmFax, String prefPharmEmail, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, String prefPharmState, String prefPharmZipCode, String docEmail, String docPwd, 
			String docName, String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String persDInstr) throws Exception {
		try {
			//register new patient 
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);			
			String dynamicChars = VMedixUtils.generateDynamicString();
			String newPatEmail = VMedixUtils.generateEmailId(newPatSampleGmail, dynamicChars);
			//appending the random chars to patient first and last name
			login.createAccountForNewPatient(newPatEmail, patPwd, patFirstName+dynamicChars, patLastName+dynamicChars, patMonth, patDay, patYear, patGender, patPrimaryPhone, patZipCode, null, null, driverPatient);
			//gmail verification
			driverGmail = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverGmail);				
			gmailPage.loginToGmailNValidateEmailVerificationForNewPatient(newPatEmail, patPwd, driverGmail);
			driverGmail.close();
			//patient
			patientConsultReq.fillConsultationFormWithValidations(true, vistReason, medications, allergies, driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
			//Fill Health Info - Pre-Queue state
			patConsultWaitRoomHealthInfoPreQ.fillNReviewHealthInfo(heighFeet, heighInches, weightLbs, medCondition, surgeries, smoke, smokePacksNum, VMedixUtils.ALCOHOL_NEVER, jobProf, famMedProb, primDocName, 
				primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail, 
				prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.TEXT_ME, null, driverPatient);
			Thread.sleep(2000);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
			patientConsultation.uploadAPatientPhoto(driverPatient);
			Thread.sleep(8000);
			patientConsultation.takePatientPhoto(driverPatient);
			patientConsultation.viewNClosePatientPhoto("photo 2", driverPatient);
			patientConsultation.removePatientPhoto("photo 1", driverPatient); // photo title to be removed is photo 1, at this point there are 2 photos added
			// Doctor Flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			String patName = patFirstName+dynamicChars+ " " + patLastName+dynamicChars;
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patName , driverDoctor);
			// Patient - Begin Consultation
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);
			// Check chat functionality starting on patient
			patientConsultation.verifyChatWindow(driverPatient);
			cmnUtilsForPages.verify2SetsOfDocPatChatMessages(driverPatient, driverDoctor);
			
			//End Consultation From Patient End
			patientConsultation.endVideoOrPhoneConsultation(driverPatient);
			//Doctor - Verify patient ended consultation pop up 
			doctorConsultation.verifyNValidatePatientEndedConsultPopUp(driverDoctor);
			doctorConsultation.clickEndConsultOnPatientEndedConsultPopUp(driverDoctor);
			Thread.sleep(3000);
			ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);
			ddscreen.editDnDValuesOnDnDPage(diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, persDInstr, driverDoctor);			
			ddscreen.submitDnD(driverDoctor);
			//doctor is back on tracking board
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);
			//skip survey on patient end
			survey.verifyNValidatePatientOnSurveyPage(driverPatient);
			survey.skipSurvey(driverPatient);
			afterSurvey.verifyNValidatePatientOnAfterConsultationPage(driverPatient);
			//bring patient to home page
			afterSurvey.clickOnHomeOption(driverPatient);
			Thread.sleep(2000);
			//gmail verification
			driverGmail = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverGmail);
			gmailPage.verifyNewConsultReportEmailForPatient(newPatEmail, patPwd, driverGmail);
			
			//verify all consultation info on Patient's consult History pdf - discharge summary
			patientPage.clickOnConsultHistoryOption(driverPatient);
			Thread.sleep(5000);
			patientConsultHistory.verifyNValidatePatientOnConsultHistoryPage(driverPatient);
			String pdfUrl = patientConsultHistory.getPatientConsultReportPDF(docName, driverPatient);
			String patConsultPanelHandler = patientConsultHistory.verifyPatConsultHistPdfReportData(pdfUrl, patName, docName, null, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, persDInstr, driverPatient);// mostly D&D entries
			for (String winHandle : driverPatient.getWindowHandles()) {
				if(!winHandle.equalsIgnoreCase(patConsultPanelHandler)){
					driverPatient.switchTo().window(winHandle); 
					break;
				}
			}
			driverPatient.close();//close report window
			driverPatient.switchTo().window(patConsultPanelHandler);			
		} catch (Exception e) {	
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}		
	}
	
	/**
	 * End to End Video Consultation Flow
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param vistReason	
	 * @param medications	
	 * @param allergies	
	 * @param heighFeet	
	 * @param heighInches
	 * @param weightLbs
	 * @param medCondition	
	 * @param surgeries	
	 * @param famMedProb
	 * @param smoke		
	 * @param smokePacksNum	
	 * @param jobProf
	 * @param primDocName
	 * @param primDocPhone
	 * @param primDocFax
	 * @param primDocEmail
	 * @param primDocAddr1
	 * @param primDocAddr2
	 * @param primDocCity
	 * @param primDocState
	 * @param primDocZipCode
	 * @param prefPharmName
	 * @param prefPharmPhone
	 * @param prefPharmFax
	 * @param prefPharmEmail
	 * @param prefPharmAddr1
	 * @param prefPharmAddr2
	 * @param prefPharmCity
	 * @param prefPharmState
	 * @param prefPharmZipCode
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 * @throws Exception
	 */
	@Test(dataProvider = "getData", groups = {"PatientDoctor Video Consultation Medical History" }) //TC_241832
	public void testPatMedHistNReConsult(String patEmail, String patPwd, String patName, String vistReason, String medications, String allergies, String heighFeet, String heighInches, 
			String weightLbs, String medCondition, String surgeries, String famMedProb, String smoke, String smokePacksNum, String jobProf, String primDocName, String primDocPhone, 
			String primDocFax, String primDocEmail, String primDocAddr1, String primDocAddr2, String primDocCity, String primDocState, String primDocZipCode, String prefPharmName, String prefPharmPhone, 
			String prefPharmFax, String prefPharmEmail, String prefPharmAddr1, String prefPharmAddr2, String prefPharmCity, String prefPharmState, String prefPharmZipCode, String docEmail, String docPwd, 
			String docName) throws Exception {
		try {
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);			
			patientConsultReq.fillConsultationFormWithValidations(true, vistReason, medications, allergies, driverPatient);			
			patientConsultPayment.verifyPatientOnPaymentPage(driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyNValidatePatientOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.fillNReviewHealthInfo(heighFeet, heighInches, weightLbs, medCondition, surgeries, smoke, smokePacksNum, VMedixUtils.ALCOHOL_NEVER, jobProf, famMedProb, primDocName, 
				primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail,	prefPharmAddr1, 
				prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			Thread.sleep(1000);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);			
			//Doctor Flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patName, driverDoctor);			
			//Patient - Begin Consultation
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);			
			//Doctor - end consultation
			Thread.sleep(5000);//wait till the consultation begins
			doctorConsultation.endViDoctorConsultation(driverDoctor);				
			//Doctor on DnD edits Med Hist info			
			ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);
			//get new data by appending random dynamic characters 
			String dynamicChars = VMedixUtils.generateDynamicString();
			log.info("Dynamic characters generated for new data:" + dynamicChars);
			medications = VMedixUtils.getNewCommaDelimStrWithCharsAppended(medications, dynamicChars);
			medications = medications + ", " + dynamicChars;
			allergies = VMedixUtils.getNewCommaDelimStrWithCharsAppended(allergies, dynamicChars);
			allergies = allergies + ", " + dynamicChars;
			heighFeet = Integer.toString(Integer.parseInt(heighFeet)+1);
			heighInches = Integer.toString(Integer.parseInt(heighInches)+1);
			weightLbs = Integer.toString(Integer.parseInt(weightLbs)+5);
			medCondition = VMedixUtils.getNewCommaDelimStrWithCharsAppended(medCondition, dynamicChars);
			medCondition = medCondition + ", " + dynamicChars;
			surgeries = VMedixUtils.getNewCommaDelimStrWithCharsAppended(surgeries, dynamicChars);
			surgeries = surgeries + ", " + dynamicChars;
			smoke= VMedixUtils.NO;
			smokePacksNum = "0";
			jobProf = jobProf+dynamicChars;
			famMedProb = VMedixUtils.getNewCommaDelimStrWithCharsAppended(famMedProb, dynamicChars);
			famMedProb = famMedProb + ", " + dynamicChars;
			primDocName = primDocName + dynamicChars;
			primDocPhone = "(404) 040-4040";
			prefPharmName = prefPharmName + dynamicChars;
			prefPharmPhone = "(404) 040-5040"; 
			prefPharmAddr1 = prefPharmAddr1 + dynamicChars;
			prefPharmAddr2 = prefPharmAddr2 + dynamicChars;
			prefPharmCity = prefPharmCity + dynamicChars;
			prefPharmState = "MD";
			prefPharmZipCode = Integer.toString(Integer.parseInt(prefPharmZipCode)+1);
			String alcohol = VMedixUtils.ALCOHOL_OCCASIONALLY;
			ddscreen.editMedicationsNAllergies(medications, allergies, driverDoctor);
			ddscreen.uncollapseMedicalHistorySection(driverDoctor);
			ddscreen.clickOnMedicalHistoryEdit(driverDoctor);
			cmnUtilsForPages.editNReviewMedicalHistoryOfPatient(heighFeet, heighInches, weightLbs, medCondition, surgeries, famMedProb, smoke, smokePacksNum, alcohol, jobProf, 
					primDocName, primDocPhone,	prefPharmName, prefPharmPhone, prefPharmAddr1,	prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverDoctor);
			Thread.sleep(1000);
			ddscreen.submitDnD(driverDoctor);
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);
			//Patient - skip survey
			Thread.sleep(1000);
			survey.verifyNValidatePatientOnSurveyPage(driverPatient);
			survey.skipSurvey(driverPatient);
			afterSurvey.verifyNValidatePatientOnAfterConsultationPage(driverPatient);
			afterSurvey.verifyOptionsOnAfterConsult(driverPatient);				
			//bring patient to home page
			afterSurvey.clickOnHomeOption(driverPatient);
			Thread.sleep(2000);				
			//verify medHist data on patient info
			patientPage.clickOnPatientInfoOption(driverPatient);
			patientInfo.verifyNValidatePatientOnPatientInfoPage(driverPatient);
			patientInfo.verifyPatientInfo(heighFeet, heighInches, weightLbs, medications, allergies, medCondition, surgeries, smoke, smokePacksNum, alcohol, jobProf, famMedProb, primDocName, 
					primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail,	prefPharmAddr1, 
					prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverPatient);
			patientPage.clickOnSeeDoctorOption(driverPatient);
			patientPage.verifyNValidatePatientOnLandingPage(driverPatient);
			//start new consultation to verify med history
			vistReason = "anotherConsultAuto";
			patientConsultReq.fillConsultationForm(true, vistReason, null, null, driverPatient);// do not enter any new meds or allergies			
			patientConsultPayment.verifyPatientOnPaymentPage(driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyNValidatePatientOnHealthInfoPage(driverPatient);			
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);	
			patConsultWaitRoomHealthInfoPreQ.verifyMedicalHistoryDetails(heighFeet, heighInches, weightLbs, medCondition, surgeries, smoke, smokePacksNum, alcohol, jobProf, famMedProb, 
					primDocName, primDocPhone, primDocFax, primDocEmail, primDocAddr1, primDocAddr2, primDocCity, primDocState, primDocZipCode, 
					prefPharmName, prefPharmPhone, prefPharmFax, prefPharmEmail, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			Thread.sleep(1000);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
			//Doctor - refresh
			driverDoctor.navigate().refresh();
			Thread.sleep(1000);
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);			
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patName, driverDoctor);
			//Patient - Begin Consultation
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);
			Thread.sleep(2000);
			//Doctor - verify Med Hist when in consultation
			doctorConsultation.verifyMedicalHistoryInConsult(vistReason, heighFeet, heighInches, weightLbs, medications, allergies, 
					medCondition, surgeries, famMedProb, smoke, smokePacksNum, alcohol, jobProf, 
					primDocName, primDocPhone, 
					prefPharmName, prefPharmPhone, prefPharmAddr1, prefPharmAddr2, prefPharmCity, prefPharmState, prefPharmZipCode, driverDoctor);
			//Doctor - end consultation
			genLibWeb.scrollToViewElementWithClass("logoH1.class", driverDoctor);
			doctorConsultation.endViDoctorConsultation(driverDoctor);	
			ddscreen.verifyDoctorOnDnDPage(driverDoctor);
			Thread.sleep(5000);
			ddscreen.submitDnD(driverDoctor);
		} catch (Exception e) {	
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * End to End Phone Consultation Flow
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param vistReason	
	 * @param medications	
	 * @param allergies	
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 * @param diagCode	
	 * @param followUp	
	 * @param returnToSchWrk	
	 * @param restrt	
	 * @param durOfRestrt
	 * @param persDInstr
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @throws Exception
	 */
	@Test(dataProvider = "getData", groups = {"PatientDoctor Phone Consultation" }) //TC_241838
	public void testEndToEndFlowForPhone(String patEmail, String patPwd, String patName, String vistReason, String medications, String allergies, String docEmail, String docPwd, 
			String docName, String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String persDInstr, String hpSoapSub, String hpSoapObj) throws Exception {
		try {
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			patientConsultReq.fillConsultationFormWithValidations(false, vistReason, medications, allergies, driverPatient);			
			patientConsultPayment.verifyPatientOnPaymentPage(driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
			Thread.sleep(2000);
			patientConsultation.uploadAPatientPhoto(driverPatient);
			Thread.sleep(8000);//wait for the toast message to disappear
			//Doctor Flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(false, patName, driverDoctor);	
			//Doctor- verify phone notify pop-up on doctor
			doctorConsultation.verifyNValidateDoctorOnPhoneNotifyPopUpWindow(driverDoctor);
			Thread.sleep(1000);
			doctorConsultation.clickOkOnPhoneNotifyPopUpWindow(driverDoctor);
			//Patient - Begin Consultation
			Thread.sleep(8000);//Wait 10 seconds to begin the consultation, instead of clicking begin consultation
			//Doctor - enter H&P and DnD data
			doctorConsultation.enterHnPTemplateSoapNotes(hpSoapSub, hpSoapObj, driverDoctor);
			doctorConsultation.enterDnDDataInConsultation(diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, persDInstr, driverDoctor);
			doctorConsultation.endPhoneConsultationFromDoctor(driverDoctor);
			Thread.sleep(5000);
			ddscreen.submitDnD(driverDoctor);
			//doctor is back on tracking board
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);
			//skip survey on patient end
			survey.verifyNValidatePatientOnSurveyPage(driverPatient);
			survey.skipSurvey(driverPatient);
			afterSurvey.verifyNValidatePatientOnAfterConsultationPage(driverPatient);
			//bring patient to home page
			afterSurvey.clickOnHomeOption(driverPatient);
			Thread.sleep(2000);
			driverGmail = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverGmail);				
			gmailPage.verifyNewConsultReportEmailForPatient(patEmail, patPwd, driverGmail);
			
			//verify all consultation info on Patient's consult History pdf - discharge summary
			patientPage.clickOnConsultHistoryOption(driverPatient);
			Thread.sleep(5000);
			patientConsultHistory.verifyNValidatePatientOnConsultHistoryPage(driverPatient);
			String pdfUrl = patientConsultHistory.getPatientConsultReportPDF(docName, driverPatient);
			String patConsultPanelHandler = patientConsultHistory.verifyPatConsultHistPdfReportData(pdfUrl, patName, docName, null, diagCode, followUp, returnToSchWrk, restrt, durOfRestrt, persDInstr, driverPatient);// mostly D&D entries
			for (String winHandle : driverPatient.getWindowHandles()) {
				if(!winHandle.equalsIgnoreCase(patConsultPanelHandler)){
					driverPatient.switchTo().window(winHandle); 
					break;
				}
			}
			driverPatient.close();//close report window
			driverPatient.switchTo().window(patConsultPanelHandler);				
		} catch (Exception e) {	
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}		
	}
}
