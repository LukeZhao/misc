package tests.web.smoke;
import org.testng.Assert;
import org.testng.annotations.Test;
import library.VMedixUtils;
import library.VMedixUtils.NotifyDoctorMethod;
import tests.TestCaseInit;

public class AdminApplicationChoices extends TestCaseInit {
	/**
	 * Test to validate Admin edits on H&P Templates
	 * @param adminUsername
	 * @param adminPasswd
	 * @param hnpTemplate
	 * @param patEmail	
	 * @param patPwd	
	 * @param patName	
	 * @param visitReason	
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 */
	@Test(dataProvider = "getData", groups = { "Admin Application Choices" }) //TC241817
	public void testAdminHnPTemplates(String adminUsername, String adminPasswd, String hnpTemplate, String patEmail, String patPwd, String patName, String visitReason, 
			String docEmail, String docPwd, String docName) {
		try {				
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);			
			admin.verifyNValidateOnDocAdminPage(driverAdmin);
			admin.clickOnAppChoicesHnPTemplates(driverAdmin);	
			Thread.sleep(1000);//wait for the page elements to load
			adminHnPTmplt.verifyNValidateOnAdminAppChoicesHnPTemplatePage(driverAdmin);
			String newHnPTemplateHeader = VMedixUtils.HnP_TEMPLATE_HEADER_ORIGINAL + VMedixUtils.generateDynamicString();		
			log.info("Non-Soap H&P Template, "+ hnpTemplate +" Patient Information header to be changed to: " + newHnPTemplateHeader);
			adminHnPTmplt.selectHnPTemplate(hnpTemplate, driverAdmin);
			adminHnPTmplt.editPatInfoHeaderInTemplateRawText(VMedixUtils.HnP_TEMPLATE_HEADER_ORIGINAL, newHnPTemplateHeader, driverAdmin);
			adminHnPTmplt.clickSave(driverAdmin);			
			//Verify HnP changes in consultation
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			patientConsultReq.fillConsultationForm(true, visitReason, null, null, driverPatient);
			patientConsultPayment.verifyPatientOnPaymentPage(driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			Thread.sleep(1000);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
			Thread.sleep(2000);
			//Doctor Flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patName, driverDoctor);			
			//Patient - Begin Consultation
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);	
			Thread.sleep(3000);//wait for the consultation to begin			
			//verify HnP template on doctor when in consultation			
			doctorConsultation.verifyNonSoapHnPTemplatePatInfoHeader(hnpTemplate, newHnPTemplateHeader, driverDoctor);			
			doctorConsultation.endViDoctorConsultation(driverDoctor);	
			ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);			
			//verify HnP template on doctor when on D&D page
			ddscreen.verifyNonSoapHnPTemplatePatInfoHeader(hnpTemplate, newHnPTemplateHeader, driverDoctor);	
			Thread.sleep(3000);
			ddscreen.submitDnD(driverDoctor);
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);			
			//edit back HnP template to original
			genLibWeb.bringBrowserToFront(driverAdmin.getWindowHandle(), driverAdmin);
			adminHnPTmplt.verifyNValidateOnAdminAppChoicesHnPTemplatePage(driverAdmin);			
			adminHnPTmplt.selectHnPTemplate(hnpTemplate, driverAdmin);
			adminHnPTmplt.editPatInfoHeaderInTemplateRawText(newHnPTemplateHeader, VMedixUtils.HnP_TEMPLATE_HEADER_ORIGINAL, driverAdmin);
			adminHnPTmplt.clickSave(driverAdmin);			
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * Test to validate Admin edits on Medications
	 * @param adminUsername
	 * @param adminPasswd
	 * @param med1Add
	 * @param med2AddDel	
	 * @param patEmail
	 * @param patPwd	
	 * @param patName	
	 * @param visitReason	
	 * @param docEmail	
	 * @param docPwd	
	 * @param docName	
	 */
	@Test(dataProvider = "getData", groups = { "Admin Application Choices" }) //TC241812
	public void testAdminMedications(String adminUsername, String adminPasswd, String med1Add, String med2AddDel, String patEmail, String patPwd, String patName, String visitReason, 
			String docEmail, String docPwd, String docName) {
		try {				
			driverAdmin = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverAdmin);
			driverAdmin.get(webUrl);
			login.loginAsExistingUser(adminUsername, adminPasswd, driverAdmin);			
			admin.verifyNValidateOnDocAdminPage(driverAdmin);	
			admin.clickOnAppChoicesMedications(driverAdmin);
			adminMedications.verifyNValidateOnAdminAppChoicesMedicationsPage(driverAdmin);
			Thread.sleep(3000);
			//verify add medication by admin
			adminMedications.addNewMedication(med1Add, driverAdmin);
			Thread.sleep(4000);//wait for the earlier toast message to disappear
			adminMedications.addNewMedication(med2AddDel, driverAdmin);
			Thread.sleep(2000);
			//verify delete medication by admin
			adminMedications.deleteMedication(med2AddDel, driverAdmin);			
			//Verify Medication added, in consultation
			//Log-In as patient
			driverPatient = genLibWeb.getWebDriver(browserPatient);
			genLibWeb.setImplicitWait(driverPatient);
			driverPatient.get(webUrl);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driverPatient);
			login.loginAsExistingUser(patEmail, patPwd, driverPatient);			
			patientPage.verifyAndBringPatientToLandingPage(driverPatient);
			//verify the added medication on patient end
			patientPage.verifyMedicationAddedByAdmin(med1Add, driverPatient);
			patientConsultReq.fillConsultationForm(true, visitReason, null, null, driverPatient);
			patientConsultPayment.enterAutoInfoOnPaymentPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickNextOnHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.verifyPatientOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.clickSubmitOnReviewHealthInfoPage(driverPatient);
			patConsultWaitRoomHealthInfoPreQ.notifyMethodForDoctor(NotifyDoctorMethod.NO_THANKS, null, driverPatient);
			Thread.sleep(1000);
			patientConsultation.verifyNValidatePatientOnWaitingForDocInQPage(driverPatient);
			Thread.sleep(2000);
			//Doctor Flow
			driverDoctor = genLibWeb.getWebDriver(browserDoctor);
			genLibWeb.setImplicitWait(driverDoctor);
			driverDoctor.get(webUrl);
			login.loginAsExistingUser(docEmail, docPwd, driverDoctor);
			doctorPage.verifyAndBringDoctorToLandingPage(driverDoctor);
			trackingBoardScreen.checkPatientAvailableNStartConsultation(true, patName, driverDoctor);			
			//Patient - Begin Consultation
			patConsultWaitRoomHealthInfoPreQ.beginConsultationStartedByDoctor(docName, driverPatient);	
			Thread.sleep(3000);//wait for the consultation to begin			
			//verify the added medication on doctor when in consultation			
			doctorConsultation.verifyMedicationAddedByAdmin(med1Add, driverDoctor);		
			doctorConsultation.endViDoctorConsultation(driverDoctor);	
			ddscreen.verifyNValidateDoctorOnDnDPage(driverDoctor);			
			//verify the added medication on doctor when on D&D page
			ddscreen.verifyMedicationAddedByAdmin(med1Add, driverDoctor);	
			Thread.sleep(3000);
			ddscreen.submitDnD(driverDoctor);
			doctorPage.verifyNValidateDoctorOnLandingPage(driverDoctor);			
			//remove medication added earlier
			genLibWeb.bringBrowserToFront(driverAdmin.getWindowHandle(), driverAdmin);
			adminMedications.verifyNValidateOnAdminAppChoicesMedicationsPage(driverAdmin);			
			adminMedications.deleteMedication(med1Add, driverAdmin);
		} catch (Exception e) {
			testCaseStatus = false;
			log.error("An Exception occurred", e);
			Assert.fail(e.getMessage());
		}
	}	
}
