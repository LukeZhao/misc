package tests;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlSuite.ParallelMode;
import org.testng.xml.XmlTest;

import library.EnvironmentConfigSettings;
import library.VMedixUtils;

public class TestNg {

	public static void main(String[] args) {
		Logger log = Logger.getLogger("TestNg");
		try{   			
			org.apache.log4j.BasicConfigurator.configure();
			log.info("--Inside TestNG -- Loading environment configurations...");
			TestCaseInit.envConfigProp = new Properties();
			TestCaseInit.envConfigProp.load( new FileInputStream(TestCaseInit.envConfigFilePath));
			//Verify the server set for automation run
			TestCaseInit.testOnServer = EnvironmentConfigSettings.getServerNameEnvConfig();
			if(StringUtils.isBlank(TestCaseInit.testOnServer)){
				log.error("Server name for the test run is NOT specified");
				throw new Exception("Server name for the test run is NOT specified");
			}			
			//Presently both Doctor and Patient browsers are same
			String docBrowser = EnvironmentConfigSettings.getWebBrowserForDoctorEnvConfig();
//			String patientBrowsers = EnvironmentConfigSettings.getPatientBrowserEnvConfigProp(); 
			int parallelCount = EnvironmentConfigSettings.getTestParallelCountEnvConfig();
			int noOfIterations = EnvironmentConfigSettings.getTestNoOfIterationsEnvConfig();
			//if more than one browser type specified
			String[] docBrowserArr = docBrowser.split(",");
			int noOfDocConfigBrowers = docBrowserArr.length;
			int noOfTestSuiteRuns = noOfIterations * noOfDocConfigBrowers;
			String[] testSuiteRunNames = new String[noOfTestSuiteRuns];
			for(int i=0; i<noOfTestSuiteRuns; i++) {
				testSuiteRunNames[i] = "Test Suite Run- "+(i+1);
			}			
			//create different suites for smoke, performance, reg	
			XmlSuite xmlTestSuiteSmoke = null;
			XmlSuite xmlTestSuitePerformance = null;
			XmlSuite xmlTestSuiteRegression = null;
			if(EnvironmentConfigSettings.isTestTypeSmoke()){
				xmlTestSuiteSmoke = getSmokeTestSuite(docBrowserArr, docBrowser, noOfIterations, noOfDocConfigBrowers, testSuiteRunNames, parallelCount);
			}			
			if(EnvironmentConfigSettings.isTestTypeRegression()){
				xmlTestSuiteRegression = getRegressionTestSuite(docBrowserArr, docBrowser, noOfIterations, noOfDocConfigBrowers, testSuiteRunNames, parallelCount);
			}
			if(EnvironmentConfigSettings.isTestTypePerformance()){
				xmlTestSuitePerformance = getPerformanceTestSuite(docBrowserArr, docBrowser, noOfIterations, noOfDocConfigBrowers, testSuiteRunNames, parallelCount);
			}			
			//add all suites
			List<XmlSuite> suites = new ArrayList<XmlSuite>();
			if(xmlTestSuiteSmoke != null){
				suites.add(xmlTestSuiteSmoke);
			}
			if(xmlTestSuiteRegression != null){
				suites.add(xmlTestSuiteRegression);
			}
			if(xmlTestSuitePerformance != null){
				suites.add(xmlTestSuitePerformance);
			}	
			//run test ng for the suites
			TestNG tng = new TestNG();
			tng.setXmlSuites(suites);
			tng.setConfigFailurePolicy(XmlSuite.CONTINUE);
			tng.run();
			
		} catch(Exception e) {
			log.error("An Exception occurred in TestNG class", e);		
		}
	}

	private static XmlSuite getPerformanceTestSuite(String[] docBrowserArr, String docBrowser, int noOfIterations, int noOfDocConfigBrowers, String[] testSuiteRunNames, int parallelCount) {
		List<XmlClass> perfClasses = new ArrayList<XmlClass>();
		perfClasses.add(new XmlClass("tests.web.performance.NewUsers"));
		perfClasses.add(new XmlClass("tests.web.performance.Consultations"));
		return getXmlSuite(VMedixUtils.TEST_TYPE_PERFORMANCE, perfClasses, docBrowserArr,docBrowser, noOfIterations, noOfDocConfigBrowers, testSuiteRunNames, parallelCount);
	}

	private static XmlSuite getSmokeTestSuite(String[] docBrowserArr, String docBrowser, int noOfIterations, int noOfDocConfigBrowers, String[] testSuiteRunNames, int parallelCount) {
		List<XmlClass> smokeClasses = new ArrayList<XmlClass>();
		smokeClasses.add(new XmlClass("tests.web.smoke.LoginScenarios"));
		smokeClasses.add(new XmlClass("tests.api.DoctorProfileAPI"));
		smokeClasses.add(new XmlClass("tests.api.PatientConsulatationAPI"));
		smokeClasses.add(new XmlClass("tests.web.smoke.AdminUserProfiles"));
		smokeClasses.add(new XmlClass("tests.web.smoke.AdminBulkUploadUsers"));
		smokeClasses.add(new XmlClass("tests.web.smoke.DoctorSelfProfile"));
		smokeClasses.add(new XmlClass("tests.web.smoke.DoctorConsultations"));
		smokeClasses.add(new XmlClass("tests.web.smoke.DoctorQAConsultations"));
		smokeClasses.add(new XmlClass("tests.web.smoke.PatientDoctorConsultation"));			
		smokeClasses.add(new XmlClass("tests.web.smoke.DependentConsultationVideo"));
		smokeClasses.add(new XmlClass("tests.web.smoke.AdminApplicationChoices"));
		smokeClasses.add(new XmlClass("tests.web.smoke.AdminPricingNRefunds"));
		smokeClasses.add(new XmlClass("tests.web.smoke.CallRepETE"));
		smokeClasses.add(new XmlClass("tests.web.smoke.AdminReports"));//pre-cond: admin reports to run after consultations
		smokeClasses.add(new XmlClass("tests.web.smoke.FacilitatorETE"));
		return getXmlSuite(VMedixUtils.TEST_TYPE_SMOKE, smokeClasses, docBrowserArr, docBrowser, noOfIterations, noOfDocConfigBrowers, testSuiteRunNames, parallelCount);
	}
	
	private static XmlSuite getRegressionTestSuite(String[] docBrowserArr, String docBrowser, int noOfIterations, int noOfDocConfigBrowers, String[] testSuiteRunNames, int parallelCount) {
		List<XmlClass> regressionClasses = new ArrayList<XmlClass>();
		//List of regression added here ...
		return getXmlSuite(VMedixUtils.TEST_TYPE_REGRESSION, regressionClasses, docBrowserArr,docBrowser, noOfIterations, noOfDocConfigBrowers, testSuiteRunNames, parallelCount);
	}

	private static XmlSuite getXmlSuite(String testType, List<XmlClass> testClasses, String[] docBrowserArr, String docBrowser, int noOfIterations, int noOfDocConfigBrowers, String[] testSuiteRunNames, int parallelCount) {
		XmlSuite xmlTestSuite = new XmlSuite();
		if (EnvironmentConfigSettings.isTestSequentialEnvConfig()) {
			xmlTestSuite.setName("Sequential Execution Suite - "+ testType);
			xmlTestSuite.setThreadCount(1);
		} else {
			xmlTestSuite.setName("Parallel Execution Suite - "+ testType);
			xmlTestSuite.setThreadCount(parallelCount);
			xmlTestSuite.setParallel(ParallelMode.TESTS);
		}
		int tmp = 0;
		for(int j=0;j<noOfDocConfigBrowers;j++)	{ 
			for(int i=0;i<noOfIterations;i++) {
				XmlTest	xmlTest = new XmlTest(xmlTestSuite);
				xmlTest.setName(testSuiteRunNames[tmp]);
				String webBrowserType = docBrowserArr[j];
				xmlTest.addParameter("webBrowserType", webBrowserType);
				xmlTest.setXmlClasses(testClasses);
				tmp++;
		    }
		}
		return xmlTestSuite;
	}
} 