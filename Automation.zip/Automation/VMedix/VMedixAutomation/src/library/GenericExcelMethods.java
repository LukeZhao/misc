package library;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import tests.TestCaseInit;

public class GenericExcelMethods {
	private static Logger log = Logger.getLogger(GenericExcelMethods.class.getName());
		
	/** 
	 * This method is used to read the complete excel sheet from Test Data excel and return data in 2 dimensional array
	 * @param 	testName	provide the test name to be read
	 * @return	Object[][]	data read in 2 dimensional array	
	 * @throws Exception
	 */
	public Object[][] getDataFromExcelTestData(String testName) throws Exception {
		// Read and Provide value to Data Provider
		String[][] arrayExcelData = null;
		FileInputStream fs = null;
		Workbook wb = null;
		try {
			fs = new FileInputStream(TestCaseInit.TestDataFile);
			wb = WorkbookFactory.create(fs);
			Sheet sh = wb.getSheet(testName);
			int totalNoOfCols = sh.getRow(0).getLastCellNum();
			int totalNoOfRows = sh.getLastRowNum() + 1; //including header
			arrayExcelData = new String[totalNoOfRows - 1][totalNoOfCols];
			for (int i = 1; i < totalNoOfRows; i++) {
				Row row = sh.getRow(i);
				for (int j = 0; j < totalNoOfCols; j++) {
					Cell cell = row.getCell(j);
					String value = cell.toString();
					arrayExcelData[i - 1][j] = value;
				}
			}
		} catch (Exception exp) {
			throw exp;
		} finally{
			try {
				if (fs != null) {
					fs.close();
				}
				if(wb != null){
					wb.close();
				}
			} catch (IOException ioExp) {
				log.error("Exception closing...", ioExp);
			}
		}
		return arrayExcelData;
	}

	/**
	 * This method reads the Test Data excel and returns the content of specific cell
	 * @param 	sheetName	provide the sheet name to be read
	 * @param 	rowNum		provide the row number of the cell on the sheet
	 * @param 	colNum		provide the column number of the cell on the sheet
	 * @return 	String		contents of the cell
	 * @throws 	Exception
	 */
	public String getCellDataFromExcelTestData(String sheetName, int rowNum, int colNum) throws Exception {
		//reading the data from the excel sheet
		FileInputStream fis = null;
		Workbook wbook = null;
		String data = null;
		try{
			fis = new FileInputStream(TestCaseInit.TestDataFile); 
			wbook = WorkbookFactory.create(fis);
			Sheet sh = wbook.getSheet(sheetName);
			Row row = sh.getRow(rowNum);
			data = row.getCell(colNum).getStringCellValue();
		} catch(Exception exp){
			throw exp;
		} finally{
			try {
				if (fis != null) {
					fis.close();
				}
				if(wbook != null){
					wbook.close();
				}
			} catch (IOException ioExp) {
				log.error("Exception closing...", ioExp);
			}
		}
		return data;
	}

	/**
	 * This method is used to get row number based on a unique cell content from Test Data excel
	 * @param	sheetName 
	 * @param	cellContent
	 * @throws	Exception 
	 */
	public int getRowNumberFromExcelTestData(String sheetName, String cellContent) throws Exception {
		FileInputStream fs = null;
		Workbook wb = null;
		try{
			fs = new FileInputStream(TestCaseInit.TestDataFile);
			wb = WorkbookFactory.create(fs);
			Sheet sh = wb.getSheet(sheetName);	
			int rowNum = 0;
			for (Row row : sh) {
				for (Cell cell : row) {
					if ((cell.getCellType() == Cell.CELL_TYPE_STRING) && (cell.getRichStringCellValue().getString().trim().equalsIgnoreCase(cellContent))) {
						rowNum = row.getRowNum();
					}
				}
			}
			return rowNum;
		} catch(Exception exp){
			throw exp;
		} finally {
			try {
				if (fs != null) {
					fs.close();
				}
				if(wb != null){
					wb.close();
				}
			} catch (IOException ioExp) {
				log.error("Exception closing...", ioExp);
			}
		}			
	}

	/**
	 * This method is used to get test case execute status from Test Suite excel file
	 * @param testCaseName	name of the test case 
	 * @param sheetName		name of the sheet from Test Suite file
	 * @return boolean 		
	 * @throws Exception
	 */
	public boolean getExecuteTestCase(String testCaseName, String sheetName) throws Exception {
		boolean result = false;
		FileInputStream fileInStr = null;
		Workbook wrBk = null;
		try {
			File file = new File(TestCaseInit.TestSuiteFile);
			fileInStr = new FileInputStream(file);
			wrBk = new XSSFWorkbook(fileInStr);
			Sheet sh = wrBk.getSheet(sheetName);	
			if(sh ==  null){
				log.error("Did not find the sheet: "+sheetName+" in TestSuite excel");
				System.exit(1);
			}
			int rowcount = sh.getLastRowNum();
			for (int row = 0; row <= rowcount; row++) {
				String testCaseNameFrmExcel = sh.getRow(row).getCell(0).getStringCellValue();
				if (testCaseName.equalsIgnoreCase(testCaseNameFrmExcel)) {
					String executeFromExcel = sh.getRow(row).getCell(2).getStringCellValue();
					TestCaseInit.testCaseType = sh.getRow(row).getCell(3).getStringCellValue();
					if (VMedixUtils.YES.equalsIgnoreCase(executeFromExcel)) {
						result = true;
					}
					break;
				}				
			}
		} catch (Exception e) {
			log.error("An Exception occurred in checkValueInExcel", e);
			throw e;
		} finally {
			try {
				if(fileInStr != null) {
					fileInStr.close();
				}
				if(wrBk != null){
					wrBk.close();
				}
			} catch (IOException ioExp) {
				log.error("Exception closing...", ioExp);
			}
		}
		return result;
	}
}
