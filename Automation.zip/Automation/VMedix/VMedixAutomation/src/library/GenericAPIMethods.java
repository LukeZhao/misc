package library;


import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import tests.TestCaseInit;

public class GenericAPIMethods {
	static Logger log = Logger.getLogger(GenericAPIMethods.class.getName());
	static JSONObject jsonObject = new JSONObject();
	static JSONObject childjsonObject = new JSONObject();
	public GenericExcelMethods genExcelMethods = new GenericExcelMethods();

	String token = null;
	String account_id = null;
	String authvalue = null;
	String posttokenid = null;
	String consulatationid = null;
	int actualcode = 0;
	int lengthofconsults = 0;
	String url = null;
	String JSON_Result;
	
	public int apiAssertFailCount = 0;

	/**
	 * This method is used to get the response for Rest API call 
	 * @param	sheetname 
	 * @param	cellContent
	 * @throws	Exception
	 */
	public void getResponse(String sheetName, String cellContent) throws Exception {
		log.info("Getting the information from the Test Data excel sheet: " + sheetName);
		log.info("Getting the response for: " + cellContent + " API");
		
		int rownum = genExcelMethods.getRowNumberFromExcelTestData(sheetName, cellContent);
		
		//get full url for api
		String urlSuffixFromSheet = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 0);
		if(rownum != 12) {	// row 12 is not environment specific; https://api.stripe.com/v1/tokens
			urlSuffixFromSheet = TestCaseInit.apiUrl + urlSuffixFromSheet;
		}		
		String xapikey = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 1);
		String xapivalue = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 2);
		String acceptlanguage = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 3);
		String acceptlanguagevalue = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 4);
		String acceptencoding = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 5);
		String acceptencodingvalue = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 6);
		String contenttype = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 7);
		String contenttypevalue = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 8);
		String username = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 9);
		String usernamevalue = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 10);
		String password = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 11);
		String passwordvalue = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 12);
		String auth = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 13);
		String methodtype = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 14);
		String elementype = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 15);
		String datatype = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 16);
		String urlname = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 17);
		String key = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 18);
		String keyval = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 19);
		String pay = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 20);
		String payval = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 21);
		String cardnum = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 22);
		String cardcvv = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 23);
		String cardexmonth = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 24);		
		String cardexyr = genExcelMethods.getCellDataFromExcelTestData("API", rownum, 25);		
		if (urlSuffixFromSheet.contains("ACCOUNT_ID")) {
			if (urlname.equalsIgnoreCase("PrevConsults")) {
				String s1 = urlSuffixFromSheet;
				String s2 = s1.replace("ACCOUNT_ID", account_id);
				url = s2;
			}else{
				URIBuilder builder = new URIBuilder(urlSuffixFromSheet);
				builder.setPath(builder.getPath().replace("ACCOUNT_ID", account_id));
				url = builder.toString();
				log.info("URL after replace: " + builder.toString());				
			}	
		} else if (urlSuffixFromSheet.contains("CONSULTATION_ID")) {
			URIBuilder builder = new URIBuilder(urlSuffixFromSheet);
			builder.setPath(builder.getPath().replace("CONSULTATION_ID", consulatationid));
			url = builder.toString();
		} else {
			url = urlSuffixFromSheet;
		}

		log.info("Data from " + rownum + " of excel for " + cellContent + " API");
		log.info("Data is as follows-> "
				+ "; URL: " + url 
				+ "; Method Type: " + methodtype 
				+ "; X-API-KEY: " + xapivalue
				+ "; Accept Language: " + acceptlanguagevalue
				+ "; Accept Encoding: " + acceptencodingvalue
				+ "; Content-Type: " + contenttypevalue 
				+ "; Username: " + usernamevalue);
		if (methodtype != null) {
			if (methodtype.equalsIgnoreCase("POST")) {
				log.info("Validating the Method Type. For current API it is "+ methodtype);
				getResponseForPostevents(url, xapikey, xapivalue, acceptlanguage, acceptlanguagevalue, acceptencoding, acceptencodingvalue, 
						contenttype, contenttypevalue, username, usernamevalue, password, passwordvalue, urlname, elementype, datatype, key, 
						keyval, pay, payval, cardnum, cardcvv, cardexmonth, cardexyr, auth);
			} else if (methodtype.equalsIgnoreCase("GET")) {
				getResponseForGetEvents(url, xapikey, xapivalue, urlname, elementype, datatype, auth);
			} else {
				log.error("Method Type is other then GET or POST!");
				throw new Exception("Method Type is other then GET or POST!");
			}
		}
	}



	/**
	 * This helper method is used to get the response for POST events by setting the header values and generating a JSON response. 
	 * @param	String url, String xapikey, String xapivalue, String acceptlanguage, String acceptlanguagevalue, String acceptencoding,
	 *        	String acceptencodingvalue, String contenttype, String contenttypevalue, String username, String usernamevalue, 
	 *        	String password, String passwordvalue, String urlname, String elementype, String value, String datatype
	 * @throws Exception
	 */
	private void getResponseForPostevents(String url, String xapikey, String xapivalue, String acceptlanguage, String acceptlanguagevalue, 
			String acceptencoding, String acceptencodingvalue, String contenttype, String contenttypevalue, String username, String usernamevalue,
			String password, String passwordvalue, String urlname, String elementype, String datatype, String key, String keyval, String pay, 
			String payval, String cardnum, String cardcvv, String cardexmonth, String cardexyr, String auth) throws Exception {
		log.info("Getting the response for POST events-->");
		HttpClient httpClient = HttpClientBuilder.create().build();
		HttpPost post = new HttpPost(url);
		post.setHeader(xapikey, xapivalue);
		post.setHeader(acceptlanguage, acceptlanguagevalue);
		post.setHeader(acceptencoding, acceptencodingvalue);
		post.setHeader(contenttype, contenttypevalue);
		String authvalue = "Bearer " + token;
		post.setHeader(auth, authvalue);

		JSONObject jobj = new JSONObject();
		JSONObject childjobj = new JSONObject();
		if (urlname.equalsIgnoreCase("Login") || urlname.equalsIgnoreCase("DocLogin")) {
			jobj.put(username, TestCaseInit.getUsername());
			jobj.put(password, TestCaseInit.getPassword());
			StringEntity se = new StringEntity(jobj.toString());
			post.setEntity(se);

		}
		if (urlname.equalsIgnoreCase("PaymentTOKEN")) {
			List<NameValuePair> params = new ArrayList<NameValuePair>(2);
			params.add(new BasicNameValuePair(key, keyval));
			params.add(new BasicNameValuePair(cardnum, TestCaseInit.cardnumval));
			params.add(new BasicNameValuePair(cardcvv, TestCaseInit.cardcvvval));
			params.add(new BasicNameValuePair(cardexmonth, TestCaseInit.cardexmonthval));
			params.add(new BasicNameValuePair(cardexyr, TestCaseInit.cardexyrval));
			post.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
		}
		if (urlname.equalsIgnoreCase("GETConsultation")) {
			jobj.put("chief_complaint", TestCaseInit.chiefcomplaint);
			jobj.put("contact_phone", TestCaseInit.contactphone);
			jobj.put("location", TestCaseInit.location);
			jobj.put("method_of_contact", TestCaseInit.methodofcontact);
			jobj.put("patient", account_id);
			childjobj.put("transaction_id", posttokenid.toString());
			childjobj.put("vendor", "stripe".toString());
			jobj.put("payment", childjobj);
			StringEntity se = new StringEntity(jobj.toString());
			post.setEntity(se);
		}
		// get response after execution
		HttpResponse response = httpClient.execute(post);
		log.info("Executing the api request to get the response");
		String result = EntityUtils.toString(response.getEntity());
		jsonObject = new JSONObject(result);
		log.info("Parsing the response in JSONObject" + jsonObject);
		if (urlname.equalsIgnoreCase("GETConsultation")) {
			Assert.assertEquals(response.getStatusLine().getStatusCode(), HttpStatus.SC_CREATED);
		} else {
			Assert.assertEquals(response.getStatusLine().getStatusCode(), HttpStatus.SC_OK);
		}

		actualcode = response.getStatusLine().getStatusCode();
		log.info("Expected and Actual Status Code are checked and verified");
		if (urlname.equalsIgnoreCase("GETConsultation")) {
			log.info("Expected Status Code " + HttpStatus.SC_CREATED);
			log.info("Actual Status Code "+ response.getStatusLine().getStatusCode());
		} else {
			log.info("Expected Status Code " + HttpStatus.SC_OK);
			log.info("Actual Status Code "+ response.getStatusLine().getStatusCode());
		}

		log.info("Expected and Actual Status Code are checked and verified");
		if (actualcode == HttpStatus.SC_OK || actualcode == HttpStatus.SC_CREATED) {
			matchElements(url, urlname, elementype, datatype);
		}
	}

	/**
	 * This helper method is used to get the response for GET events by setting the header values and generating a JSON response. 
	 * @param	String url, String xapikey, String xapivalue, String acceptlanguage, String acceptlanguagevalue, String acceptencoding,
	 *        	String acceptencodingvalue, String contenttype, String contenttypevalue, String username, String usernamevalue, 
	 *        	String password, String passwordvalue, String urlname, String elementype, String value, String datatype
	 * @throws 	Exception
	 */
	private void getResponseForGetEvents(String url, String xapikey, String xapivalue, String urlname, String elementype, String datatype, String auth) throws Exception {
		HttpUriRequest request = new HttpGet(url);
		request.setHeader(xapikey, xapivalue);
		String authvalue = "Bearer " + token;
		request.setHeader(auth, authvalue);
		HttpResponse httpResponse = HttpClientBuilder.create().build().execute(request);
		String result = EntityUtils.toString(httpResponse.getEntity());
		if (urlname.equalsIgnoreCase("PrevConsults")) {	
			JSONArray jsonArray = new JSONArray(result);
			  lengthofconsults = jsonArray.length();
	        for(int i =0; i< jsonArray.length(); i++){
	            if(jsonArray.get(i) instanceof JSONObject){
	            	jsonObject = (JSONObject)jsonArray.get(i);
	            }
	        }	
		}else{
			jsonObject = new JSONObject(result);
		}
		JSON_Result = jsonObject.toString();
		log.info("Parsing the response in JSONObject" + jsonObject);
		Assert.assertEquals(httpResponse.getStatusLine().getStatusCode(), HttpStatus.SC_OK);
		actualcode = httpResponse.getStatusLine().getStatusCode();
		log.info("Expected and Actual Status Code are checked and verified");
		log.info("Expected Status Code: " + HttpStatus.SC_OK);
		log.info("Actual Status Code: "+ httpResponse.getStatusLine().getStatusCode());
		log.info("Expected and Actual Status Code are checked and verified");
		if (actualcode == HttpStatus.SC_OK) {
			matchElements(url, urlname, elementype, datatype);
		}
	}
	
	/**
	 * This helper method is used to match the elements from the JSON Response to that on VMedix UI.
	 * @param	String url, String urlname, String elementype, String value, String datatype
	 * @throws	Exception
	 */
	private void matchElements(String url, String urlname, String elementype, String datatype) throws Exception {
		ArrayList<String> arrayList = new ArrayList<String>();
		String[] listofElementType = null;
		String listOfData = elementype;
		if (listOfData.contains(",")) {
			listofElementType = listOfData.split("\\,");
			for (String eletype : listofElementType) {
				arrayList.add(eletype);
			}
		} else {
			elementype = listOfData;
		}
		try{
			log.info("Matching the elements from JSON Payload and VMedix UI");
			if ((urlname.equalsIgnoreCase("Login")) && (datatype.equalsIgnoreCase("String"))) {
				Assert.assertEquals(TestCaseInit.getCurrentlogin(), jsonObject.getString(arrayList.get(0)));
				log.info("Verification is Successful");
				token = jsonObject.getString(arrayList.get(1));
				Assert.assertNotNull(token, "Token is Not Null");
				account_id = jsonObject.getString(arrayList.get(2));
			}
	
			if ((urlname.equalsIgnoreCase("Price")) && (datatype.equalsIgnoreCase("Double"))) {
				if (JSON_Result.contains(arrayList.get(1))) {
					Double amt = jsonObject.getDouble(arrayList.get(2));
					String amt1 = amt.toString();
					String discamt = amt1.indexOf(".") < 0 ? amt1 : amt1.replaceAll("0*$", "").replaceAll("\\.$", "");
					Assert.assertEquals(TestCaseInit.getAmount(), discamt);
				} else {
					Double oriamt = jsonObject.getDouble(arrayList.get(0));
					String oriamt1 = oriamt.toString();
					String oriamt2 = oriamt1.indexOf(".") < 0 ? oriamt1 : oriamt1.replaceAll("0*$", "").replaceAll("\\.$", "");
					Assert.assertEquals(TestCaseInit.getAmount(), oriamt2);
				}
				log.info("Verification is Successful");
			}
	
			if ((urlname.equals("Privacy")) && (datatype.equalsIgnoreCase("String"))) {
				Assert.assertEquals("privacy", jsonObject.getString(elementype));
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("TermsOfUse")) && (datatype.equalsIgnoreCase("String"))) {
				Assert.assertEquals("eula", jsonObject.getString(elementype));
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("Consent")) && (datatype.equalsIgnoreCase("String"))) {
				Assert.assertEquals("consent", jsonObject.getString(elementype));
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("States")) && (datatype.equalsIgnoreCase("Int"))) {
				Assert.assertEquals(TestCaseInit.getStatecount(), jsonObject.getInt(elementype));
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("DocLogin")) && (datatype.equalsIgnoreCase("String"))) {
				Assert.assertEquals(TestCaseInit.getCurrentlogin(), jsonObject.getString(arrayList.get(0)));
				log.info("Verification is Successful");
				token = jsonObject.getString(arrayList.get(1));
				Assert.assertNotNull(token, "Token is Not Null");
				account_id = jsonObject.getString(arrayList.get(2));
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("UserDetails")) && (datatype.equalsIgnoreCase("String"))) {
				String patietnamefromjson = (jsonObject.getString(arrayList.get(0)) + " " + jsonObject.getString(arrayList.get(1)));
				Assert.assertEquals(TestCaseInit.getPatientname().toLowerCase(), patietnamefromjson.toLowerCase());
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("Complaints")) && (datatype.equalsIgnoreCase("Int"))) {
				Assert.assertEquals(TestCaseInit.getCountcomplaints(), jsonObject.getInt(elementype));
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("Medication")) && (datatype.equalsIgnoreCase("Int"))) {
				Assert.assertEquals(TestCaseInit.getCountmedications(), jsonObject.getInt(elementype));
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("PaymentTOKEN")) && (datatype.equalsIgnoreCase("String"))) {
				posttokenid = jsonObject.getString(elementype);
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("GETConsultation")) && (datatype.equalsIgnoreCase("String"))) {
				consulatationid = jsonObject.getString(arrayList.get(0));
				log.info("Verification is Successful");
			}
	
			if ((urlname.equalsIgnoreCase("WaitngRoom")) && (datatype.equalsIgnoreCase("String"))) {
				log.info("Verification is Successful");
			}
			
			if ((urlname.equalsIgnoreCase("DocDetails")) && (datatype.equalsIgnoreCase("String"))) {
				String docnamefromjson = (jsonObject.getString(arrayList.get(0)) + " " + jsonObject.getString(arrayList.get(1)));
				Assert.assertEquals(TestCaseInit.getDocname().toLowerCase(), docnamefromjson.toLowerCase());
				String email = jsonObject.getString(arrayList.get(2));
				Assert.assertEquals(TestCaseInit.getDocemail().toLowerCase(), email);
				log.info("Verification is Successful");
			}		
			
			if (urlname.equalsIgnoreCase("PrevConsults")) {
				Assert.assertEquals(TestCaseInit.getCountviewconsultsfromui(), lengthofconsults);
				log.info("Verification is Successful");
			}
		} catch(Throwable th){
			if(th instanceof AssertionError){
				log.error("Verification Failed");
				apiAssertFailCount++;
			}
		}
	}
}
