package library;

import java.io.File;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import tests.TestCaseInit;

public abstract class GenericLib {

	private static Logger log = Logger.getLogger(GenericLib.class.getName());
	
	protected GenericLib() {} //Avoid instantiation
	
	/**
	 * This method is used to take screenshot of the open drivers and store, based on pass or fail
	 * @throws Exception
	 */
	public void takeScreenshot() throws Exception {
		//check the test has failed or passed and get file path to store the screen shot 
		String scrnShotFilePath = null;
		if(TestCaseInit.testCaseStatus) {
			if(EnvironmentConfigSettings.isScreenshotOnPassEnvConfig()) {
				scrnShotFilePath = TestCaseInit.passedScreenShotsFilePath;
			}						
		} else {
			scrnShotFilePath = TestCaseInit.failedScreenShotsFilePath;			
		}
		
		//get screenShots of all the open drivers 
		if(scrnShotFilePath != null) {
			log.info("Screen shot path: "+ scrnShotFilePath);			
			if(TestCaseInit.driverDoctor != null) {
				getScreenshot(scrnShotFilePath, TestCaseInit.driverDoctor);
			} 
			if(TestCaseInit.driverPatient != null) {
				getScreenshot(scrnShotFilePath, TestCaseInit.driverPatient);
			}
			if(TestCaseInit.driverAdmin != null) {
				getScreenshot(scrnShotFilePath, TestCaseInit.driverAdmin);				
			}			
			if(TestCaseInit.driverCallRep != null) {
				getScreenshot(scrnShotFilePath, TestCaseInit.driverCallRep);				
			}
			if(TestCaseInit.driverGmail != null) {
				getScreenshotForGmail(scrnShotFilePath, TestCaseInit.driverGmail);				
			}
			if(TestCaseInit.appiumStarted && TestCaseInit.appiumDriver != null) {
				getScreenshot(scrnShotFilePath, TestCaseInit.appiumDriver);
			}
			log.info("Completed screen shots!");
		}
	}
	
	// Helper - takes screen shot of the driver and store in the file path specified
	private static void getScreenshot(String filePath, WebDriver driver) throws Exception {		
		String timestamp = new java.text.SimpleDateFormat("dd_MM_yy_HH_mm_ss").format(new Date().getTime());
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(filePath+ TestCaseInit.testCaseName + "_" + timestamp + ".jpeg"));
	}
	
	private static void getScreenshotForGmail(String filePath, WebDriver driver) throws Exception {	
		try {			
			//handle alert pop up if any
			WebDriverWait wait = new WebDriverWait(driver, 2);		
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			alert.accept();
			log.info("In getScreenshot: Alert accepted with text: " + alertText);		
		} catch (TimeoutException toExp){
			log.info("In getScreenshot: Timed out with No Alert pop");  
		} catch (NoAlertPresentException neExp){
			log.error("In getScreenshot: Could NOT switch to alert pop up");  
		} catch (Exception exp) {
			throw exp;
		} finally {
			//taking screen short after closing alert pop up if any
			try{
				getScreenshot(filePath, driver);
			} catch (Exception exp){
				log.error("Exception found while taking screen shot. Exception: " + exp);
			}
		}
	}		
}