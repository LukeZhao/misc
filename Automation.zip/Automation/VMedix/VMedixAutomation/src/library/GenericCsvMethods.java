package library;

import java.io.FileReader;

import com.opencsv.CSVReader;

import tests.TestCaseInit;

public class GenericCsvMethods {
//	private static Logger log = Logger.getLogger(GenericCsvMethods.class.getName());
	
	/** 
	 * This method is used to read the complete excel sheet from Test Data excel and return data in 2 dimensional array
	 * @param 	testName	provide the test name to be read
	 * @return	Object[][]	data read in 2 dimensional array	
	 * @throws Exception
	 */
	public Object[][] getDataFromCSVTestData(String testName) throws Exception {
		
		//verify if the testname specified has data in the file and get the count of test data
		int testDataRowCount = getTestDataRowCountForTestname(testName);

		// Read and Provide value to Data Provider		
		String[][] arrayExcelData = null;
		if(testDataRowCount > 0){
			CSVReader reader = null;
			String csvLocation = TestCaseInit.TestDataFile;
			try {
				reader = new CSVReader(new FileReader(csvLocation));
				String[] line = null;
				int rowCount = 0;
				 while ((line = reader.readNext()) != null) {				
					if(line[0].equalsIgnoreCase(testName)){
						int colTotNum = line.length;
						arrayExcelData = new String[testDataRowCount][colTotNum-1]; 
						for (int j = 1; j <colTotNum; j++) {
							arrayExcelData[rowCount][j-1] = line[j];
						}
						rowCount++;
					}				
				}
			} catch (Exception exp) {
				throw new Exception("Could not read csv file under the location: "+ csvLocation);
			} finally{
				if(reader != null){
					reader.close();
				}
			}	
		}
		return arrayExcelData;
	}

	private int getTestDataRowCountForTestname(String testName) throws Exception {
		int testDataRowCount = 0;
		CSVReader reader = null;
		String csvLocation = TestCaseInit.TestDataFile;
		try {			
			reader = new CSVReader(new FileReader(csvLocation));
			String[] line = null;
			while ((line = reader.readNext()) != null) {				
				if(line[0].equalsIgnoreCase(testName)){
					testDataRowCount++;
				}				
			}
		} catch (Exception exp) {
			throw new Exception("Could not read csv file under the location: "+ csvLocation);
		} finally{
			if(reader != null){
				reader.close();
			}
		}	
		return testDataRowCount;
	}
}
