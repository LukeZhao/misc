package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class CallRepPage {
	static Logger log = Logger.getLogger(CallRepPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if on Call Rep Page
	 */	
	public boolean verifyOnCallRepPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("callRepLandingPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Call Rep Page
	 */
	public void verifyNValidateOnCallRepPage(WebDriver driver)throws Exception {
		if(!verifyOnCallRepPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Call Rep Page");
			Assert.fail("NOT on Call Rep Page");
		}		
		log.info("On Call Rep Page");
	}
	
	public void clickOnNewPatConsult(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("callRepNewPatConsultAncLink.id", driver);
	}

	/**
	 * This method is used to start a consult for a patient; if the patient is in some other sate it is brought to a begin state
	 * @throws Exception 
	 */	
	public void lookUpNStartNewConsultForExtPat(String patEmail, String patName, WebDriver driver) throws Exception {
		//search the patient
		if(!lookUpPatient(patEmail, patName, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Patient NOT found, "+ patEmail);
			Assert.fail("Patient NOT found, "+ patEmail);
		}
		log.info("Patient Found, "+ patEmail);
		//start consult
		clickStartConsultForExtPat(driver);
	}
	
	public void clickStartConsultForExtPat(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("callRepFirstStartNewConsulTdAncLink.id", driver);
	}
	
	public boolean verifyPatAlreadyInConsult(WebDriver driver) throws Exception{
		boolean alreadyInConsult = false;
		//verify if the patient is not already in a consultation
		if(genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver)){
			String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);		
			if(TestCaseInit.messagesVMedixProp.getProperty("startConsultPat.error").equals(toastMsg)) {				
				alreadyInConsult = true;	
			}			
		}
		return alreadyInConsult;
	}
	
	/**
	 * This method is used to lookup a patient on call Rep
	 * @return 
	 */	
	public boolean lookUpPatient(String patEmail, String patName, WebDriver driver) throws Exception{
		boolean found = false;
		genLibWeb.enterTextValueByID("callRepSearchInp.id", patEmail, driver);
		genLibWeb.clickOnElementByID("callRepSearchBtn.id", driver);
		Thread.sleep(1000);
		//verify if found by matching the Patient name
		if(genLibWeb.getTextByID("callRepFirstPatientNameTdAncLink.id", driver).equalsIgnoreCase(patName)){
			found = true;
		} else{
			log.info("Patient has NO pending consultation");
		}
		return found;		
	}
}
