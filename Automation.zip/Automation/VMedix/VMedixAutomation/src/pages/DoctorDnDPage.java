package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class DoctorDnDPage {
	static Logger log = Logger.getLogger(DoctorDnDPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	CommonUtilsPage cmnUtilsPage = new CommonUtilsPage(); 
	/**
	 * This method is used to verify if doctor is on D&D Page
	 */	
	public boolean verifyDoctorOnDnDPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docDnDPageTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if doctor is on D&D Page
	 */
	public void verifyNValidateDoctorOnDnDPage(WebDriver driver)throws Exception {
		if(!verifyDoctorOnDnDPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT on D&D Page");
			Assert.fail("Doctor is NOT on D&D Page");
		}		
		log.info("Doctor is on D&D Page");
	}
	
	/**
	 * This method is used to verify medication and allergy entries from in-consultation page 
	 */
	public void verifyMedicationsNAllergiesFromInConsultation(String oldMedications, String oldAllergies, WebDriver driver)throws Exception{
		String errMsg = "Failed on medications and allergies asserts, ";
		Thread.sleep(2000);
		try{
			//medications			
			Assert.assertTrue(cmnUtilsPage.isOldMedicationsPresent(oldMedications, "docDnDMedicationsOldListP.xpath", null, "docDnDMedicationsOldSpan.xpath", driver), errMsg+"Medications");
			//allergies			
			Assert.assertTrue(cmnUtilsPage.isOldAllergiesPresent(oldAllergies, "docDnDAllergiesOldListP.xpath", null, "docDnDAllergiesOldSpan.xpath", driver), errMsg+"Allergies");
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
	}
	
	public void verifyNonSoapHnPTemplatePatInfoHeader(String hnpTemplate, String newHnPTemplateHeader, WebDriver driver) throws Exception {
		genLibWeb.scrollToViewElementWithID("docInConsultHnPFormChooseDrpBx.id", driver);
        genLibWeb.selectByVisibleTextFromSelectElementID("docInConsultHnPFormChooseDrpBx.id", hnpTemplate, driver); 
        Thread.sleep(1000);
		try{
			if(StringUtils.isNotBlank(newHnPTemplateHeader)){
				Assert.assertTrue(genLibWeb.getTextByXPath("docInConsultHnPTemplatePatInfoHeaderSpan.xpath", null, driver).equalsIgnoreCase(newHnPTemplateHeader), "Failed asserts for Patient Information Header Text on D&D Page");
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}	
	}
	
	/**
	 * This method is used to verify medication added by Admin is present and auto displayed on Doctor in DnD
	 * @param driver
	 * @throws Exception 
	 */
	public void verifyMedicationAddedByAdmin(String med1Add, WebDriver driver) throws Exception {
		if(!cmnUtilsPage.verifyPresentInDropBoxAfterAutoDisplay(med1Add, "docDnDMedicationsInp.xpath", null, "docDnDMedicationsDrpBxWithVal.ngClick.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Medication added NOT found on Doctor in DnD: " +med1Add);
			Assert.fail("Medication added NOT found on Doctor in DnD: " +med1Add);
		}
		log.info("Medication added was Found on Doctor in DnD: " +med1Add);			
	}

	/**
	 * This method is used to enter medications and allergies on D&D page 
	 */
	public void editMedicationsNAllergies(String medications, String allergies, WebDriver driver) throws Exception{
		//remove old and add new
		//enter medications
		if (StringUtils.isNotBlank(medications)){
			//remove all medications
			cmnUtilsPage.removeOldMedications("docDnDMedicationsOldListP.xpath", null, "docDnDMedicationsOldRemoveSpan.xpath", driver);
			if(!cmnUtilsPage.enterMedications(medications, "docDnDMedicationsInp.xpath", null, "docDnDMedicationsAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Medications were NOT added");				
				Assert.fail("One of the Medications were NOT added");		
			}
			log.info("All Medications were added");
		}
		//enter allergies
		if (StringUtils.isNotBlank(allergies)){
			//remove all allergies
			cmnUtilsPage.removeOldAllergies("docDnDAllergiesOldListP.xpath", null, "docDnDAllergiesOldRemoveSpan.xpath", driver);
			if(!cmnUtilsPage.enterAllergies(allergies, "docDnDAllergiesInp.xpath", null, "docDnDAllergiesAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Allergies were NOT added");				
				Assert.fail("One of the Allergies were NOT added");		
			}
			log.info("All  Allergies were added");
		}		
	}
	
	/**
	 * This method is used to verify D&D entries from in-consultation page 
	 */
	public void verifyDnDEntriesFromInConsultation(String diagCode, String followUp, String returnToSchWrk,	String restrt, String durOfRestrt, WebDriver driver) throws Exception {
		String errMsg = "Failed on D&D asserts, ";
		Thread.sleep(2000);
		try{		
			Assert.assertTrue(cmnUtilsPage.isOldDiagnosisCodePresent(diagCode+VMedixUtils.NON_EXISTING_DIAGNOSIS_CODE_SUFFIX, "docDnDDiagnosisCodeOldListP.xpath", null, "docDnDDiagnosisCodeOldSpan.xpath", 
					driver), errMsg+"Diagnosis Code");//since non existing code was entered, the diagnosis code is suffixed with :General
			Assert.assertEquals(genLibWeb.getValueByID("docDnDFollowUpInp.id", driver), followUp, errMsg+"Follow Up");
			Assert.assertEquals(genLibWeb.getValueByID("docDnDReturnToSchOrWrkInp.id", driver), returnToSchWrk, errMsg+"Return to School/Work");
			Assert.assertEquals(genLibWeb.getValueByID("docDnDWrkSchRestrictionInp.id", driver), restrt, errMsg+"Restrictions");
			Assert.assertEquals(genLibWeb.getValueByID("docDnDWrkSchRestrictDurationInp.id", driver), durOfRestrt, errMsg+"Duration of Restrictions");		
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}
	
	/**
	 * This method is used to edit D&D entries on D&D page 
	 * @throws Exception 
	 */
	public void editDnDValuesOnDnDPage(String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String personalizedDInstr, WebDriver driver) throws Exception {
		//remove old diagnosis code and add new one
		cmnUtilsPage.removeOldDiagnosisCodes("docDnDDiagnosisCodeOldListP.xpath", null, "docDnDDiagnosisCodeOldRemoveSpan.xpath", driver);
		if(!cmnUtilsPage.enterDiagnosisCodes(diagCode, "docDnDDiagnosisCodeInp.xpath", null, "docDnDDiagnosisCodeBtn.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("One of the Diagnosis Codes were NOT added");				
			Assert.fail("One of the Diagnosis Codes were NOT added");	
		}
		genLibWeb.scrollToViewElementWithID("docDnDFollowUpInp.id", driver);
		genLibWeb.enterTextValueByID("docDnDFollowUpInp.id", followUp, driver);
		genLibWeb.enterTextValueByID("docDnDReturnToSchOrWrkInp.id", returnToSchWrk, driver);
		genLibWeb.enterTextValueByID("docDnDWrkSchRestrictionInp.id", restrt, driver);
		genLibWeb.enterTextValueByID("docDnDWrkSchRestrictDurationInp.id", durOfRestrt, driver);
		if(personalizedDInstr != null){
			genLibWeb.enterTextValueWithActionByXPath("docInConsultDnDSecPersonalizedDInstrP.xpath", null, personalizedDInstr, driver);						
		}
	}

	/**
	 * This method is used to verify H&P Soap Notes
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @param driver
	 * @throws Exception 
	 */
	public void verifyHnPSoapNotesEntriesFromInConsultation(String hpSoapSub, String hpSoapObj, WebDriver driver) throws Exception {
		String errMsg = "Failed on H&P SOAP Note asserts, ";
		try{
			genLibWeb.scrollToViewElementWithID("docInConsultHnPFormChooseDrpBx.id", driver);
			Assert.assertEquals(genLibWeb.getTextByXPath("docHnPSoapNoteSubjectiveP.xpath", null, driver), hpSoapSub, errMsg+"Subjective");
			Assert.assertEquals(genLibWeb.getTextByXPath("docHnPSoapNoteObjectiveP.xpath", null, driver), hpSoapObj, errMsg+"Objective");
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}	

	/**
	 * This method is used to enter Soap Note H&P Template
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @param driver
	 * @throws Exception 
	 */
	public void enterHnPTemplateSoapNotes(String hpSoapSub, String hpSoapObj, WebDriver driver) throws Exception {
		genLibWeb.scrollToViewElementWithID("docInConsultHnPFormChooseDrpBx.id", driver);
        genLibWeb.selectByVisibleTextFromSelectElementID("docInConsultHnPFormChooseDrpBx.id", VMedixUtils.SOAP_HnP_TEMPLATE, driver); 
        genLibWeb.enterTextValueWithActionByXPath("docHnPSoapNoteSubjectiveBr.xpath", null, hpSoapSub, driver);        
	    genLibWeb.enterTextValueWithActionByXPath("docHnPSoapNoteObjectiveBr.xpath", null, hpSoapObj, driver);     
	    //click outside, so Objective value is saved 
        genLibWeb.clickOnElementByXPath("docHnPSoapNoteTitleH2.xpath", null, driver); //clicked on SOAP Note Title
     }
	
	/**
	 * This method is used to edit H&P Soap Notes on D&D Page
	 * @param hpSoapSub
	 * @param hpSoapObj
	 * @param driver
	 * @throws Exception 
	 */
	public void editHnPSoapNotesOnDnDPage(String hpSoapSub, String hpSoapObj, WebDriver driver) throws Exception {
		genLibWeb.scrollToViewElementWithID("docInConsultHnPFormChooseDrpBx.id", driver);
        genLibWeb.enterTextValueWithActionByXPath("docHnPSoapNoteSubjectiveP.xpath", null, hpSoapSub, driver);        
        genLibWeb.enterTextValueWithActionByXPath("docHnPSoapNoteObjectiveP.xpath", null, hpSoapObj, driver);
        //click outside, so Objective value is saved 
        genLibWeb.clickOnElementByXPath("docHnPSoapNoteTitleH2.xpath", null, driver); //clicked on SOAP Note Title
	}

	/**
	 * This method is used to verify ePrescribe and Fax options on D&D Page
	 * @param driver
	 * @throws Exception 
	 */
	public void verifyePrescribeAndFaxOnDnD(WebDriver driver) throws Exception {
		genLibWeb.scrollToViewElementWithID("docDnDePrescribeBtn.id", driver);
		genLibWeb.isElementFoundByID("docDnDePrescribeBtn.id", driver);
		genLibWeb.scrollToViewElementWithID("docDnDFaxBtn.id", driver);
		genLibWeb.isElementFoundByID("docDnDFaxBtn.id", driver);		
	}
	
	/**
	 * This method is used to verify refund on D&D Page
	 * @param driver
	 * @throws Exception 
	 */
	public void verifyRefundOptions(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByXPath("docDnDRefundYesRdBtnLabel.xpath", null, driver);		
		if(genLibWeb.isElementEnabledByID("docDnDSubmitBtn.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Refund reason NOT entered and Submit button is Enabled");
			Assert.fail("Refund reason NOT entered and Submit button is Enabled");
		}
		log.info("Refund reason not entered and Submit button is Disabled");
		genLibWeb.clickOnElementByXPath("docDnDRefundNoRdBtnLabel.xpath", null, driver); //set back to No refund		
	}
	
	/**
	 * This method is used to request refund on D&D Page
	 * @param reasonForRefund
	 * @param driver
	 * @throws Exception 
	 */
	public void requestRefund(String reasonForRefund, WebDriver driver) throws Exception {
		genLibWeb.scrollToViewElementWithID("docDnDRefundYesRdBtnLabel.xpath", driver);
		genLibWeb.clickOnElementByXPath("docDnDRefundYesRdBtnLabel.xpath", null, driver);		
		genLibWeb.enterTextValueByXPath("docDnDRefundReasonInp.xpath", null, reasonForRefund, driver);
	}
	
	/**
	 * This method is used to verify upload files on D&D Page
	 * @param driver
	 * @throws Exception 
	 */
	public void verifyUploadFiles(WebDriver driver) throws Exception {
		if(!genLibWeb.isElementFoundByID("docDnDUploadFilesInp.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Upload Files option NOT found on D&D Page");
			Assert.fail("Upload Files option NOT found on D&D Page");
		}
		log.info("Upload Files option Found on D&D Page");
		genLibWeb.enterTextValueByID("docDnDUploadFilesInp.id", TestCaseInit.Current_Directory+ VMedixUtils.DUMMY_FILE_RELATIVE_PATH ,driver);
		if(!genLibWeb.isElementFoundByXPath("docDnDUploadFileBtn.ngClick.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Upload File Button NOT found");
			Assert.fail("Upload File Button NOT found");
		}
		log.info("Upload File Button found");
		genLibWeb.clickOnElementByXPath("docDnDUploadFileBtn.ngClick.xpath", null, driver);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("uploadFileDnD.success"), "toastMsg.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("File NOT uploaded");			
			Assert.fail("File NOT uploaded");	
		}	
		log.info("File uploaded");
		Thread.sleep(2000);
		int fileNameIndex = VMedixUtils.DUMMY_FILE_RELATIVE_PATH.lastIndexOf("\\");
		if(!(genLibWeb.isElementFoundByXPath("docDnDUploadedFilesH3.xpath", null, driver) 
				&& (genLibWeb.getTextByXPath("docDnDUploadedFileNameLi.xpath", null, driver).equals(VMedixUtils.DUMMY_FILE_RELATIVE_PATH.substring(fileNameIndex+1))))){
			TestCaseInit.testCaseStatus = false;
			log.error("File uploaded is NOT displayed");			
			Assert.fail("File uploaded is NOT displayed");	
		}
		log.info("File uploaded is Displayed");		
	}

	public void uncollapseMedicalHistorySection(WebDriver driver)throws Exception {
		//uncollapse/open medical history section if not
		if(!genLibWeb.isElementFoundByXPath("docDnDMedicalHistCollapsedI.xpath", null, driver)){
			if(!genLibWeb.isElementFoundByXPath("docDnDMedicalHistUnCollapsedI.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("Medical History section NOT found");				
				Assert.fail("Medical History section NOT found");	
			}
		} else {
			genLibWeb.clickOnElementByID("docDnDMedicalHistCollapseI.id", driver);
		}
		Thread.sleep(1000);
	}
	
	/**
	 * This method is used to click on edit button to open Medical History Edit Page on DnD
	 */
	public void clickOnMedicalHistoryEdit(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docDnDMedicalHistEditBtn.id", driver);		
	}	
	
	/**
	 * This method is used to submit D&D 
	 * @param driver
	 * @throws Exception 
	 */
	public void submitDnD(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docDnDSubmitBtn.id", driver);
		Thread.sleep(3000);
		String dndSubmitSuccMsg = TestCaseInit.messagesVMedixProp.getProperty("submitDnD.success");
		String dndSubmitSavMsg = TestCaseInit.messagesVMedixProp.getProperty("submitDnDSaving.success");
		if(!(genLibWeb.validateExpectedWithActualByXPath(dndSubmitSuccMsg, "toastMsg.xpath", null, driver)
				|| genLibWeb.validateExpectedWithActualByXPath(dndSubmitSavMsg, "toastMsg.xpath", null, driver))){
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor could NOT submit D & D");			
			Assert.fail("Doctor could NOT submit D & D");	
		}
		log.info("Doctor submitted D & D");
	}
}
