package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class CallRepConsultInQueuePage {
	static Logger log = Logger.getLogger(CallRepConsultInQueuePage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if on Call Rep Consultation In-Queue Page
	 */	
	public boolean verifyOnCallRepConsultationInQueuePage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("callRepConsultInQueuePageH3.xpath", null, driver) 
				&& (StringUtils.containsIgnoreCase(genLibWeb.getTextByXPath("callRepConsultInQueueMessageP.xpath", null, driver), "patient has been put in the queue to see a doctor"));
	}
	
	/**
	 * This method is used to validate if on Call Rep Consultation In-Queue Page
	 */
	public void verifyNValidateOnCallRepConsultationInQueuePage(WebDriver driver)throws Exception {
		if(!verifyOnCallRepConsultationInQueuePage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Call Rep Consultation In-Queue Page");
			Assert.fail("NOT on Call Rep Consultation In-Queue Page");
		}		
		log.info("On Call Rep Consultation In-Queue Page");
	}
}
