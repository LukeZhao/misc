package pages;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class AdminPage {
	
	private static Logger log = Logger.getLogger(AdminPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();

	public static final String SEND_PASSWORD_RESET_LINK_TEXT = "Send password reset";
	public static final String SEND_EMAIL_VERIFICATION_LINK_TEXT = "Send email verification";
	public final String autoItExeLocationForChrome_UploadDoctor = TestCaseInit.Current_Directory+"\\Test_Data\\ChromeAutoIt_Doctor.exe";
	public final String autoItExeLocationForFirefox_UploadDoctor = TestCaseInit.Current_Directory+"\\Test_Data\\FirefoxAutoIt_Doctor.exe";	
	public final String autoItExeLocationForChrome_UploadPatient = TestCaseInit.Current_Directory+"\\Test_Data\\ChromeAutoIt_Patient.exe";
	public final String autoItExeLocationForFirefox_UploadPatient = TestCaseInit.Current_Directory+"\\Test_Data\\FirefoxAutoIt_Patient.exe";
	public final String autoItExeLocationForChrome_UploadCallRep = TestCaseInit.Current_Directory+"\\Test_Data\\ChromeAutoIt_CallRep.exe";
	public final String autoItExeLocationForFirefox_UploadCallRep = TestCaseInit.Current_Directory+"\\Test_Data\\FirefoxAutoIt_CallRep.exe";
	
	/**
	 * This method is used to verify if on Doctor Admin Page
	 */	
	public boolean verifyOnDocAdminPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminLandingPageH3.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Doctor Admin Page
	 */
	public void verifyNValidateOnDocAdminPage(WebDriver driver)throws Exception {
		if(!verifyOnDocAdminPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Doctor Admin Page");
			Assert.fail("NOT on Doctor Admin Page");
		}		
		log.info("On Doctor Admin Page");
	}	
	
	/**
	 * This method is used to send Password reset request for a specified User
	 * @param userName
	 * @param driver
	 * @throws Exception 
	 */
	public void sendPasswordReset(String userName, WebDriver driver) throws Exception {
		String userSendPasswordResetLinkVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docAdminUserSendPwdResetLinkAnc.xpath"), userName, SEND_PASSWORD_RESET_LINK_TEXT);
		try {
			if (genLibWeb.clickOnElementByXPath(null, userSendPasswordResetLinkVal, driver)) {
				log.info("Password Reset Link is clicked for: "+ userName);
			} else {
				TestCaseInit.testCaseStatus = false;
				Assert.fail("User: "+userName+" NOT found for Reset Password");
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * This method is used to validate report on admin UI.
	 * @param reportFileName
	 * @param driver
	 * @throws Exception
	 */
	public void validateRepInGeneratedReportsConsole(String reportFileName, WebDriver driver) throws Exception {
		try{			
			genLibWeb.clickOnElementByClass("logoH1.class", driver);
			genLibWeb.isElementFoundByXPath("docAdminLandingPageH3.xpath", null, driver);				
			genLibWeb.clickOnElementByName("docAdminGeneratedReportsReportsLinkAnc.name", driver);
			Thread.sleep(5000);
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminReportsConsoleTr.xpath", null, driver);
			DateFormat dateFormat1 = new SimpleDateFormat("M/d/yy");
			String currentDate = dateFormat1.format(new Date());
			driver.navigate().refresh();			
			if(!(genLibWeb.getTextByXPath("docAdminReportsConsoletDateTd.xpath", null, driver).contains(currentDate)
					&& genLibWeb.getTextByXPath("docAdminReportsConsoletReportNameTd.xpath", null, driver).equalsIgnoreCase(reportFileName))){
				TestCaseInit.testCaseStatus = false;
				log.error(reportFileName + " NOT found on Admin Report Console");
				Assert.fail(reportFileName + " NOT found on Admin Report Console");
			}
			log.info(reportFileName + " Found on Admin Report Console");
		}catch(Exception exp){
			throw exp;
		}
	}
	
	/**
	 * This method is used to bulk upload of users.
	 * @param userType
	 * @param driver
	 * @throws Exception
	 */
	public void bulkUploadUsers(String userType, WebDriver driver) throws Exception {	
		
		//get expected success message
		String expectedMessage = "";
		if(VMedixUtils.USERTYPE_DOCTOR.equalsIgnoreCase(userType)) {
			expectedMessage = TestCaseInit.messagesVMedixProp.getProperty("bulkUploadDoctors.success");
		} else if(VMedixUtils.USERTYPE_PATIENT.equalsIgnoreCase(userType)){
			expectedMessage = TestCaseInit.messagesVMedixProp.getProperty("bulkUploadPatients.success");
		} else if(VMedixUtils.USERTYPE_CALLREP.equalsIgnoreCase(userType)){
			expectedMessage = TestCaseInit.messagesVMedixProp.getProperty("bulkUploadCallReps.success");
		} 
		
		//upload users
		if(VMedixUtils.USERTYPE_DOCTOR.equalsIgnoreCase(userType)) {
			genLibWeb.clickOnElementByXPath("docAdminBulkuploadDoctorLinkAnc.xpath", null, driver);
			if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_CHROME)){
				Runtime.getRuntime().exec(autoItExeLocationForChrome_UploadDoctor);
			}else if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_FIREFOX)){
				Runtime.getRuntime().exec(autoItExeLocationForFirefox_UploadDoctor);
			}
		} else if(VMedixUtils.USERTYPE_PATIENT.equalsIgnoreCase(userType)){
			genLibWeb.clickOnElementByXPath("docAdminBulkuploadPatientLinkAnc.xpath", null, driver);
			if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_CHROME)){
				Runtime.getRuntime().exec(autoItExeLocationForChrome_UploadPatient);
			}else if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_FIREFOX)){
				Runtime.getRuntime().exec(autoItExeLocationForFirefox_UploadPatient);
			}
		} else if(VMedixUtils.USERTYPE_CALLREP.equalsIgnoreCase(userType)){
			genLibWeb.clickOnElementByXPath("callRepAdminBulkuploadCallRepLinkAnc.ngClick.xpath", null, driver);
			if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_CHROME)){
				Runtime.getRuntime().exec(autoItExeLocationForChrome_UploadCallRep);
			}else if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_FIREFOX)){
				Runtime.getRuntime().exec(autoItExeLocationForFirefox_UploadCallRep);
			}
		} 
		
		//validate message
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		if (genLibWeb.validateExpectedWithActualByXPath(expectedMessage, "toastMsg.xpath", null, driver)) {
			log.info("Bulk upload Successful");
			Thread.sleep(7000); //wait till the toast message disappears, so logout can be clicked
		} else{
			TestCaseInit.testCaseStatus = false;
			log.error("Bulk upload Failed for: "+ userType);
			Assert.fail("Bulk upload Failed for: "+ userType);
		}
	}
	
	public void clickOnAppChoicesHnPTemplates(WebDriver driver) throws Exception {		
		genLibWeb.clickOnElementByID("docAdminAppChoicesHnPTemplatesLinkAnc.id", driver);
	}

	public void clickOnAppChoicesMedications(WebDriver driver) throws Exception {	
		genLibWeb.clickOnElementByName("docAdminAppChoicesMedicationsLinkAnc.name", driver);
	}

	public void clickOnPricingNRefundsCoupons(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByName("docAdminPricingNRefundCouponsLinkAnc.name", driver);		
	}
	
	public void clickOnPricingNRefundsPriceGroups(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docAdminPricingNRefundPriceGroupsLinkAnc.id", driver);		
	}
	
	public void clickOnPricingNRefundsConsultationFee(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docAdminPricingNRefundConsultFeeLinkAnc.id", driver);		
	}
	
	public void clickOnPricingNRefundsRefunds(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docAdminPricingNRefundRefundsLinkAnc.id", driver);		
	}
	
	public void clickOnOtherElemsPrevConsults(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docAdminOtherElementsPrevConsultsLinkAnc.id", driver);		
	}
}
