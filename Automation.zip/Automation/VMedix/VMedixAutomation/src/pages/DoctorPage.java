package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class DoctorPage {

	static Logger log = Logger.getLogger(DoctorPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	DoctorConsultationPage docConsult = new DoctorConsultationPage();	
	DoctorDnDPage ddscreen = new DoctorDnDPage();
	final String consultCancelReason_NoShow = "No Show";
	
	public boolean verifyDoctorOnLandingPage(WebDriver driver) throws Exception {
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("doctorLandingPageH1.xpath", null, driver);		
	}
	
	public void verifyNValidateDoctorOnLandingPage(WebDriver driver)throws Exception {
		if(!verifyDoctorOnLandingPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT Tracking Board Page");
			Assert.fail("Doctor is NOT Tracking Board Page");
		}		
		log.info("Doctor is on Tracking Board Page");
	}
	
	public void verifyAndBringDoctorToLandingPage(WebDriver driver) throws Exception{
		try {
			if(!verifyDoctorOnLandingPage(driver)){
				bringDoctorToTrackingBoard(driver);
			}else{
				log.info("Doctor is on the Tracking Board Page");
			}
		} catch (Exception e) {
			log.error("Unable to bring Doctor to Landing page", e);
			throw e;
		}
	}

	private void bringDoctorToTrackingBoard(WebDriver driver) throws Exception {
		try {
			boolean foundRightPage = false; 
			if(docConsult.verifyDoctorIsWaitingOnPatient(driver)){ //began consultation and waiting for patient to accept
				foundRightPage = true;
				bringDoctorToHomeByCancelVideoConsult(driver);
			} else if (docConsult.verifyDoctorInVideoConsultation(driver)){ //in consultation
				foundRightPage = true;
				bringDoctorToHomeByEndVideoConsult(driver);
			}else if(genLibWeb.isElementFoundByID("docPhConsultEndBtn.id", driver)){ //phone consult
				foundRightPage = true;
				bringDoctorHomeByEndPhConsult(driver);				
			}else if(ddscreen.verifyDoctorOnDnDPage(driver)){ //on D n D page
				foundRightPage = true;
				bringDoctorToHomeFromDnDPage(driver);			
			} else {
				log.error("Doctor is on a Wrong Screen");
			}
			Thread.sleep(1000);
			if (!foundRightPage || !verifyDoctorOnLandingPage(driver)) {
				TestCaseInit.testCaseStatus = false;
				log.error("Failed to bring doctor to Tracking Board");
				Assert.fail("Failed to bring doctor to Tracking Board");					
			} 
			log.info("Doctor is now on Tracking Board");
		} catch (Exception e) {
			throw e;
		}
	}
	
	private void bringDoctorToHomeByCancelVideoConsult(WebDriver driver) throws Exception{
		docConsult.cancelViDoctorConsultation(driver);
		bringDoctorToHomeFromDnDPage(driver);
	}

	private void bringDoctorToHomeByEndVideoConsult(WebDriver driver) throws Exception{
		docConsult.endViDoctorConsultation(driver);
		bringDoctorToHomeFromDnDPage(driver);
	}
	
	private void bringDoctorHomeByEndPhConsult(WebDriver driver) throws Exception{
		docConsult.endPhoneConsultationFromDoctor(driver);
		bringDoctorToHomeFromDnDPage(driver);
	}
	
	private void bringDoctorToHomeFromDnDPage(WebDriver driver) throws Exception{
		genLibWeb.scrollToViewElementWithID("docDnDSubmitBtn.id", driver);
		if(genLibWeb.isElementFoundByName("docDnDCancelReasonDrpBx.name", driver)) { //Could be on D & D after consult end or cancellation			
			genLibWeb.selectByVisibleTextFromSelectElementName("docDnDCancelReasonDrpBx.name", consultCancelReason_NoShow, driver);
		} 
		Thread.sleep(3000);
		ddscreen.submitDnD(driver);		
	}
}
