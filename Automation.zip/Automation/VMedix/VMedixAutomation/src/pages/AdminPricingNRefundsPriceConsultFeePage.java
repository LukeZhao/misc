package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class AdminPricingNRefundsPriceConsultFeePage {
	static Logger log = Logger.getLogger(AdminPricingNRefundsPriceConsultFeePage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	AdminPricNRefConsultFeeEditPage adminEDitConsultFee = new AdminPricNRefConsultFeeEditPage();

	/**
	 * This method is used to verify if on Admin Pricing N Refunds: Consultation Fee Page
	 */	
	public boolean verifyOnAdminPricingNRefundsConsultFeePage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminPricingNRefundConsultFeeTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin Pricing N Refunds: Consultation Fee Page
	 */
	public void verifyNValidateOnAdminPricingNRefundsConsultFeePage(WebDriver driver)throws Exception {
		if(!verifyOnAdminPricingNRefundsConsultFeePage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Admin Pricing N Refunds: Consultation Fee Page");
			Assert.fail("NOT on Admin Pricing N Refunds: Consultation Fee Page");
		}		
		log.info("On Admin Pricing N Refunds: Consultation Fee Page");
	}
	
	public String getConsultFee(WebDriver driver) throws Exception {
		String consultFeeTxt = genLibWeb.getTextByID("docAdminPricingNRefundConsultFeeP.id", driver);
		String[] splitConsultFee = consultFeeTxt.split("\\$");			
		String pricePartWithPrefixStr = splitConsultFee[1];
		String[] splitPricePartWithPrefixStr = pricePartWithPrefixStr.split("\\s+"); //split on space/empty string
		return splitPricePartWithPrefixStr[1];
	}
	
	public void editConsultFee(String consultFee, WebDriver driver) throws Exception {
		//Click edit
		if(genLibWeb.explicitWaitUntilElementWithIDIsVisible("docAdminPricingNRefundConsultFeeEditLinkAnc.id", driver)){
			genLibWeb.clickOnElementByID("docAdminPricingNRefundConsultFeeEditLinkAnc.id", driver);
		}
		adminEDitConsultFee.verifyNValidateOnAdminEditConsultFeePage(driver);
		adminEDitConsultFee.editConsultFee(consultFee, driver);
	}
}
