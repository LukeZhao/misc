package pages;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class CommonUtilsPage {
	
	private static Logger log = Logger.getLogger(CommonUtilsPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();		
	
	final String noHeightFeet = "0\'";
	final String noHeightInches = "0\"";
	final String noWeight = "0 lbs";
	final String dashMedHistInfo = "--";
	final String smokePacksLessThan1 = "Less than 1";
	
	/**
	 * This method is used to enter all medicines into medications textbox, one at a time.
	 * @param medicines
	 * @param medicinesInputXPathProp
	 * @param driver
	 * @return boolean; returns false if one or more value not entered 
	 * @throws Exception 
	 */
	public boolean enterMedications(String medicines, String medicinesInputXPathProp, String medicinesInputXPathValue, String medicinesAddButtonXPathProp, String medicinesAddButtonXPathValue, WebDriver driver) throws Exception {
		log.info("List of medications: " + medicines);
		return enterNAddDataByXPath(medicines, medicinesInputXPathProp, medicinesInputXPathValue, medicinesAddButtonXPathProp, medicinesAddButtonXPathValue, driver);
	}
	
	/**
	 * This method is used to remove old medications
	 * @param driver
	 * @throws Exception 
	 */
	public void removeOldMedications(String removeMedicinesListXPathProp, String removeMedicinesListXPathValue, String removeMedicineButtonXPathProp, WebDriver driver) throws Exception {
		log.info("Removing old Medications...");
		removeEnterNAddedDataByXpath(removeMedicinesListXPathProp, removeMedicinesListXPathValue, removeMedicineButtonXPathProp, driver);		
	}
	
	/**
	 * This method is used to verify an old medications are present
	 */
	public boolean isOldMedicationsPresent(String oldMedications, String listOfMedicationsXPathProp, String listOfMedicationsXPathValue, String medicationsDataXPathProp, WebDriver driver) throws Exception {
		log.info("Verifying old Medications...");
		return verifyAllAddedDataPresent(oldMedications, listOfMedicationsXPathProp, listOfMedicationsXPathValue, medicationsDataXPathProp, driver);
	}
	
	/**
	 * This method is used to enter all allergies into Allergies textbox one at a time.
	 * @param allergies
	 * @param passedInDriver
	 * @return boolean; returns false if one or more value not entered 
	 * @throws Exception
	 */
	public boolean enterAllergies(String allergies, String allergiesInputXPathProp, String allergiesInputXPathValue, String allergiesAddButtonXPathProp, String allergiesAddButtonXPathValue, WebDriver passedInDriver) throws Exception {
		log.info("List of allergies: " + allergies);
		return enterNAddDataByXPath(allergies, allergiesInputXPathProp, allergiesInputXPathValue, allergiesAddButtonXPathProp, allergiesAddButtonXPathValue, passedInDriver);
	}
	
	/**
	 * This method is used to remove old medications
	 * @param driver
	 * @throws Exception 
	 */
	public void removeOldAllergies(String removeAllergiesListXPathProp, String removeAllergiesListXPathValue, String removeAllergyButtonXPathProp, WebDriver driver) throws Exception {
		log.info("Removing old Allergies...");
		removeEnterNAddedDataByXpath(removeAllergiesListXPathProp, removeAllergiesListXPathValue, removeAllergyButtonXPathProp, driver);		
	}
	
	/**
	 * This method is used to verify an old allergies are present
	 */
	public boolean isOldAllergiesPresent(String oldAllergies, String listOfAllergiesXPathProp, String listOfAllergiesXPathValue, String allergiesDataXPathProp, WebDriver driver) throws Exception {
		log.info("Verifying old Allergies...");
		return verifyAllAddedDataPresent(oldAllergies, listOfAllergiesXPathProp, listOfAllergiesXPathValue, allergiesDataXPathProp, driver);
	}
	
	/**
	 * This functions enters medical problems values to medical problem textbox.
	 * @param medConditions
	 * @param driver
	 * @return boolean; returns false if one or more value not entered 
	 * @throws Exception
	 */
	public boolean enterMedicalConditions(String medConditions, String medConditionsInputXPathProp, String medConditionsInputXPathValue, String medConditionsAddButtonXPathProp, String medConditionsAddButtonXPathValue, WebDriver driver) throws Exception {
		log.info("Medical Conditions: "+ medConditions);
		return enterNAddDataByXPath(medConditions, medConditionsInputXPathProp, medConditionsInputXPathValue, medConditionsAddButtonXPathProp, medConditionsAddButtonXPathValue, driver);
	}
	
	/**
	 * This method is used to remove old medical problem
	 * @param driver
	 * @throws Exception 
	 */
	public void removeOldMedicalConditions(String removeMedConditionsListXPathProp, String removeMedConditionsListXPathValue, String removeMedConditionsButtonXPathProp, WebDriver driver) throws Exception {
		log.info("Removing old Medical Conditions...");
		removeEnterNAddedDataByXpath(removeMedConditionsListXPathProp, removeMedConditionsListXPathValue, removeMedConditionsButtonXPathProp, driver);		
	}	
	
	/**
	 * This functions enters Surgeries values to Surgeries textbox.
	 * @param surgeries
	 * @param driver
	 * @return boolean; returns false if one or more value not entered 
	 * @throws Exception
	 */
	public boolean enterSurgeries(String surgeries, String surgeriesInputXPathProp, String surgeriesInputXPathValue, String surgeriesAddButtonXPathProp, String surgeriesAddButtonXPathValue, WebDriver driver) throws Exception {
		log.info("Surgeries: "+ surgeries);
		return enterNAddDataByXPath(surgeries, surgeriesInputXPathProp, surgeriesInputXPathValue, surgeriesAddButtonXPathProp, surgeriesAddButtonXPathValue, driver);
	}
	
	/**
	 * This method is used to remove old surgeries
	 * @param driver
	 * @throws Exception 
	 */
	public void removeOldSurgeries(String removeSurgeriesListXPathProp, String removeSurgeriesListXPathValue, String removeSurgeriesButtonXPathProp, WebDriver driver) throws Exception {
		log.info("Removing old Surgeries...");
		removeEnterNAddedDataByXpath(removeSurgeriesListXPathProp, removeSurgeriesListXPathValue, removeSurgeriesButtonXPathProp, driver);		
	}
	
	/**
	 * This functions enters Family Medical Problems values to Family Medical Problems textbox.
	 * @param familyMedicalProblems
	 * @param driver
	 * @return boolean; returns false if one or more value not entered 
	 * @throws Exception
	 */
	public boolean enterFamilyMedicalProblems(String familyMedicalProblems, String famMedProbsInputXPathProp, String famMedProbsInputXPathValue, String famMedProbsAddButtonXPathProp, String famMedProbsAddButtonXPathValue, WebDriver driver) throws Exception {
		log.info("Family Medical problems: "+ familyMedicalProblems);
		return enterNAddDataByXPath(familyMedicalProblems, famMedProbsInputXPathProp, famMedProbsInputXPathValue, famMedProbsAddButtonXPathProp, famMedProbsAddButtonXPathValue, driver);
	}
	
	/**
	 * This method is used to remove old family medical problems
	 * @throws Exception 
	 */
	public void removeOldFamilyMedicalProblems(String removeFamMedProbsListXPathProp, String removeFamMedProbsListXPathValue, String removeFamMedProbsButtonXPathProp, WebDriver driver) throws Exception {
		log.info("Removing old Family Medical Problems...");
		removeEnterNAddedDataByXpath(removeFamMedProbsListXPathProp, removeFamMedProbsListXPathValue, removeFamMedProbsButtonXPathProp, driver);		
	}
	
	/**
	 * This method is used to enter all diagnosis Code, one code at a time.
	 * @param diagnosisCode
	 * @param driver
	 * @return boolean; returns false if one or more value not entered 
	 * @throws Exception 
	 */
	public boolean enterDiagnosisCodes(String diagnosisCode, String diagnosisCodeInputXPathProp, String diagnosisCodeInputXPathValue, String diagnosisCodeAddButtonXPathProp, String diagnosisCodeAddButtonXPathValue, WebDriver driver) throws Exception {
		log.info("List of Diagnosis Code: " + diagnosisCode);
		return enterNAddDataByXPath(diagnosisCode, diagnosisCodeInputXPathProp, diagnosisCodeInputXPathValue, diagnosisCodeAddButtonXPathProp, diagnosisCodeAddButtonXPathValue, driver);
	}
	
	/**
	 * This method is used to remove old diagnosis Codes
	 * @param driver
	 * @throws Exception 
	 */
	public void removeOldDiagnosisCodes(String removeDiagnosisCodeListXPathProp, String removeDiagnosisCodeListXPathValue, String removeDiagnosisCodeButtonXPathProp, WebDriver driver) throws Exception {
		log.info("Removing old Diagnosis Codes...");
		removeEnterNAddedDataByXpath(removeDiagnosisCodeListXPathProp, removeDiagnosisCodeListXPathValue, removeDiagnosisCodeButtonXPathProp, driver);		
	}	
	
	/**
	 * This method is used to verify an old diagnosis codes are present
	 */
	public boolean isOldDiagnosisCodePresent(String oldDiagCodes, String listOfDiagnosisCodeXPathProp, String listOfDiagnosisCodeXPathValue, String diagnosisCodeDataXPathProp, WebDriver driver) throws Exception {
		log.info("Verifying old Diagnosis Codes...");
		return verifyAllAddedDataPresent(oldDiagCodes, listOfDiagnosisCodeXPathProp, listOfDiagnosisCodeXPathValue, diagnosisCodeDataXPathProp, driver);
	}
	
	/**
	 * This method is used to verify an old diagnosis codes are present
	 */
	public boolean verifyDiagnosisCodeContained(String oldDiagCodes, String listOfDiagnosisCodeXPathProp, String listOfDiagnosisCodeXPathValue, String diagnosisCodeDataXPathProp, WebDriver driver) throws Exception {
		log.info("Verifying old Diagnosis Codes...");
		return verifyContainsAllAddedData(oldDiagCodes, listOfDiagnosisCodeXPathProp, listOfDiagnosisCodeXPathValue, diagnosisCodeDataXPathProp, driver);
	}

	
	/**
	 * This method is used to enter values into text box and click on add button using xpath
	 * @param valuesToAdd; comma delimited if more than one value
	 * @param textBoxXPathProp
	 * @param textBoxXPathValue
	 * @param addButtonXPathProp
	 * @param addButtonXPathValue
	 * @param driver
	 * @return boolean; returns false if one or more value not entered 
	 * @throws Exception
	 */
	private boolean enterNAddDataByXPath(String valuesToAdd, String textBoxXPathProp, String textBoxXPathValue, String addButtonXPathProp, String addButtonXPathValue, WebDriver driver) throws Exception
	{
		String txtBxXPathLoc = textBoxXPathValue;
		String addBtnXPathLoc = addButtonXPathValue;
		boolean enteredNAdded = true;
		if(StringUtils.isNotBlank(textBoxXPathProp)) {
			txtBxXPathLoc = TestCaseInit.webLocatorProp.getProperty(textBoxXPathProp);				
		}
		if(StringUtils.isNotBlank(addButtonXPathProp)) {
			addBtnXPathLoc = TestCaseInit.webLocatorProp.getProperty(addButtonXPathProp);				
		}
		if(StringUtils.isNotBlank(valuesToAdd)){
			if(valuesToAdd.contains(",")) {
				String[] listOfvaluesToAdd = valuesToAdd.split("\\,");
				for( String valToAdd :  listOfvaluesToAdd ) {
					if(!enterNAddByXPath (valToAdd.trim(), txtBxXPathLoc, addBtnXPathLoc, driver)){//trim the value to be added
						enteredNAdded = false; // one of the elements not added
					}
				}
			} else {
				enteredNAdded = enterNAddByXPath (valuesToAdd, txtBxXPathLoc, addBtnXPathLoc, driver);
			}
		} else{
			log.error("NO elements to enter");
		}
		return enteredNAdded;
	}		
	
	private boolean enterNAddByXPath (String valToAdd, String textBoxXPath, String addButtonXPath, WebDriver driver) throws Exception {
		boolean enteredNAdded = false;
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible(null, textBoxXPath, driver);
		if(genLibWeb.enterTextValueByXPath(null, textBoxXPath, valToAdd, driver)){
			log.info("Web Element found with xpath: " + textBoxXPath);
			Thread.sleep(200);
			genLibWeb.clickOnElementByXPath(null, addButtonXPath, driver);
			Thread.sleep(200);
			enteredNAdded = true;
		} else {	
			log.error("Web Element NOT found with xpath: " + textBoxXPath + " Add action could not be performed");
		}		
		return enteredNAdded;
	}
	
	/**
	 * This method is used to remove entered and added data using xpath
	 * @param removeDataListXPathProp
	 * @param removeDataListXPathValue
	 * @param removeButtonXPathProp
	 * @param driver
	 * @throws Exception
	 */
	private void removeEnterNAddedDataByXpath(String removeDataListXPathProp, String removeDataListXPathValue, String removeButtonXPathProp, WebDriver driver) throws Exception{
		int listOfData = genLibWeb.getNumberOfElementsByXPath(removeDataListXPathProp, removeDataListXPathValue, driver);
		if(listOfData > 0) {
			for(int i=listOfData; i>0; i--) {
				genLibWeb.clickOnElementByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty(removeButtonXPathProp), Integer.toString(i-1)), driver);
				Thread.sleep(200);
			}
		} else {
			log.error("NO elements to remove");
		}
	}
	
	/**
	 * This method is used to verify if the entered and added data is present in the list by xpath by equating
	 * @param dataToFind
	 * @param listOfDataXPathProp
	 * @param listOfDataXPathValue
	 * @param dataXPathProp
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */	
	private boolean verifyAllAddedDataPresent(String valuesToFind, String listOfDataXPathProp, String listOfDataXPathValue, String dataXPathProp, WebDriver driver) throws Exception{
		boolean allPresent = true;
		if(StringUtils.isNotBlank(valuesToFind)){
			if(valuesToFind.contains(",")) {
				String[] listOfvaluesToFind = valuesToFind.split("\\,");
				for(String valToFind : listOfvaluesToFind ) {
					if(!verifyEnterNAddedDataPresentByXpath (valToFind.trim(), listOfDataXPathProp, listOfDataXPathValue, dataXPathProp, driver)){//trim the value to be added
						allPresent = false; // one of the elements not found
					}
				}
			} else {
				allPresent = verifyEnterNAddedDataPresentByXpath (valuesToFind, listOfDataXPathProp, listOfDataXPathValue, dataXPathProp, driver);
			}
		} else{
			log.error("NO elements to find");
		}
		return allPresent;
	}	
	
	private boolean verifyEnterNAddedDataPresentByXpath(String dataToFind, String listOfDataXPathProp, String listOfDataXPathValue, String dataXPathProp, WebDriver driver) throws Exception{
		boolean isPresent = false;
		int listOfData = genLibWeb.getNumberOfElementsByXPath(listOfDataXPathProp, listOfDataXPathValue, driver);
		if(listOfData > 0) {
			for(int i=listOfData; i>0; i--) {
				if(dataToFind.equalsIgnoreCase(genLibWeb.getTextByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty(dataXPathProp), Integer.toString(i-1)), driver))){
					isPresent = true;
					break;
				}				
			}
		}
		return isPresent;	
	}
	
	
	/**
	 * This method is used to verify if the entered and added data is present in the list by xpath by verifying if contains
	 * @param dataToFind
	 * @param listOfDataXPathProp
	 * @param listOfDataXPathValue
	 * @param dataXPathProp
	 * @param driver
	 * @return boolean
	 * @throws Exception
	 */	
	private boolean verifyContainsAllAddedData(String valuesToFind, String listOfDataXPathProp, String listOfDataXPathValue, String dataXPathProp, WebDriver driver) throws Exception{
		boolean allPresent = true;
		if(StringUtils.isNotBlank(valuesToFind)){
			if(valuesToFind.contains(",")) {
				String[] listOfvaluesToFind = valuesToFind.split("\\,");
				for(String valToFind : listOfvaluesToFind ) {
					if(!verifyContainsDataEnterNAddedByXpath (valToFind.trim(), listOfDataXPathProp, listOfDataXPathValue, dataXPathProp, driver)){//trim the value to be added
						allPresent = false; // one of the elements not found
					}
				}
			} else {
				allPresent = verifyContainsDataEnterNAddedByXpath(valuesToFind, listOfDataXPathProp, listOfDataXPathValue, dataXPathProp, driver);
			}
		} else{
			log.error("NO elements to find");
		}
		return allPresent;
	}	
	
	private boolean verifyContainsDataEnterNAddedByXpath(String dataToFind, String listOfDataXPathProp, String listOfDataXPathValue, String dataXPathProp, WebDriver driver) throws Exception{
		boolean isPresent = false;
		int listOfData = genLibWeb.getNumberOfElementsByXPath(listOfDataXPathProp, listOfDataXPathValue, driver);
		if(listOfData > 0) {
			for(int i=listOfData; i>0; i--) {
				if(StringUtils.containsIgnoreCase(genLibWeb.getTextByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty(dataXPathProp), Integer.toString(i)), driver), dataToFind)){
					isPresent = true;
					break;
				}				
			}
		}
		return isPresent;	
	}
	
	
	/**
	 * This method is used send a chat message
	 * @param mesg
	 * @param driver
	 * @throws Exception
	 */	
	public void sendChatMessage(String mesg, WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByID("docNPatChatInp.id", mesg, driver);
		genLibWeb.clickOnElementByID("docNPatChatSendBtn.id", driver);
	}
	
	/**
	 * This method is used verify chat message received
	 * @param mesg
	 * @param driver
	 * @throws Exception
	 */	
	public void verifyChatMessageWithTimeNProfilePic(String msg, String msgNumber, String timeMsgSent, String profilepic, WebDriver driver) throws Exception {
		String errMsg = "Failed on Chat, ";
		try{
			//msg
			String msgXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docNPatChatMsgLi.xpath"), msgNumber); 
			Assert.assertTrue(genLibWeb.getTextByXPath(null, msgXpathVal, driver).contains(msg), errMsg+ "Message");
			//prof pic			
			if(profilepic.equalsIgnoreCase("default")) {				
				profilepic = VMedixUtils.DEFAULT_PROFILE_PHOTO_IMG_SRC;
			}
			String profPicXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docNPatChatMsgProfilePicImg.xpath"), msgNumber, profilepic); 
			Assert.assertTrue(genLibWeb.isElementFoundByXPath(null, profPicXpathVal, driver), errMsg+ "Profile Pic");
			//time
			String timeXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docNPatChatMsgTimeP.xpath"), msgNumber);
			SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");	
				//sent message time can never be greater than received
			Assert.assertTrue(!(sdf.parse(genLibWeb.getTextByXPath(null, timeXpathVal, driver)).before(sdf.parse(timeMsgSent))), errMsg+ "Message Time");
			log.info("All Chat asserts Passed");							
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
	}
	
	/**
	 * This method is used verify 2 sets of chat messages between patient and doctor
	 * @param driverPatient
	 * @param driverDoctor
	 * @throws Exception
	 */	
	public void verify2SetsOfDocPatChatMessages(WebDriver driverPatient, WebDriver driverDoctor) throws Exception {
		genLibWeb.scrollToViewElementWithClass("logoH1.class", driverDoctor);// scroll to the top , to the logo
		//patient send message1
		sendChatMessage(VMedixUtils.MESSAGE1_FROM_PAT, driverPatient);
		int msgNum = 1;
		//doctor verify message1 received
		Thread.sleep(100);
		String msgTime = genLibWeb.getTextByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docNPatChatMsgTimeP.xpath"), Integer.toString(msgNum)), driverPatient);			
		verifyChatMessageWithTimeNProfilePic(VMedixUtils.MESSAGE1_FROM_PAT, Integer.toString(msgNum), msgTime, "default", driverDoctor);
		//doctor's response send response1
		sendChatMessage(VMedixUtils.RESPONSE1_FROM_DOC, driverDoctor);
		msgNum++;
		//patient verify response1 received	
		Thread.sleep(100);
		msgTime = genLibWeb.getTextByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docNPatChatMsgTimeP.xpath"), Integer.toString(msgNum)), driverDoctor);
		verifyChatMessageWithTimeNProfilePic(VMedixUtils.RESPONSE1_FROM_DOC, Integer.toString(msgNum), msgTime, "default", driverPatient);
		
		//patient send message2
		sendChatMessage(VMedixUtils.MESSAGE2_FROM_PAT, driverPatient);
		msgNum++;
		//doctor verify message2 received
		Thread.sleep(100);
		msgTime = genLibWeb.getTextByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docNPatChatMsgTimeP.xpath"), Integer.toString(msgNum)), driverPatient);
		verifyChatMessageWithTimeNProfilePic(VMedixUtils.MESSAGE2_FROM_PAT, Integer.toString(msgNum), msgTime, "default", driverDoctor);
		//doctor's response send response2
		sendChatMessage(VMedixUtils.RESPONSE2_FROM_DOC, driverDoctor);
		msgNum++;
		//patient verify response2 received	
		Thread.sleep(100);
		msgTime = genLibWeb.getTextByXPath(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("docNPatChatMsgTimeP.xpath"), Integer.toString(msgNum)), driverDoctor);
		verifyChatMessageWithTimeNProfilePic(VMedixUtils.RESPONSE2_FROM_DOC, Integer.toString(msgNum), msgTime, "default", driverPatient);			
	}
	
//	Doctor Medical History- common to In-Consult and DnD Pages
	
	/**
	 * This method is used to verify if doctor is on Medical History Edit Page
	 */	
	public boolean verifyOnMedicalHistoryEditPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docMedicalHistEditPageH4.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if doctor on Medical History Edit Page
	 */
	public void verifyNValidateOnMedicalHistoryEditPage(WebDriver driver)throws Exception {
		if(!verifyOnMedicalHistoryEditPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT on Medical History Edit Page");
			Assert.fail("Doctor is NOT on Medical History Edit Page");
		}		
		log.info("Doctor is on Medical History Edit Page");
	}	
	
	/**
	 * This method is used to edit and review medical history of patient by doctor on Medical History edit pop-up page
	 */
	public void editNReviewMedicalHistoryOfPatient(String docHeighFeetEnt, String docHeighInchesEnt, String docWeightLbsEnt, String docMedConditionEnt, String docSurgeriesEnt, String docFamMedProbEnt, 
			String docSmokeEnt, String docSmokePacksNumEnt, String docAlcoholEnt, String docJobProfEnt, String docPrimDocNameEnt, String docPrimDocPhoneEnt, String docPrefPharmNameEnt, 
			String docPrefPharmPhoneEnt, String docPrefPharmAddr1Ent, String docPrefPharmAddr2Ent, String docPrefPharmCityEnt, 
			String docPrefPharmStateEnt, String docPrefPharmZipCodeEnt, WebDriver driver) throws Exception {
		
		//edit
		editMedicalHistoryOfPatient(docHeighFeetEnt, docHeighInchesEnt, docWeightLbsEnt, docMedConditionEnt, docSurgeriesEnt, docFamMedProbEnt, docSmokeEnt, docSmokePacksNumEnt, docAlcoholEnt, docJobProfEnt,
				docPrimDocNameEnt, docPrimDocPhoneEnt, docPrefPharmNameEnt, docPrefPharmPhoneEnt, docPrefPharmAddr1Ent, docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, docPrefPharmZipCodeEnt, driver);
		
		//review
		reviewMedicalHistoryOfPatient(docHeighFeetEnt, docHeighInchesEnt, docWeightLbsEnt, docMedConditionEnt, docSurgeriesEnt, docFamMedProbEnt, docSmokeEnt, docSmokePacksNumEnt, docAlcoholEnt, docJobProfEnt,
				docPrimDocNameEnt, docPrimDocPhoneEnt, docPrefPharmNameEnt, docPrefPharmPhoneEnt, docPrefPharmAddr1Ent, docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, docPrefPharmZipCodeEnt, driver);
	}

	public void editMedicalHistoryOfPatient(String docHeighFeetEnt, String docHeighInchesEnt, String docWeightLbsEnt, String docMedConditionEnt, String docSurgeriesEnt, String docFamMedProbEnt, String docSmokeEnt,
			String docSmokePacksNumEnt, String docAlcoholEnt, String docJobProfEnt, String docPrimDocNameEnt, String docPrimDocPhoneEnt, String docPrefPharmNameEnt, String docPrefPharmPhoneEnt,
			String docPrefPharmAddr1Ent, String docPrefPharmAddr2Ent, String docPrefPharmCityEnt, String docPrefPharmStateEnt, String docPrefPharmZipCodeEnt, WebDriver driver) throws Exception {
		
		//verify on medical hist edit page
		verifyNValidateOnMedicalHistoryEditPage(driver);		
		//edit
		editPatientGeneralInfo(docHeighFeetEnt,	docHeighInchesEnt, docWeightLbsEnt, docMedConditionEnt,	docSurgeriesEnt, docFamMedProbEnt, docSmokeEnt, docSmokePacksNumEnt, docAlcoholEnt, docJobProfEnt, driver);
		editPatientPrimaryDoctorInfo(docPrimDocNameEnt, docPrimDocPhoneEnt, driver);
		editPatientPreferredPharmInfo(docPrefPharmNameEnt, docPrefPharmPhoneEnt, docPrefPharmAddr1Ent, docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, 
				docPrefPharmZipCodeEnt, driver);
		Thread.sleep(1000);
		clickNextOnMedicalHistoryEditPage(driver);
	}	

	public void reviewMedicalHistoryOfPatient(String docHeighFeetEnt, String docHeighInchesEnt, String docWeightLbsEnt, String docMedConditionEnt, String docSurgeriesEnt, String docFamMedProbEnt, String docSmokeEnt,
			String docSmokePacksNumEnt, String docAlcoholEnt, String docJobProfEnt, String docPrimDocNameEnt, String docPrimDocPhoneEnt, String docPrefPharmNameEnt, String docPrefPharmPhoneEnt,
			String docPrefPharmAddr1Ent, String docPrefPharmAddr2Ent, String docPrefPharmCityEnt,String docPrefPharmStateEnt, String docPrefPharmZipCodeEnt, WebDriver driver) throws Exception {
		
		//verify on medical history edit review page
		verifyNValidateOnMedicalHistoryEditReviewPage(driver);
		//review
		reviewPatientGeneralInfo(docHeighFeetEnt, docHeighInchesEnt, docWeightLbsEnt, docMedConditionEnt, docSurgeriesEnt, docFamMedProbEnt, docSmokeEnt, docSmokePacksNumEnt, docAlcoholEnt, docJobProfEnt, driver);
		reviewPatientPrimaryDoctorInfo(docPrimDocNameEnt, docPrimDocPhoneEnt, driver);
		reviewPatientPreferredPharmInfo(docPrefPharmNameEnt, docPrefPharmPhoneEnt, docPrefPharmAddr1Ent, docPrefPharmAddr2Ent, docPrefPharmCityEnt, docPrefPharmStateEnt, 
				docPrefPharmZipCodeEnt, driver);
		Thread.sleep(1000);
		clickSubmitOnMedicalHistoryEditReviewPage(driver);			
	}

	/**
	 * This method is used to edit patient general info on medical history by doctor in-consultation
	 */
	public  void editPatientGeneralInfo(String docHeighFeetEnt, String docHeighInchesEnt, String docWeightLbsEnt, String docMedConditionEnt, String docSurgeriesEnt, String docFamMedProbEnt, 
			String docSmokeEnt, String docSmokePacksNumEnt, String docAlcoholEnt, String docJobProfEnt, WebDriver driver) throws Exception {
		if(StringUtils.isNotBlank(docHeighFeetEnt)){
			genLibWeb.selectByVisibleTextFromSelectElementID("docMedHistHeightFeetDrpBx.id", docHeighFeetEnt, driver);
		}
		if(docHeighInchesEnt != null){
			if(docHeighInchesEnt.isEmpty()){
				genLibWeb.selectByVisibleTextFromSelectElementID("docMedHistHeightInchesDrpBx.id", "0", driver);
			}else{
				genLibWeb.selectByVisibleTextFromSelectElementID("docMedHistHeightInchesDrpBx.id", docHeighInchesEnt, driver);
			}
		}
		if(docWeightLbsEnt != null){
			genLibWeb.enterTextValueByID("docMedHistHeightWeightInp.id", docWeightLbsEnt, driver);
		}	
		//med conditions
		if(StringUtils.isNotBlank(docMedConditionEnt)){
			//remove old medical conditions
			removeOldMedicalConditions("docMedHistMedicalConditionOldListP.xpath", null, "docMedHistMedicalConditionOldRemoveSpan.xpath", driver);
			//add medical conditions with validation
			if(!enterMedicalConditions(docMedConditionEnt,"docMedHistMedicalConditionInp.xpath", null, "docMedHistMedicalConditionAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Medical Conditions were NOT added");				
				Assert.fail("One of the Medical Conditions were NOT added");		
			}
			log.info("All Medical Conditions were added");
		}
		//surgeries
		if(StringUtils.isNotBlank(docSurgeriesEnt)){
			//remove old surgeries
			removeOldSurgeries("docMedHistSurgeriesOldListP.xpath", null, "docMedHistSurgeriesOldRemoveSpan.xpath", driver);
			//add surgeries with validation
			if(!enterSurgeries(docSurgeriesEnt,"docMedHistSurgeriesInp.xpath", null, "docMedHistSurgeriesAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Surgeries were NOT added");				
				Assert.fail("One of the Surgeries were NOT added");		
			}
			log.info("All Surgeries were added");
		}
		//family med probs		
		if(StringUtils.isNotBlank(docFamMedProbEnt)){
			//remove old family med probs
			removeOldFamilyMedicalProblems("docMedHistFamMedProbOldListP.xpath", null, "docMedHistFamMedProbOldRemoveSpan.xpath", driver);
			//add family med probs
			if(!enterFamilyMedicalProblems(docFamMedProbEnt,"docMedHistFamMedProbInp.xpath", null, "docMedHistFamMedProbAddBtn.xpath", null, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("One of the Family Medical Problems were NOT added");				
				Assert.fail("One of the Family Medical Problems were NOT added");		
			}
			log.info("All Family Medical Problems were added");			
		}
		//smoke
		if(StringUtils.isNotBlank(docSmokeEnt)) {	
			if(docSmokeEnt.equalsIgnoreCase(VMedixUtils.YES)){
				genLibWeb.clickOnElementByID("docMedHistSmokeYesRdBtnLabel.id", driver);
				if(StringUtils.isNotBlank(docSmokePacksNumEnt)) { //default set to 0					
					genLibWeb.selectByVisibleTextFromSelectElementID("docMedHistSmokePacksDrpBx.id", docSmokePacksNumEnt, driver);
				} 
			} else {
				genLibWeb.clickOnElementByID("docMedHistSmokeNoRdBtnLabel.id", driver);
			}
		} 
		if(docAlcoholEnt != null) { //default is --
			genLibWeb.selectByVisibleTextFromSelectElementID("docMedHistAlcoholDrpBx.id", docAlcoholEnt, driver);
		}
		if(docJobProfEnt != null) { //default is --
			genLibWeb.enterTextValueByID("docMedHistJobProfInp.id", docJobProfEnt, driver);		
		}			
	}

	/**
	 * This method is used to edit patient Primary doctor info on medical history by doctor in-consultation
	 * @throws Exception 
	 */
	public void editPatientPrimaryDoctorInfo(String docPrimDocNameEnt, String docPrimDocPhoneEnt, WebDriver driver) throws Exception {
		if(docPrimDocNameEnt != null) {
			genLibWeb.enterTextValueByID("docMedHistPrimDocNameInp.id", docPrimDocNameEnt, driver);
		}
		if(docPrimDocPhoneEnt != null) {
			genLibWeb.enterTextValueByXPath("docMedHistPrimDocPhoneInp.ngModel.xpath", null, docPrimDocPhoneEnt, driver);
		}		
	}
	
	/**
	 * This method is used to edit patient Preferred pharmacy info on medical history by doctor in-consultation
	 * @throws Exception 
	 */
	public void editPatientPreferredPharmInfo(String docPrefPharmNameEnt, String docPrefPharmPhoneEnt, String docPrefPharmAddr1Ent, 
			String docPrefPharmAddr2Ent, String docPrefPharmCityEnt, String docPrefPharmStateEnt, String docPrefPharmZipCodeEnt, WebDriver driver) throws Exception {
		if(docPrefPharmNameEnt != null) {
			genLibWeb.enterTextValueByID("docMedHistPrefPharmNameInp.id", docPrefPharmNameEnt, driver);
		}
		if(docPrefPharmPhoneEnt != null) {
			genLibWeb.enterTextValueByXPath("docMedHistPrefPharmPhoneInp.ngModel.xpath", null, docPrefPharmPhoneEnt, driver);
		}
		if(docPrefPharmAddr1Ent != null) {
			genLibWeb.enterTextValueByID("docMedHistPrefPharmAddr1Inp.id", docPrefPharmAddr1Ent, driver);
		}
		if(docPrefPharmAddr2Ent != null) {
			genLibWeb.enterTextValueByID("docMedHistPrefPharmAddr2Inp.id", docPrefPharmAddr2Ent, driver);
		}
		if(docPrefPharmCityEnt != null) {
			genLibWeb.enterTextValueByID("docMedHistPrefPharmCityInp.id", docPrefPharmCityEnt, driver);
		}
		if(docPrefPharmStateEnt != null) {
			genLibWeb.selectByValueFromSelectElementID("docMedHistPrefPharmStateDrpBx.id", "string:"+docPrefPharmStateEnt, driver);
		}
		if(docPrefPharmZipCodeEnt != null) { 
			genLibWeb.enterTextValueByXPath("docMedHistPrefPharmZipCodeInp.xpath", null, docPrefPharmZipCodeEnt, driver);
		}		
	}
	
	/**
	 * This method is used to click next button on edit medical history page by doctor in-consultation 
	 * @throws Exception 
	 */
	public void clickNextOnMedicalHistoryEditPage(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docMedHistNextBtn.id", driver);		
	}

	/**
	 * This method is used to verify if doctor is on Medical History Edit Review Page in consultation
	 */	
	public boolean verifyOnMedicalHistoryEditReviewPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docMedicalHistEditReviewPageH4.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if doctor on Medical History Edit Review Page in consultation
	 */
	public void verifyNValidateOnMedicalHistoryEditReviewPage(WebDriver driver)throws Exception {
		if(!verifyOnMedicalHistoryEditReviewPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Doctor is NOT on Medical History Edit Review Page");
			Assert.fail("Doctor is NOT on Medical History Edit Review Page");
		}		
		log.info("Doctor is on Medical History Edit Review Page");
	}

	/**
	 * This method is used to review patient general info after medical history edit by doctor in-consultation
	 * @throws Exception 
	 */
	public void reviewPatientGeneralInfo(String docHeighFeetEnt, String docHeighInchesEnt, String docWeightLbsEnt, String docMedConditionEnt, String docSurgeriesEnt, String docFamMedProbEnt, 
			String docSmokeEnt, String docSmokePacksNumEnt, String docAlcoholEnt, String docJobProfEnt, WebDriver driver) throws Exception {
 		String errMessage = "Health info NOT correct on Review Page for: ";
		try{
			String heightFrmUi = genLibWeb.getTextByID("docMedHistReviewHeightSpan.id", driver);			
			if(StringUtils.isNotBlank(docHeighFeetEnt)){
				//equals
				Assert.assertTrue(heightFrmUi.contains(docHeighFeetEnt.trim()+"\'"), errMessage+"Height Feet, ");
			}
			if(docHeighInchesEnt != null) {
				if(docHeighInchesEnt.isEmpty()){ //default 0
					//equals
					Assert.assertTrue(heightFrmUi.contains(noHeightInches), errMessage+"Height Inches, ");
				}else{
					Assert.assertTrue(heightFrmUi.contains(docHeighInchesEnt.trim()+"\""), errMessage+"Height Inches, ");
				}
			}
			
			String weightFrmUi = genLibWeb.getTextByID("docMedHistReviewWeightSpan.id", driver);	
			if(docWeightLbsEnt != null){
				if(docWeightLbsEnt.isEmpty()){ //default 0
					//equals
					Assert.assertTrue((weightFrmUi.equalsIgnoreCase(noWeight) || StringUtils.containsIgnoreCase(weightFrmUi, VMedixUtils.NOT_APPLICABLE_NAN)), errMessage+"Weight Lbs, ");
				}else{
					Assert.assertTrue(weightFrmUi.contains(docWeightLbsEnt.trim()+" lbs"), errMessage+"Weight Lbs, ");

				}	
			}
			
			//verify BMI 			
			if((weightFrmUi.equalsIgnoreCase(noWeight) || StringUtils.containsIgnoreCase(weightFrmUi, VMedixUtils.NOT_APPLICABLE_NAN))
				|| (heightFrmUi.contains(noHeightFeet) 
						&& heightFrmUi.contains(noHeightInches))) {				
				log.info("Expecting BMI calculation: -- ");
				Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewBMINoneDashSpan.id", driver).equals(dashMedHistInfo), errMessage+"BMI, ");
			} else {
				String bmiCalculated = genLibWeb.getTextByID("docMedHistReviewBMISpan.id", driver);
				Assert.assertTrue((StringUtils.isNotBlank(bmiCalculated) && !bmiCalculated.equalsIgnoreCase(dashMedHistInfo)), errMessage+"BMI, ");
			}

			//med conds
			if(StringUtils.isBlank(docMedConditionEnt)){ //default None
				if(!genLibWeb.isElementFoundByID("docMedHistReviewMedCondCommaDelim.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("docMedHistReviewMedCondCommaDelim.id", driver))){
					log.info("Expecting Medical condition: None");
					Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewMedCondNoneSpan.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMessage+"Medical conditions, ");					
				}
			}else {
				Assert.assertEquals(genLibWeb.getTextByID("docMedHistReviewMedCondCommaDelim.id", driver), docMedConditionEnt, errMessage+"Medical conditions, ");
			}
			//surgeries TODO: VM-4271
			if(StringUtils.isBlank(docSurgeriesEnt)){ //default None
				if(!genLibWeb.isElementFoundByID("docMedHistReviewMedSurgeriesCommaDelim.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("docMedHistReviewMedSurgeriesCommaDelim.id", driver))){
					log.info("Expecting Surgeries: None");
					Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewMedSurgeriesNoneSpan.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMessage+"Surgeries, ");
				}
			}else {
				Assert.assertEquals(genLibWeb.getTextByID("docMedHistReviewMedSurgeriesCommaDelim.id", driver), docSurgeriesEnt, errMessage+"Surgeries, ");
			}
			//med fam prob
			if(StringUtils.isBlank(docFamMedProbEnt)){ //default None
				if(!genLibWeb.isElementFoundByID("docMedHistReviewFamHistCommaDelim.id", driver) || StringUtils.isBlank(genLibWeb.getTextByID("docMedHistReviewFamHistCommaDelim.id", driver))){
					log.info("Expecting Family Medical History: None");
					Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewFamHistNoneSpan.id", driver).equalsIgnoreCase(VMedixUtils.NONE), errMessage+"Family Medical History, ");
				}
			}else {
				Assert.assertEquals(genLibWeb.getTextByID("docMedHistReviewFamHistCommaDelim.id", driver), docFamMedProbEnt, errMessage+"Family Medical History, ");
			}			
			//smoke 
			if(StringUtils.isNotBlank(docSmokeEnt)){ // default is empty
				if(docSmokeEnt.equalsIgnoreCase(VMedixUtils.YES)){
					//equals				
					if(StringUtils.isBlank(docSmokePacksNumEnt) || (!docSmokePacksNumEnt.equalsIgnoreCase(smokePacksLessThan1) && Integer.parseInt(docSmokePacksNumEnt) > 5)){
						docSmokePacksNumEnt = "0";
					}
					Assert.assertTrue((StringUtils.containsIgnoreCase(genLibWeb.getTextByXPath("docMedHistReviewSmokeDiv.xpath", null, driver), VMedixUtils.YES) 
							&& StringUtils.containsIgnoreCase(genLibWeb.getTextByID("docMedHistReviewSmokeSpan.id", driver), docSmokePacksNumEnt)), errMessage+"Smoke Pack(s)/day, " );
				}else{
					log.info("Expecting Smoke: No");
					Assert.assertTrue(StringUtils.containsIgnoreCase(genLibWeb.getTextByXPath("docMedHistReviewSmokeDiv.xpath", null, driver), VMedixUtils.NO), errMessage+"Smoke Pack(s)/day, " );
				}
			}
			//alcohol
			if(StringUtils.isNotBlank(docAlcoholEnt)){
				Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewAlcoholDiv.id", driver).equalsIgnoreCase(docAlcoholEnt.trim()), errMessage+"Alcohol, ");
			}
			
			//job/profession
			if(StringUtils.isNotBlank(docJobProfEnt)){
				Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewJobProfDiv.id", driver).equalsIgnoreCase(docJobProfEnt.trim()), errMessage+"Job/Profession, ");				
			}

		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}
	
	/**
	 * This method is used to review patient Primary doctor info after medical history edit by doctor in-consultation
	 * @throws Exception 
	 */
	public void reviewPatientPrimaryDoctorInfo(String docPrimDocNameEnt, String docPrimDocPhoneEnt, WebDriver driver) throws Exception {
		String errMessage = "Primary Doctor info NOT correct on Review Page for: ";
		try{
			if(StringUtils.isNotBlank(docPrimDocNameEnt)){
				Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewPrimDocNameDiv.id", driver).equalsIgnoreCase(docPrimDocNameEnt.trim()), errMessage+"Primary Care Physician Name, ");
			}
			if(StringUtils.isNotBlank(docPrimDocPhoneEnt)){
				Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewPrimDocPhNumDiv.id", driver).equalsIgnoreCase(docPrimDocPhoneEnt.trim()), errMessage+"Primary Care Physician Phone Number, ");
			}
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}		
	}
	
	/**
	 * This method is used to review patient Preferred pharmacy info after medical history edit by doctor in-consultation
	 */
	public void reviewPatientPreferredPharmInfo(String docPrefPharmNameEnt, String docPrefPharmPhoneEnt, String docPrefPharmAddr1Ent, String docPrefPharmAddr2Ent, String docPrefPharmCityEnt, 
			String docPrefPharmStateEnt, String docPrefPharmZipCodeEnt, WebDriver driver) throws Exception {
		String errMessage = "Preferred Pharmacy info NOT correct on Review Page for: ";
		try{
			if(StringUtils.isNotBlank(docPrefPharmNameEnt)){
				Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewPrefPharmNameDiv.id", driver).equalsIgnoreCase(docPrefPharmNameEnt.trim()), errMessage+"Preferred Pharmacy Name, ");
			}
			if(StringUtils.isNotBlank(docPrefPharmAddr1Ent)){
				Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewPrefPharmAddr1Div.id", driver).equalsIgnoreCase(docPrefPharmAddr1Ent.trim()), errMessage+"Preferred Pharmacy Addres1, ");
			}
			if(StringUtils.isNotBlank(docPrefPharmAddr2Ent)){
				Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewPrefPharmAddr2Div.id", driver).equalsIgnoreCase(docPrefPharmAddr2Ent.trim()), errMessage+"Preferred Pharmacy Address2, ");
			}
			String cityStateZipFrmUi = genLibWeb.getTextByID("docMedHistReviewPrefPharmCityStateZipCommaDelim.id", driver);
			if(StringUtils.isNotBlank(docPrefPharmCityEnt)){
				Assert.assertTrue(cityStateZipFrmUi.contains(docPrefPharmCityEnt.trim()), errMessage+"Preferred Pharmacy Phone Number, ");
			}					
			if(StringUtils.isNotBlank(docPrefPharmStateEnt)){
				Assert.assertTrue(cityStateZipFrmUi.contains(docPrefPharmStateEnt.trim()), errMessage+"Preferred Pharmacy Addres1, ");
			}
			if(StringUtils.isNotBlank(docPrefPharmZipCodeEnt)){
				Assert.assertTrue(cityStateZipFrmUi.contains(docPrefPharmZipCodeEnt.trim()), errMessage+"Preferred Pharmacy Address2, ");
			}
			if(StringUtils.isNotBlank(docPrefPharmPhoneEnt)){
				Assert.assertTrue(genLibWeb.getTextByID("docMedHistReviewPrefPharmPhoneDiv.id", driver).equalsIgnoreCase(docPrefPharmPhoneEnt.trim()), errMessage+"Preferred Pharmacy Phone Number, ");
			}				
			
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
	}

	/**
	 * This method is used to click submit button on edit medical history Review page by doctor
	 * @throws Exception 
	 */
	public void clickSubmitOnMedicalHistoryEditReviewPage(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("docMedHistReviewSubmitBtn.id", driver);
	}
	
	/**
	 * This method is used to verify the text in drop down after auto display; first 3 characters are of the text for auto display
	 * @throws Exception 
	 */
	public boolean verifyPresentInDropBoxAfterAutoDisplay(String med1Add, String textBoxXPathProp, String textBoxXPathValue, String textInDrpBxXPathProp, String textInDrpBxXPathValue, WebDriver driver) throws Exception {
		boolean found = false;
		String first3Chars = med1Add.substring(0, Math.min(med1Add.length(), 3));//first 3 characters for auto display
		genLibWeb.enterTextValueByXPath(textBoxXPathProp, textBoxXPathValue, first3Chars, driver);
		if(textInDrpBxXPathValue == null){
			textInDrpBxXPathValue = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty(textInDrpBxXPathProp), med1Add);
			textInDrpBxXPathProp = null;
		}
		int countOfTextsInDrpBx = genLibWeb.getElementsByXPath(textInDrpBxXPathProp, textInDrpBxXPathValue, driver).size();
		if(countOfTextsInDrpBx == 1){
			found = true;
		}		
		return found;
	}
	
	public String calculateDependentYear() {
		Calendar now = Calendar.getInstance();
		int year = now.get(Calendar.YEAR)-16;//setting 16 years; 18 is the bar on dependent age
		return String.valueOf(year);
	}	
}
