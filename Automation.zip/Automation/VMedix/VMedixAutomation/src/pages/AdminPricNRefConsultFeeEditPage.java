package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class AdminPricNRefConsultFeeEditPage {
	static Logger log = Logger.getLogger(AdminPricNRefConsultFeeEditPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();

	/**
	 * This method is used to verify if on Admin Pricing N Refunds: Edit Consultation Fee Page
	 */	
	public boolean verifyOnAdminEditConsultFeePage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminPricingNRefundConsultFeeEditTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin Pricing N Refunds: Edit Consultation Fee Page
	 */
	public void verifyNValidateOnAdminEditConsultFeePage(WebDriver driver)throws Exception {
		if(!verifyOnAdminEditConsultFeePage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Edit Consultation Fee Page");
			Assert.fail("NOT on Edit Consultation Fee Page");
		}		
		log.info("On Edit Consultation Fee Page");
	}

	public void editConsultFee(String consultFee, WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByID("docAdminPricingNRefundConsultFeeEditInp.id", consultFee, driver);
		genLibWeb.clickOnElementByID("docAdminPricingNRefundConsultFeeEditSaveBtn.id", driver);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);		
		if(!TestCaseInit.messagesVMedixProp.getProperty("consultFeeEdit.success").equals(toastMsg)) {
			TestCaseInit.testCaseStatus = false;
			log.error("Consult Fee NOT edited: " + consultFee);
			Assert.fail("Consult Fee NOT edited: " + consultFee);			
		}
		log.info("Consult Fee Edited: " + consultFee);		
	}
}
