package pages;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class PatientConsultHistoryPage {
	static Logger log = Logger.getLogger(PatientConsultHistoryPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/**
	 * This method is used to verify if patient is on Consult History Page
	 */	
	public boolean verifyPatientOnConsultHistoryPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultHistoryActiveBtnClass.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if patient is on Consult History Page
	 */
	public void verifyNValidatePatientOnConsultHistoryPage(WebDriver driver)throws Exception {
		if(!verifyPatientOnConsultHistoryPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Patient is NOT on Consult History Page");
			Assert.fail("Patient is NOT on Consult History Page");
		}		
		log.info("Patient is on Consult History Page");
	}
	
	public String getPatientConsultReportPDF(String docName, WebDriver driver) throws Exception {
		String pdfUrl = null;
		int countConsultHists = genLibWeb.getNumberOfElementsByXPath("patConsultHistListTr.xpath", null, driver);
		if(!(countConsultHists > 0) ){
			TestCaseInit.testCaseStatus = false;
			log.error("NO Consult History found");	
			Assert.fail("NO Consult History found");
		}
		boolean found = false;
		while(!found){
			for(int i=0; i<countConsultHists; i++){
				String rowCount = Integer.toString(i);
				if(genLibWeb.getElementByID(null, MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultHistTr.id"), rowCount), driver) != null) {
					String doctorTdXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultHistDoctorTdSpan.xpath"), rowCount);
					String dateTdXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultHistDateTd.xpath"), rowCount);
					String pdfConsultRepLinkAncXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultHistRepPdfTdLinkAnc.xpath"), rowCount);
					DateFormat dateFormat1 = new SimpleDateFormat("M/d/yy");
					String currentDate = dateFormat1.format(new Date());
					if(docName.equalsIgnoreCase(genLibWeb.getTextByXPath(null, doctorTdXpathVal, driver)) 
							&& currentDate.equals(genLibWeb.getTextByXPath(null, dateTdXpathVal, driver))){	
						log.info("Consult History Found for the patient");
						pdfUrl = genLibWeb.getAttributeByXPath(null, pdfConsultRepLinkAncXpathVal, "href", driver);
						genLibWeb.clickOnElementByXPath(null, pdfConsultRepLinkAncXpathVal, driver);
						found = true;
						break;
					}
				} 
			}
			if(!found){
				//search on next page
				if(!genLibWeb.isElementEnabledByXPath("nextBtnOnPages.ngClick.xpath", null, driver)){
					TestCaseInit.testCaseStatus = false;
					log.error("NO Consult History found for the patient");	
					Assert.fail("NO Consult History found for the patient");					
				} else {
					genLibWeb.clickOnElementByXPath("nextBtnOnPages.ngClick.xpath", null, driver);
					Thread.sleep(5000);
					countConsultHists = genLibWeb.getNumberOfElementsByXPath("patConsultHistListTr.xpath", null, driver);
				}
			}		
		}
		Thread.sleep(2000);
		if(!(found && StringUtils.isNotBlank(pdfUrl))){
			TestCaseInit.testCaseStatus = false;
			log.error("PDF Url NOT retrieved from Consult History");	
			Assert.fail("PDF Url NOT retrieved from Consult History");		
		}else{
			log.info("PDF Url Retrieved from Consult History: "+ pdfUrl);			
		} 
		return pdfUrl;
	}

	public String verifyPatConsultHistPdfReportData(String pdfUrl, String patName, String docName, String price, 
			String diagCode, String followUp, String returnToSchWrk, String restrt, String durOfRestrt, String personalizedDInstr, WebDriver driver) throws Exception{
		String errMsg = "Failed on Consult History Pdf Report asserts, ";
		String patConsultPanelHandler = driver.getWindowHandle();
		String pdfReportText = VMedixUtils.readPDFDataFromUrl(pdfUrl);		
		if(StringUtils.isBlank(pdfReportText)){
			TestCaseInit.testCaseStatus = false;
			log.error("Patient Consult History Report is Empty");	
			Assert.fail("Patient Consult History Report is Empty");	
		}
		log.error("Patient Consult History Report text Retrieved: "+ pdfReportText);
		try{
			Assert.assertTrue(StringUtils.containsIgnoreCase(pdfReportText, patName), errMsg+"Patient Name");
			Assert.assertTrue(StringUtils.containsIgnoreCase(pdfReportText, docName), errMsg+"Doctor Name");
			DateFormat dateForm = new SimpleDateFormat("M/d/yyyy");
			String currentDate = dateForm.format(new Date());
			Assert.assertTrue(pdfReportText.contains(currentDate), errMsg+"Today's Date");
			if(price != null){
				Assert.assertTrue(pdfReportText.contains(price), errMsg+"Price");
			}
			if(diagCode != null){				
				if(diagCode.contains(",")) { //more than one diag code comma delimited appended with general
					String[] listOfDiagCode = diagCode.split("\\,");
					for(String diagCodeVal : listOfDiagCode ) {
						Assert.assertTrue(pdfReportText.contains(diagCodeVal), errMsg+"Diagnosis Code");	
					}
				} else {
					Assert.assertTrue(pdfReportText.contains(diagCode), errMsg+"Diagnosis Code");	
				}								
			}
			if(followUp !=  null){
				Assert.assertTrue(pdfReportText.contains(followUp), errMsg+"Follow Up");	
			}
			if(returnToSchWrk != null){
				Assert.assertTrue(pdfReportText.contains(returnToSchWrk), errMsg+"Return to School/Work");	
			}
			if(restrt != null){
				Assert.assertTrue(pdfReportText.contains(restrt), errMsg+"Restrictions");	
			}
			if(durOfRestrt != null){
				Assert.assertTrue(pdfReportText.contains(durOfRestrt), errMsg+"Duration of Restrictions");	
			}	
			if(personalizedDInstr != null){
				Assert.assertTrue(pdfReportText.contains(personalizedDInstr), errMsg+"Personalized Discharge Instruction");	
			}
			log.info("Passed all asserts on Consult History Pdf Report Data");
		}catch(Throwable th){
			if(th instanceof AssertionError){
				TestCaseInit.testCaseStatus = false;
				log.error(th.getMessage());	
				Assert.fail(th.getMessage());
			} else {
				throw th;
			}
		}
		return patConsultPanelHandler;
	}
}
