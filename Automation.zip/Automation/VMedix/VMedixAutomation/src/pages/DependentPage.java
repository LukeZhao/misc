package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class DependentPage {
	private static Logger log = Logger.getLogger(DependentPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	public LoginPage login = new LoginPage();
	CommonUtilsPage cmnUtilsPage = new CommonUtilsPage(); 
	
	/**
	 * This method is used to verify if on New Dependent page
	 */	
	public boolean verifyOnNewDependentPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("createNewDependentPageH2.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on New Dependent page
	 */
	public void verifyNValidateOnNewDependentPage(WebDriver driver) throws Exception {
		if(!verifyOnNewDependentPage(driver)){
			TestCaseInit.testCaseStatus = false;
			log.info("Patient is NOT on the create New Dependent page");
			Assert.fail("Patient is NOT on the create New Dependent page");
		}
		log.info("Patient is on create New Dependent page");
	}
	
	/**
	 * This method is used to verify if on Existing Dependent page
	 */	
	public boolean verifyOnExistingDependentPage(WebDriver driver) throws Exception {
		return (genLibWeb.isElementFoundByXPath("patientLandingPageH1.xpath", null, driver) 
				&& !genLibWeb.isElementFoundByXPath("patientLandingPageP.xpath", null, driver));
	}
	
	/**
	 * This method is used to validate if on Existing Dependent page
	 */
	public void verifyNValidateOnExistingDependentPage(WebDriver driver) throws Exception {
		if(!verifyOnExistingDependentPage(driver)){
			TestCaseInit.testCaseStatus = false;
			log.info("Patient is NOT on the existing Dependent page");
			Assert.fail("Patient is NOT on the existing Dependent page");
		}
		log.info("Patient is on existing Dependent page");
	}
	
	/**
	* This method is used to fill new dependent info
	* @param depFName
	* @param depLName
	* @param dobMon
	* @param dobDay
	* @param dobYear
	* @param gender
	* @param primaryPhone
	* @param zipcode
	* @param passedInDriver
	 * @throws Exception 
	*/
	public void createAccountForNewDependent(String depFName, String depLName, String dobMon, String dobDay, String gender, String primPhone, String zipCode, String groupId, String memberId,  WebDriver driver) throws Exception {
		//validate required fields
		genLibWeb.clickOnElementByID("newDepenAddChildBtn.id", driver);
		Thread.sleep(2000);
		if(!genLibWeb.isElementFoundByID("newDepenAddChildBtn.id", driver) 
				|| genLibWeb.isElementEnabledByID("newDepenAddChildBtn.id", driver) 
				|| genLibWeb.getNumberOfElementsByXPath("newPatRequiredFieldBlock.xpath", null, driver) != VMedixUtils.NEW_DEPENDENT_REQUIRED_NUMBER_OF_FIElDS){//validation done on 9 fields (includes both gender options) and dob - mon, day and year
			TestCaseInit.testCaseStatus = false;
			log.error("Add Child button NOT disabled when NO required fields entered");				
			Assert.fail("Add Child button NOT disabled when NO required fields entered");	
		}
		log.info("Add Child button disabled when no required fields entered");
		
		genLibWeb.enterTextValueByID("newPatFirstNameInp.id", depFName, driver);
		genLibWeb.enterTextValueByID("newPatLastNameInp.id", depLName, driver);
		genLibWeb.selectByValueFromSelectElementID("newPatDobMonthDrpBx.id", dobMon, driver);
		genLibWeb.selectByValueFromSelectElementID("newPatDobDayDrpBx.id", dobDay, driver);		
		String depenYear = cmnUtilsPage.calculateDependentYear();
		//verify invalid dependent age, greater than 18
		genLibWeb.selectByValueFromSelectElementID("newPatDobYearDrpBx.id", Integer.toString(Integer.valueOf(depenYear)-5), driver);
        //Sometimes on firefox the drop down list does not close after selection blocking the next element
        //Trick: used scroll and click logo to avoid this scenario
        if(TestCaseInit.browserPatient.equalsIgnoreCase("firefox")){
        	genLibWeb.scrollToViewElementWithXPath("dependentLogoImg.xpath", null, driver);
        	genLibWeb.clickOnElementByXPath("dependentLogoImg.xpath", null, driver);
        }
		if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("M")) {
			genLibWeb.clickOnElementByID("newPatGenderMaleRdLabel.id", driver);
		} else if(gender.equalsIgnoreCase("Female") || gender.equalsIgnoreCase("F")) {
			genLibWeb.clickOnElementByID("newPatGenderFemaleRdLabel.id", driver);
		} else {
			log.error("Please pass correct gender from the test data");
		}
		genLibWeb.enterTextValueByXPath("newPatPhoneInp.ngModel.xpath", null, primPhone, driver);
		genLibWeb.enterTextValueByXPath("newPatZipCodeInp.ngModel.xpath", null, zipCode, driver);
		
		if(StringUtils.isNotBlank(groupId)){
			genLibWeb.enterTextValueByID("newDepenGroupIdInp.id", groupId, driver);
		}
		if(StringUtils.isNotBlank(memberId)){
			genLibWeb.enterTextValueByID("newDepenMemberIdInp.id", memberId, driver);
		}
		//Add child/dependent
		Thread.sleep(1000);
		genLibWeb.clickOnElementByID("newDepenAddChildBtn.id", driver);			
		if(!(genLibWeb.explicitWaitUntilElementWithXPathIsVisible("newDepenAddChildOldPopUpP.xpath", null, driver) 
				&& TestCaseInit.messagesVMedixProp.getProperty("depenOlderPopUp.error").equals(genLibWeb.getTextByXPath("newDepenAddChildOldPopUpP.xpath", null, driver)))){
			TestCaseInit.testCaseStatus = false;
			log.error("Dependent older than 18yrs pop up Failed");
			Assert.fail("Dependent older than 18yrs pop up Failed");	
		}
		log.info("Dependent older than 18yrs pop up Successful");
		//click ok on popup and enter valid dependent age
		genLibWeb.clickOnElementByXPath("newDepenAddChildOldPopUpOkBtn.xpath", null, driver);
		genLibWeb.selectByValueFromSelectElementID("newPatDobYearDrpBx.id", depenYear, driver);
		//Add child/dependent
		Thread.sleep(2000);
		genLibWeb.clickOnElementByID("newDepenAddChildBtn.id", driver);
		
		//validate if child added
		Thread.sleep(1000);//wait till add child submitted
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastTitleMsg.xpath", null, driver);
		if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("createDependentTitle.success"), "toastTitleMsg.xpath", null, driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("New dependent/child NOT created");				
			Assert.fail("New dependent/child NOT created");	
		}
		log.info("New dependent/child Created");	
	}
	
	/**
	* This method is used to fill new dependent info
	* @param depFName
	* @param depLName
	* @param dobMon
	* @param dobDay
	* @param dobYear
	* @param gender
	* @param primaryPhone
	* @param zipcode
	* @param passedInDriver
	 * @throws Exception 
	*/
	public void createAccountForNewDependentNoValidations(String depFName, String depLName, String dobMon, String dobDay, String gender, String primPhone, String zipCode, String groupId, String memberId,  WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByID("newPatFirstNameInp.id", depFName, driver);
		genLibWeb.enterTextValueByID("newPatLastNameInp.id", depLName, driver);
		genLibWeb.selectByValueFromSelectElementID("newPatDobMonthDrpBx.id", dobMon, driver);
		genLibWeb.selectByValueFromSelectElementID("newPatDobDayDrpBx.id", dobDay, driver);
		genLibWeb.selectByValueFromSelectElementID("newPatDobYearDrpBx.id", cmnUtilsPage.calculateDependentYear(), driver);
        //Sometimes on firefox the drop down list does not close after selection blocking the next element
        //Trick: used scroll and click logo to avoid this scenario
        if(TestCaseInit.browserPatient.equalsIgnoreCase("firefox")){
        	genLibWeb.scrollToViewElementWithXPath("dependentLogoImg.xpath", null, driver);
        	genLibWeb.clickOnElementByXPath("dependentLogoImg.xpath", null, driver);
        }
		if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("M")) {
			genLibWeb.clickOnElementByID("newPatGenderMaleRdLabel.id", driver);
		} else if(gender.equalsIgnoreCase("Female") || gender.equalsIgnoreCase("F")) {
			genLibWeb.clickOnElementByID("newPatGenderFemaleRdLabel.id", driver);
		} else {
			log.error("Please pass correct gender from the test data");
		}
		genLibWeb.enterTextValueByXPath("newPatPhoneInp.ngModel.xpath", null, primPhone, driver);
		genLibWeb.enterTextValueByXPath("newPatZipCodeInp.ngModel.xpath", null, zipCode, driver);
		
		if(StringUtils.isNotBlank(groupId)){
			genLibWeb.enterTextValueByID("newDepenGroupIdInp.id", groupId, driver);
		}
		if(StringUtils.isNotBlank(memberId)){
			genLibWeb.enterTextValueByID("newDepenMemberIdInp.id", memberId, driver);
		}
		//Add child/dependent
		Thread.sleep(1000);
		genLibWeb.clickOnElementByID("newDepenAddChildBtn.id", driver);
	}
}
