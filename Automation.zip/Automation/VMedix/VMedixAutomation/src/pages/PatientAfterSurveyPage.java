package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class PatientAfterSurveyPage {
	static Logger log = Logger.getLogger(PatientAfterSurveyPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	

	/**
	 * This method is used to verify if patient is on After Consultation Page
	 * @throws Exception 
	 */	
	public boolean verifyPatientOnAfterConsultationPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patAfterConsultPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if patient is on After Consultation Page
	 * @throws Exception 
	 */
	public void verifyNValidatePatientOnAfterConsultationPage(WebDriver driver)throws Exception {
		if(!verifyPatientOnAfterConsultationPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Patient is NOT on After Consultation Page");
			Assert.fail("Patient is NOT on After Consultation Page");
		}		
		log.info("Patient is on After Consultation Page");
	}

	/**
	 * This method is used to verify Send Fax, Logout and Home options on after consultation survey
	 * @throws Exception 
	 */
	public void verifyOptionsOnAfterConsult(WebDriver driver) throws Exception {
		//fax
		if(!genLibWeb.isElementFoundByID("patAfterConsultFaxBtn.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Send Fax option NOT found on After Consultation Page");
			Assert.fail("Send Fax option NOT found on After Consultation Page");
		}		
		log.info("Send Fax option Found on After Consultation Page");
		
		//home
		if(!genLibWeb.isElementFoundByID("patAfterConsultHomeBtn.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Home option NOT found on After Consultation Page");
			Assert.fail("Home option NOT found on After Consultation Page");
		}		
		log.info("Home option Found on After Consultation Page");
		
		//logout
		if(!genLibWeb.isElementFoundByID("patAfterConsultLogOutBtn.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Log Out option NOT found on After Consultation Page");
			Assert.fail("Log Out option NOT found on After Consultation Page");
		}		
		log.info("Log Out option Found on After Consultation Page");
	}
	
	/**
	 * This method is used to select Home option after consultation survey
	 * @throws Exception 
	 */
	public void clickOnHomeOption(WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("patAfterConsultHomeBtn.id", driver);
	}
}
