package pages;

import java.text.MessageFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.BussinessLib;
import library.GenericLibWeb;
import library.VMedixUtils;
import tests.TestCaseInit;

public class PatientConsultationVideoOrPhonePage {
	
	private static Logger log = Logger.getLogger(PatientConsultationVideoOrPhonePage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	BussinessLib bussLib = new BussinessLib();
	String failedMsg = null;
	public final String autoItExeLocationForChrome_PatientPhotos = TestCaseInit.Current_Directory+"\\Test_Data\\ChromeAutoIt_PatientPhotos.exe";
	public final String autoItExeLocationForFirefox_PatientPhotos = TestCaseInit.Current_Directory+"\\Test_Data\\FirefoxAutoIt_PatientPhotos.exe";
	
	/**
	 * This method is used to verify if patient is in queue waiting for doctor
	 */	
	public boolean verifyPatientOnWaitingForDocInQPage(WebDriver driver) throws Exception{
		return genLibWeb.isElementFoundByXPath("patConsultWaitingForDocPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if patient is in queue waiting for doctor
	 */
	public void verifyNValidatePatientOnWaitingForDocInQPage(WebDriver driver)throws Exception {
		if(!verifyPatientOnWaitingForDocInQPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Patient is NOT on Waiting for doctor in queue page");
			Assert.fail("Patient is NOT on Waiting for doctor in queue page");
		}
		log.info("Patient is on Waiting for doctor in queue page");
	}
	
	/**
	 * This method is used to upload a photo.	
	 * @param label
	 * @param location
	 * @param driver
	 * @throws Exception 
	 */
	public void uploadAPatientPhoto(WebDriver driver) throws Exception {		
		if(isPatientPhotoUploaded(driver)) {
			log.info("Photo uploaded successfully");
		} else{
			TestCaseInit.testCaseStatus = false;
			log.error("Photo NOT uploaded");
			Assert.fail("Photo NOT uploaded");	
		}
	}
	
	/**
	 * This method is used to upload specified number of photos photo.	
	 * @param label
	 * @param location
	 * @param driver
	 * @throws Exception 
	 */
	public void uploadFewPatientPhotos(int numPhotos, WebDriver driver) throws Exception {		
		//Uploading number of photos specified Photos
		for(int i=0; i<numPhotos; i++){
			uploadAPatientPhoto(driver);
			Thread.sleep(3000);//wait for the toast messages to clear
		}
	}
	
	private boolean isPatientPhotoUploaded(WebDriver driver) throws Exception {
		boolean uploaded = false;
		genLibWeb.clickOnElementByXPath("patConsultPhotoUploadBtn.ngClick.xpath", null, driver);
		if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_CHROME)){
			Runtime.getRuntime().exec(autoItExeLocationForChrome_PatientPhotos);
		}else if(TestCaseInit.browserDoctor.equalsIgnoreCase(VMedixUtils.BROWSER_TYPE_FIREFOX)){
			Runtime.getRuntime().exec(autoItExeLocationForFirefox_PatientPhotos);
		}
		Thread.sleep(5000);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("toastMsg.xpath", null, driver);
		String toastMsg = genLibWeb.getTextByXPath("toastMsg.xpath", null, driver);
		if(TestCaseInit.messagesVMedixProp.getProperty("photoUpload.success").equals(toastMsg)
				|| TestCaseInit.messagesVMedixProp.getProperty("photoUpload.info").equals(toastMsg)){ //in process of uploading or uploaded, if not would have erred immediately
			uploaded = true;
		}
		return uploaded;
	}
	
	/**
	 * This method is used to view uploaded photo
	 * @param photoNumber; Out of the 6 photos
	 * @param driver
	 * @throws Exception 
	 */
	public void viewNClosePatientPhoto(String photoTitle, WebDriver driver) throws Exception {	
		if(StringUtils.isNotBlank(photoTitle)){
			String photoXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultPhotoAnc.xpath"), photoTitle.trim());
			genLibWeb.clickOnElementByXPath(null, photoXpathVal, driver);
			Thread.sleep(3000);
			//close view photo
			genLibWeb.clickOnElementByXPath("patConsultViewPhotoClose.xpath", null, driver);
			Thread.sleep(2000);//wait to close
		} else{
			log.error("Photo title NOT specified");
		}
	}	
		
	/**
	 * This method is used to take a photo
	 * @param driver
	 * @throws Exception 
	 */
	public void takePatientPhoto(WebDriver driver) throws Exception {	
		//click take photo icon
		clickOnTakePhoto(driver);
		verifyNValidateOnTakePhotoPopUp(driver);
		clickOnTakeSnapShotOnPopUp(driver);
		Thread.sleep(5000); //wait till the photo is taken
		clickOnUsePhotoOnPopUp(driver);	
		Thread.sleep(5000); //wait to upload
	}
	
	/**
	 * This method is used to click on take photo
	 * @param driver
	 * @throws Exception 
	 */
	public void clickOnTakePhoto(WebDriver driver) throws Exception {	
		//click take photo icon
		genLibWeb.clickOnElementByID("patConsultTakePhotoIBtn.id", driver);
	}
	
	/**
	 * This method is used to verify if patient is on take photo pop-up
	 */	
	public boolean verifyOnTakePhotoPopUp(WebDriver driver) throws Exception{
		return genLibWeb.isElementFoundByXPath("patConsultTakePhotoPopUpTitleH4.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if patient is on take photo pop-up
	 */
	public void verifyNValidateOnTakePhotoPopUp(WebDriver driver)throws Exception {
		if(!verifyOnTakePhotoPopUp(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("Patient is NOT on Take Photo pop-up");
			Assert.fail("Patient is NOT on Take Photo pop-up");
		}
		log.info("Patient is on Take Photo pop-up");
	}
	
	/**
	 * This method is used to click on take photo btn on pop up
	 * @param driver
	 * @throws Exception 
	 */
	private void clickOnTakeSnapShotOnPopUp(WebDriver driver) throws Exception {	
		genLibWeb.clickOnElementByXPath("patConsultTakePhotoPopUpTakePhotoBtn.xpath", null, driver);
	}
	
	/**
	 * This method is used to click on use/save photo btn on pop up
	 * @param driver
	 * @throws Exception 
	 */
	private void clickOnUsePhotoOnPopUp(WebDriver driver) throws Exception {	
		genLibWeb.clickOnElementByXPath("patConsultTakePhotoPopUpUsePhotoBtn.xpath", null, driver);
	}
	
	
	/**
	 * This method is used to remove uploaded photo
	 * @param photoNumber; Out of the 6 photos
	 * @param driver
	 * @throws Exception 
	 */
	public void removePatientPhoto(String photoTitle, WebDriver driver) throws Exception {	
		if(StringUtils.isNotBlank(photoTitle)){
			String photoXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultPhotoAnc.xpath"), photoTitle.trim());
			genLibWeb.explicitWaitUntilElementWithXPathIsVisible(null, photoXpathVal, driver);
			if(!genLibWeb.isElementFoundByXPath(null, photoXpathVal, driver)){
				TestCaseInit.testCaseStatus = false;
				log.error("Photo title specified is NOT present: "+ photoTitle);
				Assert.fail("Photo title specified is NOT present: "+ photoTitle);	
			}
			log.info("Photo title specified is present: "+ photoTitle);
			String photoDeleteXpathVal = MessageFormat.format(TestCaseInit.webLocatorProp.getProperty("patConsultPhotoDeleteAnc.xpath"), photoTitle.trim());
			genLibWeb.clickOnElementByXPath(null, photoDeleteXpathVal, driver);
			if(!genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("photoRemove.success"), "toastMsg.xpath", null, driver)) {
				TestCaseInit.testCaseStatus = false;
				log.error("Photo NOT removed on Patient side: "+ photoTitle);
				Assert.fail("Photo NOT removed on Patient side: "+ photoTitle);	
			}
			log.info("Photo removed on Patient side: "+ photoTitle);
		} else{
			log.error("Photo title NOT specified");
		}
	}
	
	
	/**
	 * This method is used to check Limit on photo upload.
	 * @param label
	 * @param location
	 * @param driver
	 * @throws Exception 
	 */
	public void checkLimitOnPhotoUpload(WebDriver driver) throws Exception {
		//Uploading 6 Photos : No error, photos should upload - Need to catch correct message here - photo has been added
		for(int i=0; i<VMedixUtils.PHOTO_LIMIT; i++){
			uploadAPatientPhoto(driver);
			Thread.sleep(3000);//wait for the toast messages to clear
		}
		//Uploading 7th photo to verify the limit of 6 and error message
		if(!isPatientPhotoUploaded(driver) && genLibWeb.validateExpectedWithActualByXPath(TestCaseInit.messagesVMedixProp.getProperty("photoUploadLimit.error"), "toastMsg.xpath", null, driver)){
			log.info("Photo limited to: "+ VMedixUtils.PHOTO_LIMIT);				
		}else{
			TestCaseInit.testCaseStatus = false;
			log.error("Photo upload NOT limited to: "+ VMedixUtils.PHOTO_LIMIT);
			Assert.fail("Photo upload NOT limited to: "+ VMedixUtils.PHOTO_LIMIT);
		}
	}
	
	
	/**
	 * This method is used to verify Chat window
	 * @param driver
	 * @throws Exception
	 */
	public void verifyChatWindow(WebDriver driver) throws Exception {
		if(!genLibWeb.isElementFoundByID("docNPatChatTriggerLi.id", driver)){
			TestCaseInit.testCaseStatus = false;
			log.error("Chat option NOT found");
			Assert.fail("Chat option NOT found");			
		}
		log.info("Chat option Found");
		genLibWeb.scrollToViewElementWithID("docNPatChatTriggerLi.id", driver);
		genLibWeb.clickOnElementByID("docNPatChatTriggerLi.id", driver);
		if(!(genLibWeb.isElementFoundByID("docNPatChatInp.id", driver)
				&& genLibWeb.isElementFoundByID("docNPatChatSendBtn.id", driver))){
			TestCaseInit.testCaseStatus = false;
			log.error("Chat input and/or send options NOT found");
			Assert.fail("Chat input and/or send options NOT found");	
		}
		log.info("Chat input and send options Found");
	}
	
	
	/** This method ends video/phone consultation from patient end
	 * @param driver
	 * @throws Exception
	 */
	public void endVideoOrPhoneConsultation(WebDriver driver) throws Exception{
		genLibWeb.clickOnElementByID("patConsultEndConsutationBtn.id", driver);	
		genLibWeb.explicitWaitUntilElementWithIDIsVisible("patConsultEndConfirmPopupYesBtn.id", driver);
		genLibWeb.clickOnElementByID("patConsultEndConfirmPopupYesBtn.id", driver);
	}

	/** This method cancels video/phone consultation from patient end
	 * @param driver
	 * @throws Exception
	 */
	public void cancelVideoOrPhoneConsultation(WebDriver driver) throws Exception {
		Thread.sleep(2000);
		genLibWeb.explicitWaitUntilElementWithIDIsVisible("patConsultWaitingCancelBtn.id", driver);
		genLibWeb.clickOnElementByID("patConsultWaitingCancelBtn.id", driver);
		Thread.sleep(1000);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("patConsultCancelConfirmPopupYesBtn.ngClick.xpath", null, driver);
		genLibWeb.clickOnElementByXPath("patConsultCancelConfirmPopupYesBtn.ngClick.xpath", null, driver);
		Thread.sleep(2000);
	}
}
