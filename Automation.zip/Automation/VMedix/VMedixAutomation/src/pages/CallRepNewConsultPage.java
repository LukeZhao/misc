package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class CallRepNewConsultPage {
	static Logger log = Logger.getLogger(CallRepNewConsultPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	CommonUtilsPage cmnUtilsPage = new CommonUtilsPage();
	
	/**
	 * This method is used to verify if on Call Rep Start New Consultation Page
	 */	
	public boolean verifyOnCallRepStartNewConsultPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("callRepStartNewConsultPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Call Rep Start New Consultation Page
	 */
	public void verifyNValidateOnCallRepStartNewConsultPage(WebDriver driver)throws Exception {
		if(!verifyOnCallRepStartNewConsultPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Call Rep Start New Consultation Page");
			Assert.fail("NOT on Call Rep Start New Consultation Page");
		}		
		log.info("On Call Rep Start New Consultation Page");
	}

	public void startConsultForPatient(String vistReason, String medications, String allergies,	WebDriver driver) throws Exception {
		//select self - patient for consult
		genLibWeb.clickOnElementByID("callRepNewConsultPatientRdBtnLabel.id", driver);
		//start consult by filling form
		startConsultFillForm(vistReason, medications, allergies, driver);
	}

	public void startConsultForNewDependant(String depFName, String depLName, String dobMon, String dobDay,	String gender, String primPhone, 
			String zipCode, String visitReason, String medicines, String allergies, WebDriver driver) throws Exception {
		//select child for consult
		genLibWeb.clickOnElementByID("callRepNewConsultChildPatRdBtnLabel.id", driver);
		//select child - add new
		genLibWeb.selectByVisibleTextFromSelectElementID("callRepDepenDrpBx.id", "Add New Child", driver);
		//enter new dependent info
		Thread.sleep(250);
		genLibWeb.enterTextValueByID("callRepNewDepenFirstNameInp.id", depFName, driver);
		genLibWeb.enterTextValueByID("callRepNewDepenLastNameInp.id", depLName, driver);
		genLibWeb.selectByValueFromSelectElementXPath("callRepNewDepenDobMonthDrpBx.xpath", null, dobMon, driver);
		genLibWeb.selectByValueFromSelectElementXPath("callRepNewDepenDobDayDrpBx.xpath", null, dobDay, driver);
		genLibWeb.selectByValueFromSelectElementXPath("callRepNewDepenDobYearDrpBx.xpath", null, cmnUtilsPage.calculateDependentYear(), driver);
		if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("M")) {
			genLibWeb.clickOnElementByID("callRepNewDepenGenderMaleRdLabel.id", driver);
		} else if(gender.equalsIgnoreCase("Female") || gender.equalsIgnoreCase("F")) {
			genLibWeb.clickOnElementByID("callRepNewDepenGenderFemaleRdLabel.id", driver);
		} else {
			log.error("Please pass correct gender from the test data");
		}
		genLibWeb.enterTextValueByXPath("callRepNewDepenPhoneInp.ngModel.xpath", null, primPhone, driver);
		genLibWeb.enterTextValueByXPath("callRepNewDepenZipCodeInp.ngModel.xpath", null, zipCode, driver);
		//start consult by filling form
		startConsultFillForm(visitReason, medicines, allergies, driver);		
	}	

	private void startConsultFillForm(String vistReason, String medications, String allergies, WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByID("callRepNewConsultChiefComplaintInp.id", vistReason, driver);		
		//select State if not selected
		if(StringUtils.isBlank(genLibWeb.getSelectOptionTextBySelectElementID("callRepNewConsultStateDrpBx.id", driver))){
			genLibWeb.selectByVisibleTextFromSelectElementID("callRepNewConsultStateDrpBx.id", "California", driver); //California
		}		
		//medications
		//enter medications
		if (StringUtils.isNotBlank(medications)){
			cmnUtilsPage.enterMedications(medications, "callRepNewConsultMedicationInp.ngModel.xpath", null, "callRepNewConsultAddBtn.xpath", null, driver);
		}
		//allergies
		//enter allergies
		if (StringUtils.isNotBlank(allergies)){
			cmnUtilsPage.enterAllergies(allergies, "callRepNewConsultAllergyInp.ngModel.xpath", null, "callRepNewConsultAllergyAddBtn.xpath", null, driver);
		}
		genLibWeb.clickOnElementByID("callRepNewConsultContinueBtn.id", driver);
	}
}
