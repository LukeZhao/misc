package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class LoginPage {

	static Logger log = Logger.getLogger(LoginPage.class.getName());
	GenericLibWeb genLibWeb = new GenericLibWeb();
	
	/*
	 * This method is used to login as an exiting user. Authentication is not validated.
	 */
	public void loginAsExistingUser(String userName, String password, WebDriver driver) throws Exception {
		//Log-In as a User, who can be an existing Patient, Doctor, Doctor Admin, Physician QA, Call Rep Agent, Call Center Admin.
		log.info("Login as an existing user");
		Thread.sleep(3000);
		genLibWeb.explicitWaitUntilElementWithXPathIsVisible("landingPageH1.xpath", null, driver);
		genLibWeb.enterTextValueByID("loginUsernameInp.id", userName, driver);
		genLibWeb.enterTextValueByID("loginPasswordInp.id", password, driver);
		genLibWeb.clickOnElementByID("loginBtn.id", driver);
		log.info("Logging in as userName: "+ userName + " and password: " + password);
	}
	
	/*
	 * This method is used to login as an exiting user. Authentication is validated and returns a boolean value.
	 */
	public boolean validateLoginAsExistingUser(String userName, String password, WebDriver driver) throws Exception {
		//For login scenario testcases
		boolean authenticated = false;
		String expectedLoginErrorMsg = TestCaseInit.messagesVMedixProp.getProperty("login.error");	
		loginAsExistingUser(userName, password, driver); 
		//matching error message
		if(!genLibWeb.validateExpectedWithActualByXPath(expectedLoginErrorMsg, "toastMsg.xpath", null, driver)){
			log.info("Login was Successful for user: "+ userName);
			authenticated = true;	
		}
		return authenticated;
	}

	/*
	 * This method is used to login as a new patient to register an account. Registration is NOT validated.
	 */
	public void loginAsNewPatient(String registerEmail, String password, String firstName, String lastName, String month, String day, String year,
			String gender, String primaryPhone, String zipCode, WebDriver driver) throws Exception {
		log.info("Login as a new Patient");
		createAccountForNewPatient(registerEmail, password, firstName, lastName, month, day, year, gender, primaryPhone, zipCode, null, null, driver);
	}
	
	/*
	 * This method is used to login as a new patient to register an account. Registration is validated returning a boolean.
	 */
	public boolean validateLoginAsNewPatient(String registerEmail, String password, String firstName, String lastName, String month, String day, String year,
			String gender, String primaryPhone, String zipCode, WebDriver driver) throws Exception {
		boolean patientRegistered = false;
		String expectedRegisterSuccessMsg = TestCaseInit.messagesVMedixProp.getProperty("register.success");
		loginAsNewPatient(registerEmail,password, firstName, lastName, month, day, year, gender, primaryPhone, zipCode, driver);
		if(genLibWeb.validateExpectedWithActualByXPath(expectedRegisterSuccessMsg, "toastMsg.xpath", null, driver)){
			patientRegistered = true;
			log.info("Registration was Successful for user: "+ registerEmail);
		} 
		return patientRegistered;
	}	
	
	/*
	 * This method is used to login as a new patient to register an account with group information. Registration is NOT validated.
	 */
	public void loginAsNewPatientWithGroupInfo(String registerEmail, String password, String firstName, String lastName, String month, String day, String year,
			String gender, String primaryPhone, String zipCode, String groupId, String memberId, WebDriver driver) throws Exception {
		log.info("Login as a new Patient with group info");
		createAccountForNewPatient(registerEmail, password, firstName, lastName, month, day, year, gender, primaryPhone, zipCode, groupId, memberId, driver);					
	}
	
	/*
	 * This method is used to login as a new patient to register an account with group information. Registration is validated returning a boolean.
	 */
	public boolean validateLoginAsNewPatientWithGroupInfo(String registerEmail, String password, String firstName, String lastName, String month, String day, String year,
			String gender, String primaryPhone, String zipCode, String groupId, String memberId, WebDriver driver) throws Exception  {
		boolean patientRegistered = false;
		String expectedRegisterSuccessMsg = TestCaseInit.messagesVMedixProp.getProperty("register.success");
		String expectedRegisterGroupInfoErrorMsg = TestCaseInit.messagesVMedixProp.getProperty("registerGroupInfo.error");
		loginAsNewPatientWithGroupInfo(registerEmail, password, firstName, lastName, month, day, year, gender, primaryPhone, zipCode,  groupId, memberId, driver);
		if(genLibWeb.validateExpectedWithActualByXPath(expectedRegisterSuccessMsg, "toastMsg.xpath", null, driver) && 
				(!genLibWeb.validateExpectedWithActualByXPath(expectedRegisterGroupInfoErrorMsg, "toastMsg.xpath", null, driver))){
			log.info("Registration was Successful for user: "+ registerEmail);
		} 
		return patientRegistered;
	}
	
	/*
	 * This method is used to enter account information for a new patient's registration. 
	 */
	public void createAccountForNewPatient(String registerEmail, String password, String firstName, String lastName, String month, String day, String year,
			String gender, String primaryPhone, String zipCode, String groupId, String memberId, WebDriver driver) throws Exception {
		genLibWeb.clickOnElementByID("newPatSignUpBtn.id", driver);
		genLibWeb.enterTextValueByID("newPatFirstNameInp.id", firstName, driver);
		genLibWeb.enterTextValueByID("newPatLastNameInp.id", lastName, driver);
		genLibWeb.enterTextValueByID("newPatRegEmailInp.id", registerEmail, driver);
		genLibWeb.enterTextValueByID("newPatntPasswordInp.id", password, driver);
		genLibWeb.selectByValueFromSelectElementID("newPatDobMonthDrpBx.id", month, driver);
		genLibWeb.selectByValueFromSelectElementID("newPatDobDayDrpBx.id", day, driver);
		genLibWeb.selectByValueFromSelectElementID("newPatDobYearDrpBx.id", year, driver);
		if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("M")) {
			genLibWeb.clickOnElementByID("newPatGenderMaleRdLabel.id", driver);
		} else if(gender.equalsIgnoreCase("Female") || gender.equalsIgnoreCase("F")) {
			genLibWeb.clickOnElementByID("newPatGenderFemaleRdLabel.id", driver);
		} else {
			log.error("Please pass correct gender from the test data");
		}
		genLibWeb.enterTextValueByXPath("newPatPhoneInp.ngModel.xpath", null, primaryPhone, driver);
		genLibWeb.enterTextValueByXPath("newPatZipCodeInp.ngModel.xpath", null, zipCode, driver);
		
		if(StringUtils.isNotBlank(groupId)){
			genLibWeb.enterTextValueByID("newPatGroupIdInp.id", groupId, driver);
			if(StringUtils.isNotBlank(memberId)){
				genLibWeb.enterTextValueByID("newPatMemberIdInp.id", memberId, driver);
			}
		} else{
			if(StringUtils.isNotBlank(memberId)){
				log.error("Member Id NOT entered as Group Id is blank");
			}
		}		
		genLibWeb.clickOnElementByID("newPatCreateBtn.id", driver);
	}
}
