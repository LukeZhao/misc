package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class AdminPricingNRefundsCouponsPage {
	static Logger log = Logger.getLogger(AdminPricingNRefundsCouponsPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	AdminPricNRefCouponsNewPage adminPriNRefCoupNewCoupon = new AdminPricNRefCouponsNewPage();

	/**
	 * This method is used to verify if on Admin Pricing N Refunds: Coupons Page
	 */	
	public boolean verifyOnAdminPricingNRefundsCouponsPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("docAdminPricingNRefundCouponsTitleH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Admin Pricing N Refunds: Coupons Page
	 */
	public void verifyNValidateOnAdminPricingNRefundsCoupons(WebDriver driver)throws Exception {
		if(!verifyOnAdminPricingNRefundsCouponsPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Admin Pricing N Refunds: Coupons Page");
			Assert.fail("NOT on Admin Pricing N Refunds: Coupons Page");
		}		
		log.info("On Admin Pricing N Refunds: Coupons Page");
	}
	
	public void addNewCoupon(String sampleCoupon, String price, WebDriver driver) throws Exception {
		//Click add
		if(genLibWeb.explicitWaitUntilElementWithIDIsVisible("docAdminPricingNRefundCouponsAddNewLinkAnc.id", driver)){
			genLibWeb.clickOnElementByID("docAdminPricingNRefundCouponsAddNewLinkAnc.id", driver);
		}
		adminPriNRefCoupNewCoupon.verifyNValidateOnAdminNewCouponPage(driver);
		adminPriNRefCoupNewCoupon.submitNewCoupon(sampleCoupon, price, driver);	
	}
}
