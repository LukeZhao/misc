package pages;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import library.GenericLibWeb;
import tests.TestCaseInit;

public class CallRepNewPatientPage {
	static Logger log = Logger.getLogger(CallRepNewPatientPage.class.getName());	
	GenericLibWeb genLibWeb = new GenericLibWeb();
	CommonUtilsPage cmnUtilsPage = new CommonUtilsPage();
	
	/**
	 * This method is used to verify if on Call Rep New Patient Page
	 */	
	public boolean verifyOnCallRepNewPatPage(WebDriver driver) throws Exception{
		return genLibWeb.explicitWaitUntilElementWithXPathIsVisible("callRepNewPatPageH1.xpath", null, driver);
	}
	
	/**
	 * This method is used to validate if on Call Rep New Patient Page
	 */
	public void verifyNValidateOnCallRepNewPatPage(WebDriver driver)throws Exception {
		if(!verifyOnCallRepNewPatPage(driver)){ 
			TestCaseInit.testCaseStatus = false;
			log.error("NOT on Call Rep New Patient Page");
			Assert.fail("NOT on Call Rep New Patient Page");
		}		
		log.info("On Call Rep New Patient Page");
	}

	public void createNewPatNStartConsult(String newPatEmail, String patFirstName, String patLastName, String patMonth, String patDay, 
			String patYear, String patGender, String patPrimaryPhone, String patZipCode, String visitReason, String medicines, String allergies, WebDriver driver) throws Exception {
		enterNewPatInfo(newPatEmail, patFirstName, patLastName, patMonth, patDay,  patYear, patGender, patPrimaryPhone, patZipCode, driver);
		//select self - patient for consult
		genLibWeb.clickOnElementByXPath("callRepNewPatCnsltPatientRdBtnLabel.xpath", null, driver);
		fillConsultFormInfo(visitReason, medicines, allergies, driver);
	}

	private void enterNewPatInfo(String newPatEmail, String firstName, String lastName, String month, String day, String year, 
			String gender, String primaryPhone, String zipCode, WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByID("callRepNewPatEmailInp.id", newPatEmail, driver);		
		genLibWeb.enterTextValueByID("callRepNewPatFirstNameInp.id", firstName, driver);
		genLibWeb.enterTextValueByID("callRepNewPatLastNameInp.id", lastName, driver);
		genLibWeb.selectByValueFromSelectElementXPath("callRepNewPatDobMonthDrpBx.xpath", null, month, driver);
		genLibWeb.selectByValueFromSelectElementXPath("callRepNewPatDobDayDrpBx.xpath", null, day, driver);
		genLibWeb.selectByValueFromSelectElementXPath("callRepNewPatDobYearDrpBx.xpath", null, year, driver);
		if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("M")) {
			genLibWeb.clickOnElementByID("callRepNewPatGenderMaleRdLabel.id", driver);
		} else if(gender.equalsIgnoreCase("Female") || gender.equalsIgnoreCase("F")) {
			genLibWeb.clickOnElementByID("callRepNewPatGenderFemaleRdLabel.id", driver);
		} else {
			log.error("Please pass correct gender from the test data");
		}
		genLibWeb.enterTextValueByXPath("callRepNewPatPhoneInp.ngModel.xpath", null, primaryPhone, driver);
		//select State
		//select State if not selected
		if(StringUtils.isBlank(genLibWeb.getSelectOptionTextBySelectElementID("callRepNewPatStateDrpBx.id", driver))){
			genLibWeb.selectByVisibleTextFromSelectElementID("callRepNewPatStateDrpBx.id", "California", driver); //California
		}	
		genLibWeb.enterTextValueByXPath("callRepNewPatZipCodeInp.ngModel.xpath", null, zipCode, driver);
	}	

	private void fillConsultFormInfo(String visitReason, String medicines, String allergies, WebDriver driver) throws Exception {
		genLibWeb.enterTextValueByID("callRepNewPatCnsltChiefComplaintInp.id", visitReason, driver);		
		//medications
		//enter medications
		if (StringUtils.isNotBlank(medicines)){
			cmnUtilsPage.enterMedications(medicines, "callRepNewPatCnsltMedicationInp.ngModel.xpath", null, "callRepNewPatCnsltMedicationAddBtn.xpath", null, driver);
		}
		//allergies
		//enter allergies
		if (StringUtils.isNotBlank(allergies)){
			cmnUtilsPage.enterAllergies(allergies, "callRepNewPatCnsltAllergyInp.ngModel.xpath", null, "callRepNewPatCnsltAllergyAddBtn.xpath", null, driver);
		}
		genLibWeb.clickOnElementByID("callRepNewPatCnsltContinueBtn.id", driver);
	}
}
